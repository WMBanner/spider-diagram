#!/bin/sh
_=''':'
# Spider Diagram, all in one file. These first lines are a small shell script that runs this same
# file with Python 3; everything after them is the Python program, with the app packed inside.
for py in python3 python; do
  if command -v "$py" >/dev/null 2>&1 && "$py" -c 'import sys; sys.exit(sys.version_info < (3, 8))' >/dev/null 2>&1; then
    exec "$py" "$0" "$@"
  fi
done
echo
echo "Spider Diagram needs Python 3.8 or newer."
if [ "$(uname)" = Darwin ]; then
  echo "If your Mac offered to install the \"command line developer tools\", click Install, wait for it"
  echo "to finish, then open Spider Diagram again. Or get Python from https://www.python.org/downloads/"
else
  echo "Install it with your package manager (it's usually called python3), then try again."
fi
printf 'Press Return to close. '
read -r _
exit 1
'''
__doc__ = """Spider Diagram launcher.

Serves the app on localhost and opens it in your browser, giving it real file handling that
browsers like Firefox can't do on their own: Save overwrites the current file, and Save as /
Open / Export show a native file dialog (macOS: Finder dialogs; Linux: zenity or kdialog;
Windows and elsewhere: Tk, which shows the system's own dialogs). Works with Python 3.8 or newer.

    spider-diagram.py                  # start on the homepage listing all your diagrams
    spider-diagram.py notes.spider     # open a specific file
    spider-diagram.py --install        # Linux / Windows: add to the app menu (Start menu) and open
                                       #   .spider files with it when double-clicked
    spider-diagram.py --uninstall      # undo --install

Installing and updating also work from inside the app: the homepage offers to install, and when a
newer version has been published (see build.py), the app offers to update itself in one click.

build.py turns this file plus index.html into single-file versions (dist/spider-diagram-linux,
dist/spider-diagram-mac.command and dist/spider-diagram-windows.cmd) that carry the app inside them.

The homepage lists .spider files found in your library folders (~/Documents to begin with; add
more from the homepage) plus every diagram you've opened or saved here. That list is kept in
~/.config/spider-diagram/library.json.

The server stops by itself about two minutes after you close the tab.
"""
import base64, hashlib, html, json, os, platform, re, secrets, shutil, struct, subprocess, sys, tempfile, threading, time, webbrowser, zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, urlsplit
from urllib.request import Request, urlopen

HERE = Path(__file__).resolve().parent
# build.py fills these in for the single-file versions; when None, index.html and icon.svg next to this file are used.
EMBEDDED_HTML = (
    'eNrUvcmS60iSIHjPr0B5SHa4pztJbNzei+c99H3fSV+y8gASIAknCIAAuHl2ifSppEXmMtMzIvMHfZ3j3Gf+JL9kVNUMK8HF/UVU'
    'VcfiJAFb1MxU1VTVVNV++yfd6QRz1xD6wdDa/9Nv+CFYmt37sWXYW/jA0HT4GBqBJnT6mucbwY+tcdAt1LbCx7Y2NH5sTUxj6jpe'
    'sCV0HDswbCg2NfWg/0M3JmbHKNCPPcG0zcDUrILf0Szjh4SNBGZgGfuPrqkbnnBkaj1PG/5WYk//9Ns/FQrCk9YWTGj2G/0t+pPe'
    'nhD0DcGHngXNC6aONxA0n55prstKCYUCVLdMeyB4hvVjCx9uCThY+D7UekYJ2tmdDa0toe8Z3R9buhZo31Jv9v6sHMJXAb7a/o8/'
    'y3I/CNxvpdJ0Oi1OlaLj9UqyKIpYHF4KOAUHzgwLioIoVFT4D77/WTmGdnSj67NvAJKheaeeppswTYKpY4XAtAxsYyZRdfw6j7/O'
    '5PgpfZWidv3AcQWn28WFCcvgs0LHsRwPH/1ZVtROTe924Xspt5KUW0kuVxSjHVcqpQHnD+NxeUYnEGj0MgEafWN4AN8qBF3fMHv9'
    'IP7tUR0Jp0rompaFv8aetQ0g4KzsxBD0hMDTbL/reEOaM/xhaYGxLcmCJBfLOwKh1bZUrFQq1Z1kg7ZjG2yUnjMw+Ai7NCf8WSEC'
    'Uy5Kicc46o7m4gvPGdt65tW7Y9rJdwzSjul1LEPosKHRLHTm8XeaYiUe2NLiSrEclYdRLanBVp3VqG9QXqqyZjlI9Y06qXyhjroW'
    'LlcL+gJRwDUsYr1VLkrXklqsCZJYrFtKsVqQisq1pOATtahaMnyBH9fwWmZPCuGjOj6BWkK5WBbqyU5KPf6JhKocbzG24hPHKfQd'
    'PyBW4Xc80w32/yQIpZLQcF1rTgwF/gcu0zYA6wxAJ88PBFcz7eAbsJWhMWwbnqEDa3SAye0JhuUbjDXN/cAYCkBggWn3itBo4M2F'
    'vwvAb8dDoJ5i+OXYMthv4D5Qusi6+yFYDqDyY+B4wI+KPSM4h+a2f+Uw64xLfqPCv+5A64LwX/6LsD3Ugk7/2oDX279uu8DVDM9n'
    'NA0MF8t+E3TNG+z8ulOkooYv/GfhV3z0q/BN+NVCwvx157vwL9BiBwt8BmJeHWv/Vgon8zc/mCMfF4RvnuMEwt8J1kKh3fsm/NJV'
    'u4rR/Q4/Xc02LHxC/+AT4NvwW+oCH6rh7+E4MHR4UmlX5Zr4nTeDFAgPDcWQdA2LaZ2OgWvzC+Ne+KjvTAwP25a6otHBJ54zlfFB'
    'u6t1a2FTfgAzHT6tYjHdwYb0ul7pUDXHZmAbNYMDCU84BO16p8NqwTMOu64aetQ8LAosZmqI7NHCSANH84PFJ7wcr85b7TNE7LW1'
    'bblc3gv/L9Z3aM4Me1zw+5ruTL/BhiSJ7kxQ8A9VEPfw36JU3glbcwiQck1UdBrJgI+32q2wiYMnfLz1rl5vy6xiGsEIC/DFv4SL'
    '/lfElAKhCe6y3mDrb2k8kCQJ+H8SDyRN6shijAeGapSNehIP6nK9pikZPJANRVJqKTxgW18SD+SyXJONBB5IFakmtbN4IKlSWarF'
    'eCC3ofVyEg8kXdZUNY0HiloWq90UHgBmiPGKRXgAi1uROwt4EI80xIPMkxBf2Jzl4EFlT67tKTIggbw5FpQzWKBqulETk1ggwbRJ'
    'ehoL5G6lrZbzsACXOUSCvwAXaTuzgm9+AC/8Bt89ZGLwiHGav/ZNXTfsvyGzMX3X0ubfBNyvhX8yhyhSanbAChbNDpShffqbIFVc'
    'qM+EifBX1zJmrO532vnD72y//iZ0xp4HaHGIoH5P7fvfBPl7ZseH+cQ9/Xt2t4+eAzoFJnDpggY4D48ListH1B4HgWMnx2PaWL2A'
    'AH4XqHzBBI7uA0wAkAHQvI/9wOzOC1x8jl/0EJRypmmYiiJM9SQxH2pqPujXUPN6CLBIsOGHHLaDkv4eLIWOu1JULtGAKP6Z90hl'
    'aI3bWmfQo9F/Eyaat430CzhGSx8+AfSER0hrXQsxji0uw5GuY3PYSlJRFQogrFtGge2Ve8IBCuvXWueRfp9A2T1h69HoOYbQPN/a'
    'Ex6cthM48OzMsCYGTr1wY4wNeNPwQKfYA33A9gu+4Zmc2qLZZ9OOf2HrRDnVRGUCwB4P7RBLUdMBBeTvOYMkrgSDihAXlmAI44Ap'
    '9R3L1HkxXGG+eRaBtSSXPwHA1MP1xL9LEIHWG6ZIoCV0NV0nqgEMINpNdLAb9sMBAwl+KVSLo0Lux8HlY+9L0BauEZIqkItUTiNR'
    'jXCIUIhKTTmuVEVAnGkfxgFCldYxkOzYALHxX0BwQB1xKTkMTTskQjGDTMTtd76ngJLTQKkEVIU9nEXULNJU5QIFXMDHLgJjFkSL'
    'ilrN2OeEFk26HC5DciDL+FVmuEV7CCUWCIG6LcSPDcsyXd/0s/OQbktH2SnF3ziMBcvoBt84kIDzpb+Q/Dm2fW1i6AXQ2e0eiHlY'
    'H3a2uQ9aqm+2QULvO1MDgABB0+5RFeroL6VEt99oy4R+cwh8EZ+oMEco03bHQRF4LVt3Rvem3QfaDHJWM71ouWubWhJ6whZuEeHZ'
    '1r+Tv7LLiTuPiY0DttHFq1vEym5mKTJkvpyqlcRICh4jnko85PCRFA8v8WgpryGQvlkoG3T6pqXHDIFX5thUJDrwIuAl/hgEnuwa'
    'L6W7FN1XkO4JnSO9/Jswdl3D64Bm8F2wQPsBKLBbWrqiqBrD7GDl9M4GXNyw0JLw98SOEWHORoiYZtfL5o5taGkUqaYwDbGvjk9C'
    'huHC7k+LmctWknOFC833FTYsRkrfbCfY/gboogEF6ju5m02SjHjdsEI4N9ED5C84uQHgXlGNAdWNrja2gmQjRZJHFrsjYTYmltQE'
    'c7E2SxxMsk2BWHQ9E5Z1nttFRJC8lV9I/8nrMCq5iGaLfUXcKdljqHUly6PlD4WcmL0q4sJCV6OdFeXlInJVqMNxVBsHDqJzN0FM'
    'VMzWPLYDhxysEu3Qv9DIrqFU/Jq1k+jF9INE5QxYxBmIb8gZ4LDafixlLoiOJGgAu/eCmArENKmkNhHCfC5dpNC4WE6w51gkzAEj'
    'dzUWMTpRszhoR6In38XY/GzGiRbg6HsR42OjXS8UhTsNIkDU6C+oj6XXTa6lBK9i4DiWz3oneQ5Kuo5vMrHSMywtMCdGEg2OnGC1'
    '5pLdq3Cmw7HIGeBj/jZL6HX4Lw5zjdQXzifB5k+5FSghyfQ8E3Qb/FuAHcxF+2qBSco+js01tGC7sgeY7s52OHrWcAQLSMjxL7lx'
    'p7CRbUlTbmYKZ1pOzg37FbUg/mHzlICFM8qFOnJUJ2Z+YZWhZmIlmjQ2VzB86B6VyhTpZ8CXaKdPscUknkuM/PKZoaW1DQt1wM5g'
    'UdNYLoKUF2h88x0u7tYfapa1sdDAcA3tKnxXzyOWSCZJi8GL8nMIa8/TuNEmxvL0dkJd7iyUoTMe6BoWAZT3Hj/P2GZ1QFDeQfzY'
    'Y2cNroYGA3yw2A4bIuIoQ1S+4bORFmH5bcBanKQEwG14lJyQou45rsvKReIm6uq65veNBZGWFymws5tvQqESbzeaPdH8BJchbp1W'
    '5yMsaVtOZwCymzPu9KF1thZsSxj7KLIxOSOp1vD2i7ajG4lBRRgTsU7HW1hlrQ10CdjxHdabzRpreIlyxO0pHG8TgtoijS8T9tle'
    'lhbgl5gwGMxZISc2yi1wkAouuLrMjErY39WGpjVPCK4penI9o8AoKpwAbhXQ7PkUKsDMfEDPOhKEHKEV2vj8FVPLtlCJs1luoqBf'
    'oQ5RZfIFW7ECaH/QYLgUkeYIEPnQcihdmL4Af/EFtcIURGGtZYN4TSXB3VaziNQYi1DF0lwf0J+YaL6azaYjkoGyo2L8Nto6kKRq'
    'WdYnL4UvR4gxCc0SXXPYlhZdrX5kETat5CpJiXTQ1iMdGtg/7RrC2CwMHdshjNoToq+5KhIBTcZjaIcWumvOSJ1whKHh+xpaCPw+'
    'CLJ8qfvO0HCRXYOgE654jHJUGZkHLjEZHhjq0Wac0ATj89kCvNoTCjUSGSKNRUygeVlMmW86mtXZBp41mQoFQZGp3lLWsLAANNQs'
    'QUfG852s2KvmCGC1vG2SuqNR8ZngQxGKsr8Xjxx/LiEzjuewAk8LpLbHqZYTmtOlpZjCBMHCbANX5U/44R8UB16qs+NG0CsNf2cP'
    'GIgumICbKJlyWw508pwVUfkKhnwhh2VEC4NHHtyuRAJ+Ej32BJh0/iwAekMrbNzrQWB/RjBZtPKIX6FWxiEW1YBwYUPLGgOQaS17'
    '4c+/ajCEgjEDytYN/cdW4I0NPKxiuKcbHcfT2AzSwJGSOV5Gv6OtOToMCOeiOMGTW1IEMvyMI301KfpWl2kFiSaLpl+wjWlWDluj'
    'RWcq54HFxYMVqnyyob7mF8auDoSehcQZrIUiUflTkFDTmg2yHFsQqHs3xtN3qVjxBUPzDcDgAggAsAd30euI7xv/y8CYd4F8gONF'
    'Vf6OM5uypSDWJzgZcyspVnHgrJUhHrIL0Rm7Z+jjjqEDSw7FWvyNBp7V40wMgG9t0eRwDZS4bKg8MAoNmeOfhV2BsdTQrFETQzN4'
    'iEYgTG+X0SixF/PUPvBULLmTOqdhfRApJhRsBBVPBz5DyYlTiqj6fvrwTq6l1LzaAmmnEC1upp2DGwsHFukqfJteL4YUcypH4kWO'
    'mSKncsqiFE8DLudjoAVjP3O+oixlaZlqBFFEY5uda+WxVTr8leRV5nN+uruTvyXmEeLSQ8AVg2jnsopVFcKVYHgHCko3beeKFs5y'
    'ep+co4RpO7kwqRY1POu1Pjv7i+301fR5a465jbaRSHEjXpRqgr6AnvD57XUtEUgZIkh3Zwwj/EWvHuRZ3lCzMk3kmyzyLchr7dEh'
    '8qXPQkVhEUw3Pa+5Q83MrMpnFmSbrUdtYgj8tOw/bwk03rkzBtEWX2ih1MXFG3p6ZPXypCrTpv0/Kd2qte9ZAxt87xjZlUpOR1K5'
    'VMohcYQdrz6DLOoEGme2uAeoSnoPiOTqne+fQuhamp3gibBMPKUSysefOmH7nI4UMq5YGefLG3u47CQmoC8vJzUSr5Zq31ETmyBV'
    'stnorJhq53sBxPPINxXa4muLNfFgb5o9rfsFBO0FI0BanpfFpDzPfsWoKEbiglpZEBdSMgLXuzIiwic8K5LiQIwzlQhnav9hcCYl'
    'Q+Ry4XKou4WiX0JbreC5NQl7tDihJUZM2l5Sa8J+pSzDyVVQK5N+csbkSEtdxDXq8wmd5TOyBUMofsI7Dj4jxa1Fc2W5WTruKzbN'
    'LDsBWNTblspC1GxbwyOecJbyzk3kfBklPIFatDem2jZzpMu0AXWFRpS0C9DKCkW57MdEG65RyE5Iw82wJVmKREasAYplmgPBv9WF'
    'EmMrr0jaPUQWF6pZZizWhnipLJQqBqa7ifSsLtSMrVYprImxep0fR5qeGYiRe0+edrx67aOVtrVJjJsLykPaNFRJDusGhrXk6L0c'
    'H0vYDlqpAMmQI0edOt1uWsFMOTfm2YpSBbqmFRjsCGHOYxx2MvPdLo7NcEApqlw+JZ/jpOU8EWy51xfAdYTD+KKM+otU0RRVW8Zm'
    'ljoWJ/oNWwp9WVMY8FmwwjEdz4DQl2zqUUHqpWfR7h2dQSw5ukitc/Z8h/A8YSSAdk+xWZBdNzRyhDUiGwfvgU9O4pArMj7QEd/x'
    'upOcxAnFSqMv/N3Jenjl6MnLrLsJszcaxdM+ZAvHLCuOcJae+3zpfKlery8eMK0TM8JTjq5JZtPlc8t8FjYxrb9s8wmOlqPyPSn3'
    'l+WU3P9nEOvw6GpnZ53g9UdIWXlOwYkJOUenwewB5qIld437bbzBSCmxaYn/YXlBL17nVpbjFcgHcMXceZKiXFlEUS5rZcvU+WYM'
    'XdgVvmndgLtbcheKX28c2KrasN/4AgXs/Lp4hpux7agb6fmxXaL7KdNebXGLVHP9B/KVoq6+zg0thIk7vEaokPKYEZfZxpNOmVFL'
    '5Ia7sXfBUu/cpTsddUKK48YOEbltfcZTONY91MgnC8EIehmZZok1JiWF5R011BccUwhnQbgxO+QvtKB8JhhVRKG0IW7GtlCE+rQh'
    'IhdRQ+4Hc8QJafnRIvHCZUfiNKtsxBGvzjtk/pKX/+pwj0gzjhaqxg6w6f/cE0tOFb+HJh35ffKtcXPdmVswk7oxqR6c0YezmT4L'
    'SBE3+7XiLIA3sR8a9jllw78J50vmmrfCiIKHwUU68k5I5dJKSUYMJW7u7RW1mFl/5DDhaMSYbgx/hfNTSMxs9AkeJcdHOuEpIWDu'
    '981DW9bv8VxFXOolHQ/ggZx3UsSfdT8pEGqS/CLGjCC2OdWSuwVAWWAOQUlPgHidDf/TZ0+11ccdm8TusLFGJpVwlRcjXn6XzYMN'
    'kzmUfu5sQc06C6c3xjUjXRkPVISh/mwEUyX0uPmX0OUEQ6c9nBecJgGJTKPo6O+CbwAb1DF21A/8PTS9DeDDNTvBGPBjTwg0EoHI'
    '9g5NHcMMzxMOSlEuCESlPUELEk9Y7AG5upCbwtRBGHwy7wljF4RCPquwSlgAnxPZCG0jmBqGLVB4hQ9tBz6WxkIwQDTzB4ic6JWh'
    'DdCDD1TSYZEBmVpW7iCNvv/El/iDnSVew2nH+JSCtsKBOyYxJctDlBSDVWImuQmQm/p1L7ZVXDLmr8YgLOmG+Wz0Nd913LH7tzwp'
    '+tfv+b6IfEKSllklaZFSItJJr0IiuCYENh1ZmrZZ5RaJTUGViETMAB4bti9oCQee1JDD2Ji0Bl3ZYH3XOqvnx+aF3CAMe9q85hoe'
    'nW54N/7+7RvPtbDBCoZ7DpM6mENacjUryeiFfPEohVwcBPxi2Hr+sX9eyQTMeadxUGiYjidIuEig8JRxgt8gQEDNjgaEdEOsVLLR'
    'VbV8Cys/XBTYf+S8moGG2dY6P7Z6HjBBcoJKddeud0UN42zy6rQt7jeVqqIZeo00ibwqLvD8xSrdblvXO9zk960PY6L0AtuI2YWp'
    'tbPU9Sm3wtD0fSCanWV62nIvL+6OvaTdQOsth2SZc3pK42WUSvveZuG8Kb2AjmFzonfwwacliqT1QpH/nG+8SAFctK1CwMWlTT0M'
    'FqWpz8cR5gHy+7hELLQcnRckzFGpsJSFjfnTIRbMkyJpBkWukzfKnvNJj79s9WhPX+XWuFgR0CabbiBpcMmx4G44u0XdWBpMkjhw'
    'WDgBLWd2uri1VZHLCxVMbndcYSVUNrAS5sgISfLNFSFynb+jCOfFgPBFuEMP1pw3XaczTrCTFPhLtYAoGiIv+Dk1zVbbysRBp7TU'
    'P2+GjTDoeAFCXWsFxLGGdsByV0SVsnwq1gLV0NkgO6gFZMoe+pcXnETanqENClMAMAvLX7m4gjOI+sqPra5m+WwfXO7jF1UPjcCL'
    '0g9oSd427ZPkNNR3LN1YiFeJ6GWpKSsxa9lD5UgiS5SB94PNhYBlFddJAsvqrRcHEjXJ0Sd5jJ5KI0AOJ2LiFC9RUcmYS6upiiz9'
    'gJpTcWztJX86Vt6EZo7g89oxh70cn4MEHaWjuEJXEdZRjfnI5/GSMMiA9OZwl/dRVzVGY83iDgpBX2NZIQSkP80nhzdKB7lNKjpi'
    'PDKTMMxguLMHNaEikokvdCxD85iubNjOuAcNOqChGILW01A7JlWZbE1cK04MnCgkxZso4odApW+ZqGMqX4BJAgqOTM7RQom0UFLe'
    'DGPSyeRPPbGJx8yZJS8amrNt0PB9kI73EmwexaC9lOlsJ2N4oeXOpgMC8e0T3AMAzWD7apjqiyAtyg5LXO9T07EvJFJH7GUgSr1c'
    '9BeJDtXbVsE104Gom8QR1/aIL+/kpMeIJjYR/B51E4ljIY6k3MnZr/TmuSKGWMlXkVZPv1xenP/lhtY86Ium/bPGEGwxtMgmhQei'
    'hwVpifuob7AVMT40GjtB0mGJs5v02X3Stsr4nLLsBH2Tjl1vVY+1rI0zxfOWWjSXxF7yZFQKJaMqLw+oy4CordQ5k5vL1/MRsJ0n'
    'JS51KXtixt4rfyKicX3vLLbRGRobejUr4sbq5ZLEYTQ+7JG79n3d2pyx+8vcx/T775PNKwJxIUNWNZ2wiO9Ey9Jhfe4YY6Hr9LFZ'
    'TqaE1cdm4XFKGIuznCCx00fY3MkolXd0LsviJn4VacqVl50zr/M12TzrXI5rRjyWlQpRwtEnm/kBOdrS3SD04qINIaHjpVCnSyK7'
    'n6TflSjKGddmGLpRKPby4/J8t5AU2EX25XP5DHOij7itOuH19TkvI+50tWafzQV90RlZTHufftIdOd2J7QTLjV+4Hm3NN/1UBp2I'
    'rjfKIhMXz6VNPPxeODqWEsfhVH3JIeO6QL70aSp57ouLzbLvfhTlFjKNpOAV14nK5Te+mf9S8qBdynBMlDs3Nw5Qv0xBy8qvNA+V'
    'mHoy6W1I/Vkt5GKHBcxGuocQg263LZfJKU/qejshPnU0T193vLJ6i12eKCWyOC4oCH+AD2Byvdcmb1sIqI+ZLx5KpIPqpdCbniYr'
    'snvRD+LshTC14d/X+qzkuXm8bhd4wEuO5Qt7KfITvM/vIHG+ofSmTKteDPrjIcZDar4Li1ogWywinVACqvi+LrvN75HZZjGrDbOZ'
    'qZ/znEiNBy9OWDRtrEhOk2iBp6Vd9OPgSPbpEMwcSyqHNRk5kzqPWBBmfhd3D9Yr3ZuxqbPg79ivb5uuawSxIh8fmS7aMz6lYy1A'
    'vRhqmQ4cg8luD8yAZYEOfzDPdEsb4rp9T5YpOJ5JbDe0siwN5uEYpOm9ZZ5Kcbwd01hrC9b3vPFz4WO1c2U1P+AiPwNiAlzPmBia'
    'tQreSiKYbEmumIUNMplpJTdtSR5LDYFJs1Y0+4HkGwOadJqLOSTLRvE5h8fkNs7jA/jU8yjj8Ox1LbksyZaWic2IAE2pU0oqfTb7'
    'lU4QLpGnRiRhkLk+m/RNAp5dSEo9qhiJ+Z86H0Nj+KL1m53wRxEy/IKAvBi4hJgrpZ0i10mavoF8Oz4PDh8WKCwknrCquHF2p7jh'
    'RTE88l+hMlbCqKekvSCYreOzSd2Ly9O6hx0WsVHcAqjtvNZS+iRL24anV+RXlv69NE1ax3N8kAlML7EUq9KkRe6jRPzJjB8s72Jk'
    'hJESjl/lrK9oytdZqkRJ7H4mfFdeH7T7SblR3CB2JHQgxodrYt9ZPaPzSXfKWppMsIHdVGObe2XwMhlv5M1EDSVdyU7bYMVPZ0fN'
    '9+Nco7Ev2BDSzYWc4HNJJ78CeI739m8lfqXMbyV+ORlKi3jTDAic7A6nLXErvGUKv1L5H1sRnYVktiUw10HCJp7sCW+q+c2fD9uO'
    'hTdzbZmYW8LZiu722qJUoCr8t7X/W3zX0ZYkb+FFR/Tp/dhStkq5r5Vimd7DXpIpIYusRH3Je7yziXdRX9pIZYMyak4//Bamrd/9'
    'DiZsvMSmc3FmcRtdMrMxQGVBliaFmoY2DlKmClJB6hfU5ANBmtRSw1AACE0WZKZ8CTSCslUtVBIP5WJFEK2qUGkknkFT4qQelyrA'
    't7Ny8ndB/lg5KGCHzrpB1WHWBFWoW+VCOQU3POvD9JU1nD78n4GFKf/OJGllv56xtt8hTCZ0DJ0Wsh3LolA/q2c6FnnHysqO8RYS'
    'D6/WW913RagLFfy3sBopXGvsr5s/GIbcl1TE1vJEUle2N1uLYTWCS6pdw4dFN8mtbNAf259mB2qWyOQJ3Xcmi/CpFuuKgH8sUJMk'
    '1JWA/KrFCsCEfxNPEba+jItFn5WiovIyhUTVelGssvbipytHNHTWLh8Cq2g4Twwt6vxfxE6pUC/U31b2QIcPm5D6WUyhItLeREo8'
    'gE9Ydjn5oCC3qm/pyYVmJ2qmEqAKzKZyVqPPKn4iwtdWAk3GlCVA87sOgc8Lc/rLNx6pFu88+N1Dzp5hwPUkA5aTwA+R/5QLSlHC'
    '/5MzAexVvKoAf1rNAzTTbjvTdRMtAx5VNQlPq8L24Q8SAjyO1rgASy7idMLDGBJVEFeCwEziayGAZ2JmHWvJ8RbkfqFaTDJi2Knq'
    'hWL9CjYV2GnqjbhyFelHOVOzmKOkkeBtA7gL6H6/npPhpBTLsCr1xN4BWx88Fs/k5M4jFetQHfYe3IBUoZIaUL2MzSQAp+2lVU5u'
    'UjARSnIeUAutw65crOHXJC3AC5iJM6mWrI6MZuW4B8a87YBCvAbPZcJzNcJzOSFhSZUEnkdLXBFq/aIoIaHxL2r4pca/1JCN0RM5'
    '+lYJv1VBX4G9cCXwqHSt5SqYOECDTS3ClrIK/1lKIfEUcE2s0h9cqCqAU6xKWbYiSakKZbWA7RQA91LNA/OlhrCJQtjOCnFhg0EM'
    'pVqxpqIHh4woU5Wp3TXgX4MYV0V/6yphX1US0pXyQIUlkScK7DO1vkJrUYdfUh2XQlmzEn6wbiUUoUIrq4RLDF9CRIClVhg+sM9a'
    'X1rfYYEUMkPfAAWgfUJF7IB9qeEXFV9M1GskXNxQ4fGZ2kGJUkYeUlB8lDaR1Aurl1E3J+YGfI+GDpIGUIClFlAGZDsTbODwtQD/'
    'rha10OGuwALn1nWlCtWW2pcqsICwr4r9Cgjw0B8ssIg7rVS2ABNIlAD0gK+rJfUw3mEdogKqSNjaROkrKN2iHkECpYVDxbcW6CgF'
    '+F9DnxspEnGBY1kw45mn0MMVgC2VYeZkqV9dCSS5CK6fljJOiqSeqR9s2aUKfuJTxIu18iR8W4twxMTqGq5vOI7aWTXSWCREKmDz'
    '0W980q+my68WTQLQtTtr8b4uqP1CnUQi8ayMyw4KBnxfp8CwEID1o1QnlYRMiPJCC2lJxkldpzN0BhsICag0SMDUuLqynPycwF8v'
    'lJdTMjnotEuU9OUF6nkFllONYbmfVhXYlherikUR5GwNNhmOGuViDQiigzITPMT/afusIiNdTR6e5vc34dHAnwBzkEYyenA1I6hU'
    'kHG31Iy4omblD2K30qTC9tBJZd2WvgENS/WOCkwaGIlQK1R9YHD4mW/okEJLR3mJxaWcfL9c7Qs8c7DeXAFEcRYvF0nuCjJ53L0z'
    'DIH4jpwlld/wkmr4YFcyEhywuQgdS/P9H1seSPf7ZH1NPqVQRP4c3oSB0QBQ+4xsLLwcXoS1JZAd8sfWoeXQXdWmH+U2xezxPQe9'
    'uPF2l7kz9sJXPgwS7WtRQ7m2s9/G0GLfM7o/tn7h5h0aGgzotxKDKgKSsjcgiPyuwRgufsjeNS1ssoQF+ZBLMOYloxeis438eTiB'
    '1jCjdgg3DxfmkAuZvO8scCOE6MaY7lFgLk0Q3qu4tY/tCekpEdASssG8hAaTpVODY0OguxHMvA86NKDbrvDgcoufe4b1MiMGqKMR'
    'PKKviqAJeOrFV3Rr/yb+kQUh09QtaUW8rVuaCLxMECUeWia6nUD3tJ6AidccO3ASVxfsbO1jlX/81//B1pyPZdDe2j8MPGv3li/x'
    'GhgwP288HszJm0TdrX18lN/B4+YdNPxMFw6fNIaM9Ezzlw7lsW92g6X9JdH3JzD5mN9O9hVMPnTc+Z7gan5gEC7rYxfkCJZem7JM'
    'be1j8380YhvREL6C2DiIA0+zO/3UuFjOB4qPN3Q+Hhok3nI6x9PrHr+uwgxgvaBG/iIeboYuh+Ngs+4xbUSbwGXXc3jG0AE0IiDG'
    'QT4ML5vBcIcLGUFBv4QpxvRgHE/HcU2ARMNsAqz/8AKRDJRb+1QzH5LWJyC5NHU/A41jW2xmwixmtuFjz/G9IRxMYBx7SG49M6Rs'
    'ZCVxGo9x22endj4HN2yJN7yKIDccw1FIDNEYGgjdfMm0LSyujSFTMARc2aitfLiO/lgW0dD1r3IIqBqt1TaOemDMAYM8QxiNzc4A'
    'T3WftDaN/RgP+IC7n9u+4f3hPEMLx/QlloHhS6kxRjTB96oFmvi0uEMHF+EwBMagFlYf5m7D3chsgyjcy8LMMC/EtBTgQC8/DTXv'
    'dQFsWurNAL/WzFhWaNgOwOgJlDELxAWNxw8i2ThTm6+B4f804NdhB2ugO/GMJHnz+cS3DKKfBgQ74M0uzOKRM8Ygxg5whsEfywCO'
    'mFT0VSbwaFBeJh9zNDFJru9YRixr8eb/aJLXk6NIkX0+xSdmKXTb2Ipf5xSg4W7tX1FUaWK+eXHm5sArcJMFn6EHo6B5Hl4WkbyS'
    'i3zLMVVvB/SnucASEeFeDMxrT0CpBwPLJrDThVGuAgrOQMEoj8Wsh8XDYyAu77ftzLZoSvwG9LC1L+AHgK/PfysRlCm43dQg8ext'
    'a//SMFw/4uwYHA4AkqMoQNZB39ypCeDw/FZkWCXIhxoP/RW2kbz8KP53gKmFPRvZUBdaYXIHFJzTS3i8U/yt5K6c/liZXSLnsTlC'
    '2o7lihPH4iJdzFUEHZkJbb2cr/CZpMJRMX+ROSzttGFZeV2Gez1ew4ECJTo1cjYcSidUOmRsG/R4TESY7K9pd7M9AgumYqiY57WZ'
    'Qd7sz69SxiN6znyKMA44hlFoeR/1pXAqSIhA6ynIeRiPoJMQwX3tYZUw6UEfp9WaryaB46EL8yGchTbpaO7zaGEFqMcabP8Mul99'
    '8k4agzoL+O4zvc93ugHTlSx4MNU83ScEM2zdXw3hCTQCEOIHbxdGbzmALzFefArUK6I3Ir1IJGbF/T5Oq8a7CdPczX+Fh4DwcxwJ'
    'xRxjjvDA6Rm4HReFW/wggjdwEohi0dMOht71nCHJ3oyG4pnh8gZt6L+umQCE9wrhg3LCIavPE+nMGeB5E7ABf2CVQiT7jadDoz7x'
    'ksNows6cKR5VxnoHjFzgmTUSqQ3IVME0fDI87v/muIhKwkSzxtAMu959a/+GPn8rsbfZUnghyBi2xWv6XFYKwdnaf4a/y0o43S50'
    '5RBseCVwXK7EBrqfM2vRpFxRTobUlNCjhJZq2/AKdhxyiFsYbGfsTQwdtVL8XAakH3ganQQBc2DfNgJzkYl8cjd4CH0b+GhOmaJo'
    'MPYeMRnuAhGS3R7uaLSbfUGyC90pIuHuId34Box4yW78YIRsIWcEwAz/8a//XcAMKBH0yT2aKJRyWTpuUWjauoPpO1hTuG+ETaN/'
    'bnoPTgG3XtQk8QAnboUkmi9/NskJLs/qTOBukxL8tvOFNSH3uqWSYwphjGUw4BsOAzMQfAkScrjLh+SnzHszvAwiJfO6njnUvPlX'
    'JHnWGhmBoH10aEKJU2M8kO+9JFs4f7wGbyyObEg/fjdB/pwGuH13c7rzJX7DuNYjZtRI8VG8cCU7pZ5BTsTA9xYYqbS1L/1//9cy'
    'BipvRTr7vry8mLK1ryx/q27tq8m3m2wQh5wvJIfm2r0nvD5lYQywA8GGRmkp4esyMJhPAGw9qW0gXYbuZdk/gr9f3Chy5KJVwgcO'
    'KY5vBPkj8SsRs7CxAJJS43vsEVfes1bptEEY0BCFJlD3XeZixYzOIXnkUP0ixYftIa865gcQ0C6eQETt/DGi/y1jDsK27nTGQ4xe'
    '22xrY7mZSSvTMHeUThnRQA6zQMtloci+8I//+n9GUjuIZR3MOYIHnmh0KArndscaoywa3wMf7o5f0SkT6M453skwnmpa0XCen2Gz'
    'FcIB++zMD7ZgfLwnnDpOzzKEI6fjk+pyZbY947bbNTtGpkvoNEMDTmcGsh+2Xkq1s13EVztLJUsdidAbkH67XRzqS0sGM0D1Owsl'
    'CeLt20V4srS00/ZN3dSAdd3yb/BmbGG1D9ONq6UnMqTanxXrlhLUKrXcnXOMTBMZX9FPElrU1Cp6Y7JBSHW8oyTlfZZrhcfdszuz'
    '80DDXs7FeLEtgR7DVhFSBWzePC965j74DS1BUes3RK40iaTk+mFGdiC3kBYJzxnpIi3DJCeRFyQJROkFmlzWK6EYdRtu+Q2Bp+eA'
    'oZCP+B6pni4l7EDFjduLYxsCwMMUSWAuf/0rff3b3zBvKeAt5s8mmwKSLc4MbxxoIkTzvejUBqbM7ZM3h4DXQPgpdwfgQWEqbtwx'
    'ME883e8SOA6HKE03gBVoRMY+0evBxYjAn5G8Vzl0kFNRnlj7NAbdztQszO2gebaAl1vAiqGw9sjO6rnddg8UQMNFVRw/v+LZgTBs'
    'JIQz4SIX3EeYRzTA8Cz7zJRDh9IY+jp09K8cZ1AowxqhPP6SdqwRKJHJ59xrnkw95hr4QwhTFIbm4Yyp8lc/Rmbb0AJrzlDSRTSL'
    'lEFmag3tNVv7T2TpXTHPJ2Z8Gg3fI4M0JmTsYO5Oru+IO+i6EmyuruQP+4bFc4T+MQ7nHuzgllEuYKED4/doO1q8y2Evpl4a/y+B'
    'BuyGARkeLH569VmYSaSuE1w/OdTuAfl75iEwvuEQH3wFWvIk3YSKuufc3TMPCvaOw3H+FTi4M+lGkDwONdgMvCUUzV5yAYQAKgBA'
    'jX/8t/++stEDs9db1iZ7l2zyBza5m6tlJredlIadPVxF+9eXD8f6mssO/ylufJlPBfXxB6nUCaXaj4eSPSETuPVyQb/eQCtYqgyl'
    'xBomvLEJSYrZXXqUORNAA7O7qGjCYoaHZsukVRfmGYRbE48+8kug2LR/4MyWvWcZUlA7YV+WStEGitF0nSp6rixXWBfkvc9M2Ani'
    'TWq+8El2uro06s/PFoWlw6rgx9JxmvY6tZ1SyYDOgh+/xzxspEV3HwzfSPhVoSCT3FR+9RPXBgnb7DSJXfpD2LVHs7aDBlZoJ1F2'
    'mba8+uQs/eMzHIbSR3zdS48OTBY4C3fiYkcp4ZRidxRZf+QE0Zz+8XynEw/ws3yH2BZd/pE6nFgx5q39P2aVQMH6sp9UpIXxI/Of'
    'dyBi8aaR9PKHL6Ebjv7fZONIzLvZ0PV8+wt6OQF+ewYlus9Qfjjh2+TdCKgPC+JwZ1byP3Zc1B53fn7q71hPK6xsn9whsxZlE5/E'
    'rpJ8YMjIFjj+I1Qfasu3vut1545X6ODi9ZbueS9Q4KWQKbLSnpymIvOBHFoTpyvk38pXC1kx/v5pBvwzZypXFGKZOEvP9efEo2B7'
    'zg64w2eRYzu/Gm4g9IEdxC5jHcezv6arEA+PMA6BWqng4VHulyVWlBH3BCJqZkIBwuoMbMP3FxguPwb/wmiM1Gj+8OAIK5qQP+Qs'
    'KerjCQmDhCXb2MjaCXPZ2xLYdR3AkriInpGAonxakY/NcgMoNTUJBbtoUZmYl5xlKxu6rmAgYv6kJyO+zhRlxX6RBwrLyBbBcsR+'
    '/m7AhBm7sBu0o8x/bFUE9bMwOmjKjGFkP/9IGMWiKAlqGEeWBPRriMOdT5YhToPoeRPMweRYCWsN5wT/Xshj2AlXbISEnQqhRK9N'
    'tXns34AppHC/79KRNTLMb5EjFve5c+yQfe/8TsOR40xCvClSxNh7VahYhWpBndQ+Pjloyha8bNhoY/4dwK9Fq5EPvgzQfwn4NuyJ'
    'adh9vGQVH4fecL8H7J+Z+s+P8Gs0SPkultPgU7iRbkKGGIMUG4vxx+/JjSjHWSr7ofTJZWZ30CUYBf38d+ISJKIkZ+t3IZFV0/V1'
    'zr3Cbw1FiEywGnmusWMBOrokBdL0o4CUyMHTcWDIDde1yI2T+eCzQuvdirHltDHlgE4YmBMnW2nqQdhmrJVpUz3H4Ede3Jt67ON1'
    'UcylLLSrbNY7+X/GJ+ueST7ufh+dZ5iO5PCBY/d7glHsFYX/hJfOfJ863gBkUeD77DcTwxPRE5E4voPKDbS15Fh2EaojcraPpQLm'
    'ex+BIWyzJ1+R6FmAfSQE86atHMl+Y0fBCGx2WPsHHSmGc5Jnf48maF38G53degvKxO84oyv1o9BvP+20n6QrOr6OHZsJ2jHztDfD'
    's4XSDp6Is5bWnh4mD+8pPjgK2oahdTqGG/zY4lHSe8V337H3NJdFBYKKXcIHSXVlSXN0vHxkelsCy4XNspc6eKQIL0wX1iFsY3kj'
    '5rCXBovsHaW/xP2zXJqYb+C3fyoU8OTM7IRe/Hg8DtzHwNTPPJzFg+kLD7phYskxQf/GPamhlA8j3OOaJvopdA3yH8dL4TTLKgqF'
    'AnQUanKBo/lBZOKLHtsMhq3opJbshoYHzR9o8WkRK7YleA6uumYZXhwaFFtIWb0nMu/n2J3Z65QL15EztS1H0zMZEvxM6HsYFE6R'
    'oou7RgT42IWNzcgDfAFWVnQprOz1qbPgvLLfpDeY9z3X94VVvIL/PeSaFNG3FF5c3XO2XMsgZnTxaUsBplMNSfpP6VQQiU5Tw/9T'
    'ltwTBQ8Ce3Em+LsMCec3wCcEUD41c6uq3CxxLD5y7F/R2XbAbkD8Aseb5XK7kDQyFIJBSMaR1UuxkQTL1/EVowu8D8LpcQCGjq5Z'
    'KcsR7ceWobfnvNUn5gTIJqEvx93xF8AvZP7W3T/vElfQafSYHmOPOdN0+ugB4Qs+cAi2heBdglSCgoEsxw9iN5mFNCeprZuGavod'
    'cu86inqKMXij8yVq5hC2A5Td2WcuqVA5lnEii1qPWp4xc8kKAVNhYSm5JxLJHpGrISZ/3rrXCtkto29m4MNovF/RwyRrP4B+MFtS'
    'PDsR8cEbJrLt58SmJke0xuqWXEfsDTeWWO74eXbBeoDl2k97NQG46dGcjK3kYJLSUnriD5l3Hh8E/SJvFj6hqz1IeBuPdKHR0liJ'
    'pGftc7Q2S9q6QkpNzCBS7lJUw+0aW2SRXHzv5aSnY1KCqeFjMh3PDyjVv6H5RtGdY0gqBQWgjWUe79V0CKS10YLP3OIw9pNv2H7H'
    'M112gMHaJ5bChI0F0Wb/T3/9EyW43+IwbX0TtmRRrhQlif4TJWVrD9/74yGRFrxn99WiRkSuPMiQBVQGQJIcGEnfw28ELNmxWIaC'
    'noNOeuQ+hr6y/A6mPUpWgOcPfuRo1nZmKKvSgFl3yIuGY5g9mBuTSSq+YRQZdMynCGGDDpNdcHM6y5dEKS6cGZ85wB0gJABtm4c4'
    'hmZ2dustC5TF8B0qSffq7OxFeRWY3yn+grbJGIYtQyfwweDGd/zYkTgq9UzrCex+WhRQ1aPgHSrNRXjbCT2yhobXM9g8FPkVwSxU'
    'k/ILGh673nePtDUQCiN3UGycAcAuEQ5vFV56jTC0DiBSDwyx+iQ/0ZWlLmWToNbwLM9kSSSYaSk9iVSEd0XHk3hCiK4Lxa0/Cf+y'
    'twLLxKKkKpUFLGP+atGq2yDU0KJPSUfFNPtRvkO64kEDVqszxHCstubtEU7ihJA228HgKwQSY5P2uGfQjHvEhbF8e4LvwhbL3HnJ'
    '1ElOfz72kMW0OLKV3J5gpbu0nfL4jcg+isJ2XBYnmDunJtyXz0jPac9xPbDbHz+wzR8/vsdj9IGCDBdbNONOuNc7n3yWooV5QPts'
    'VflcCCAcB1OHfBlp9b4xoBNuGqjmA6pvR+GrruZpzP2WzDCh5yytKdABJvXw95ibb+w4mCRYwosiG+bBHvs8559NKpiYgRcOC5NJ'
    'GF9BRQRvwkSy9MjDjMywCD8sc7SqbDFjwnkfD11mmaZbPVApsuM7sylBijUvMr9DRlFsUpFdIHLw/D9xBByH+XWnKLDwzbgvuik6'
    'pPIhbE0WOXzj1dF+iEyUrw22PkBs7icOK4fU5OHgfIy8sCM1zhtjWx7d0x2vzl4SEZmOzKbIY/64lMLAJ1ddLMBSeiXhjA/h/SiF'
    'wTrCFOFvWVYXCDO9oRP3p2H5ye2Ym876mtWFDoemPaasR5iGzMR9Fd22KQ46oYv6TIkF9h2Gr9JRQ5bwmryHMYacIMM1Qvd7lsiI'
    '1ps2Htdl9//xKHYGUgV0Ygr1xklDNJiiZYGPALDDCKANVlQR+emFj1eXCP+8dcj5wj/+6//45y22lwfmEE9tWQNsDbuaafl8sIB3'
    'v1IQQJesiLpj+CgVdxy8htAMPd2ZaM6MZqTpcPsfanLEs3126DK2A9NiCjyUicQI0Hl8JPzNVlRcWFEWuB6xWsZHv7E8EbS5RNsy'
    'oxQerv1rHL/bNZlkAi8RTordCovxMTJn6ZXJKLIrzeBCBGNQbBj1LmxTNzAz/7yVG9YOa8dJNkRi2vcwOoW3h6k0wtIhHwLyRw9v'
    'JDDSPID6HICn64TNa9EcUD30ogY4mMnSCGeAX9GVzGyUPxlo8k06pCcz8ST3Aoo83mGTzGUoHk3PRRpmOYYWkJYENqfkmBMEGqUb'
    '6xb4GR5PS8B1RIvEIrYtUDMcYkTkyE9haBhBGisEH8QORHmO3GwuGIZoTHgBxoh6PHMbTPJNPnsAYjF07+EsmjDK0Lkrh89U97X4'
    'rhalilxfwPfmw+nxzRNnVd8El8Tt0O7FTEk2ClEwHxlmN6AELT2WeSfidYSXaGRFZkZXc8O0nZrB2bidJ5/qwF0sYICIqqwUmvxg'
    'gAGJXm0kNM/AdJs6a/pAs2HQb4Y3UCuIGc/X7Anu8QBrrE4scGEuxCJcIHp66Euy3QMMBMCAa5TChkrMVlbgBjTA9FuKyYkZc2CG'
    'YlEUwc4b3ENOB2gxxRI+IguXu2j+EN0pqwUCyqAiXjclFMN8D90xuVVxiJnYoodmPUZYnFgfjhtH18fsQDY6I0mMDIQdkKqNPudF'
    'gg9ojezHHbdBWqGdUQuVK+IqngFyBQoa3XAdcP4Dj84wNkAusV6uLmGmCYbJzomi1HrRntzHzBcxfdFuQhyM03IcYkLsJuY2MZX4'
    'WfR6pr0PJD02ce+OuQjCHusKJyDQBoYf5eOh87eE0IWcFoCMUzJGPJZLsFOiDc3rUC6WTt9xwsQH0R6MuwGsfAeYBZBvzEFJIGHU'
    'xHSgmI1SXTOgYBs/L9KGEMvie0M0mzwTKApQbYYDSR8xf+1yKqCGlBfVkBBgnK6uBqRAkxdtQAwyxHCNbXqYPQrACzPyxrsqpc7B'
    'fV/rBGGEHIUXob0eoWZznAE6vbzHOX37LsmRCALtK11k7QwWkkb4OVBqXZGZmz2Bp1mOShvJFHBsjrkK1tW4wM2VQSzLrlZkq9cz'
    'AiaQFXlOPajHEmjaqGp2KIux5rPtpYtzREl6DVQyglQ4FYVYsfLhenNRiiaeoUwCYzv9UCpvG2RSM9E5zWByCCtNuznbeHD0yQlm'
    'cGg2zzzK2JyZQl17rPcoQyfAR7OisQPhaOF8vnJR4j+M7OJyHhJgMdw9fMYj6TwXGwkCSteG5y4Y9U6xkGgBIpkyShBE0pi+h5cy'
    'JpOkMqkwSd5x7hESCTZBeElZ3ByfeHhkeAskyfe4HungSxBPfFKR0Q6DtEeg78Q2KpS+WXCmY6ezVMN8WcSv8bTqV/yJDei0b+Tt'
    'l/EZVrzyPF4ugdV4uIMrQn+IU2GAaRQqeuogsDQwPppEVG4khptsCw4hCm3jXIqHESOYfYaV4cAJvWj0ReE51DWj6FaYhj1slhQR'
    'Pxt/upeYi2hmsX5f4xGyOeBQuhy26XZIcAmjYJmJxxFC1+sOCGlz6HItKsigF0iLW1kjEi1IPubIxkQwbniMTdj4OmXdJPERkTvc'
    '+P0YOWKTDCUHNf2Qu+Stf9ggR0jfDCLEZ2a5AlODOWDbmTnmpnZiIbqJgttOInJYY2OLzB7RueiChZnzCiGyqtKuTYpiaLEVGl3G'
    'IUNRh3TdyIaDSgAMwxobXJOLMCXkiLT3Jaqj0G4ypT/g2kSPEJ/lOAcOwI8TcQ+YM+FpHB4wkvZI2hMWDBWMpMZNfIrVekyvCFvd'
    'KHEeWm83wSK1rCwRiChvFbMQ08LFuoTPpQmuURASMxkvMgOYPFm5mWHcIZ/hFA2IYVjd2ODDthFEl0Br5yuXuLnpnja180H7FrPX'
    'xwIbwjal5mKA7SWyvYWwsk3TZyrCTnJsaKDdcHwc11CyYsmZHZKV+U6dlhFo+XAWaKlBmkSk7mLEPLNdJDJcpidEOO8yzoRVGIFo'
    '+ALRjtlnuDWcIZDPzab4ihg/75ZUMbIU88FhjTAgPyl28HoaSze7CTop6iI6HaKd08eN12aSKRfvSTnUcbHmoPcfMR0LM4TQof8/'
    'b+3FVlKQMgwHnTLaY5P8T4whIM4kksY4BYU7CRo1cramTBdmiC1kdiLyyQMjYaMi5rBsHClwQUBhZg8A10/Cu+2COODYCntVdOc7'
    'qSFEmQZxOwBxBEfE7Od0XoPL5jk9VJ6KwgNXjHgnHabGWtzTNz6T2mTdpPx1m0dmzIQywtxRKKE9M47j0cPQxRBlbo3hj5HemYWf'
    'Gbgzy5Fu/xuz2R5GMxgKZ0SOOcnmhW2e2iJlyg71T+Y7s8Mtwa3QlArVuOxnJ2lyL2vdjioQQ2WWgmRedCZXptpgInVeanVuUn8R'
    'mPGbpSqPLwkI7W1hTh8y1PNJZ9J4knH47JBfY2JvZi0Ya0msAj8aopyNlMw5PKJNWOqZ4dKIFoy0p0EqsS1IBWke9mu4pKtQSyzK'
    'EsgpOTtMI3P0Q13HIhYtOV4FsifwLOh04JYw/S0g09Py9r6taQoEY7peOraHES8w6QRn7gMO8UgfPq+Esjy2DKPjCmj8CPe3qRPB'
    'QJtjaqJBEGArFEk6WA6X6Da8BuUf/+v/zaDaW5BwGI7mCzmEdugCylIMk8TFzvtSgnxRuAbWofWM0EgLfyLxOwIKzTKbLKwiLyzs'
    'iTkzGDRpoSaEMTTZMd81bqtoxxagKM1LZnmh3W8rms26wsWjyzrYUfZ94K7OGNMJh15+eSDssKVKQ4zCnc9lQdpreXIY3IG7pk27'
    'AVsRRnjc/UlgAYAbzWqO+ZPNaianFLBch6MzSwGYO2frKrF9hUkEdDHBYgYexjL2CNddZpNjjWFSKzZYnrwP82um68MkIvEx+zVO'
    'BJmR2oxwXDoA4nbBeOXXz5Gac8gV9ltgh580C9/ibCh7LBXKHjtO5MZt+D9KAxYpONlpXNNw7FXBE66xHYirNLHuzbGLFXU127A4'
    'o6e10CkDcui8Ptjh4BIO08FIdHkEO3NyWG6uSFFJbpBQsUdbX4nOKthI59FOtzhiLkqinMEMZxFbyWAPRxnarYYM5dYvlixWck0W'
    'zHISWncj+/u3rAU/xJyQEMklIFTWUH1YxPslDWeM1MhE2ZT7c2DSQ3Y2Hh5/MC0gzAoRH5xhmYI2RVaClsaMWrMeVpiwP/0NryMj'
    'r5+EUxu7tj3f5RDfFWCviFwHpf2fc/nKTLL/WwmaZG0zX+cQokcDdJp+6I7k818UR96nNGB4rQE+ZH5z/l6EqeyMH9YEeYggbAM6'
    '7mzRjNJZqhHw1Mzs0J1OKkIfvCWOXksjkRFQ3EG/GsnL796KbEsOWQTSyM+u2/ojw2+zN7CsvnwlHPPKC8RIEwDip13wC36zyeub'
    'I9ShjrD5n7x7DEfQoqmNU6159uLMx/nmKKt4xFLD5AQabUTR+QeMdOfLQ02MMrsPbninSGaAdF3cknSIudfH/eRFKUtvn/scNV07'
    'XjZy5fNkFWbO24ONQ0OST92IaJltD2aDr+5X7qqh60l/Z5J6Ai6fyEaCmfwK7XmBMvtFwh4zmqDtlJmaU7tvYivQnZ/NAiiEc7ie'
    'lI7ZHGf4gb0w91HwCVPrOLyYAsjQSI/e+tm95Tjd43rQTzgKRFlr2MEks5hz/CDhne0/LIbtZ+7QzBL7VRoXv0zt/2HyMuZHnvB5'
    'vkPpcyslW4REGIXN5CVzpJI8m2OqXe6lnSrnpzy3k1laqIaTCNt+jBTXhTQtntGhbNMP9GnNQw/sZVlX6MrT/Rv4m5d0JW9OTj1T'
    'T0Pe8ygDRH7owZACUP6USBSHKW7YvbaweOTErdkTDUfOfoKCZVF7vfAJatyWNufPQhf839DBE5Bci+5ydLxwPXJkpLQM9jSn5Hl0'
    'JAvYi02HzSWi4CgGA8Xb47WtD7WZZdi9oI83KIuZ3iigIY7upA5T84rZqKNJjdJNb+UQDZR8cno9K5kIEPVl7m0xMOaUezhWVr5A'
    'JWEjCek3bC2zRzKpZdDW2Y1y+CUKDU6ETMXF+A1uVNDnt7zll3zEY3deEhd3SbEjDJ2hQuz+qiXF/vGv/9s//vV//8e//h+gcvPy'
    'LB1Qbuk4/Scva7MUnssLl3hB5AtLykVFTFtf1dQhLxc/afEnnfja1FUNHIUTEl3+uKLwGy+MfsGryokR9ImVWOQQODjDy0TixMTE'
    'Xp/j7wyJnDDvuTBpK3kyg6Snoe8pORsnfNB4hmaPdP7Pq0gxIFdmIuJzIaSFHCLCGFAj4vWJUDWeczZNzFT4wfCTqbWOKHeTg7c1'
    'sORaedsFVUzGKf1k4tk4ComeRyFz+bGMVIYu4151Tzczx/xkftzZBltwak6WZUS2A5b2AB9jAFLW5R/DhXKSvUO1dBh6Ju1DZ4ih'
    '3E7iqs4/NMduXu88Ge6/WXbdPBjo4CeV6r4ZPuGQNL94dQ5v9jPAsHvvn1jgQEIjxKdhOEHyLp2Xr4DGOlmXtHBFWscMSaHp8Ivh'
    'lHFAzfZCGA0xxzCC5ivjjMygK5OhxBwNx7Hi1lsBCCo/7dnCWoI+Dyx5Dtx5IaUUNMLScUY86pWKrbpS+Wyp4WRJz+RbsrRjjm9x'
    'Mdb6Kf7auAv0flnfAy/FOjiAHxu37yayri5vn5di7d8tSf6BllFvbYeUtovnT4wt6J+9/jGdmejz/JjdV35CzD2TmTfm+F+gBXKb'
    'LLAmlhtH1gOPRIApxRJjSOhw9gH6LiZuJU+FnqU5SCbrNOYEwDQ5y1S4vry1f8YiI5cWUbb2H8ftfqbU8k7bCC3mvAHQ7vFjaU5s'
    'jy7vSFwm+Kdl97SkBI/88OTsfp4MwQsTRuJ1IOzgEg+nf2aHZ000bdKkDZ2EwTj5Nd0TRCxum/htgTvHkTvwd4p9LSViZAkkdEj4'
    'WhJOP/iceECg3+YAfjMetvFhEnSpmIT9qwAW+Dz9DJEsyYBspzKj8uy7zHLBg3v4Lnj50ylONxN8rCQ8nPOF2a4/Le6s7P8nJo2u'
    'mYtFREYQkXPPqvTE5NBr2j+fovinJSQKyv6iiMRDxrfJrYdCcr9FweuZsHxawFTk/ZfyQGEfG4pMBNzXZabELAZtq+Ca4b1N8OuO'
    '5aBbnQkaazEVlNeiVM/7oU8Pm6+8NlYKBFSL8qI00Fkmag8nmtxnNpBi4jZS1SmYekHWo/VkHrpGZDbZvJOOY13hJe1hRyx+nxbg'
    'U41kG/CWSUAbTqBuWDR+nhPByyb8WVOXIOJ1GUSfqs7wOGyAY8KnL/NesimdOZ754digbj6ME1bKI3NCx6xMe2Q7aoHtqV+2I+is'
    'zY1465JrlyLLx4GDNyh1HIxVD9DeyGaLsaGkOYk9Yak5kwasJbcPMWdUzWchUjwpBXpiF4W//hXt7n/7W3iNvbPgZIn2LYH8WqhN'
    'x+ZOh5FLCjojAQf8JUyNsScwoWlP+Mtf0Obwl7/sFLf2lwyZ/MO30pYWAmWlfarrYNqeDOz/7/+TgBV+0GbNPG8MM4wl6TqozqFL'
    'KZQ49jvpLI+pK+RW57YjQM6HvZxEcgvZ6H4rkRkvsuqxTDXoT9MbmzrF1489YZsf+vmZONECvg2T56EfF/csVOg8f2ePXL7JKyt0'
    'zxkzt8MoOUbkpsVy18Q2xWAc5FoUwwPMMCWWOUEx27HoGpTMikAb3F4Y2/rg2SFG2mZSKy3cpZxvBcTay22AVwYPB4qPdiMxA2QO'
    'Op6H5Y0G/5+5L9zvZCTMxUqcA/L0+c0MR3BAP0tmokJfCV/GmcOUFEngK57sLUst8OqIUldHOfI+q2NSZqfElRpsF0tnhMoOytYm'
    '6eRjNDLc+vFvfsaxzPKmsOJ4FnhabjoyeHlDQ8e/2dmOCYjnXVqSaInnUBx7R8Aat/b//idhiyvV34StNFWh/1nC+03BnzycBB3S'
    'yDnOGLogDJr4G2eUPNbIhRqb41fE00OSL+HZkG6fYM/wRICuxGOVmc/dlg2jO9exQxV/cr+rsEORfxG2TCwj7tF3uokJWpeQZzH/'
    'E3INYm9nccF5/JXf+PtNsEGJZI8GoBsSkHgayh7RzTX47Be5LeuqzB+zY92orchJ75/Hoqh0+vL+M27/Q/JmTPuksRKYEI99c/cp'
    'dp7l6yXvJhM9bHGJ9igGIog9ptEBgznckaN+wj0Dyds3qK4P3cYPmb9Gkffq8k7HFv9imfsH3LGNeQYK7Hl7nwU6AlvhVdv7mbg7'
    'CnTmbqNxml2sQdZPblWhQKY4A6xLAfJhH/H5RNRJCCkAFkH4RLdpoqNEWJEyHMXBunFtvvh8xsLNOMAoF5Z6K2xBjofFHMr5baBh'
    'qCJPHRIWj2JaVwJ6PHMNz6Qgm65nGNb8W3qob3GneJDHAmporZjAEBY+MYO4ZHgVI3duSSw6yz2RhaMEi7sFWPkvRGNSml6kNL2Q'
    '3M5SgfG7k2KKKchFtS5Xq7Iiq+WyJFfEslGQ1JiOClK5XBQlSVEksaqIlXqGrsQsBRmiIinSRhTkJBD0kJBLS1y8ElrsgrxFuEuh'
    'GIwwnkqU3XQ9ziACFEopp7pdCnwErA2rpZEyrOhQuPUsYOmuc1F17ob4lkb1xQaZX30xKsEvEE6X49G6zJkOGevickdTBZzEoTP4'
    'aK724pki/KKoH7b/swRfNOZUqmwYVgyz34kh6VD+Sz/mJDGOyWkck9M4Fh6qDnmaNs8osIwvCVxTxGqxVqlIkliT6lVZUmIsU5Ri'
    'WRTrSk2q1utKRVTWYlmtXBc7GSyTcrEsyQbDQSO4Cd6QwDqWRyD4nkpjLXAu72QXUk+1wxLi8DBWDe8LNPLQ54g5fvI+wwYxmCAB'
    'Etc+YohYAHtee8/IB8Nm8C7AAgZCxW0Bn9tOBg2BqLwQ2g8PMPqOZBZ9LxHdz7cDFpqDe80QcyOFEcQ4/h4Lq+DDiVKRTB0WdeVH'
    'ce04o6SmreFmShrTlDSmURJvyk+lG4FmWilmVi7WxapUUSuKWi/XKrUEikkVuQj8S1SBz8kyMLrqOhzrirWOKGZwTM7FMXefwIrw'
    'hYfwQ6koL6BjJ3fQcLl2b+J1amt6j/EVwcfrvaJC//hv/z21mlo27zpReM6uW0rsmc8keyRyX1Cac7q9moKRbTJWC2qM4iHOYGQM'
    'DS9nL6ZWeNILFtZHfs6U+q8P+D8Hymkn2Ek0x9yrKhQK+dKr6aVX00t/xjS0OJo9ytX+uyGBshESiBHA5TTA5UVcjeMuecIPFojy'
    'bwyxFEFcSUNcSUN8ueizlgS0RjmuylK9rKjVcrmSlBPgVa1eVUFSqIA8Ua7I6+irUtFqYjcDqJJLX2QB4swiQC07/O5FD2FfxER5'
    'DNPgZ/ScRIXs81JUs5Rqr+3o84W29f1GUqAoxdwulhPCxvS4UkI6gTrpPT9bPIYn2e1xcp9f0cMFbTkklST3+T3hREbOQO57n+z6'
    'hosiLFB3LQR5cs1mHTHL54qmUwU2bfXamSRvqDAjDSevh0Z0OPHJXogrRndGrOghw403XAKkgXWNfmXKyYOqJDA3pHUdHEBJ5ur0'
    '2V7YNd0ltpnxC7vX9fYj7K3wyd6amEu1RJlU1/XxFvbBkPbtkz3R5Q4lnrJ+7fo8pjt7/GRnGAixrovbz3IVFgkZhoGXgGd0xqjP'
    'rsW19FiOP0stJvFKlkxpXV/iBo2Xkuy6lNwj0N5iJGR1vpclZK0wlUAysQ+dBaYSDkVZyhxMsxIlWWUZOnKUpGp6c62mN1cZDVfX'
    '2oDEeUrM1XMcPbHBVooKbKqoIqEmXleVrC4uKtViHTQftSxJ9bpaq/2OVq7NtSee5jS8sDmeVc8I0wzwvbIoUBK5ZGbRSEbuOUKc'
    'Cs6DEu0wlXieAPrACoSxrHGf7jhI2UvoDANXjNKS5ahLYeuxV1+Y6yJqdC/O36GjvQxNRmTmFBLpeBIJ6zgaZeBOKIaY3iLf5iX4'
    'Y7uEoTBRwimKtTH8vCibNYpTLY19tTT2PeJt6ElxrgoCW1mpqIpUBZFTrqpZbJOqSlFdgW3VzWw/EXz1NHz1NHx3eGVfUtiU60Wx'
    'Xi1LoliuiTVFSYFWrxcrslirqpVqpVyuZQ0Gtc+YpeieeCzlIgixVS1jhpYydugDZ5aEt1ovqpJYUWtqTSpXq/VqEl65WiuWa6pS'
    'k2SlWq9UvwSulAG3DQDE0GaNgBkr4LFlmXgZVgxxTS6KNVGWVEkVq6JSr6cArlWKlapSVqpKpVatlr8GsZyB2OBAxFBnzEpSxq6E'
    'x0CUGCgBtyxXi5WaKlcVVa0pVUlOI229BpihVOQ6gC5V1S/BrWTgJnBioDMWCilrogA08oX/RAJPAm6pLhZh6cugRcmiWlWrSfWp'
    'ptaLMB65UqnLoAfK1bW0lmsBi2HMqNJSRpdmdwXHwKlSvShVpRoiAuii5RQyiHINlNCqrEplRampapbaJGUj6Dj90N2ceBBFIMQQ'
    'Z3RpKaNMP/fx2DVhTkSjoVSuAdRqHf6vlRMgV4HeajIqzPVyBfTn2tcgltIQTwmEGOKMLi1VsgzC0ve4mA3o0CaBOLndi0VVBUQt'
    'y4pcU4DkEgMAPlIE8quBLi2Kal354gA4OVHMQ3x6J4QxDclH5KEENeLhZaQZqZpl2My9LckEpbJUhAHBqtSBd6tyOUmbsFRF4OTA'
    'TypSuSLV6+twfJUFzhz2QvAAdg/HsoWeIN+Y/8G7a/S+tzXfqKh7pfp7SW007h8HbxcPvcZB474Bv+CzcVRSe2evj82boxfp4PFJ'
    'fLt4Om7Cu2MocHbeoH/up43GQdC2H+bNgX54ftJ/ezYbZ9Ae1D9mRRoH/VflZtrY5B/oux680if0/3R13/gd/rEGby837/ithn8O'
    'H+bPJ5aGgJ0QeA92+PuS/TbD33fst6KfHYj4rcl+z1snF0f47Y3a69uZ32bm93vn7ILqExBHs6B91nqP4aN5un57LreaNEs9/NNp'
    'nF03mr2Ds8bxxetzy+mFpdsVmPqjdwlbGrD5DufZHMJ8BWoTe9JwDOfhq8NHrH/Xhz+BX0+1l5rvl4N+Z3gcLwbUfBvC+7tLG77f'
    'PMOj4zo+dtsx/Aerx3PYYOM57jTa04NJ4xQ+GwcWPn+8Pxg3Tq8bVz0Y9NF547rRmDWO2iV5egDz1zw6QGSbNo/h8+Tgvnl6MJ2e'
    'H0w7ZwfT2tXhdHB9fF97PO4f3x0/HD+d9Kcvx7N77eTh+OH08Pj1tC/qZ7Na93jWMS8Oz42Lg6lxNquytu+b0F4H2lPPDxuqcXJw'
    '3Dzrq8bP/V8twXAfDhtH08Zz76jxCLPfB9Bnxwel2n3jdEq0BX3Ds9Q/18cH969njd5ZadZo7B4j7Uzvoew9wNc8b4SU83DSb/Su'
    'j497zdPzp5OHTvPksKcBYj5cm9fyxXzQPm5eHF089nqd53Px5ngwPps1lbsp9g1IhPR4wmg3+c/xIfR1ctDrnGO5mz687x0DjPcw'
    'x9fHUd8HUL9HcD5C3wfN55NZ7+20fzCDvr2zB/Xx7qB2cP98LV48+ZOzktyDpZwe4/iPju8bpcatK526D71Z5fLjwz2uP4yar9en'
    'x0/0cPr6cNfUrNOjg/5/7Df3zdfj63N3dPM49I+eD/vW40Xlvel6Dal3fW7zx42paTjSpTa9eT06/J//fQ9eH108PDhH902Ykcd5'
    'cCz3bg6emlq//x/iW0m7vBxVBq7rPrut6uDhrDnfvZt643b3UdIetZFVHTVvx2r13W8fOJp0b0q7w6BZbd3eyUN5Prs5fFc6s4ny'
    'Vm7ORN3/ELvPT4b24NyUmm/KxHLe3V3luSOZtQP7ZfA4Gg+HcxsE5+78em67+vNuMDw3Z+2uaj82asP5RLvzrIorV1TnfWQOL0rT'
    'w49bya9eanq732p+tJSPu+p52aiLH4OmU/fOA2k6unqqfbTK9ln5+Xyye/c2cp92326lu4/b2t0c+htbmlZpjtyXyUOz+nEtKvKw'
    '4r5677sj88q6e5oqb7WL937l5P1KfphWrbvK9cfDnX3mzepPHwEsm37y8XJ48fDUGrzqd692u9WuXdyLt271yhmPX4e+WnupaV5f'
    'nN3dXlTc992Hi6nRdaVSY7xbnTwoT+KTEk74UH3rOUPxwLnU3pvX58lvDXd0eHrcZFR+D1jyb0+vsKB9bQSY8CC1nh+Oqq/y3VPQ'
    'v5qcu82RbgU3k3blqCG9NC/1u2l13GrNHfOtuju6OzUOBqpxc9vqOv6sFFze1GfPZw/91+AmOH7SDTnonjxdNu6sl6t5dfzW9SaK'
    'q7ea47e7t6uTISy+qbT7D2fAJGfzCu6i1q7jH1x3zx/rbVdT9Pqh0X8aHR2XzalVeveCq9vRhW8P+9LtTA5aldbIGrulg5frpvQg'
    'P4m7x7VurSGKu2P15Lbdl+4npqvOlFn9412nkXafju4umvnc6aB/ckOFmtfevwN/fNL1K9ENBi3DGjVLTenqVKp0Ro/2+Vi8qkhX'
    'Jaskd9xg9tR6cW4fTu5uHu76J82nO6dtv1VeYYOQrusTcaD0GnfDaf2Z7zyjh8tR68EoN1/PZoOW255VLW3XexxZ84+HVmfcFJud'
    '8vD8fXLZtppN8QOWtacqBNKZJH7MLvIAPjltvDKW9npzcM9ZGv6GUlpDPDnt3UCBGywAPw/6/6bvD+UT/eVsrl1NnAdDmd9Z8Py5'
    'A3g2b9+0huUjd2S+2mO793LVmo+klxP9uvZq2U1xZLUuW+eeM9F6N63Z7at1efGutN7uWi/qqXQ3vHsJjieVG0t6rcu3Z7t+/Xgm'
    'lbqjQV0Tq3dBWRpeBWd37vto0GiIMxT2GpJyq9Sv9auby9KzVy01Dq+Vi4n4Wne1ilQb1C/tu7eT+bhkjMatemVXrR/KB7I+fhu/'
    'PQ2V19JTMFermlO+Gpc/ymfX1UfNfXqXL2aVi91bT3yvDW+Re9w0tCPFsu3Li6ChHb7fn/Y4W4EXsBO17+EZfOIL2qccEHfb4Y+Q'
    'A7GtChvgG9i/b4mDoTrsdoJz62R24jn1yukNFpJ2Xe3F1Oy3+ofVfGg9VWbK00dv3nm5mrxaRult1BxWgjfjrlP1zPNJvyWfiK2T'
    'B/j/1pB62tQw3l78yWxUsV8nH09nreuH1m79Qqx7mlx9Ohw/q0Nj3toVhyVvLFeOjfF4aH80p7X3QVs/vNEetMrkbHwvIeRH12JJ'
    '1irdd2n2MpA+Oi8PNd+47Oy6r3N95A/Lp1XNNW3J3jUaE+XKqkwMdTSaVABHabD1I1/2dNO80sfDc/fdOu6c98rD8WhUbt0gV4xm'
    '6FCd8536+cAL0R2HQkQA3w4GjjN9xf9wUQ/M94Pe9D/+Z8OZHh3SWl9en16ets5twsvpqwUc8PXUP2G88H/ybwcPvXtGdiNE7dOX'
    '40dkXM/EuC5gJVuMcQ1hfVvEuPD9cedjcH101K278+qN26y3NFEuXU1u7qz6S+1Jq15dvvj97li8tievs7bcfX++qzUuXo6Nu7P5'
    '4U0Nerq9nhuB32+V9Nqp9FCqXlqj0sP7S/ms1b1WjPmw3vbd+ly2Zx1J/9CeDp3d5zd7/F512m7lFOrfXV/ZN7XJS+lkfntvq5pc'
    'up9Vh1375S4A7uWVTvTRizq8aAWtt/dyu7PbOdLvWoik5ctxazB6vxq8WCWv2SzfPj16YvlEOqk1vWZQmh5IYqnWOKmUetCTiD1d'
    'Vm6fypfvu0eDa/fust6qfVz49fvah1bqf1TN0vvD5US6H4vt1vPFrma+1ibTG7F+BbN01pBv/duW06482mdjt17pT8SmbFxIgdYa'
    'zGunI3s2Clrnk/FLeahrcn/atg81933yXr1uuxJyHen2Qrqbyvfzq4H3NnoRX7TWk1JXJjezt/GzJx2+XN3MzfL9xGu2zkeGKlv2'
    'pa+o+nh8UXUPaUPB5TspZ9dv3fr+5Ht4dnrcxQF4IS9/oh8Ho9vXSl/13i+tQPEU0Srf7krabtC07cox7DeTt5Pxx9Pk5dI6047b'
    'F871y1356GB6eeNPLoLn8Ux0n73KfPdRr9hHnZnUnZ++jsRXu2pruxVP8qrdh+qRfTmCfyz4/3nkGlKrZUhP9vVE05SH2+qr223f'
    'Hd5d2fWG7s1fnqWRdeKopZOR97JrVOULaLpUdjrV+Vnz7qrsuZ15xdMPgaPvOva42qq7o2mnPKgEVvnsQ5qPR7fHDejOg3+dxk0n'
    'a49qzmqAH1JVvpLmUksVW5fmrjo8fB0Nhy+N255aGlWtztuoPRffWoeGGZyOSjd3ZlmcnOovnRfryusqs8vSpB7cld3a891tr90+'
    'lT6uZ7un9cmD9DSrG68gm7b0cbX9WNY8d9y8UlrNUeWq+lTVjuZXION/dA5V6+N43rbc7qN5VW91b27LT6Pdi4ryUGl3L1TlDXSX'
    'Z6mmdQeuOL4Izt4V40RR32pqbaoPEP/fD+a1p1vfNWZX9ZPK+8x9GdfE+llw/f581BUlUXqYNOfq4QXs5Idj3A+eGY7owGY4Zryw'
    'nYHwhe0Mny1xdqs39aZ8e6fMrs+e69aFDAvrtV9U76x0f3M3qNTN1/qH0vm4/jhrHo3km/bHy01Hn50clVvV0nHrzA2aeqDtfoiG'
    'Zl/W7+vtl/ZIei0dNz3NqVoTya2/dS/uHsqevPswg6UdVzuj8ctlZVSpWMYItLJWy3p6Ke/CRh2Ir6VTY+KULq7n+sHHpDU57/Ss'
    'ln1W0q91YzY62Z00B1L3YqJ1KhPNGzU61uDtRrkYKdXgadBrNPw1dsygX35+6iuDyWuwO/7oPEmjk9fqUd8Ynzxctl8u5ZvJQ/1G'
    'ewoAMealc3Vw+ma+7T6Yj9XWY/X2fX5Qveu9jS9suTl5NR7ak6Zhaa1qsyZWxbo7uDYuVflh8BpIV+MbY/ysiXXNdJsvytlT7Uma'
    '2WqlKdcq0oMlXlTm3ZbXrp/curMb96rVPSydVu9ePt5BRjy5MJ/Em97MHV9XPPXlRrPrbunNM3fd7tMLsajyfXCjX7aalyCuOpVL'
    'WzOHu375ZlQ6CqSHu07rbDp9RRNLjfbcoSOBSOWfcjWTXt3jm/fT8p11e6vOLWBtl4FsvYzdl2D0Il/I9lntQwI9L2h5pq9fHleb'
    'u8OxU9nVmqWb0vm04zVr7ZP3+qP3Lj18nNs9vT+/1fs1/XV3+NExzY+HyllV6h9XpdtG5b0ynneq7bPpjd8+ffGf3ZInubXj/pEN'
    'vc6vlfPR/HpUf9HHkl5vPZZK14Pjp0FwL1Xqg9nNyUTVus/dsnxyPW80NGZ629UqlSv9VtL1m0vjcjQ9qDemV6Xrjv72VJFbD81J'
    '/6Herh8dTPRHNbgq3ctXwaw7uXm0ZxfK28HkvuMZleF8NPF9Q3rYvWiNdh/6yrhdviyXRi33aQrq76E+v9f9p7HitbzqY/XhYffS'
    'Pb49Gr8Zrc6uOG9LL/bzaHDY1XvV0QQm0anW5uLEapYqx5e7hjq3xxOpZbQOS8fq9Lg6aFTmZemi55aOtInUFR2zO3oEOdTf9cyX'
    'k1plcF/uUalbb6R3W9PB08e4WzsejV3/Xepooj0cjbTj46rfUMz6Y9l2/Ofjulm63m1VBh9Sae7rd5XW7pt7fyM32pbh7N6XLL9b'
    'be2+liYXdmn+CvtuAFvhsKG8HowHUEkszWt6FyvVL6SrISzbu1c+n3zcnB6Mp8B76k9vZ96r5HYvWve7YsX26rdnjxOrU1JvdWxE'
    'lM6a9aCr1h6Du8ug1Gu5FQt0c9NXxNrgoWt2nMObeUN/f5AOZsFL96Xj1ip3g5egNpsFXR0IYPfi5Kn+1J9iqVL74/pRlYett1F3'
    '6t1PHket8/qlMzIuz+yLXVECxlu/eRS9w4FRPahcv92e2OXxSSsw3/TKTAX137yqHn0Mpfmp3i41zq/HtcHV88h5a3n2+NGpVqUb'
    'rWs4T+rh8HJ0oV+P7o3gtftydvN8/HA1qd4NHPutZD7LL7XK803w3pX7z/LDtf1+OXgRvfZ4UrWeVPv9xhu1z5+qL6dB66Iutdzd'
    't+Gz4XZArXs5G4vdfutyMmgfKqOxrpVbH3fd2a57W7+otrRKVX0e2ZW6dxV46lX7oSs2J0+SK+6O9PGD7taqNw+q9FaevLcnu85j'
    'v3sYnNx/XN0+vE66r4qnf9RuHi/fmu2HN+vu9rw2mT9NHg2/pWu1hq0bE0Ay9+lkUmu8KMfi2PJO5lXTrbRcwOGuYbQb7kg2Py7K'
    'l3eNtmi3y926c1Nuta6f3j390ui3A00yyqelpvhyrjdr5eFoLLdf3twXqX0nHT/JrrxbE53ry/po+GKoLeWidnsmnnfsagv+Ae7w'
    '6MHagOIy0Ua22njlRvkD79q2b2/9UnmutGpX2l11V5XGT9JNS3bfX+cXauvlctKzP271A9CCGu2z87I3aH9MBlftp2ngetXd2rRt'
    'zcudF6380nqevDc9e3ronjcax71PnVrNvbPzt+AdhOax6KrtW7t8+Sa9j64Gl7fzSeWyuntpWfWPU/vg0LzXb14rw2A0f6k9j4ba'
    'pV0Hfl26qbWNdl3dfX+Zeg/NeqnTaR4OtfODykV7/Fy1biVQEoO7U+vlzq9VHM8LpHazJTU91fFO9ff/n733WnYcSRIF3+srWDk9'
    'dc4pniQhCBDI7Kwyaq1BAGR23mkokiChBVV1mc3bvuwH7JrtPu9/zZesRwAgcUSJudN392WyrA6BQAiPCA9X4RHOXS9jJ74oPsEN'
    'QIqXo8HarVOVyfocez4xb11Gih1UybZgMMK6Qk803ai240CRT3GPPlZNW1lvO9c6By3FjBCpgRcIZ088zZrXsNb5r+7rNdmIHlR1'
    'Cfrg7zYdS6pz2223TM2+fEk2RAsfTmgXnCXStx3aG60gb5tk/xZvkS6STd0Piw+/cW4h8WzOfAFvhxAzV6Z0j/e149wziledRYh/'
    'fOG4J97yPuFjCZDxHnzDKeDd2SRyxi00PIq+fCgs8JkHSJc/DpVge3euTk4Xombfc7kjX3k9ka/cnpK7AHZuEnoLB3AthFG82eS3'
    'relKtcRUSZpDIUx4hs57P/BVpoR83fkKQRM0ZPijXev/hF/7jvqplTvql7mdJfGzdnef4txB0qQ/6MSniu8ywB3K3WWQxt7J5kS9'
    'V4L82pJH86cXvr/m7UP80+1GwMzB7KecS174U5i/5C/NEv70+ydPb7c3hTcH/XwGSEzjU2HA72f5Xni5/XZa/hThixuXwnc87trY'
    'gc/wwt8+YfdnzhrgVfP+cYOue/ovHjbA19W84x+L01FACuQPmd6BEr2X933325dLOV9x+uW2tl9cUPTnKkf3V7xTM0rOHBuhvuTe'
    'qP8Zh14gZYUw0L787b99PP7bx+O/fTz+v/DxaLVqRu2Nj0cXrylo7vTax0Pr1Wcr7EPR2JRbtRaBRrkJ79D/cNSYzer1ZB1kfhbd'
    '1ry3G822wkxsLdvnrSna2Odi6Qp6Q2yL5IGVziHfXRDn5X5k9YWVrSwq1/HF9Rf7GT1pRNMm8idR8VrejpI1n/tXry3rtdOqUS8D'
    'PE13DnDDe6vZAFhx/todntZsuZitWx0Y+91IbJ+JuSisYPRDrSX19r3rzBruuKZ81tyBOSuXYV2dYPxrjdZsNK81uVrcqTVPxrb2'
    '/9+/TXOjHlW1q/ZVS/cvg4PXO1TZOVs8twTD5xd933fothBWOfm68s77abM98KkLfdTri5Bti+OrUxQvHtua7WXx5LdG1UuV6M5B'
    'ztE02mmJZFSeG+TBkvdWTTIaa0nyT6SlnNsExTD2qReXTbO3twgudg6jDT0r873NQi72ttv2pFqM+fJpzg92lzlhD06ssSkSR5cQ'
    'jvd8OjEtL7oEaKm9Xn3vkRuePgH0F+NgeGV+wV30Itst1waz4gH0qdYEXrwmuyifAVH1SVCOi40uJRB7clr2ZRvXfGomFY52ymRZ'
    'XzPsLhh6KyU2TXnfb44O1JVZEmrMOe6AA22kGEcAJOMgGBcn35gCjD4lb8NxJbL46KBfova6KxIH2x8f1sFZME035tvcAo0rt+dk'
    'sdPR1kty2h9V+Q7dmIdtoRvQ/iBmgnLLH/iGuoy2cjvQBsfmhCsqLO8S0SA21Ks9ZImyW1a2QOOW/xwsGozkTkex47YgkJPj9LyI'
    '1/3gTB3EpUxZzCUuD2oXNhgsWLEzHE5rIdleDiPysFSN4m5DHAmB9jlRdmVZNkXKJTxh6w01PbgMyIalyiMW9GKKW3Gi4/PFBag7'
    'yzW/vDU+Nei5INANe+sR4trrS+F+3iJBsfR7TjS8WnpR4C1aEse0x4m0bW2a8+XF68/nlzEhGQId8G26OjQGQyLwvHi+ONdBblpY'
    'jeaBZ7iAUdjdIlbtdsfmqh3tSB27YjWs1dqmtvznLCa/5w9Mzzc5qG8sHDtSsV6NRiGp7i4HaS6SIjGId+KFZdngqnj+pk65o/hY'
    'p8u1YTQvjuiw4xEDgaXbWmPTFFW2Qa1Ir7/hav3i2nWU7YXluptidbnZ97grf+ruhEax6S8q0oDUTXFkndYNprxuBbw07PZ8z+Uv'
    '3llx3H6xZzNLOt4su6A889ZoXvX3wn5+IKGhCtFdVqnAH3daLGHbxfNFla9j5dJA1bc7TT+uyBSpW+RIP20aJKp+3Ol3O37fPV/6'
    'Z+3o9ZvVZUeWt9Uyrey59dZYXKsOueH8y2Y9O4Qm6RLMchWd5ZrC+3p1QXaiRltZLDYrbzxkbFP3m8PgpJdPDdSz0W7NxaMmZesh'
    '395d9ov5sTr0Il+dG9E4Egn5bJPbw2AnyJIbbJcELx69YG1JB7J82dhA1xeNfy6FbPRjcQwdqnP+ubwWWuFB0HyVnvpNRtwXL3aP'
    'pItCLzYEoC8HdmpOXnYfclsO5C4z4qF42fXXba8otDT3yDkScEZYuKf/FDjTTuyz0tbrD+LIXymKsxeUzXDAdyLFkXxf932jY3me'
    'YruHxaTTNy+LqbwlfaDjxa3ftq29XakQxzAMATQ93Bn+Uh8GLhkYjYk4sS5o8ZJEpb3zis7l2I/6lUVVEtTOxdIXynU3jNarTnzd'
    'X8reWp73je7VJ/W21LEPmuMRhHztXvn4Wpue2IBfGqJUJwZEg6rSZ/kgm4REVwHXu3TbN+j1tlvRxaI/7arhqclN/LLYtcTtmq9J'
    'R6M4BWmVb1Bl9PQ7uaezdkAf92UYlll0RE91xYmoVb3YFTf+/roajdfbyvTcnlBOpHMeTTb562q9lPpViz3M2b5/PJADtd4W2/Ol'
    'PF9WBkafc6p6UA1t21iz/blSZClbPteb5VpDDw1SL3seN6FtV5/Ky8NmchIuE3Iz7AauP5E90ffpi3s0+9uJHAeKHon6ZKPsncDc'
    'DXZLra+CpDdTXgv28/HFO2pFd2pJ0+pgZR1M1RIMhp9tBuGGWp47MQhX9lzjnA3nzDkQ4TdaMShbklAdtFDuQ1hkeLk8CB1q2R/2'
    'oulltbfa5QNLg3y8WNivcajuGgo16Ady7UJQrLhifT0mhz3SKO7Xp3mLteTNkW1xXp3slD2pfRwcxWqbk+mWfY0GiAAPusp1FZzN'
    'Y5P3bakRxkthbXMrqhfQveMyvpjskBE6eig3uyd7w+zODQVt+8XQpYlyHJpFqx87jYF83Jwvx4NuCcyQ8vc8K6j8pbgbO2r7dOb6'
    'TnGlTajhbl8RAB9Gk55QD4oU5fKE0eSuNG+r06MFmCWsqbM22jTWZbvbjMzKqti6llH22i33+d3MXU+olE/RuLcHNJoDw20fdoZp'
    'OII2M5oDRmW3Dnnenzb2atM3r2fqUgkuwwFBcG2hQSmOvQfiVbzw+4PY5tiuOxtuj61I3LGVyCCrDqGZ7oGbtttCIPhiw+itO8J8'
    'ZJnavkJH86vcP4ntykAnXSle8pI3WUjXwVQ5+seVFvm2dQ0HpmCsjuGaqtUNS7rNnuI5taJuS5Ned1kko2Aez3WHJ/WWXj6LC6dv'
    'mCyxbF8iCziIF5P15em4OwiBwrTnm2CwqpAnWhsNKjt/ONd6dI8d60CIxy1rL28ZGGc+lsXJlt0feGkfXr1qkWC780Go2+J0Q9nt'
    'Wp3wNjdZo8OvGwthdF2F/oyTJ5bCTKLjeEoOVWtU7e6uHW7cr5udixRzI9AMpYHvdaZzyqmLc6nKT1dr37pOr73wcByLY8IXxWm5'
    '1mJZUKnL3IE6KlrZN4AOKb6zOMTe6rS0XWkZxF60ZIa+1KBmA0YKrJpcbHeiWLQiXvbOeoshFgGre9OVCnp+ORwL/l7dK6o194+L'
    '69oCEjHfrJaRMK/GXVYr1pdXImZ2RWe6FWrNRSDawXZQGQs2N5vNJjIdLc6E5Dia7URjP+KvUXRSo2X75A2iySRsXeVyrT2YKVYj'
    'EMrddnCet5y5v4Q1u5T27Kmm7KWa0rbP9nEnDE17RVWvF3F8ttbRSSrahD5ixmyPoXx3LymurwTk0DVZpa1yCw3onWXwV3U6k+zr'
    'iWUjsWc51nziyRN5LRfJ5rphDWRpf2H67etsOZKtOhP7vm8Pl8K5r/qyXq7s6Jmk0jud7y6PzDxkx71z5B5t0Nz1+vpotGlCX5St'
    'ZrwN6WOjyk68zWVHKDMKiPkrsUG0qu5wXD3Fxb0vc+65Mwjp8DxaSsUJTdOt6VofdweHq6TvltVx1zWhG+HK5LpDVhDkkAFCa9px'
    'GI4HR0V3jCXLEZR7nIqUFb4SGRyGrYhX49o6HVVmuFmFM95cEgf/OllTbeFIGn7PDHzeDE4g3YyO+Q7OXElj9fFclZdjEdphDHHA'
    'tQhvOgX5lTstRy+6oBNtm6/Imzk5LC7VeL8YlNX5ZtRuTtjG1eCGR5e1yoOJpLnTMRkcRE3qMRNP1RescRnpncM4anMgg5yCixuq'
    'VFFvHcm6qpKCz7R19xoaYotdzq8Gzw/FYZcRmKCyvHY9Ogo5zppqK6lXNLb+ch4GLVYeE/RUDWJSOCuu7XdifbA0CJBu7WKtRjpu'
    'jRv4ocuKY6Ck260QHA7zI2m3Ak1drbylrMTh0ueXQ3HDL5SWcjQkHuQRm2x3z8o89iRSCYpy/Xiah7NxI9CI4bzje4vlWF4OyZiS'
    '+rwSVJt1MlZAUZkvvaG+OClc2wgc3yHbY5kRFXleLtpytUWXu+dhx3LH/LI8358VmQNJos0408Nmb1a0Shxfgk7ELdSm3jyO99N2'
    'dN6EMzK8bC5LYtE7hsLyTJ6jSc/rrYeepgyOGq0FjEfFJMGSJM12ezAx+s7nQ1+MBMscXui9zx6K1amhN72OdSGKgEze+ULuOxsl'
    '5kCZn3Qn7p27TakafVmsJpHqiaKs7yNhQ/ZjgVJavYoeteXNMGjPlnuRcgCJijY7Pi6YTb9q1FcL0wM+vt95vU51tBypK6pP9kyl'
    't5lNZlGwZC6BNuUmI2N4dSqbJdO1BHkXzryNf3XozZVvkrU635uM76DsOGm1Cu2BqkR1w+9b8w6sCRCkO0eJvKjE6NQkG5o7Xpjc'
    '6NoRTO5sdGZXiXOo80IYsIdjdN7uRVHsLEbrnm8MZc3oarx0PVkgANllQ1AaRiQd28UjY8zHkicvyjJntmKGjZzdUCwG4yKnX0l1'
    '2pBAKVB5Zux2PYMrb7g20yQcfYNk1plFT8WQ6ytHcn2k97ERrCsLEvq0Afmvxg9pp1reHnvGoRrw5UtvUXV8ymhFMhvS1eukolym'
    'px2oVtZcHoqyMjdZ9+Jq+9Wx7YPYGTBtUB39/qzOOL5Fj1caze2vw+UQdGUmrKzIoDNenf2xQo470Xzcmk9cjvUtz4+nNus7O2dd'
    'rPbO3T7bni5bzaEszTjbl+XhvsZfKcvXxsumPKnE21U4KHO1+nIsxPGMag2stmT6gTWL2ZY6OOw3M2a8URZxQxSOge0UO2rlYLYZ'
    '2Svv7MvRIpmpfloFVmT0fGk9NSK/150HrORX2b2o7g683VRh4AWKt4QwiDcLcagvOXPgD6sN0u2TU3noTyvh9CxbW3tGGsyeqmxi'
    'znTLrHAVTkc6PBT7g/5eLx6u6+68qCpzyfEkzm1224co8PqeupEXA/sM4vPIHEaKZnDisWlKxEDiog4b+hqxGk6bwnl2lihzHQ1I'
    'vxcw/UlZY/Qpo+/G5eVRUmVfnFSE/cAM+TIvkyORX+yWXjQ5hDzTHHNxdD5atK9Gun+RwsD35+u+57VJjb+Ul87M7Mfz1rxFd8+1'
    '1sqbNRagbStcq3I4j5cV4byZ9w4ktQVdU673mc7EU5y5bo2t4KBUFZJWF0P6KnmEfVlpFyKaNEedSnhe2ztF9OPTmpYuxLLpMb2D'
    '73ttmV+ZoUZeQlq1SEL0p7Kg7RiNcLbX7a7WCqVpT+6I10gHIRrkOT3kSGJ9tZozGRbOwPM7wVFYr1EXXH/oBb4dl2cnowvDJMpG'
    'peJEwcGt6tJK8WixvWlKi8mcupBteW6fyMtEXAoisNzYV68TunvsNGcnVV1rNdqsrjU56OrjJdEcqmuGQjbGPe2NmKu1MgfnlhKI'
    'Ar9y2he9H1rXy/Qsqlo/PM8lWWhy4+gQLeTBmLMkZu+1pPG6tVP2dj9a+OYm9ABIWLFjr1lvn8bnixSRp5haR07E+67alsnD1Vua'
    'XpVusZK58Vq8yJyDpSgS87Y4nm56O7sqWqrpdIyRJs2JQG0qrjqVrp422BEmwR892usx7XWX9v19i5KVvhcrpsKqW6Y/DTqN0Umo'
    '2tOtcTgdL6tg3F9S1PUie2o1nMR6h5qI5LzBhFe7OrouSeO8pHTqOD/RnSC6dM5xNEYhbs9jkG+HlHQ5x3Gjr7VNtqgCcFzNqsTh'
    'yXNXPb9+7NTCcDSrHKP26Qg8WAnmynDTO4iCTCs+yITrfly9ynORrDLHeZWZhOd4Fder1e2EDyOR329FghiuWcNwDsylY4x14KBd'
    'kLfIuTHoHb3ZNRpO6lsSlOmrPDmGPOFVHXXgS5bPGvN+z1vRA/IqznVjWxx1hLpK12190gvFir4POhOXXXgrEDabKzfSu67THgey'
    '5itDhp9sQfiwx+qVDtYqQC67+/lVKl7njf5kLhsdwlbawtqzq5p4ceVqY2D7/WHHn85pPqYcZ+h26+zusg7o9nWyrPrSibbmbNHT'
    'aXVf6S4kKlr67cFgP9tHw2gDq7M397RaxQvazEWy1GZQZY31eLP2PZsdDmJf84cSrXTGE6vnknpVJPpCvQJ0VR97vEYwxpALO8px'
    'MOGdYtufbo/TvtduW9ZqtST9tX/x5PNx7htnoHrri3mydvGekDrE8uI79XWHqxxBnyVHVKPiKuPVcnphR2I1PJqX2Gf3Ork5k93z'
    '5NAajZpjszOY9I/Ls99zwsmVioyzNAW0joX5UhwvxeahfTgcwt5urRqCoJLWdeUX12tfdZQ6CxLrTmyv/PKpQRrdgzBvdnRAz+KY'
    'KdvLIndYtociM1HWIky1GwyrYcCM25ZA2kXvTK3I7p6eMgc9X+Rl8c6xOmRF1tJkxjkSzKYYFhucOYlJcV7ucOXrYGNMcs+LQZ23'
    '+AG/iIfcmdVgDNrOST7MScoH8k07xbVQvRIeFwxXJDucamw8Py72nUjxi1C4ASrhSFk6ji2eN3Y30IvkHlSGY+/M70MyCqNBNFX9'
    'dTgUCbEaD0FyWvjBebStyeLAalj1mRc0JFihE80/OAP1QtVqavPyx/Ynkx5Uvb6ymS6q10WP75DL9njYDU6iP4vWMScFba7oGYcA'
    'atRaFzHyo+JkMOjLi+WgvxD9sbC5LmJRmnJXS4S1yhg9etlf2cYa5PRTrcWRoAZfFwQ/7y5ni6lpYwU1lEFDBRI5MPmG6602li1L'
    '8ObUW6IwYZU6GSyCTctnx5sBs6ScgakPXNsxaVZbxNvpcG95tmYF2iUci/Y6Xhfbo1PYpxe0UFF2HiuSoOkFoIq6E9UWqwftLFIH'
    '3a1uTW0ptonRfndtS91QZtj1nmKvcseS+ZHUH3R2jsj2Lr617oYT0ecnPFUVzL2+pNuzmTFR2XA9YkBD77SH3rZ6CJgtpRT1/Rlm'
    'gHUsx1t5lDAUImlR77j8tS36oEaJOiIxS7JiN5lluCdPoiW2AotqnTjyMiZpJejW/WM42646YjO4rC6LzQX54Z/O5ao1L/PG0lLO'
    'p9FZ3k0nwpAiRWvcBsngPFyK+rQ5HByU6znyO77fA70M5C1vMjcCRZA1T3Qby9GxJwwnq4NLV2bMKG4OjOpiJo6i4Cx3+9J5tohs'
    'teVPHYMdKoofaX4vNtmBD0qAYlcr57jTU47dZWcctiRnuAjCqz/v2ysnVq3FwhZ7pMIc9hRgTZsggbk7db1dGSzD+t4uA12QpEs5'
    '1KNjUSS5s6xUmytNqLi+yoxY3xtcwk17vgxVh62qK3q6pm3T9QeMHsyNqcF2z1wQW7o2Gq/aoGoeXMUkxq5xii9Knx3WDrE52Heg'
    'y9U1sSoLe887ysvAbw52OwbGEKF+fej0W5635riqMOxG6ngskKPQNhWeDYe2WgwMvsH3pfJhsRrYLixHTSWJxfkYD3RzOZiorn8C'
    'SYYvHpcM2zO1KT82Jn770KjLlr2OzBg0AsJx/6ftvt29RERjidDIrjSbgxI0Oa+YlddxmYDy0VAMz/PldAWqP8dpW5XcTUI7ptqr'
    'gVml+my8uWpqGxRRLyheQME/KqbW7TMEK275pej7aChBu16WlzNSBnbdqY8WwnBqhAMq9h09llR7ue4dLYOeXzgjPJziTuzPK9qk'
    'Up7M2nQoMTOmvVpHatUxtMnIq4BsJoE2FSgHmScDQ6d9kTla5um60WaRxw0qC312ukyogWHv/bXn9SegHF2R7VqTLEsR1fP4JLWi'
    'arURH4fFvTIGCkXHIM9PGhVDovvx6dyeedLq6rYBehENjC4MzuFic50oIOTTB1m42BX+WrWalV55MRaLyowlpfYEhBanw+sO0df7'
    'sVdfKAq/ry52qyGr5zNPGP6y41obD7n1jzeLlU2v1rOwzb/40NWKzKzYmBJ7cWPvvdE8HLlSo+jkk21/vdWcZmMUdSJ5N6CGgnD2'
    'aHJQ9C2Nmk9bIM2JQDN3jKXPzbCijnUxBpluca22KWu8FeQ1N1wtwojX66bcEHxqMKbOU+HoexWvoytuIHuwjodxnzpFB/6gmg06'
    'jMfuibiAtHK1A20QKCvASv9StcbicKmIsi9phwVx9EWCcqdNieG9Od9CJ21hhcRMa+ZMe9deg195wWp4NlnLH4oraaKU7fVSmhih'
    'IIgtxWkHbVqJQXSaGzxLRNOdM3RqcYeRrpLcAC1iTU3m13W8mnMgpm79qe4z05EXzauONg5ai9NywnHKwPLYwX7r+ov2oT0WzpFp'
    'mit7L40U+OOCFtAze8ap3gHM/q/8m3Rj5WweDQa4p+37PqzQWrfv2kpnbdknWYg9AsRZ3RmTe0+alNesZRyPS05uC4uQCtkekLxg'
    'vGuIYTQ/rocyq0R72Zs70nFf6ZhrZb2Wr11RLVrVaDgWpHM1iheeRUoLV/bXwZnzq3ugGIvVCWRj3rg2Y/pY5BZmzC+tyWYkmZSn'
    'F5kNvV3FjWZHUjuDKBI3y4tRNI7GaXmd+vNp+7wMZcuxyLXWXiqTrWKJmhMRdtD16AuvjAU6EFbaWOqQKw0dlgj5zsX2KkRlXInl'
    'QDu2RW59uExBV1nE7avYB/qmxuUzt9dXityhNxNSjgSjfOFOtYYzvB+GIbujYU10z5vFgF37S/K0ohcDf2WXT7X9kT702vbuvLYs'
    'E5amTHDOEZBx53c2S98Ymjtley72hkN1yKvr4UZXRGte4ycNEBLISHaXJlldCwbZ9Q+iyHuguDEXm7cVuriBP9bV7iqhPBtvRYnQ'
    'rwotLWytygeBaPIDg6BngWC3LcYYdcQNu4wOMDUqNaFc1pyK/V67bBMVQ96qnrWz6a6okYq2vIxNhx6bgT7uHGV3DkoqTF9sadF0'
    '5fPCuB34miswZlW6Do80yCbHmt3rNrtjAHGs7W3fBvmDdf1ufzI8/c9gITuxTCW+sHNz4MyCw2Sy2ZX38zLdG43OVtdtXplitzju'
    'lmvdXu7Tes7WuGL2rnh21wbO2KH49SDWo7l0FHhhMQel4Mgp5dirkONosF8GwhJGfh34pLt0Y43e9ahGWTYpakAt6AFLavpQmPdp'
    'UC/Osj+fWJuW6F0XVzGmRoMd74Rqn12QRz3sd66yozgAk6I3oHrm2qAldnW+SufFxVmdiSqpFz3PJYmdR/EKL1VNv3rZjHwuUIUt'
    '27bUpXuJj81DlXU1xzgbfVPvWhVnfoqq6qLne3KRX9LDuHzcnCYbR47HywOrN6vR1CiWT82jfh73L/ZFnB/HstMZSUF0dQPjOK8w'
    '01Px4BiD8WGprio2Mtv09lIkzFuCP2+GDfM4ZCNDoNg9TzFtUpH0AbELCbLKV2u13m74mkKE+85iHu8PK7IKlIEJDuR8yVqz3WZU'
    'HfS7GqNrgzk7POrDmUcUJ1Nu6vb9uu8TK1I05+04mFj6jFJMjhCPF/o6jO32mqJ8bmz7gUJSl1DlDd0r8/Fx5lR9a1vt6+rGCPSu'
    'NlyLwM+nPZu5ipUhCf9V9kvtokVV2Yz7pCy4lBn7fTqsLquUAJTf446t3YSSh21Dsvvd03TFttlJWSI4kz0LEUuwPF1f9hRnGTnh'
    'la3wjDAL6I4NEjhN+wbD03w1ritaJ1i1zte1Ji0HiyVxXQ0icxP40vzS4497IRDOrjq+ErAO2uuytpvuJyPLGh1ZXWpLIHkzwqQy'
    'caaz8lna0L2JsSubYTme8V3QAnMftOiw1+L9ujM4Ls3tenKq1Q9/Zq0UO2Va2YU6DN9R82LFG0hj+TJhNy1TV/zY7IE644qLa/26'
    'OI9NPzIOujxWVWUfrfyFcxBjZtI4arYZy5S+aHmaX2SE00oL+XBvMKEuL48Haz5pHvbzcUu+HpHE2atOD7zHT23jIEigalOryYxk'
    'y75Wvba6u2HEx7Na02/a6XaTiaSmoetr7XH11LQtc9OI5A5JykMt0EzvavWXlwEzdorzC+ufN2vS9dztWFR2QnCmBgfNpQiFX+yH'
    'indsDq8r/diub6rDBW1QC666IIfjyATBziMG+H/WPR5G25l1EVRrOl0FtOLE85WycE17zxLSvNvzDYGXHG9pE0VF5iNCqjgLqVpW'
    'pq611/R+VCGBQtT4Wq01s7ZvR/tUp9yguwYRWW7MpSU5uioG2qev8q35FPQFs18hp3FvwwjRZtxeV6eqNPDn4og7BPzEWhGKie5R'
    'mW9mik8KNqsegBxX2OnMEgGIeVeaaOdwVnH8taRbi+U4Fmk2tnZ66HmECkOgHS1aX/SUVW3ZAjbAXdZc2Sd9S5HIpSHVakZziW/t'
    'aIttcq63Z5VaPabq3CWcr1RgRwtyGZ2iy5Dmh5OyrJd7jC6qvGwOh9KEXepsNB7rw83wGo2XIVWhFWVI3sZ1P/Nsgbms1d14uhp6'
    'qtf1gVL7QA5cvxxWlaHvHMh1wJDDzjm4UNGO3xHGjiYFx1jZnAfEsq/V6mpX+kOkbomct2+GfOUEkiMrmkc7WvrXqeJw7YsylYWz'
    'Ajje80QQzXhYMpMV74M0O+6OkWlj4i2a2knbVVjftwKuJ2rjYRREE1fZiz2KN078WBTKtY7vOIDTE4+YiqzYcK7tdUViyjPGkaKB'
    'L3ocP5fkowzyZ+0wEfqb0TiIOpTSZnVVuQwFKp4clfW1XexVynJvc3YE46AKZGgMJjpbR371p3X31K9XhcnqeO52WaZZHOmeM5Ir'
    '+z2v7cqd6WLssdS03ZlsZdlntM6ca8wM4moPufm5GM/K+26+gT2xV4xof57lam+uD0e7x7Bj6XIezTeboTRj+2y3U1zVL23JCXp+'
    'tc2v65Oz6TKDji2KCmN4VXI+nZj9I3sVJNK4umfKWQrcJKSX+iBmw8iaKZzhXo/93ak6VcKOOK74Lrm3YiKQz5E4bjMWKImAX8Ac'
    '+SVLELLXVyah2pnPo/1+RYL+CPxFsUEk1VrAYTbTIGYsjfTEtXqNqxItHuf7hVSp1faH1+urteJc+3yVp41R+wLM0ihSF78IKrAo'
    '23TPnMjXwV6Uzz2vfz73zoeD6jKdsXG+DJBlS2zPjcFgF/gEudxWjsa86m8D0xoceGaxbVUqlYu4cEFDphuk2K7tSfHqL1xxqZAb'
    'ptsz2X7F4vvekPNGeqS7lmcajmTJba8qt/sT0j8bo25LjIaxD+xipcKAEbMOx/ty1zmPrmQ85GbVZTydmmsn0GCSz9e2zAeVTuCO'
    'r2ws1+19jXaiRYUr9m0jOm/MrmKdGU4Y8apZbk1Wfjna1PR6vBEvlRGxeln1nNpfDmcKZlpXVjZMKz3xK1GLb0bCdCRuqON2sqWn'
    'CImUnjRhpuO9FRnNLt1w1fAiD2RH6h27NuW5NMFzx4PYrFfaF6naAQwpgzpRX45XMWG1m34gD72Yoode4IJgL8yNo6AJA7KlkJ0I'
    'bTMQ81alJ1QnlFWvald33CEuIN9fSXFlMJslU6uvu4vaf//7HftEubz+24fsYupbuPfbkR8c9R2FD0Encdw4en3cpvxOGclQ03ig'
    '6K5yFOclC1OmJLEQ//ZhF0Ve+KlcNpzSyTyYnqGbSskNtmX0Vh6Zjv5vtuIBYIGh6CiAWhwVbEgtQGp2fkbJQpeloW1cHIXz6TWE'
    'u+DV+aXk1mzNilF8lBOKpIXOLyWhUVAtkhvgy7az6Krvnvx6dZ80+epCaRpdtz7El3T/kIxF/vJjligRBFUlqjxBEOyL26UrFb7E'
    'UDzFcZUqSZBc5Z94yzr1W+fAMKBvj3stktheSj6+HhriF6f0hvfzWult42gM06Dt+NQbiuRhJXFpk3gl96B1+Bre54KuhLvkgnPd'
    'jSLj7aEx9SccxDt39boSZRFlDUd/eXV7tAN0cO6BV1AEov/49/+r5nnWBQGQREJM7oL/j3//vwtJnLwXyQUcQeseLeqGS3isDu+M'
    'FU4u7F3TuYPsXHAoqjQET65TKOJVAZ92K+jmBtQJFNDvHuGoVHg18mnAt6xiHQc8S4b2UICR1i3jRRBFHD/sbVyB5OTjq9jCb6I3'
    '5Y5TqckBvHvoqHzRUiGLm4fBgKpR6NeLZWSh7l5W+yqUSpI/jS/2bsy3VzegU69uQG8mOIOw608uLYYnSyxB01V0JwPHvblWPFvD'
    'f+7idtzw/RJg1PHkGmAE1gd8Evbel1f3o1Ov7kdvYqx/3RcUrK5EEQxBMzxHMXT+imaGYUt8hWEqJLpDv8KQf9yX37lj+rf6gsF6'
    '3ZfXwfhe3ZqOA9rkqR0J8Jc4mqlUSLpKVtgXV02jqE4VmqpS6CJtovon+vF79zK/7AcmGfjmd+dNJ17dok69ukVdQCTk9XxU+UqJ'
    '5QFvOIIlOCq7Lj7pB8uVCK7CA9GmaIohqT/sx++d1H3ZDxwIAt8Ej6B63ZNXd61Tr+5aT+gScFEgasnqvdOZXN+YCl3iSJZDEcAI'
    'kuVfrBsC9ZutVmmapQn6j7tGbXijUnnVtcod5FeXrVOvLluv4Bi7yhGI0wax/B8K4U55EWuXZSolniI4kiFZCoDNhTugSLLEEQxM'
    'AUPR8In8J/LP3zhHTaOwPMDcMqZA35hCGowjzAL23IhhGko8F8rOtFCYWxT/E4fo3eHQdvfQIs/ZMfkQU2QMwk2IyShxLnT6Q1hw'
    'FNtAfAyH6Xa9AuYEmOriL+YbUQ4AX6EAKpYJTDC4vO1OPq4Nimf+JqQNPvmcQJ0BgmWrHZ5MfMQamMLRNE6YxykBICWaYiwo6iGO'
    'ZYLCcofPt7h12aFx6PXtxHjS/XfAXwCevDMR78WRyc4dP07Hnacca04inyBJBKQ/JFdcCuhy+t8L5oLlxceS7mrnfE0nWK07LC/h'
    'jmVSZcd1tzDBTVeD+c6FRETTeotPoxo46ucukZrC59yko6dEuMZZFHQG//egy6TYXBTHexRaz0IA5IJjoc9xhKPLvBSqGq53yUde'
    'DG5XMOCwi7levR8o5g+CL1KvwhlQr8IZpPGs0DoK/zmEIKM6fzqCDPUqJAH1KiRBF6bj0yvkLxZCjOX/y0D+/UAc1Kv7KahX91O0'
    'bjoPrILnBEV/KNjuP4vYvgX4fe59B/iVWkW9UqsmFpKZMbEsxB4MsY51DDs0rP+FiPE+q77HjH0lqdKvJNXef/z7/2mDmIwidqd0'
    'LS8eUTTxW1Lea2WQ+UNmhtp4w8wIDdCE/61bWNp3sELQhdDtH6qBb/bA2sLlTqQSioAC/KJ1DyodCjmMw6+ecAB1ROq9GHMcu1So'
    'pfGs39zrghp8e6nL6zjRhu1FaVDgpAqkt+CgwWn82VIBBzNGTby40gXHLU4DnXkoErW7SUIip2HBXuoa3+FJ/JCo6Mk0fqBfiesZ'
    'imwC186LWO5d8nwta6aY8UpWzmSntKIborg5Meod6Tut7HVsYvpFZbe7Z1BlbNq17379aznUAtOLfvrur9mD5jphVPhL4UshLHz5'
    '6RaBr+THQLoSzdMNHsOnz2nO8LiFvH95fPgXTXGOSvjw9Iz4taWnqfgZJYYRul8nScTPKBHFC4e5TVKTl4db1e3JWIBPDx8VUM6N'
    'j+EljAz7uVBH0zFStAV+b8P0PoO4sHWNwrL3XJi7oNu6z4UuWvSRqSmFsRGDfFELTMUCKBQn/Bgagbl5+PxduVyoZ6HYcfA2xIrT'
    'gG9JmLZPKG4jQj9ksAAMR5e4IDHAhpctihYIyreB6lUt1AisM3MLjXtx4CH12QNIS2lvprVhSxBa0KGvDyk3eXguPKRUGj8m9A8/'
    'JlQFPyYCM35M1ip+JPkqqVH4kdnQupZk4DWaVRn8qFEUw2gP37LRnE8mwr+1e8MhGtJUhH3IPi6EyRyB9pCInh9TFvXpSN6y9Ead'
    'f1v01q0FZPulsACNh3gujBCJgt8hUsHhVx4ixCUKv97ncD6qCW9rvlULELX+TWzNF73JGLJVPgOawryose3BwjTDwiMiKwq+DArd'
    'j4MW8KjXmdcEKLB4wiY6xFaTmKoKCoUXgvCQyG9pgO/vvkMX/QBpwLe+fMGUMW0nF7EaGyoeTQAKWRWBLmQ04+m75J4g59BAsfZC'
    'NIXf0vKZoSV8QDEDUTVakgctvOSrAiQ1QgHJT/hOKiQdoYCTqFupWXEDAwLf7u0MFSCyqJ1ffk3bwcCZeuHjTyk5RVYcC2UrnEA+'
    'RLU7hcdfCufnwgUW4HNhV/gV1hdqLK09aRCWGDwnDaHSOJDvbURyHUIWr9BImzCR0InqOAUm0B0HlwfS8IxGD4rDzCO5HWPGGRlB'
    'Chf89wDoAQSqsDVgMFBvIMnUG27sROnrLomcDRBA8YURPcLqR5XHju4uIhQxEQ32Mw6fmn9HFwAJ6DKuDPpnHPL99pJ29PZugTza'
    'BEEXgxgBcAhFUUNIXOhiI9ktL0oaIy3oVrMZALf5UtgoVmggSgYykKQEjqFniZ+/S9FZNzZKbEVo7h6fEAGFOQFmtVNCM0xjWkEJ'
    '3cie8fgmYSvhe9oAlrA/FR6S0I6wmk+B4sG7Db2KbXhX4sgVgNMmtcBMZ6tJmtemuIsO5jnQz1L1uZCUQwYdFDcS2iZLDBC1zeZT'
    'oeeAimVC724rVrUUvEhu4KPbzno6Lh0aERpVgC3r5+PTc4L/n/B0Oq6OIP+lQKA/po6xAIk6AP3oFmvz+QWSJAJLKq8UkKyCugqZ'
    'IR8WUz7laNev6D/obvnHwsfbP4y0qdacaMiA97YSJSJJIgriSPc5AfFeGjFG0QhCE3RUIDgwuZfCIzaJYHoDQN/pTQHICmhsSKw4'
    'pkWwhoMAQOMEQ5SIRehWNwxJch8aakPFV5NFOBo9yn9SLgAbomc6kIgEVpADY0y5stpRhEGo2dCTRtEqQVA9fcLWH1hdBVAhIEtq'
    'Ishm6z5V6ZzAsKVyEsgEeHA+lD+kjXxI6qIKQD8B63FsQZgWKw7Tcfz0hnpjYNPiiYgO/+jCTVK0zKOR2rA/pGkfCo8gpCERE8D5'
    '8PQZD5ODr0VDxDan7D4mGJFDiKR++JfgxRNuHkmzHzeWq+CFnrX8tnDhAeUEsSIT5GA+ohPw7kJqg7/VntbxueBBV/HORGKyxjFQ'
    '0+oT81sCATZqQI2oL6DLo1CtigVCFrJSQHdfWFxujSAihGwsz4nF7WSGiJinJhnAgE0EA4Ko+31EnkqFObLLoH6m4wdYBJhmGwrC'
    'RoTWt/o11zMBUCzXGgUQnYB2bmJo5EinqJ9jccgAgXdekJyOjQduiOn8LrENXVKZ/+C4p1LSRKWQWRig0xqQmQtg7QdMx6DP4Q7r'
    'jOiCRBSoGCHwjaVANxY3BLv3/jPOkCLTrRtbF2txaD2lPcJi+h2cdN/PSlilEuJNBhWwzkPLSc/38nbNI9Y9UBM9JzQT7RCPkHLT'
    'yYHTKRaszPC3l1JK8IBiQottGNEy4vXoAagxzAdi+KXCj+XvNGA6IYifJyNAX1tAkQNg+cA/YTUnb7/8mlLdHIn5guV4EmhsSoBL'
    'pZL+fFuKiUT1nFt9iNNDCepWAg/ib+ann28kXS+97iNKu/f3TtlxlSAeICsfom0ISxB1g6WG7GSpckU8pcapJED1xgzC3NZVgkDp'
    'SvpUmKh7ELxKaPBaUAtM8WOaZKSvAB6mXf/4B4DwVLIV7/Hx6wHA/4Z4U4oqKGERIcve4wGSv4CoSTwUfi7gcXN+j70ATfyE6sKj'
    'l4wh/XrUb6NWwTmAS25iBwdlxosp5RuP+hO0FxiIOxSSqx5LZthzImNrBI/6z6W0mieAS89eoHH4kvTwZ6DkwAw/g1J2q982ASMj'
    '4xHdK/iEcQLJK0ckcuRbRl8/w0dzU3g8Fn56IVA/FdCFmCfMNl7i4eODg94fckX/WiDz+bNsbnRfHkn2JNo4LvGysV8QJ1MAwDs2'
    'fz1+S0HEkKPHrP+f8UYFavt7nJyRWJjt6OIZaN3mk79HM+tiBHn4c3Cm84Fq+fxdttBua/VLCiwyGMNKscyrkRN2cNPvLA6U/Ioe'
    'fHoB523R4ET8/JzYrdMk/JwT2RIagsBJEe83F25+sJ8RfsICSWpD2J61kTVQQOv26bdW9lsKcFuX6aq7d6SU0runm5Q77I1b/7YQ'
    'VkOsDX59wDv1SOtMNjjxEzZQPICoXpvPJ1KSzwEZBn0ECoh+wkgJIvQAKvsOZZV6TaGbZEXmHPQpmRz0hDe4kD57WyGaBfwPuRg8'
    'Wgj5UoUOMeiHEIex/5TKT67zMRVYC0cFNPXEzeNgeNF3iGGiLmmJtpVipFX44Yd8L0vpbkr4aJWwTPD0VNCSJyiXpr0onPQ6Xw5L'
    '5LgcfsLl8NOLcskQ5MvhHT5cLgn6jsrhpxyOawjBofdzQ41NS88xtEesiCqYZiSKA95uAt6DVKxC6CgeMOroCUbDwDwSj9jJsKyP'
    'CBGBkSYjViq0sfAAXB81hLcXkqqdC9ZIEwE2NaQA2QVBAseux8m3/SkDC+SIOWf8N1WMH5DAExxiD4vQqTkPtQQcGZQcfA2vEn40'
    'AZC7ow6aQbRzhuUNrBajxkIFNBoQLPQXxoHLQ2BkMkmQat6GXrpj050M6Am5TQ1caGn+fFs6CTN6Rne+Jh9yLCqTtTNMSioAGRep'
    'U0ek+FmWmuiwBNaubqyijZQw47F4fEI4cMTEDjGs+9sD4mnFY+HTrZZ7CzvjDFVqqMby//iXr8RHXvm4+fYL++tfymYJWR8eNUwQ'
    'kTXgMSny9WBcECNF4tErrgs9e3pKt5eTzCbScxNYH6Ecriul3G+YnQmDB4MBRf4KSjY8fe/kKLrzioxD/TCqsfE51xrajvxSeFuz'
    'U0pY+VM+s5aKSxggPdM1s9ZKGDGwTBBiEQENYpoKUkCiiML8QN3nJ6yPJi+Xp+e0zkx6QED9nEwJZEohyTKlWipMA5TFL0+4HfxY'
    'SArDRDolrI7gEcAqCWS6a7afMgvhVxi7f81eSpbhbKPdt6SpX+8jD3UikoBr/JJV/SVfdfqQSTv3ok4J2zYBkBuOvUHENA8mO0nu'
    'L4UsMV/Tbc8Ot42sEahELhWn5cDOZgZd/53Aq7ououMIG9LU9HO+nTRWeb6RLOlVC+90Be3R4oV1e9bwL1o0lmJ7jyMl2pVAPXf0'
    'W/bnwkcQlNkcrn998EzLStjVGXMxyzKhk5g3AUY9fLtTbagEKTkJl8DqDuoUfspXeOObsAgwI8Rx3F9WhEK843rQA64GPbwYG3uL'
    'Olf+H/cbqP9WfvSc7T/QPdT/2Jqbf5wM1XvKbqT+qny8Ao0olr98K94oBK6mhNZ+OlDo9QTyJJF736H3p9uC03DTyNwE5dCySKt4'
    'Lpw+3ap4Luw+3cunGJyAfjMpf8WfUUiAb09JrYtkem7pSbFf3+JRsu/9YonjpYbTUWVphiwpTzywiv8lJ0Y4SNQx8vQtXbopiQTi'
    'BxwZZUnXJWogrQX9JAUxE4BV/A3V/TnZbEGiCb5QP9uHsmMEAFJQExuQgqjERwu4lZVlQQYbpOJuXcSXMXoia5SCRBvvM7YHpTqx'
    'EYJWnDTyCBQnMd2mhhDgn7YZIn3trpy92G4sgJaxwzwSm6rw7p0bRqWXDMPJcYpEInjE/XzFKkLjhTUXTaz+LR1QXBvSYTw8HQl8'
    'n+Et43afky94+LxvGbm/03c0IdlXxFRQY6WdEj56CIpblTd7dkYVU1L4uaBjN8NCMs2fC2pgKIfPKVYVkuoUXYfq7uh201He63sp'
    'hOF8dLAScWs8x7rzZDmxXN3l1MTKoGAkCCM8mzdN+TXvxfTJVs6PH0ks+OfRMYUEKccJ6YM2igXyLSr+kmOQ/yRjbIbct+V0uAs/'
    'b4QN6z1hAwSopFii4/+X5Y7vrUTmwP22sHHh24uUyMXvySc8MyjtfUkk2fz4kokTVilNeClPpMmlwPAsRTMey38Li+UtEPPCw1MJ'
    'ctmPgCfAqYxHGF+SAvqJRI+kHdz3F/ODwPqUggez5X7C8OFZz6s7if6HJA7rLnH8kk1RmnZXAlHmBHiUK3l6+RFTxxt/xdlQSrbD'
    'kOR9PeOAkr0X+PmHuPkGffEIvETfu2CbqLK3CQBkSVNezkCq8/65GaCI3Ayk6lOCdGgcXunTt0FKVlOqNN+6i6RFpAKkKjQJ3UuG'
    'pIiev0uISqZ+Z2Tsvh0UlrJnTAKT3Z80V7JJFJbQ79uvL7eNwlL+/TaJt8zJdlKIqd6dVyrImQ0LiveX3KZTWjjZegLVHauqSEa5'
    '7UI9oM0k9OtuNnmZJSyhQgghk6dCbusqrfW+gRWWsudXcKc2x7wtAtvp7qYctF9s6qmXQulG6jLDioLFpWQb6yXxvmW/GWEOph7e'
    'aoOCgDAgZUVI63hD3IHSZMXMcO66mN+8ywKyPWLsXwmM/RMw3huNR1roCz58qxPT5t+q811F4g4P9tf5E2W/vCmLALtvW74YgwQk'
    'xO2C6PFReS6oyd6gkqoGP/9cUEqIAH8sPKr3NBWlPeXsNTAQk82jg3hgakO8gZiJAE8I9MI4p+xlaxTbC1ML9O3ISUFJakYeIniP'
    'AOgldgTAm/pm6jr0ji06OdqTeQ3BArw5DqXDAcvgNhhokzuvLD1CAkZvA2mDeOAen74SsAT0XG91w4t2SW/xdjnS+j//Tsd/edt1'
    'vViEXt8MmS/Mw2GsRjB/mPH9ktJLJC1+KeBFcJe2zKRhExRydEQrEVzhvVh8yjNpDXFntA4eIddX8xvwYpTdi8Pdo4Zm8jYTkIwg'
    'SVeZs22amw0aqxti3DuMKaWiho8K4AZ8/NfCI1X4MUme9u5V6qBYpIkwrrksUExHhvLP9w1qrLKlFpVbkwlJNp1H9flOnuHrESEg'
    'YM1I0cIC2gX7j//9/0g9KBKH98SrKPmG/EiTbTtgTenRmQBtCKFzZhfANQ3Zm5KTRU+l3HpFWmgZfv5hTncgyMGPopdTvUo5mlsl'
    'coMS8KYImdSQ+HFPhXaD2jYxa2T2D6hpALwRMT7Ut+jO2BCEf0uOtGEGB71JPOKA0b3KtNiZm+hvCR/8j//t/4Gcb/Nkddx9rg65'
    'dpOe/XwH6DFCnDPCA1pLtCdTQzshma9L6AWgv+b9ytNtSA900s/I5y5SDunmUGIpzDKEcYAVHLxLB+z0Nrqo/i+JuzqA9Pe/In8z'
    'vLH25YOpfSgogal8TJxIvnxAzOPDT39FU4lPEn74F/PjX35BZX/9UP7pr2Uo+9PfP3/3ynkgsbfjTeQf0I4qgIKecznQXl5CI7UI'
    'WdpuTnEaIEZktCwDvT0+ZB5wpa0RNUCehH48PlD6fXSxmbiNHd4SvoXpMIHljU2InQcLmxNyrUKi+Bk7ARa8C/Lfw5JIkp+85Ser'
    'SX42y09yaX4ykVySXGmtzC1XJcnFoUUFc9nYIZuxhtxywsRB6UOYkM8PGGSsO2LvTkxasdNkslWfuu+k5ty72SfzVS+lnlda0zC8'
    '1OUn+XZLyNvzEQQDRIISPeCFr9Dnd32F3uqomHNlekRiIHlDarOKv2bfkPz9+E4qLFUip079SQ12DBrkTXvFNimUcBsdRK+TvmBt'
    '00mIa04ZTe0FiNPpMEwGthQgwwBW90FgLKTTg+zs6MgdHtGM86XsAaFaYiWHVYk3wmNkKjg5yTFLpN7n5+Xz23n5z4ztl9vYvqdI'
    'qVBjUj3m/8+YN9z448f0Uc2N9B2Yr0iM+JZXMt58g1kCvVh/ypSTPwT7+9xUpxX8YU/QtKN+OAn0KZwpOx+D3JNO+HuMXcVIob5m'
    '7KmCoL3fzZcfXvbxLgkl/qvZBryLfVZgBpGT9um1uJkTNp8SXHJSb24kOeW2QnJz9TuyWiILOb/d8d8V5ZL5OZqhqWId7x25E0ux'
    '36dLBdl5nNcS5cY8LwwLkQs8rzlB7SkDO1cciW1PqctiIsTdljAe0AY6rY4dchTs3YD5GkkV3AcNfYHFhG1waJndx/Xx7cAid8lk'
    'Pt4dXVxZDbWAx/em7SK2kInIINrcxKdIcSi0KQELJSihXZvSGT+e0XrJ5KRygcoptCClv5a1UOb8+xtZLEEqKdlGyzoQIk8k7T4u'
    'NnL9R2lo2hK9NjcqqTsIWn94gDI2kPN1Qm0EBohCyEMs9ZzTzSClWqjmFI0818TsCDnUgfLrJAiLVFVdR5QtNy9hhEzjSDtB554C'
    'VJl1ecqNeHiChfTOiHuvEDS19SVqHbYqZvur+Sm72ye2CbHPyv/GpHn3SfPQpH3MZ/Fwli3K4uEsW8iSm8lcVvwYgoyrPKVCruaC'
    'ZP30dFeJ1cvilBDwuzSe67yCGs+9qzfJRL1M0l2e/6R+hwWIRYIM6CRp4miJsyA0sJQL4jvp/RDYAFEqSMgTEan9H9FxkQKe94dE'
    'KsS+tXpawSOWr5BXGLSBk7A6p+AjqwH2ydeTML7KdouElM+vfepymBsilQ5Nk3VJ3KUzERNXjLeqEvUf60DQs0TdRbaCzIZzN1X8'
    'fBuwT9mY34YSWYNug+khm55xRopDTk+5W3JxYx5qLaV5BwwCjCymo2lJbB5Lv9yG/4CJYcIy0RygkUtWYdLPfOeTwUJSKt4uR05c'
    'yQijOUJMI93QxFvjeJsiI+o5WgtE7mrgnmGIgebeocdjlY1ECWptKdru8fHwXDBTlfBw20c0PyNfkrwum1RdA9oPJTUjWaI5Lu7l'
    'uDhaoDgXYokJAKUEAtt4OUYZH3p6CXqCtb9+l/hLhC46HHYjeIAzxmaDqNHRSF1IkDNoxl5haAITbfGfTCfvwIkFGJiKu9ycOUjn'
    'BhBV95L+YKTDNptH7BuGnMAysQh57miJsnFHwJu9EFivnm3OPb6VZkBohY+fEzmyjmWB6CYtPKD7H87PNyESC4lobzP1scQmR8z7'
    '8HYsPhW8jS0lwP1/WRG+FyNpJhmDRyStE5kKmFhdUN2JBPsMXUw/ZZJtJrDi70+JAzX+mMk2OCoyllyTdpA3dwzIcMm7eIJiaySO'
    'wAib0Uh/RodGkuDVuKkglaED42MiEGcEB9WuqOldE/epScgoDDJSuGCUv89P1E02uwtKNykN5pDMmbCzSihUCZrSnwuPuPKfIAk9'
    'A1WlnoB/J6n45VMB26ixRnHfXjGCl4RdAYR7VKEEkPUfkVqeF7dzVr+fb3on8mzJtEJU3SPJwIxUnhL9MLcLjj+Ccll5QlWTmeL4'
    'sgxSIXEK/1zg0r2B1MkuzPhgUp1agpRU1PDc0yNZQpUkO+0JuuaY6uZ08wDI70eAToxdL27p2CAOHyr4Q04sRZwJKvmUjnZSECXd'
    '23i1J49geLwr13iDH1mt8YZ/HrT8FnyuEIGt6HgzP6el4x1KBEGyvY8qTPb3czUiXyAYmzKCL8zvSBSw36EGMxOi2QE6it0dPhW+'
    '/z7zhnjOXPURNIAUSmjgfoaJ5TyClfDpJR4g3EzmEKawhOYwPL3Kkrq44FxUCWaWSjcy0Pynw4Zsx9jjAfKzhU8vZ9o7w0wfUvR4'
    'pwDzpsAFF0gs+3fvV2yIeSWvobNrKRVFY4XMMcBrsIHg73/5ZZi5hMCIp0940B9+Rd82p18L+Df8FUD8yy/odOGvf/+c38uS0PIa'
    'lu5zSrEIdbIUhBoUjVLwHtKPKC+eu2EJjT1OQQdwvr4g2WgHJCEMuWlPd2IKN+eN71OvpJ8LX79BA6iQgMxHaTIUR95KCMZ8LbuX'
    'y2yYLDOyRHH5TbRT6p0QprZfaCS/YZd8QhKGhagKHtR09DEIGNHxVlrmifgpYS3YuHxKjn+ZO2xl/i7nk3I3S6OevuPrgesdPXwr'
    'lHM7apnTSOowAnICbiLXy8w15cdCiL7u3vu6S7/etyq3CiKeUNcPP7weDC7rUGpfRjWaiJujMsWXuX+EQc/6foNLM0zr8daFCC1W'
    '+P+OSNDPYemdpYBQqYLtS8Nk2cBaK6DWtV2ShlYGlQ3qvT7km5rW9/2tvqc7PAgKAIBkiKdUBJijsQEZFx890EAgv51aSm5/CtPz'
    'jlidQiZZhHSPthtGqeSVnB4KkWyoWCn6Yl8URCIx104aQluCyYmPVGQCscS0Upkyu2kqMfniNsycC8QIaEzeMzRVGO48eQQdBL5x'
    '2f0OQsPQgSr8fN95+JikwIBmc/qEFRlYPB8LaMU84c+f7tj7oup3x/pNauYK9tJ/YY6mEvd5DnpRHD7+khDET1nh54KOyQvMOl5C'
    'aDcey1hfUCcByAT0j4U5fAhcfIjycY4USCA2P+IvOPuPKZok8OOkVDbEhbDT1mvsuGMuEIjENJBUjbVMH8R5VPbp6ekp58IkKNsw'
    'dSn+lwg9m8lkp95WoRklWIH8m5HHhBmhTfREtkyOg2UzX7rZOC+FUFOs3FUAN0k8wcLknE+0QzYWP1aCKEXXxAqBXfVAZlTN7fZ2'
    '+1hYQAdD0yQE5x2HMNRf8E9qaEl8gpOku5sAYo7RXY5Bg0aSz+9QW6JUreCli6YKsT1Ff0mRopQok8xbpsWCbPKXX6Lf4knaDrAK'
    'HcVHIGISHaWHBCLsY3efwzdU++FfHmBWo4xowzMC7Nenm5EDdzdF8p/SFm5ObajdZOsPn5bNztCqaA/770WAOFf444vCv/79jyD7'
    'o/JvQH45HhKmjwg+UNpjmKzHMLafC1pi64jRtSoaYiDEzTqG5g5mNCl0a5R8yiTS/DQRIBV9ziNL99bcS1rzcm5ZBnPFZ1SigznN'
    'izKwELV3SxIlhnnK0558MbxPUCh+ySotYng+p8zgj+l/Mlp35oLUhRd8CIu5CRsiWcCMgoEk6nerebqf1nlRxWvC95InnhJphILS'
    'uxcfdvgDzbzw5T78BlnfXTw3ekRkKqHjI6wtndL19njZ3dIwubwLKAm8B0BvEtux38B2eBeww9N9Gybvkv7xEfPlF7Px9Mrwis+N'
    'DdMj3PADdB3JA6eEwiPJAP3a2xX2CoePl8Q9vPi7EkfC0qLdp7efEuEco006VZhuYUzs4r+rrIW30OMB/TW1/HaAwOoXfNkWlj+T'
    'q1JAKPbMMzpiiVdy4rea7Yijq7tekmxE2J5KMKAOqOhooy4RFbLDGjlryE3EjfC5aSza5kT91JXhG9JuotuW9BtikhG4wl+/4Cpe'
    '7Vp5SqBk8kwp9IAfPT78LXHDvG3qpP67mUterjQeCiiNaklLlwvF8lPOA/qm4+Nafk5+ikhchr+4/Cf8k3d7Rh0CwLFjSNJ29Pm+'
    '2XRzR81EkZwfRs47uZCVzdeebnlgqelG2hPrBW4Ul88dlUpPcWI40UZF5gV8n9JPyb4kMNvbydzMpyTfysdsPywHhfm27Tt7NZ+Q'
    'Ke/jx3upF518kfFzIedinX4xb8Pwa84z/O1A/Xpfmsht5WYoN0Itu+ImvHtFfP3hrz99+Ia8IrSUzz788AAa5A+K7X1Gnm5/xW9W'
    'hF9+wi/b5OUDfkFXHX9+KPz6Vfv2dDMIB1tkkMGHdH666UToNCTgVWj0nAj5cab9Qi6EQItvW2Vfj4WfYBjZ5wJ+4Ao/FCiGQW/4'
    '4Rv2i8kdGT2jup6ReBDh2zHySwptTgAsKAe0oqZvaT5YZ0jtudmoEy6lfDW/YSsT+v1YQK/Y1pTfofg7quUvv2weiadfn9Evmf5S'
    'T78+/T0lLjWQ0dDJdiQfWYBmt/sNkNqRuIJgQwQwo615fOkiAthjWBtkOsQmRWSgQNfLGVYp2wVNMyrJXZCFKFMx0BULWFhFg488'
    '7PGDWsjtWCUlTzvDsNDlL4XJYNjoPiemQXyWHerAe1aoSCJq3sth+Te7TSCMoDUlhAWDbwlM7exY48oZKhNnfjvW9Ut+wxXWkY4t'
    'e9B0fs4s7Ap4xNh4LJS/oEl/QsSOKBEVosIAyYHkAkmVeKTDPEKmIvqGckFy8oDUg1IlZzfAKm6GkDkO/BXmZ4suM/qWQ5XENGA6'
    'L3i1deOaKmgKIDWRFEWRlSrBAXoEGAaGZmmaQn8haZuCRVYqDM9TPCSpSG+0X9VDkSRP0BWeo271sBzB8jxTYchbPSRRpXmWZ1g2'
    'qyd8VQ/BcTRBVViSv9VDcWSVhOQqe6uHpXi+ylUJgknqyfcQ2ZoQPDDIFRh01AkLF6ryNEtWqxwqY8OiQHcKV4gqRVRY1HlgvTXk'
    'H1Diq1We5yo8httCht1SheIYnqKIpCiqrMIQDE9XCZ5PitZxqwTF8FAnXSXvrXJUtUpWWZa6NcsRHFtlqngQ0nMtGdUYPudFpxrU'
    'm20ZJluJdQDy6dvn7wp5q+3XISg4Dfi/S6L5ByzBO41fhyB7NOD/LpUlq0+ZDURHmNRFimiX/Jy8vbdjqe/yW5bwlhOyd6jQY4NE'
    'Bwah54DRXYTKDSqXgAyX8KeIWkDk5xlPz5DEIi1qfYjFeSB7DUhv4PQGSm8k6bfbnrYB6JvoEOrdEQ3v4oDossM3TiYwoRlsZPoB'
    'AnmHOlDPp6JuQWpuVWHrIZ4sQE6arsI/pBnWEuwjGQ4mlKkiRKrjNUkn6A9lPmKcZhiWpCsMh8tgvGJpjqmQVYrLlwnvZQiOr3CQ'
    'ocqkZUDY5skKxzCVXJHPr4WqSomostUKCciU4SZdognAL5LhSfqGnBRNwCqD1UolyPkRqme5Cs0BwrMpZlIlluChWxWCJG+YSVdI'
    'muRhFJi0IF4jJM8CxtJpi4DSsNBJjgWqkbZIQlIVvROoqvBb4pWPyM/xFV+CBZnNA3L6JJ9faHrHlECiS9aAIP2ckscfC+j4LKaJ'
    '+BnG5pFEIjDofMlwArFM7R3pQkq0aCRW3KA4liI3vW8CGHUJVNQFOsb+CAvkgQDJsoSueX98eHh6Yc5OGFbKnO+3OWQE9w29TZpC'
    'wDFMDsfsc145SwsjMurc0qHxezrGSShUhBxPiRahI/OEjTwNbCdbxbvEiBsqeLdKR0cqdKRPkTdfBTXEziIWVpxfaKy6/oTLI9BA'
    'IwzQntbjNnH3LRfQ13/FmwTp9y36jjatguQzNj0B4wqQ68MtKcesQgoJagDZjwk8gJZMSgMs9AkhIRB8WAIfC9arjTAk473TCSrt'
    'BeAYDEhydvrHVxlBE/xXrG1ST/gBl0gWLC6vZYpfxjkBB7fwv4pp59ev2jO6i40A/eUr/GrpI4Efz+kj+pBmINJHDT+ev337+phQ'
    'z43lusHjDo8ismiw+OnbGxzNA/DukvntxQLIgQcDodp/BrmBoLYTfw98zzCyH6eOiNgNzXaBsuLdWhP789wcFZ9TPyG9kHr8/LYz'
    'VQmJd8l9A1hO0w0PC1T4koL0aiHdRPFHNCNzQwZUSer/9HKrGln5MqfjOEq8IMN0hzqNd4Ba2txiUbySNpGhGpeAAdkZt0KlJJLH'
    '882/JbmcCps8FVzYdKKci7Ri4w5l45JJlJfsRKCtRCCeJS7qON02jKiEN+XH7gkZzFHcFCPx50TKKr6qLLteEAYyhN4bj0+J621W'
    'LHG9RY0uDD85EHDbTMfTgw7AYAk2dkw/NgqKFrjh7brutPZ0xJE3N/KTj23VUUzkNuC6TzlvDmhTeLlxt8n5y77wH8wOyaO0+8FC'
    '+JAC/hVX5nrpBntGdL7foE2VTSlAaxZ+iOT2msy/MN03z7tQvYP5jzkRKXHP2pS0M9p6uiTPl6e0dmxcyrX29JQtAOHm5JC5iCSa'
    'R3aLaOrD4KB5Q3e4YIEDVge6mBLfV5sevUK38cEC2sVq6dVA4r7fvTC/N8NurD7mvNae/l/u3nW5jSRLE/yvpwipso0IEUQC1CVV'
    'pCSaUpVZlVNKpbqknrReGq0ZAIJgiAACQgRFotQ065/7e23M9g3WbP/NM8y8ST/J+ved47eIACVlV/WsTVqViIjwcPfwy/Fz/c5n'
    'HC29F9y5qc86dXrNhZ0u91ZsD3YoBnqE6Q0cY96Ns1he/LJsC7ldx5trxhDy33vu/NGT7zx7PwLfNIb+4DFN678bGY57NKY193dn'
    '/G/nUJ3XFUbfSWQrMTIszMac9NIkm2arunK0yVKAniD2Zeu98RyIHPfWhlrds08F5U/Q3osl0d6TRTnNXdDHuz/98PMPFqqL5eBW'
    'MZ4F/YOkuwKCbHDHDBOu96eGMXmyQ/RMXj96/CAf7wiqJW5Mx/l3fAFTBhjHwWhfYuDw9PHYcIRDjaWbHIiuYgKUIUTu9vALAggV'
    '4tAImBtGfDAjO6B0Vvd9l+CKnecrfSt8g6WG/G8nlWA8DIP/zNHD0aPRk/AzR2dGBvzOf2b+MH+U/95/5uM8e3KWB585yh9kj/Pw'
    'Mx8+8p+ZPcnOxlnzM7k2PaXA4picTR/kQyyOzwzCY5zng5EdA11UnxkDO1IYA8UMzVard1hhYSiI/aHBIANgMVSGcNdSELpyjB/j'
    'LeWH+UauHAEifim20TUNhSH6LE4uOVmArpetncvjlQV1NZd8jEhX4si6GLbA9piA9TKfNttmiJ51WAZ6s8D1YQQ+7bvUum+AoMLQ'
    'TqZyNiigrt/fZ0Wihudn/cnQQHNgJj0A06akgpc1LbzB92WTGtpi/cy+6FoApau2aSLXiqHB57VA7b1lPhNP4mdqOE71OKbGGYbu'
    '/DqDN7A7UE0PeLKZIn/N16Fbtjb/hwJRW2TONuERBl9f4NiKk51ZM9dhfBtODwGRQSCrv7/h/Y2zus26jSfWbTs4kUz936K8tXOY'
    'enltbRyhBUvm4grzcJ7GjOm6aYOembo+MIpJvI2tVcWQ6g/o+lT8ka3RfN08SKV37hz9AOY1DQ7WDxvc8MY307Wo8IdNSuPcHqoW'
    't/vLcTFJvv+f/+9fC7MDFD85q5Jj4oP1qRpfl3PEP9ifZskZPvDELvTQNc7u4R6hiLPBNfWXPN4zeF9z82/wZCNPNnyy4RNaG71W'
    'Lv/ri7r3pqGSgxqV7lFvjsHTvzkenfQpjoz9gxEf7OuDiX+wzwcP+CAYWT7lP/YT+nJvTIEBl3UsUNIc8X3+179v97ybaqNzub3l'
    'O7iwt+Dx3Pi+42PpjanAPF1A0lmw1ETaOznxqvnqcmy+C9OJT4NNVai4++Lo04epfCA5QJCsGkxaLSyb/Ql/StO++ElPsuXSCy3q'
    'MP3Rig9giPijvMqQdaZmUEZf6ceZZfYUSOU5FNY95l9b52eGekxDj2kSGshSpqNnAu0ASAcv/iPfjTboDFfWvDJiyO6z5OETjdUN'
    'FbWum7tAggJXai6wggvz2eYNZ/w86wWLOGV/vfWK1q8ShgjTD2Bx0xRlAQhsZy5EXLjAAJu+XLAvVh9BiI6eqWTXvC6kp9nugm7q'
    '0jKbMDfU1MzGeWmNXrpezosQ8EeHqW4YdOrSGRfAM+AgWU+cOh7J9UQORMKg8grA8OaAoIxlTsxTc+s0+Z//twCpixWrVxWzJbDq'
    'LtQ3mAdKQA/KKyLA6z4wl5EzN4iqIzR6EDjygv3slDSWwqNQqqFdJYOoVbU4W/ZY+/0GEcWRog/mSD7wcH8YaocsAHtPyN4Y9E4c'
    'iHh6oAf30RAJYE8o4BikT2g9jxxXSFTDdgNnfUcCzCLeNwUfBDQquDU+iWYFR76g08+LizyQyC0sRbZM3u7JDqTsrplDiIa9XtMW'
    '5HcqNQUuXIgsQAU5nkJyJaKwjVyCrxCELUXWXiZEsEDWJBtb5IQvesMVIGJm0du7fStKoBmfOUtwocW7c5D8hCiTrCBys/i1m+U8'
    'FTkw6I3AEChJ8akphc/j1xmhkOoH+RxiKwNikfYlyy/5cYswmwRZQVyiBskvZ4owXlaKyYhevQ0yNIYWrT5lHZBDCEO5BIOgZz1a'
    'svxEGU431ZFcTxBAQPbz7HLNKqny0N+Gj+q7UO87mlLAgVWtL5dIJnBeaMfO8iuvS6k0l6WfcH0sHdcVI4BB1geBplvhBk/R5PI0'
    'DdJlaefNo3WeV6c4uapVPikYP8Axcu6IPhkneg9FF94rr5Z4i+SfcJRwC7icT+mHLGva55Gxa3uQ/MCUemfaREHILQeDAb6PINu5'
    'DJ6sR5TCJGCsaNk8zepT3DxXHlpGBSML8fQgOc/mZ2YuubYas2eWMzzgILInCIwhzEUYEBfSMVH19BNqf40kLkQNVFyeBOQeJK6L'
    'pcrqw5BSkAgtrh2fdRPfGsut8UnooLvYsO42U9ZVNwmsqWnh6x5Ht4QKue9lbg5k/+it+omN3KGTzAWpsgSfBukXYF0C/Osffvjx'
    'xT+9eveWKFX9RDwFo9JcWPHNJjvG/q20fyv9eHt/qfeXch8OtKEAEQzz8+i2HSH18LVxm6S5IB+GKIEyZM6Rg5pWEidJwGpWLezj'
    'ZqlsI0jea9JUhm80VTVNxk4sMs9sCIz13Te3cEaUzMPhug6RY89JKnSCe9y3pimZyks7mfi10VQVw+TmxDM2rPU54k4Chx0KzscI'
    'rRudBG4zAmQImeYo8Q0g/xrO0RIJFBttPVD4hHZnords2TSyvtLRJLKsSm6AqhnNtQWP6fjYDLdkSu01WA5IWrKC6eECqwLCBY6d'
    'YrSj/rtR/dF4XXK+zdwy1jV48NE9WDYw2a7CqfzIxXnZXJwfuTgvBxaxTT9fJuNYac9lPzE855X5hssBuI3d5CP+QjSIStxFkQfm'
    'cVwsbXlrZSTCx8OBEQ6HgydYALe0C3JnKn7YqrjdvhZ91N2HBuDAWDyfTTeAsrEnf4aDB/z9AD8f8ecjdpI/nyAYZ0Tz6qjV661L'
    'AWxgYzE8tkJ3wCaOhieWRLwIWSCgSJitryfPUq0hlla4I2cJqmC5nkLTGoHZ0nQKST6dWV5LWjE0pzfUO/DZMQd+IG6RyVJOSenN'
    'Gzm84JQFvmMI4mQkPpd0g/vOU6L6B0I60hdMgbSpSzHdJLBf4z6hxdEkDVkdLwoI+dZXg2DvOa1MIpeaPlEFkTbpIZoI5b4PKBCq'
    'lvjmB5CUDwMaGESXgaHaY418J9Q99KnEcTcwSkeRIaMW6/V+pJsb4f6u3I8cWyinfLAYAiqnfPDwAtPbpJRcWISwviXq6/pC03ru'
    'vrKzwJ4tYFbxZkstLICqttXS185jByznceeXMOdo5yMaHdl6p3CPXqK/U0TcLDcSjomf4hN0Yw3lYyxTmxaqmiDi+pnLodREvXwD'
    'fVVVn0iiFW7q0O+UHogo4A81Lu4UT3afRTMsaw+zvwTMoDiM7HN/PxpaW95CAsBx9jNk4sHwf/x3CnJue9pWuBdub2elSrqonRgE'
    'B7L8AwEWe8xgE1PfUxmVSGVhF0q0rKGoeLyfRtoGPSw5XmTQfA0tdqO05kDvLOvmU5ZWiWPpaaDhHLGTQakNS22k1HlUKlxoZbhf'
    'n4Ll+KRDx7FvoMjav2ZCRBNtqaXEv2ROIhSN0rIcl2bVVblmy+xrihtiIQ0CV+CwR6u4R4+xvhvq6+h5E8vGRoAY5rf3gdG8rOFK'
    'rqBdlu97bJdWTMSzpZPHLoBkRImJfs6VLkAjK/9VYq8V21ChL6H0YdNgmtnY0DW2z8bcfzD6Kx1tyL44hojfG/eq5CMBQg6hov2q'
    'lImTTVtNDu1ufuPd/ZU64IHTYny4RMZRZZWRZ2ib3Ma8X8I/kxWxCCbjy8lFLimJCPQ8WxfT9IDvvFhuequ6SukRILoOLydifNZp'
    'S1z8QB+AAiJdwmA6Jjk90+RGPp2Brx4OFwxcHj2OLBprau+ApvVztkImN8DemfOt6CfvebAVEvw9HIL/et+gbx/4jXUgHkJTaKoI'
    'HVewFb9l89ZGYO9v7P30MOmhK0BNQwofsxJ5WeHScGMnqT5JhSX6oOEZ1mYio9Q4houhPQikPaUJdDrS3hSjjiK7UZH37Vo2jVre'
    'jzqKhLV0EM1iqLrdYhTiMOLxe/P4vXn8Ho/fm8fvGzCNXFl+uMxoc7Y4bGaoYkJY86M/CCFcR9Sv5pcogVg7C5TH0tcbmt4wcWEi'
    'vR8DHZnVxVhljk1wAR3RIHUcp0SNyG5RLxpLBZ2aTjlQ8JMHFF6VS7TMobxt1SzWdCgC7R3JkImgA0AAUesryS8z9fUul7nFliDV'
    'WkM5J6SFEreympLRhGAQouB3H0r8CbK37GhfE8DlgWcP6qF6y7HTax92S08mpxGllivwkoLiWkNys5pqQMO9GC4zV0REdRxKqO6h'
    'Es58+iVcqdTNnAqOZEJtUy+L5ienX4//lFCj7aWLN5EsESow/hcw3HTxkYYRP+IYFl2TbwLvwJUoa4QbFCvIV2sooEhDoS7brFrH'
    'I7+hWIMRC//UGUhWCfQGp7BoG/bYTN/pHnCVBnqFm4bOgIm07CgeyYdSe5VazURDo1SP+cIPFA+kONKfueKRoklFQmued0tI89eq'
    'B0zmAijcgtLta2Zf8vZh5SJ1kGDHDByfvJzGruCw8pHkwMgIMYM3ru2NJixWUHzYLD48UYisdivOM3sskpTz3+Z1YCoBYEP8ai0q'
    'tZq2mlpmrM60JasuUZ2drxbV7Cba2ubAu4aHTzA7H7vf3dv67p59t63gy5NzBdo6nRbrUx/Mb3GR6+S0PnV+DpaseiGaQrvdNDUT'
    '3AbbxpkFh2oT7IXb58gsfrODCIGx23x0TklrOOw69RSD+MHQCgeB1aphQWyJeXKQmW4OIKrBisrJwg1IbIuU2YaO1KBoVrwYGi1X'
    'Hu7NuKrzgkMfV2debu7GPN6NGEBsxtoqpPc+6u7ag/Lrhji55lke7km+hIzh5oMuWWIcA8EEgmsuCzCnojuXpZlnYqp7EAJmUJPU'
    'scytxjy3PcxFb/+Rn33Bvuaibv/Ij75wmnRt+zIsObYqPVsyHwcm+0hVLimWDYMPukPkoYPEZbrRtMQ2ExxjNw9cljdULO5f/k2X'
    'Uu5zr3qEaOZQ+5cfX7x898tfpDfmqD9gsHVf03wxnTEzyiEi4LF/93LJhNjqrxT4MjY0C/KceoVoedGEyjGjxRVZQm8UMBljIttX'
    'c7IhYSkOcELViWMBsmJMDwIbpMKXWxPpNlNocKav5uaJ1xTKWW5xtr9E/RyYesdQSwWmXrnlTb0AWQqVkl9utggdaBsDo1RsueOw'
    'IM1ALRuDEpiNYTG2vnA0GcfeHRgoMeHasTKC+YW1lfTBbNAy+TayTVoZVzvTUyHrdEkjYiEzVTVtq2gHZ6a1rSqbp8Bq4pMbW+p0'
    'fvn2QegUJwDLFXKe50wSRHYRPGZ5pobIWW6RhMTrfV4sxmLzc4zzWpof52dUDqmtF+B1oQV5clmrQpc5qlWUNI38cuYdZLQVOtaZ'
    'IV/3YzxvXb9BQiI5gKxYfFoZap6vq1MFWLEGXE4NHQQiH3kXAdBEpZXlZj4A6MdaJyPFbwH27H+lGe4Wa8qzhjWlwz/ic5vGE/2v'
    'Nvb1dZifxdsO9biQPE6OzYHUUEl6Uy+1ksfHeJNGCdg97kZX9uJJeLEflXsSXe2fnMS2IqSi1zgCDBu/1vDzmTiYm2YMtZHvOdhm'
    'kQ5y/sjGpA60EmElbeq1KDfomhBAyH8kgD7hfPnqP4IjTmNJItEhOzp6JjcC7YI8QawB+qk0SxJ5eaolqLjWeQC9G7s8X0ZQN6Tf'
    '7WrdlLK5sX/Nei/Us0HasAEhjEWxLhXytPaBy4vufVH1rI45DPgLNDzjzRuXI8ve7UL6RjUcTcXCxVjbd6mZcTkQk+PBYOAezYJH'
    'qpNgvubmQiQu6kXFVWhfjhePAqkXYI6FPjxTO2diXmzmIglO5swi7fbpTkD8XSddSJGxLzJ2RdoWRY7ERaDgeuNwzCMqxO6lZFt1'
    'bPB1b4DzTaBZqq3epC01oyISIIihpP+JLoPgEFwluhVK2J5kNULtdpT03knQ0DyhQG3OyJnoB6lnNuusPoc/UBCX09wGXc7NK3Fu'
    'vqI4bBXn+0OBJfNK8v0AL21FeI4/h7ySBe/ozELyLNl/2BABvGXgz2IZ2H+YHnbp9Imf/DyhBNJQ5HOWnyfngd2fmsI4a8lhFOJr'
    'um7mRQJ78fsf4Q07ufKuxIIqFPu69CbeO2Wv4atintmSWxw6kxcdGVis5m9ExV/yvSvyvun4iXPsxXEB7+8TOb3M1Yn48H5//F7v'
    'T+UqcJcwX+U/6X7iL6ciOgGhyNyb0D83s0XkcswiLRVhsJBVSahLOa9UifBGocLcWq5Lx9yl4LY8s7VJInaLFOgo9MRu0f5g9V4P'
    'w+hXURBYjYGZ0etRGDTberxpv231DThwN+23/WN75soe6DhxS0tMOzVSgRGLJh6eiyvaYiQGi6nrZt1JFeI9+ri5RR8H9VLyuzKz'
    'eE0wwpKLFD4x1yO5hhh4bp5vhvZ6LwF2zGbUbBtfioPyxXqdbZilrvdJ/WcPkgcPwFP1/sWiPkfWvgf76W1qgX3dEILjP/tp+X15'
    'DeMFlzf/wjhnfmvv5ceu/GB/+/ZD0q9aq4ICrOot8yNH/KWX0CbgqKuQNQZ6shnJweB6hNUzGGxGhhy/nBerVU7XOzp+klUHPJ5p'
    'NKTC7tsyiQVGuC/r6XO0G/7Ek4Y/saM9duXVQ1HU1COblCI6ZvvJB+X09qY8EFHdNWORcX09ktpxvTfd2BNzIwU2XP1szrN2mJ+V'
    'MHA27cKHiD7IALcAjXw4ygezGFaHQWV8ux6G+wx+/2uLSFaPwh1aj/io4Qs+xMFSj3Rif1l2CJQR/aHm/O1//aNmHYfo5Rm6nhUt'
    'u9yBrS8w1fQiHIjjMAEMTyFUnuJB39oaek3BFTpT1bZq8oSQ+FXpIPlBPPKKCtL8cin+rZpdoS6dhUOchTVw+JyY1rFPc+SCTGmU'
    'QWKSGn2dx57TNG/YUDNqEfyQMKAKMp2+f6CMK6OxIRJqch4P8mjZYeSHz6JsDGCKXlltthgcNLmogBj34S0RsbGfZCBtEkQ9Xqwf'
    'hvgKKFrYZeGLnVOVsyMRiMzu5p9Vki8ROTKfsb1AKgM3AhXs/UiTdExzBdVOiGT5X+aH9PWiLOjEmwDd9CIlJyujaBrc5h2LyWRQ'
    'i1qFUAU3ZPR2gyE+PgkBFM1qeSEfe4Gy9vNh43Xs5lErJLHPF7+PXsRw29eW214TlF++dJQ8AFJz0Jchc4WjQ0e3u2itYgctUylR'
    'GUZpDBRMsiQd/UyFy44KR30BeR85QE6JVhLUGx/MvrNj00gGm6ouL4GzYPMXmp2OTaVTDQgcCaIKIqgCvJ2cCKWPyRIAhvGJs4A9'
    'GDxyd0dqd3gjVtvQd7BXFyuaZ+Gk9+c00LXN6XCuZygBYJckMkwjg1AM0mNosljbnjAO0hANx2rIMA1AU1t77ZORnX2aGDUNixhe'
    'rA7E0bkm3QtCSSZMaE1DqTRR1ZIJwIHcsX+b8lJDUOd0xHEgX7IH4ehv6OpFfoXskG4XqlszJJZaorqanoDFKhRr6sixz9xwK+bP'
    'dPCLZNi1mJ8KbvG1GKYKlWMxBbbN2PYI3XWPL4nVH/vFXv752Azt/eQBeV/WJeZ/W2YTldmkDfuHDcV9xsn3FqNjXolhRVtyphUs'
    'lcCoQuvn5sC15h6g3K5/DUtRk79ur3f3C+vda9R70mVNkyMwC8xnWVKZcxcH9jJvwFb7bYDlVV+aRds89JLe1Xlh15yLf5IwHUiY'
    '5+VqVUgoh7oEzcsV+MWpxYeu5hYE2zcnjhV+q6HnRNe+ownF5xIChBadosB3yi9dPvzlzBkA6X3asYDXOcq8PIaaGquiwbwDd0X4'
    'd/5CqKL9DW+uLpBMPgxo5UullcHKVz+d/Mw7duKCKx+vB909oBU6cGjTRaqhhy9lz3HEeCE7ZkBIk97n/HKfGxL4KBAkwnhEvaet'
    'O22xem8G5PelAPvIeOMUINFP/Qvq1xC/YsvbU6cfpQ4wy1w4j5cSp1usLEfxkiG2Zr3Lc/fhI4kbMA9sSfdoaOuWBEIrv7LeXxLW'
    'g1IMuUi3EJXtpA+AU/WvSgb3eRkJu/Fz4/LZZSDf6leCXjsyKPDbj750XL+kPb4ZtSh32m12zA2G/fTnbz69pI4BKJj8tblJXuLn'
    'yN0c8SZ+7bt7++7eA3cPpDgEBIcx1AGhwkBqkSVoIzVb6xSnr5mLPdxC2qfNs3vffMKJ/mCwj9rxc3/w8ObeaXLQrqes6+31gC1p'
    '1rATMqZYIX8S7sKdElaHdvp0BY3k9Nk9Mz4k6fhC0uyb5JXeuv30cC/cfnhsr273y6qLz4yb/+Me0ZwwjpObezou8dUepYJn90bu'
    'BkYWIYTP7lHAu/ft83AWmTP8gwzLpFibDZ9MrlGlWYam0slGfm/M77Wdv9Fgn+78T26C/kCCuWHlFuBQI6FFfDM79IDo6pWX97K6'
    'zpCTz7tQXXWtKLcSrhSqG0DG2op5WNn4R8NyWYbKHJqw8qtAp7BWO6ZVOf/M+VpYUH7lVEVP7ISzo2CVfPNp6j4UFv9w4K3s1hp/'
    'jNRu8vubaBom2crOghH0sklRm+EdPMCouQWMjphD68uan2xpu7ra2rCpzuyjG10F2pr1C3H7pif0zdJwFYpT2aiQaMzAa5m02XXv'
    'mxJV91YgNCzt31qlEkxbKajoZZF+zbjURgysxPDTHhqfQ+EhjAvwsk9NPd98MiL6jbh6PLtnOPeqXB/Q0TNf2y3TspVoXDn4JkWN'
    '02MqM7zJfOqyD7uV7rDc9KnwaCIhlMuaee+LEJpck5KaI1jS3LUziRLSgN7Tr5kq0KYR1c4KogE6+/1lMddMY6o2UoUTVINX5Zp5'
    'l8v1tFhmNVIjXhbPJK9VgIJs2AGzla9XQCNW3OQwlJdwb5dFP1GoIQdPFGpQ3pn7Alp1zGJqhHb5lsNJt0lVcQ/itksHrFYxSAE6'
    'RNuNh15OhyOWS+bE4gEmXaelHQXSzlpvyTwsSXwFrCzCiNqektjjq0mIVZiiNyh6pkUBRycepFCAfzIk+0AiqCabAwmdWg8P2mbG'
    'tTczrmlRWI8YzKrsNFDlAsUnriPw3qWvxOWAjXKyEGAQoG6yZOA2IzBmVDfS19pCIFq0v0PRVWbMEdZXpg/C8z3AZ8n+DiG6w8R4'
    'qKNyc0dBIGeelJAVENBDwwbA3a1cWl1dS8TgIfJMi3jQOYX6UsyvdwP0ioBcpcO/J8iIBRr0OZstng6ShL0bTCxaXRwB15z71gTb'
    'SIjTbz7h+uZfv/mkFeEneiFMmXoccEiOzSsnTaGHJMI/RpVo6JtPisS4u2sr0pgww4NXQTKCThiWZ8ljhWGR4iTQlUBAnJlNBILb'
    'IyjiboxaSN+9bxEO9C3XHY+rcrXHL8NbbtiaWH/yWpreWKqM/zjvbBzLKpv/0WNJorICJ4Vdcf+0NAvx2b3LKl+/NWdw/svynypz'
    'eAjXA9hFx/YAd9HyPdLJ5+ZoxYfePP02bsh2JZLKTi/X897vZIRl1IlCHwTxwQ+zUsUwg6/itWuTFse2fnpWbCN2niwF7hJdVGca'
    'gYgNphGZMQvjlXizn5WTy+pdJpnhXKqigUKfVT37PA0LhJCQHUWVdzs3+5x7XYIfzLvsgoyJmcye68ZRsvN0FnBMoyf3nks+PTj+'
    'OiV+5Ga17GsGlAg7AVYEZrtd0okKympLtPqJB5h77HInAvMbusiDZL+vi+2TKPYO3PSoqwn9Q3D6nSME7RSwe3v4GCwfPIWYckNP'
    '5ejDvp3ZbzmMM70oIMTxSaj+tBA0gTllpwGP0nMoJz48RG+pRwdDn30EikrOqrwh0k0QyObiubwmPc9fNJx5cO9NXbnuhpY/eqCI'
    'e40OWMO9hu91W3FHt1lxh5aWauviamEmFzablguNxnizOyGrZCilfBEdZqjSgR+R3pvJPedAJLWfNOYKvlTvYKB65oLdtE9ilzej'
    'LFtXfVFw4xVyWPnjC5pAOQnx0DOHViTpa4CTujXSAAbVOwQppsmFUs4pRARheLm0eXWBS0ycXk121vuVjCR3HYFd7F7M6SuKJvKJ'
    'hFNKwgiLdcM23YadBf2sERB0ZV6FVsusSdvxQeqxd0EBzBdfFpKMJaAtpnRy14PxmstXtLP5W6975iYy3nqemDd8clo7hPdeCnaq'
    '9BiYlBjqe33FJy7OznLya7wd+I0iXbaDy7WMS6G5fn2marEucPLEZdBwufClE3WUwBTfe4l84bmR87jDiKQMpvqFxXUFtJfgZ55j'
    'Zq7MMPsdxtrFJmiXR7CQqVz9ZfzejO7gYza/NKQVPCu/Nm16oyFbOgI4JEN3uO2Er5gP2NjRoC5flVf5+mVWKSutKatMKcwVfxhB'
    'wXfNVOcvLE/x5sWrH969++FYu2fuVr3gFZuk5x9sQb1xEm8nLoyCRg1ZMsHKuOXDF7nkDfULZD7QOKxntiazjcPH1DXbh86HZm63'
    'ZsRIEt1Jbbvj8lqypkq60mXochbDc8Y++YFBlMnpCJV5LkilN4dRhjnkTpxnAZjkKpvGiduHfe+KICEVmTjh9JOxoq4JZKd1OcRL'
    'mbpxBAX3fEEmuks5+/e3NbRhQ+f2fUFuO+9oSPxDgoJ7vqA01HmycQOJ5gbcP6OVxelQ0MRyG+q5tpFicJmQzVwVtabeRjIfG7TN'
    'wPBgGzsIL56NCxKAAgEXYqygyUQDJBFAhm6B8vkNKi4Axy0TDvswK4EehpqBXcKICmQYW6Gfp7SqVKfsPH0lzCHNFGempd4nm6wN'
    'iwInH0j5ZXWZzV1KU7N5SHRSAL6p5784+RgJLbbJXAgnoChw8pbSQPanAG4QulmdF2f0AJFWNFWmuku7yuCAYlELe+roUdUQz0pn'
    'wbxQYLYgpQmtVmZKNXhUm0CW1QP/wBm8BFMethUJWJCZ4naMb8k48Y5wPbQSMOLADJq0wtgyReVjOD5CfPP8rxLEkM2gbqkZjzsI'
    'ojjL+kfS3R65PM1sXRFwqxGZFkFw4OJlyRshCscWsQmhZxdtXAqFPQOPeMFcD5Ioe8/j6zI14IXsofuEVPkuNOZqn2uHZuGZ/ahA'
    'BzYLk0rk3QUjcBcWbENISpQY3cMkRmwQoZ1EGC17vaDMtwIgSdgVX43et9rkeDG2oTqOq0KnipymTNoAzklmh/RiSKnjDP5nG/VG'
    'G9qEGEQ258+94PeQ8QSP9Oee+00EJS3MnydtiJC19YOReP4lFPkZlPvs3gBJELNrd3nFk0GC9pebRlGeFq7c+YG/r1CEci174eYw'
    'SpEnRuFnYgAsGW069CXCHIXUsMAph95wPFkJ2sW177/OHVER8PTKqoeIqGwPmHITl7F6I/45twjRIXiKqfVp8oDQJxv8SuUDdncP'
    'PWoHyyg+yoY/U/k2U8pVd9OYjolsTznIXc7WieljKlqeXXvoIm9N2Yd6gnmOGF/KI/9L3nqCtx4N9TUZ/PvApdnV4b+fPAw+OQDK'
    'kg32iBlQULwC6sUDKk9cmew6DV/JNpIwxUHvSKoQDdY4O3MOejwKSjG8YCCqCLCGQ/PUETGomgOCRmggS+7WbYAZiYnR4kx/IUg0'
    'IXCuDDolNBSN3UUE5SRy83hfjjvFyVu5X5dQUjiEWSlJqeswsk+9ySLXwIZbe4uBFJe2BuMYgCWRhxx3K1qcT6DhFQ0/U+dreFc/'
    'T+Bxzc2VcRXbq3GkH7Tuhd4v7jUzob3uAS3Aesc5mRMqg7RT8SEBhuY2dfhUl8wZDW7fbci8WSjxBvfHev8k7Tupd7sv9TMfY82+'
    '2fkPDhgnyevEZXVuJTf4SK1DBxJmLhEEHy9SS52sTTtCy8wtclbyC8btqqhyz90wI0nlncKcasXm4SjDDG192w4++eoWmTNVVojQ'
    'zrjjahyEa+6yLr0shuUQSFZ6NxbQ1AOGwgpB09XccJRAZ6pXkI3juEFbK7KTHJl1i3blFfxE+XcD8cq0mbaNkG8F0fkkUDTPJ26v'
    '9dzHBXyfz2a5dm53B3BpIz99lUY8wQtaPDINf5G1TX01XZgjFbU5wrBD0WWbROYF+JHJuHH3+zT9u6izqX9uqasla+YEjvRjq6Pe'
    'oqEGDcrWv0FDfT1CyRe0y2/0N/TT1/v4/b3c19+bSFcdN+k7xaVjtdSmC+npYTjhH0KpljEA3/OIf+FiAL7ncW664aTceCC25jtS'
    'L5cXEsc0JYzvB1sZbyny3bV9TDy8KZ0ER0yNZ7mc0Kd/WhDCwekPEOJJqirCv7kc+0tSsl6Xghtr8fM67nFnmeBYML1JvTq7ocJ+'
    'dO+5LkVXIlBkexr/NbR8briS/cEjr6gWBAOEnqineuBRHSuqUZJ2F1FUez/1A9XWeY0cqA2UqNb3AUQD6rubWz4dSu5bTonH9pQw'
    'LQg952e3DorH8B6Tj0IfXJNgFux7c/ep88mBW859ro2b0Fr5zkcU0PxM/AOa80tijtNXZDsAAoXGgDF5E2q4LWuSpp85Frs+2Ou3'
    '7cdS+XUTB/LFX6rfhz5gMCy3rrAGTjlS2UR3CiK9pL6Z8j40wdT8Coyec7/TwDi8xNzlHvfYH1d3e7JIeOOHaVG7ZdLKUE4DLXNI'
    'wX1s9MjSIuZTR852kKTHw2Hyzaez6mZ1bf7++Mvrd944qXI6BTwwiKPv4P42GkquQUNghGqJx6vVnwQaD0CU0zEl56mOWGaoDjUr'
    'D2a6ITZotL1PE68fzkzxsH1chVZzM4t8gb25PVO8P6ECXBirAToI5P36Cjw/Um+fi6dcZRWp9zGMu8kTL/LdNER/EERVajQ1GnMx'
    'WTW0TnCSkFSUCw3Ooxy34Q2JxguENoYLbFY5POwlI9aO9QfZSZU3mfQWqfMK4/k8tc5hNl127bXqMB0Qciyr7ErNBSOYwPcu47wa'
    'UI7n6tkhsO4Wep36VX6PO+xEqcszeJZ0EL0tzj/ffMLOOkp2YuotNrub508RCZDQeMwDGD9wKns/MHNxnmNd4eocBuVr74iE1L0y'
    'wOKHZP3p3g3Gs8jFr5sKk3sD8TXrYtLhCLb1rX3mn90nj3LHi6J+6fZqa3Q7fYp9L5+4GPiPRHJUvIJV2CskdR4+AaX3QAbBGon2'
    '8Z7hQ82nZst6D+FMaMWMMyTTbG6+2ez6vbNsUcxZMbe73q2Kv/LrDSnQO1c6lIZE+NHCtxt+J68mZnMZhgddeH7qc4SazoVn0I1X'
    'JFgiBlbgFhrWud6aJxS+nzt3yI2qjjU4bdxJKIsQt5ct4ADBrxJrPEJzcJnJZeh07fkz+7PqfcYdoDtt2DUzYQapt2STi2uPy6c2'
    'afDVS0u1mNOzIPowFx00K86UXl0x955nCGYDevJIfBkRmCA/yD333qGvSrCVDsUlFIclNe5M7tibpFYF4aYxrB4uOh21IyWZeO1I'
    'pbOB+XPUyCy3L6b+1Db4boCEfEzZ9/BR3Kyr/92AeQcb1Y4Gj20l5lY+4U4NK6OwhTEKAGLbKfGC79gJ/Bp3OobKNuZH4soweMQN'
    'ZENs0PXgQRo2LEsf2RDfZWuAgdCPCWvffyWehrqJ9XU7oVv4nJ9CRwFF7mbqKTlnzKetM4pjaSsVoMU7VLIEV1y9pU46S2pTp95R'
    'Z0md6XTjaKsuaFxv5Ppcry3FOIuIa9Xlv3tj/mE/bzyNPICLkSf4thuOIE4j0m+6ERF/0w3XxfX1f6A3kbOO+JI+E5fDeWbGiViV'
    'F8X0JdhaNUPe4St0MgqPQBE/xT0FYJFVBW/aaY5OfbHrT+NwfOIOx8A1zZ1EwdLyvQnHdI/ytQ6pXIQjCk5on1408uFH0AMjrVpz'
    'qG8r2DiC19eCW9Czrwmc5la/a565rVnav9cRqvA4eej1AHQVlN6YwbCr/m642z1mN3VYOp/WwYcBgHOLGUa+nbhcoPcTpnQKEhr5'
    'aKtgU4KTtaTjmSUeJBHjWXKgj0DAq5CrBT1HFJJlpuzM6R7vjcCDD/v2QKhYQT9aFo8Mz4SD2L7yqJ88uvUFs4zSwwaCtqXVw23j'
    '1+yY6dMDzR+703eIfebuqW+J88m8r0by1SY76vGf58YokHjNil7MWk6X4Rlb6CFb2FN2FzcXs3+OGfbJnNGap/gbe2fKstCs2EEC'
    'bETAuwTYkFqb0GWVdwITjxXDAkrqqCu6t8SUAQ2/IWYPaQMuDXcVbNHCkbyiQe6KJr0rLMF7bDbB029t1RHPefq0WCCN9/k6P1Ni'
    'tDBTuwY/+5vaQyt7CBN4dk91W/yG9B7S91W54dVeIPNW/ZfMiCnP7l3/XEz/2fwfoY6T3G/WULFEZBY7ZzXIklmKkSSmSVDN3UA+'
    'smUMa4Y0XL3e3DLVn1rD7pnsZcBkw/hTaL1/J97acAwt7pp3eeaYMa0zMzAk8vKeiEly25J6d5QZRsPx4nPPi+uQpiFHODk3h7qO'
    'n9Mm01ZjDp0V0tYHCtxJuJXw5q+hGBrwvnhGZHKp31WcJWtNS0/aaIjmTBAvVAYV6GC6R6Bthnias672YIA2CYxViLTMi+CT0OgA'
    'wS+WOz+WOyfMGP7k8ZP89493qHlxZZFj3p61IG5y2+sGgkPbLGVb/6kc4KYZDDuGWx6lWyXZ07bIOnErzS3ubPbPHGPz40/KNLkd'
    'xxaaew4FA84reC8IDosYHPPxXm6NJF3P8LCMsOPm4InlVKEafsNMcHxL37Tl1if93fZO/RnRVEWW0uwFuy3cFO78bsd2HMCD/EEJ'
    '0e0bCK2nfiXgQ5/ZL1UrMBdxjx2hR8hDd0jftA7PVsJtnqIhHWueYJebmPDxj8NeO2xRMWprxFJhN2vtJoW3L73NQhj5sMS+K3Fb'
    'cCPGHSIVQDgMQ/BUvLQhuG0Ne2tQdcRDZXAPEkexJp/Vu7f76J4FkiFCopGWsqRawAPt3r//n//XPXv+uojBcpUvXc7F74GkX5ez'
    'mWW/1J8fNEw+GbDtD4nO+CzZ+KH0DGJzIkRNYSZuF2umV12OYZUVt/PwDDJ1QgwdUTVDw6FTFX7Xni6VAqSrgSTQTUBCyjGm32C0'
    '38Y4F0ejkGCMQ2Kxvy9UYjTaFsfaSQv2GzqqcOePr33jf5ctPtpvbO7vOja3bG2OdsfGDbRNbSGoLamlHbzB105TXRjJ4PlLXda6'
    'LE3PeDuO8x17MXqs0S6jYaiHpHLjc9HGg8etSQooAdfKQ1BxpQFjTwPG2A/6bN89u62x/e17PBz1WyRPSrT5tCBgVihyUUsKRwEE'
    'WY7Lui4Xe/P8rE4PwFfPbPSERHyGSFk0Kxguc0KXUWW2l4G3aZcsdm7JgZFQzi0hgAS6lzzYulXpYIAQ2a3LgK5y51nhF8If0PdW'
    'n3FH4lfP84VdHPEcRivl3K+U8y9cKd1yctdquaysAPC7gt+ovP95pA84bygEsDstdeFO/RppffBwa3D21tD5zgV2nlWvyzoPM1Sq'
    'AK8iOoS0pJjA9KbcpyyttcAEUYV2IP4tOjWwdyxRZ9LTV7LVqu9XmJk6HjiYunTQdrD0h8wD9az8krXFFr+YvPyCDvCV7sXjz4ol'
    'JvGJY8t4TAyDWXwczOLv5Yx48B8nQcd7yG856gNFiBYNaCCtSSPkU0idHG1aOj2eMil0TihcNBgcch+mjlz54rf37tEtnIk3VATd'
    'jwwWkU7CPwmTT9HDBMpS/DDHEf6Y04hXpy5YTi0RrAtR7EECntVqvvmvRX7VC6O1aY6l4hmeWb1vPn00JQQxg782N0ials3dowuN'
    'cWREOVyPXtT1uhhfmpdFgW1EtcUOXZSTb3o7vxPfyc1OentZU+OqrAr0FLaZct1L47TKOXz6tOvSdrE02+pP735+xRxrCE2HIwSr'
    'Cr4Vl9VmOXlXlvNxtvY3uKXfZEsbf063J/QY8/dzvrw0XRYOMWX5V3pbStfrDQyrpRmat6a3hgDg+36q80Xv7btf/vJDP/kvb395'
    'PTBLwpxBxdkGToypquQniBZSQMu7lXk7/zUzJIIAAMElId+AalmXWVX3dswXANOChP6yLqvsY+7oDRIrGcL/7//23xJQ2rd4ZspB'
    '5qV3VnaW7xCi+AZr4tv7yZ77z7DBaHQT3rr/rR/5SblYFHVPDBXLojp/sSwWZhDgZVm+hXJSHBy6v5cHtCuorOpz5HhMgwoYoYA6'
    '17ne0kA6IBj8oVjXmx7HLlgOHKje+6pctnsGS8YbSWglhBs2IWsjlXAyOM7hN1N0GE5Qur/K1pVWqn1vxK3dlSi1VNgNJnwwtQN5'
    'B0AMUW/tio36jU/mUFZ5bggCLne0pbvNYbIh5sGo3DbSdkiCaSlXvbQ5bto+W/T1Nlv8orm1LQbdcy021pgyYzjU1pmELMbLjcfp'
    'vfPL8T0BGa9cmKMG7B1o4BCTkRCLA1zYGXx8LIuWKb6znrEAKVj6BCZ4Z6dCQ+O56eu3NJ5Z5VAPTOGGaiZojcSTJB/MBnQWNd0i'
    'JOuqzBc2uaYhqFVVzJYLhCMPNKVLUf0JecsTxou5AO2teBGarQVxtiqYwqM7Y3ve1TKOWEyyM3jQik+maKXM3UC0xe8zdWVSmP+S'
    '2ULkRSMNX5ppW+iLAL6FSgxNMilJiKxlW65yszHM8TDfRFkfr2sqwHpE2M+vaTYKz5aqoIs3oyrzKQH2rYf0BQbowvpE67uUlXSc'
    '7ka4Gn351mes8hj/BCLxSYDdYuMTez2+cOTiEAsza9fw7Da3vfcsAm92odjtCFgkAswfGSuN0XFR2GZW4hmpGL+Gj+zLGhWkTFkn'
    'EsctU6OWNUMouAJRaxXmXkDiPyHZgnhrJxwhXAK8z9vBpgimQ+/8iABrU/FPqmDwjmmxBwEtSnZmpHwILnDRDW/yKWoG85dug1+e'
    'BNGixe5ud0hoE8QDTsFw7go6OmNmBCDHCBKOaJa7Ohd2bSZdU0O+eyGZHKq7gBa4sf5DF+0i8nnkwrgW/pLrhAghcpPqloOEDyvO'
    'st1V7SlSJkZOALa64xgQJ7TKgQZWqKfOIXIKN6aRaSqzuWFh7M4SqpPGw1HbT3GHUshbQT0Gn0BmmjIs9GwpiWttohvdWw6IR0Jx'
    'l97MQTgKvuWtx0txrGnm9ux2VgkTJS7j0BEXCQMufin5RXvWTDxMbSrlh1HK0Q3LbrQsTL4PnriiVMXd2KxQPzIrgBwkjLGUXJ6g'
    'yZPzYk5MAWB2u/yEqx05l2xSEmXBkHIG35UpnKzGDK0kXZTQhDh11iR/bRjUVceAK6ABBD2u/NWgSTrvNoebizWlHHThgogl3eCF'
    'TVrRN6vcprZwsdCannCPL7z5SUyY1Wot4Hp61/HHeqat0rbr0WvTzQjSqJ34cKWuR6YnK1UeX4M1a7Qmam51nr7WmBJJcqglGvAM'
    'qzipSLiaVoFrVVXnjBEw7FqQLgQNPzL8INx2R0+AK8p826kUl9bN+bY3be699ZDhdHZEkM9s/wHs0UP888T88/C7IcxC4sIaPTtJ'
    't8aZood7HSGm6gGfkyCyb00V8hQeNyhwP/GziU+605G5fJoBeVSGvp2028dK6cBPs/gRKKXA/qx8ZohHQxfHiiZcrsAslWDWJ1r+'
    '3Ma3xkWRkNIWfRQ3h62wkqTJLlKWFYtP20oyIdtHUlGM19pB4tJt303wYbPylMc48nEOg8HA3Mcuy4m+sJz9oTg7g49fjlxPB26B'
    'uhyjOtT4Ju8MTcnCDP8Yovoo3/s9A/LouuHi8D4l6CtRAxr6KMbXtULr7sTJJ2W09rHeFLh9N3k4BC6Tpyj6fTfRaYBw+ZegfMLX'
    'ZbX35vp00858ttKTRSJKnaUFHzTNzerOk+Du4WdEd3Meiy13OlWw8SbS3uUS15VYZwPkK8RBgSP9abq724cqgdkwQQk8pWU/WbA0'
    'S+HYunniK6HTPyBME4aurCzevfkFYkWyZi4Li5R4IKy+bPuIE8YiWFkwK3IEByzwC35qkimuIgwpmQ8RJYtpwMbiIpgSMxzRjMgs'
    'fDG/EAxTa3LTTlg86BfeFYjR+RTIsfZuz0/UjOjRcSYIiCbVHB7ek3k5uWAcnsgeDrddovzQ+R5HX/Q28Re/NcwGIHQjiYJLbnK5'
    '7skB5gZGqXCF6aggVhyYP+40uvFylhMFDyzgx3ijKMJG/lsZthwL7wrKfXzuHm8Xgihf+rBCiRYU/a4hx57tH0Tf8LNprfebZgtS'
    '5HhcXvdsqFy4wAMQkbWEfjtHLuhDzfJSxYSETDBIYSBFj47MT3JmuxK5/wX7wYONGILyWAhKoPkINogcYWYIp+ZlFNlx+8Ux6ror'
    '2mv/t6zCzlXEyQZDt3c2LzPqHUQlcBCAfRgmzS8G9Z8ytaIwsnwKYogEjQC1f3VZx8idZnZ/hIH2q3ejZhx3fivO/aQWDeVBEK6S'
    'L1b1hnG4SQD1oWDr1cS0v2yIXKT9veqjEXnmCAb8lZAiOJ73ElHtgg8WTS4nMij7J+row8IbX9gKShkDxhuxXmtx4l7DVD8cSo4v'
    'e+JmxLjOgGuNErsAb0+lGslgLsc6OyM5h9bswk0QyvVWVEKZRRumgbhoKXccqJP1oCwRjg8ThiirgDlc1PrUKYoG20+SL9wg8okb'
    '/ti2G7AeO3eD4vCrw0ZrV9xCJNf5wkgZb9VDIRIr5ej1cqXVft616JURNKZ+NU2Px1o0SBY2PxpgDFNVRJ++gyGLlkWzrm1Q9fHx'
    'N59kPF9nC4Q4MoY+vTk5sRMl9i6zeO+1SjIIP725Z/MMSb1MQ3C5nOdVxT0o38sgtlPnia4byzIbHd/RUv120xKr+nT4AgAmYvLM'
    'hRH9hNcyHYoEj0owpUMNsSiI3UavnE71joVt5KFQMdjUkmllxBil4BMBiNr/hYPzXeY5UiDVAq9DzaRf/FvOkZlCopqj721eO7eS'
    'imdAQ6ApKOzijTQcTrf4u4D/5icBXoOFYwkBG6iwMVUSzNjidcGxx9/DOmnPnzYoe8Ee5pEOI5y+cF+YA0TYscktmpb2jggXU2sV'
    'heoh3wG7Zm62cihNyu+m38iXQZ13gliXSVvrVkXNB4qdyqqxJK9NLhuHCsuDAJA3J1aGvmjbWlOftWYdwM5v6odMhQp64POVQLHV'
    'VHEWlBAm+aoO9JqRUrOvkFuBblP7UoXqMe2P9IYzJziO0TA1dZixarBbfeyqvnCfGiwXGCGzune2/KKD/NZJTs4wtYefX6LrXNaz'
    'UHaG5IR87tLCffdpoH3d0yLgBSvJNMFtrLKXR6jWunhuyYZaDnAAufBMbz4xoxRYT2gzQ1LBctl2JLHragUlNEGaK+KtsGnLgnoh'
    'R/qAvloAuBe6MrQ+Imq4lQlkSV2zCrbRMP1gGFWDJisX1nQL6WhNJzYFyN1ep6lF/bC4VKy1K42WnAh0dSzQBZ9iRAprOQhAAylo'
    'OhGTJStAzVJhATlStJaKp0B5UnSTTdrLcZ3SndnMfDqgJ+j0+lCu6Bcw3Ryq/fbbBGvKyFLmWKwPwmndaWx56qItSqzDDTLMbAww'
    'KwfdWUb0e3nrDp21zWljzWtn2YTKTKcJLeoAEZMOFzKV1Tnw49FglBwoyjw4QNw6jXG2t3So4gFfwLamWEoSF7xBGLeC2ZWGpMSM'
    'XwVqnutohOn/am684AzAjfZJKS967wG/e53HOnhg/TpIAgTe0ySJS3w/O46d/2MBBvplvZ7vDk1Fe2fm4M4Zlb/OP1waHtQS1oWp'
    'Rw18Inqq9wOtSVxQSc+IKGqch06ZoR+gSsEXatdX5gT7UfBpqWm3tCQC3W/Gjzp9/q0Q+hplblivEMq2I3YJPGFWEIQWs5YlQOiY'
    'W/pyyE0detzKXAuioe56URNcIc5pcKcV/+btD6oJpwUiiIpLPVbnsSTGXiqWfZQo8FKdK3xWcgUTYK/WOQK7ljPJr3qGeXCJ0y90'
    'peHuK/I3LUFcLFju3NIhOkqOoQiWpomzVAjksLXAFWEIcMkM5FKTT2eB6DVMEwKGIYk/oPFj9GQYvClOrO5lzNqxzSLQY1sB/XN6'
    'TVO7f2YB0CojudCXCipKqVeMDJLiyfRRTt0D91OXxp+y+Rmda2masiRfF9VUJ9wn2FvItsbqOAMLzTcdHCCAim3Rjox4s36y8Jip'
    'kc55kUq4jtVNt1XNtoSL59HKpe3ttYfvXrVqDtuG4Wn/oY7Lu4as6s+/c4CFkqKIO6Yn2pIOSwKXSBfMIW1oK2mbKtrMcBGoJDIs'
    '9ZD+LUYDdpZ4PJN5rJkc6KL60jmfrayZRaoIQKqyhgnJqr9pzLE1VeIng2Vrmg7x7Bi0pnTEKRMvV03jhzB8LbtHtcqwYfYDu8f9'
    'qPvSYJ9YGRlCFPECDV3OcHThvyc0cXi0W+Yxm624JHY1rdlMr2DrkWWjt75NevuhMcLZD9By3xsJYAbxKCGwziFDRYehAwAbsOPJ'
    '45axY+HqMEe4crn+XsZAR9OydzZUvcqPniHou73azQ5wPbZYAIv/JfwaeQBhFQt4LBbrtC8NeU2w95Uwe3sBQMHRw+H/+O+0nyp4'
    '+feaepSngiL95bWgG65L06p0CL6xZEAULlhuFRZPNjmHE1y1IgUvNQd8fSUqszjJqacsP754/S9vXr346XVkjTQ9FFLbT96+++FN'
    '8MzZ1xyUzIU7WyBvb0WzPptnNQ4fAlofdwASNsAIT9KAzGMQNkErxwJKY5oWT1ih/va0CN80i/RqqpDTM4Gdngk6xafA0sb6KZzP'
    'BCcwuDEGg7zPQOvDlo0+U7RptdJnpI+z8eDKGt/3EbZyHdnqMwWO3th3zuWdc2ewh9nw+jAEj8RCk3QEHl7DfsAbYciLpeQJ5vO+'
    '5v86Dg2/NdOYJ0S03Dd/AdcEBP0AwxBJbTHH+6kT9pkeKuyLRV/tfWBSill8YnwYBH4L/jR6Eg3Bh0HgsKAHEgodhoQdO7uYaj7U'
    'LaSdpDoQHj3FdtSNMtJF1fT4uxPhIZmV9KecLgkXlXh70KnAip0kqnK/wH15Q9JVpXECHLOhTC1uW5kNxP0TtHGUPEQQ4INHES4m'
    'BYfwDL6VAD98pKeJExoKyckLugEygum3qQ1sgNiPAu6fiL8bid2ZwEyDNAgJBI2p8vlHglEbubhYyJlcLvMDPZ2tpCJESZo+KxR/'
    'lUqZymZYJfBkbhagTZGung+Uxz7my/nGrOcxrh48MiQxg7yNpEGB2FaciTwkGSLOCsXrCrOkmjHxyKqBkl7AxKmol59PmUaVv0Oo'
    '6oX1kQiic00/P1r9aRNf0eOeJW5dKfpZEzDZH7fVcXESHrnSDA7owqyIhXlM1z6bBjvySsBXLsItH53UkrqVCwjrw2wXs0AWwQam'
    '1SE6XW0Z6vCjg9U+oRn+MILULVKbrW1huup7/NQdDrCCgN72MHp9/+EsJxg9Wd1DszPDMC5wSuN48c2gUkpkh3YCWP6wA57XFF1E'
    'TpFwZzHbLoLqTewaaQyWOT4uKu87pGPn2CKhOeRpR4PRfjt6/rLiodfqQz+5ypa+PTOepkcBUiTeM2LNRTPIHjTiPsciJibWD8G/'
    '8JyoPj02s8d+kPlq1OgWEULADOvi9B/KioN3Ee6zjy0O0Q+SxxUynoCtUDf6Smw1zGVMBgXPFFvNWfFQZTq404Fkp0Pcu2hiBHgg'
    'N11unPZd/dz7CRYMv5As6/bFHkzYoslVLm/jKZdfy1Fae0Goi7wIndR4LNwN0ximjZclK5CpYkDppjfyPJE9U3DE9173qABzeZ9e'
    '84jhSBK/9FhO2AufSPfCyvsR7t6CqjkzfPn8gM0ubEvHqm/TSlTfpvX02dGbGN5ApDmrpqH333k5zwMHYcugurwH3kOYh0YdyD0Z'
    '1SQ9Z9c5rfLVqW2HGQ/isyMNuO7WSmTiiUDtxuNwjlNmYx0eMkmUJMkarLWLfLvgJyCLjZXFri4bGr+KZyDGtLJaG2u0k2QRK8n1'
    'YbaY0+N4L1/GdfQqyQ9qPrNjG9jMK8fHYKZWJyd9XSrAqoaDZni2NRI0BrYcQXMnK3cc5Q1TVZfmhjILBdW7zFJ+1YWpxtLUY6Jb'
    'aZcf4fZYAAHS2t72y94mCjeD7d06SzLFcXTnAwXVfBUfkCjRgPbfcrSP9v3Z3hcRcN8S1Q6o/y+iKhmQmLdQE+uKt7zNFS/2VfDv'
    'mi9+O8BBWLmsE3zR3ecmNkvnWJDGTjjAPZ7kAtJl2psgnTJTKix5kG/sA1Op4gtPAvjMBkPxdmAog4B6mrbAdXFzPnOEaInT2rBF'
    'MMLAfY3vYO24d8Ka6UoMZ4FMXOjM3jIcIwQ1jckwv1jNSchXOA3gBWsHmZIc8uT830uONK5svX1cmhUto3FXeA3Tx/cnfcf0M2MB'
    '2AsEL6G35NpJOSm4QGppvGLIa9ChRFJ5odPBu9IJXmsfrBg2RnlXtTSeOiBxG9wjQtOy3RDH5NaG0qjv2kArx8RFg/EJs0Vwm8mW'
    'x8/gZRlyt5Wbgy7kBO8MGmN2EnYhJCgsjMlP2wCuejaxO3rARPh6otZSmvdcqYN0PmCyBtgl8mxoLtwJ9SYjMn7LkjIrD0SKyJi5'
    'qJjapNqBF/sZtFSB2OGFDEuBQcvJHYesyTD9vMghST3wbRz8Cl7IhivskEP+Bryqc7j9om7fRIc7Bq5cmE+ps7ERzKhImuooUlpE'
    'DDfVUfzcyxUExEhuEwMRTKpM8x5CK5bMdezh1/xwCM8cYHCaM8AndAk9wZnexrDKfdNqP9l/3E9GT4DSdmKZMLitF6DamihOQ6Cm'
    'khJNECEhJrwFn+2EqXrbME3t8aGRkehznaICfg4dmR9LbCN6bIsfusFHjhHuScahbpmWcGVILEK+0tGQpe92p6AIy1nrztVtG/iT'
    '2mSudUfJBh6IfXWakg0O7sPS6lMfe6c/MQ31zoplNtf4XJ8noV7TfRDSBZk9wLIlHy6RoULSXCz3zCpBNs60OZmSg2BLJA8JWqi6'
    'd8obr+xX/cdnYiRhL6xEj6AqWzXjJ6qK6LXzat7atU/0KDYXC/SiH1sYwFsZduynZfczTRxjpv5ncYMKiR+VEIvwvki5geCXJrMM'
    'BAqyLzI1LQJRwvm9Gh7h4kCZ/wMnqywiWWXaElZg2LpJvRYWXrg0rPYT+L86S7G6vav1Fcq0eXZNt1AXxFSV84/5LxIMFH0L1xCC'
    'oGsKAD0bruZuPOgnD4fDENGeNkckm6xpcabVKJOQwcLmjAVlUoc7sUlipkWZdQWpYZFNDSNypRntYo3/Hef7xq6wUJ9wFCTeOK1c'
    'O4GHnHWHpp5L3UPQDbUWIGeouF1KglHNUKp9UuWcPAwchLi0aUdQrT2DQM3qDfyPaGpGmjcvpju3kDuavwVDUEKzJpozbQhGCr5O'
    'X4VcgixdPkF4HA6CDOPreqkpfnxG3FVWrH9TAqO/Ty4idkcZFKi8rQRsO8/kt5mkvnX34kRAYwpDYflxR/mxK5+dhGvzT+VVIgt3'
    'GudwPLBWGW5cM3Dzy4q+uRJqx8XkRj6zkZNKryD1MiwZ4XS6cOrsIlqFonPdsdlasVanB2EmB4L3+DQPlGQ9RI78ClIEyldA2mgl'
    'kV9WoR+COeEnVz5/50SEkrEm4GTmk95Es2QyIVpv7K/4zJaMY2HrczkTMaPUGOmM3mLl8BlFQj1ndqBpd8YHmm1khSw9namYR9/d'
    'kop59DhNff5S4Utqz5Wwy/7UpdAzVs1JUxquIYkGeQXdcNkUohidDtjHBQMx2ZBQ+YKR26Esi+1xvBiYxheD8YmPjdQl3vFk3BEC'
    'lrjVeOAZ2ffCxL4HA/vY/AWf2pFgiA8vYs13GC5lRoRiwwf7G99wIjq9BYTJ4wtzdemv+Lwp3JhVh7BRI/2ssY785SXsR+J9b+6t'
    'zQ0zCbaIXH5gERzctbjiD5Upc199GEhKzURwwXyUFoKe3EmQ6EyznG3X/Zex3v/WMRZP3dlPy+/L654dvXDkyhDgHuBRcms3sLXx'
    'VoB5b0tZxCQtlXYMSjMV3k0cm+xz2ql/hx43ZmCcEZ1KsvDEZOZ28UGqS+rIWiekJDGBN4wX1JZlMjkH82kzfL+IvEm8Cls9Kp3K'
    '0XA9VxqH3KmlFKDgMRSAyzOmVQozessRrogWW6yOSxtdrtgBjkkDcKPZeQ4Iw7m2ezuSzeu0jiOFJUlBoIVDXIUAToY3kZ6F2XWx'
    '+OKo50D71A+1VAEFywic1QpNV5vFZ9T1iHCD04v3GJB15K/vk3Q2bBGN5C1Fp3f+xefZ0zj52bXY/apNmPqz5dlPNURrD0enu7ql'
    'IRCdhmK8wjbLQEKcxplhX5uH3s+VV86czfyw6J/ZVlFBCHfTQ/TYPXEv8Ulo3Lpb0WXgbrVJ/eF2IcJtfSBT4bRoMqtETmraAPwr'
    'Pl4umr9+ZKkK72OV9YLlVZn1WDETquobGiYC5RcQp/SMTBRW1Uk7e3tW0/lBQlWNjC653EWAuUKRq8FFTHTwfWYwULXqxdwKlWSu'
    'tK1aN2ZN9KeECiGTKsLeFf5CJUkXwRvejPa7VeV4L8yms6XQCrPNT9za7R332QvhXfAr1dMbePL7wV7UoGcnCzWlUAabsCraLtCZ'
    'phvYVUYlQ+RjaZeA3q1y8bhnTw69OE+f2cNWqua4N5oMSdOoimXRdtuWcEEcpjNps9UrwsyyiD4RH33fUVn0tluhAzIbwtFxBqLd'
    'D32jqALLp1ZX0Riza8RrDjlqMfBskPbPqkb2WJqe6lYrsmdebk0GndWDGAQnd3/ee92hqUhO9fqqdDYsuosyjat4KYmjBSR8noeZ'
    'mKkikKLMOadXV5qA3Jwk9oAj6BFjFlr2OGpCx0DxnZm2KBKIyMAO2QMSgaC0idWaOc0MIF1CxB7h7GJoKOxtVbad6aAn8erCQIjF'
    'oU5h9owC6gLmNzqjQGgFCGSF+s4yYjj1jMAyGsJfLi+onLUyt/OahAv8oTUbZpJoHTdzOy7iqh47lZhJzbNp4FdutUFhTEpD9rlc'
    'BQLxsvLk4FNg4okcrsRyBKC0a2uqO0xk/V07C28yESn22gsySl8mJ04pJw28+unnn97FjnpD56j3W9gC7yAOqQ5tvgKEc0sMjIxX'
    '5nk/qUKz1XiTfnbL6PkaW8jd0KkLVxomcXrFGFOXwOkVdJRL6jNfkeG1JjBawA5ZCo82+gguvTSB6S4MYljMcN/+vYFHWePsD7rm'
    'uiWnvsbA+BI8100HxhslMb3gDfvoN4/bZ6mOcuk/I+jAWc2pbxhDu2rJi6AGwiSoQeE2BCpNThF/eeo2DikLEb5Je5T8SCuOgoBi'
    '6JNFYEf3xOKLSJP0pEdUtyvVn+k3pJw+bUL3OY+Jls+YaAYr5w2QifFHPdZmJWJy/pKrZf88x9vSkou9AuGYIirFuaHtrOnaMC3O'
    'znJa4DFNVZ89YDZKn4nbE3J+4CLPayFxWX2nGZt24LTK/HBRIjM5jgOSKKtQZUMi7xQxmKc+x+UXen2Klr65h6F8u1yJDkx83Jlj'
    'WG+N5VaBUpPM8DPL6U+wnyg7Phl7JYKNfVBTfgaLyBB7gIXE5jLJjovsJNXcNl4mem2f3AKV9UqiDaVcX5Mp85L2P5dVeTI+7miR'
    'RSKzIibdUavZstdkbb+327Kv+YC5efdCKvrCF3nhiqTK7od2riwmF5knF5nb/P1kPU46dEKvvE7oldMJqeByWcfy4iuVF1+F8uIr'
    'lRdfBfKislRUNIOHUlW52Rthyq2Cq+nPhlBFSrdleaV5QsPx+rMfjD+H44WTmF6jITwHz6xAzNBr1LybTAPtnXlvD7cPY6MwMZ5M'
    '/3ov+skep/I+1zskzTVcRtZj2C2mYy32fT/ZViry+c3PCEGFMi3konUW3Rvz3lheR1/NctCzw5Q/lFvfu1vjyFIiexJpGNEirTg8'
    '7k0bz7EOjpIXAt/iKiA+eyQBddSCldfu9W6716awgkvZE+ElmE2PEaJRrpNysQJvPjfnB111Pfu5FGobc6DMKAzEEKtNYXbh9I46'
    'ccHnQRjHsuz73F44ZpK6WICBzc0dS8cntk+0bijR46HB42KQ9N4EVB+8oVg7lmLUYCfgH3yez1fa8wPvosVkqyUi3eACWQ+Sn/B5'
    'Z3QBoK7JHhFnBLBA79mXO95ZjG7S7KU1uFzXLkgcrtlkgsk0G2qKk/bMcIrsfEWyL0eatXXZ/K9E6QjUT24cYmW8dz2u1feYTvxD'
    '/gq1r/Qp5qkV6Xm6nZeXDeflSDFJbbMoJ4Ny77ucnLFDl5DBxZKzFKXlLLP6z0z8FGZje2McK0SVxJF76g6h2OuKuDBn60Zf6Yig'
    '2OsKuIid0EyLz0V7bCrSX5h7PVUdySqv0RTc7vfhtqzDGypcIt0NC8RxBg0G1CZgDqd4y8xtz4Fq4RUCzF13xjqF4VbEN8EyC3z+'
    'roeh2/JKGFwM8vUopOfBg03jDSoscbptGm/og7gDS4l3MGtLVSdlePA0dOcuFIX6nqVXu6/4s6H/fmIm83pon4TK8idmNZvv4ZNY'
    'G453NkP7JFSd453N6DBwY+Iso/9Ob+QRYUkxACaATYzJk9wGCMZSChqNAqxawjuLWWvZ58Ck1ge003K1/+gWy9X+w7TLmiTWC1T9'
    'xXYKrMhzEpyIknTTkn3ikRoxpVZiIm9GpoxCTRnFFlPGk7Yp40nblPGkbcp40tjYaNvu5SVd5vaH6s9w6wa+CQ9dFnPnpiXMvThn'
    'vQgzggXFn08l0ok7nIApuIvxCCtQxK7O4FgxD8P6S8htHhY2HjHp3aJG6TPk3/vlo/Y7GuWdDgL10xKBomPgOO9I/ZXFbu07x2t2'
    'QEQguFC0FCg9wTeRvPPUO9FTGrXRw6OYB1E7PBqXVs0kCi0C57mD9Ly8IqgA0f7ps7eOsJ5jnxsbENuyvYREV1Wkv1kpUizPSm8U'
    'uWhKU7eFAnTaLzocHXtbgiJaULYMgbVgtgyXjawh81KsIefFrdYQAdtobP4wdq4VOtdUSVfXMLlQtXp8DOC9PWzjY/cDt+yd0clJ'
    'l1F42iFPiAd1BWVNz2/q0TD1ny7+19W1FLlyIMipGxCEJEVesfMyPJ7mJWSbQxkjdzadF7y71fwbBlOgBvP2TeS4GllaEG0h8c70'
    'g82AhHhjsZe3MXEPmkzcbYxAg+hijXbHn8lgv2CG8bOSlPd7e6GOBMk/hO83Q8HFX1NE5e8HCPh6MWDkYRB0jip64XV4QL4YnMO2'
    '8/3AzIN6TG7jRX7FQSfFX6D482fmNf+2kZAgHgWBQCI0/zoINkQ/waXbLKlmovNoEsM+ffSHg+HjdOsW+XXgEWmmql5z5OFXDAB1'
    'ds5YsBsoQYPHdvmoU5TkTej9ij7KsnA9aJ9FHvXWMpLOrVsNCU5VJO5fjpxTpNNjxFF2q7S71NhzC6XIKHF1NOOpoOULEnPCMB6I'
    'RGOeB5j+1ktadRLq2y8HBOHroF9QKz+OBO+ZSSARcWAMAV1Ch8mvIOxCf5t2ZOsu+nlLsnpSarOexvfsVj74GuLe8J2M8Frgn4ty'
    'kiEchkxyrvBhjSE8qanlUDMjB6bKSui9LsAjNRKJj4MfZwcoVdND088H2jgVF+3ThGgH60AX6hwTvSi+3KAPp8vqFC1ZRYDqBYK0'
    'GQvqk89pOrpjpfIzsU1VIetr2kr7XnusbI14fIDuVRYKEb2mE//6AF20ygMb5dynoUuyRNAD2S5kfLZnb1QkZwoJ+ql41bNCGQnA'
    'kU0uPUhOAbSVT09Nq3es5E92xXFV+qJhXvxMOU88qxm5SC0A3OKSMOzZRkPU6rIcKAiF7CCmw5BNJCoDKEeEIevjg23wtY9WY5h3'
    'bFxT9LJB8scXb8Sqtxb6sAqgraL+OlCq06qcF/hgPpFoOllRqtnma6xJAVgkFQASOvUk89u1jQSfzzn7ZzrNJemKB63acctZEaQI'
    'lxSQAt2TMsR97ZE5+83/ZV76+ECz7QEsz37H8E9EXuRLoT8OxBJ5vU1FMmpaZg3ucKYniXQE7MdMjxq9A+lXgzX8u3IoNUvKu2Ft'
    '6W/nTk1lE8ukaXUhSiXj1rNK40/4y/AX8sszB/aAF8EFnhoyZm1fDSOsZOCr8INKVjqXVrHIWvU8rBawXYuzugE2FQSZ2JDNyhlT'
    'qDUEfROaZxVxci7WMIAw8Q9fU8p2aElQY1PadsRyjWiWc4G1kiDmgu0GLrNp3wEaZChbUMGi4ZxsK17fFnrA63B+OYsdxbYqV2hv'
    '1LGhtWUp1pZVI7gzcHWVxNlCbRA/BPSqwP8VSTcQ5y1T4uts6fuU16zBhO0/VNQPq2aBW2YE/LH/MIwPNY1CjOZ5pV05EjSBD8KP'
    'nysM8Afh4M/NnxvTqQ9B+KiCrFTiAOrDmD+IDqnj/qYdy2xKQEN1EOUluK6onQp8m+zNTaPkhjcbJc3NBjNv1s4fcBJycc39Yjac'
    'ZE/CMGG6CY4z67OtKI5Oy01m9yj0JdIXDEc9pz5iqg5stAsPO+TAWCmj6jlRmExjrQk4W+ro3NNQgTIaqqJO1CjTWJfCp6PwaahW'
    'GUWJNOYD08pTdORf/zUxF0No2UZyscGTjT7Z4Mlm1GXf6xZj5owq9T6DKstErrAsQzlGf6kO6Zpfj2/El3ijYoc7XNCPm5Zy9Y8U'
    'arcTQ5B7hALsya8sTZvClmUczQ54lvyx33R1FJhMntNVpPck/fB+h45N7C3DfWdG1p5ikezPdWGTp+hU+0uui73g8aida2WrpuAz'
    'GoKGxhgTsQwVeoYGxKpjTNMy1O+ZErEOeTO0XhU2ZcphQ5m8GfVd8nZbIqY0iN7yebWsFw4/4NDil1y34ufVKcdlULBr5preOzdm'
    'FQDPq2qfa4qtDGak7Wkqs91WutQCa9YrB/Gw6l5nKgS2R7peU7f/ifQvnOmDaKIP4nkOLsN4a60WDnqG4/wU09TxAJMYaWWbFNYU'
    'GTW0tE16Ox5shg2tbZP6miKjhhY3DfTr8YQuNq/UXCIsn0JLMuwxlMlEJo8nlpDjdmeFBRRQQ96Uo1yeN1E7KD50dkAmtwHN2VhX'
    'bESqd/W6sDbankU8gZ8MeWwnJdC8GjAr26J41DHSiQKsz7dEZDiXOIDZFA7Ui9KwWIVFIsVTYcAgsMCQGh5zEY5tIqJe3t2SODIa'
    'eUXMnTJGOwFgnULVdTVj+StnCyVL9uWIZ46Z+gzz49ibJucTRhK1OQ6N2Llubong/iYuv6E3R3Pxu/sRxNJiUl8Pzko64p8+Hg6T'
    '0f7qOvnm04+/vH53cxqvSRnNZ1tj7mTVdSFyZCRzrQg8DcGLnwCkvu9MlfOBTPARhZZ3+XXd01v9ZPTdEKzoccukW2czxZOoPATr'
    'p+RKR2OSF/NeyJJJScJLEM0VY6I4qmyxTgdMP51KNpfH/eT8IK7+fjJ6RGveTeAH3mAmxbpr+gZcC7heWQKhXlHFchzcpF+Un6cb'
    'p9zhAM8HGU/p+WC8hXBwpjgv0Yt35wPTOIVT/BoHk9b7BP3xnFpk7gEz0lmfTVh30AZ13NKGNEGeDC0EBOhXOm1kumnhcAgQ2jqK'
    '4P/Q193suVwjV5U7lUB9dDDHyvI6g/7yHecfqBX1Nq63gRtoeVhCI9biCuBORu8S0IUmaFlYffU8ftW5Bjzp2Es/ivuTfka8cZqB'
    'rn5eY/OGY5FpeyYQC+yA4JNpc/Z3NiOxNROiRe4MaWPmnXQLO0ZXfKGUkCGUI9tDn/cw9p3ctu+YWe631cy5UiZ7tE8umxvEOsHq'
    'BG9p5KZrtJobjRvL7EvE5Ww6BtCnZpFFTzkzG0iyerOOjzCAB8TlReIZMg/2wYYPwKd98vmbemgvfmts3xqHb0Vmo208XHfUHxn1'
    'YFpK8mqgeyjTHFQORZl+ZrLwTagce/aWKdNUwiBaaEwvx3p521r5bBcbs/75ae8Qum5a5MYxGX1V70RytdAa53pruQzvhRbwCdQ3'
    '45bqIwMuhMeV81XT2hqECWCVW/e7gnJRuLEbeQ96R7OYKc/YvbyrNynC2O1sS1Jq0R1tS6rHy3EDCktlh0/da3BMM4Bw7XrQq0v4'
    'WIjNWDxdxkJoxuLdMhYiM97oMxKY8TaZPJhBSw7t2Hxmj2+Rcnwuni2uJep/JWJEqcqKp/wWYMSLBGLvP+dX8f5Gyp/b8puhvb/n'
    '7z+XL22HOX+NpLuMRN0okajIsFM9rgTEdylHVemPKGiqw0NKpNapnlT2rXP9oOCtxhwFA59wCQnvWn5uauaO0MJnvtsTqHGmlJ8l'
    '9NsOw1xp0jxak/NoTc6jNTkP1uTf9MCj5bS5jG8tHBsHIiIW8s2Su82p9TfuYkP9gC1xoauDJS7spJsSnxFaOjDuvlJ4afR5Lvqn'
    '/yxRpnkW3FX5mBGb9O1zk1lAPCx9j28aKJsE5IbXr3Xt/6NpeAEyC0sELtZDYodWNa9uw7SnF4jUFiGo0rEB1fGZ+ERExfbERSK8'
    'x+CCBWUdC/0fBCy23ar6Ycxa1Kvz4st7dVs3gmzVHbmVWzpX9VQjBtbv+QOoVfB8PTJ7ytT3GBy0w3cynLoRsfaAs7UPF5/9f/+3'
    '/6exyCQD87b8y5rikgEiZiJ2mRKYu78kboOh3ebh82cJnT3sQ3PxHHxZB06Fc5Fa8Lw1e2j9c+EQFDtSUvRmE6HMnjBvy22Bouei'
    'kHKyQguKeVJ6iDZ62ePNh7oKGoZt9TofrzWiEsg+m+ShB4GZ5jMLRtXAZlyrHLgGOvMuWwVt9vSnDW1r0VynIWFqYdwKymvE8kY5'
    'LTGch65NHFJcT0dcVoO1WSJrumWNNLPl46FbLfi8YiaJuhXt2zqEVItsPpc4rarBA9wFM2YEy946HUyZNpO/Nmn3Aa6rm6W2HOxs'
    'FMp8+Hw+HGpgP5DW+OS5fCQWmmtan/ke+BvoSNCofRD1qRt2MfQJlwTW27iPwNmIwzy9jjyM5N7m0BkQbXi1yDryhog3UhLT28qh'
    'fde9bUT90BKuXkUvJAa7mWiKqUMnTD+GY4dG2VkufqAIogBWoEWGh5uCQ19U905F/GX+asDVNyDqrZ+K9UBducA+nh5hRuUgbexq'
    'kPwoSZIgCHB1pUGn6R0CtK/5PBF0eevhQT2HdQvZSAhKLr6oCos/3yTn+XU2K4F3d26+aDMpF+PQX8nDtwWxwk30thi7rdODaZ1N'
    'i8vKIruHarCvAG0LtNhb4lfbXp1hDoswqHXhg1oXA4Y7RH4NV31HGsWnESUeDUNnisk50xZyXRKjThkl+U0uSCGZDctDLZe80yeh'
    '43gItp1hKE6CHB5uDdAu7vXAWewsuxI4JVbJtLSCtCTX1+6DJGGP0/X2elnTj/Gzfo4ulkqUb/BhCzeN3SLBvigq++key9qi31iv'
    '66oFXL3W8FoBbaOTEFDtsK679plLDuMyueaIOVpJRBwCdxn/KtDZAFJg4qcY/G0a5089XmgSozCjGN7+YTn9Mh30cbfCua1sPmkm'
    'bSMCVgBy2PBgwXGlawaW1ZUkk/PMdIQ4Y7vsMNdDjDFDUUwvMolWXRAm1CZrlUfjlFrgo+RY3mJuM32y9aXMvzQGeNwJdeQx9BkW'
    'zrOE7DE1zi4x1eWinxwzkygpofTT3I13pSlAXqC0GxjSJV3BrpmxjCxAabe0e7hhfit6wz5qWcLpeCgLcAvk176F/FLmV9OMcJ3r'
    'ypXEXmaD32mKUVHSrF1TYcg7PrbHqM6miDqkJ5IjyuxxMCeEAYuRuFFi01VCHKkcy3Oz1Ztauv5lIXGNsu+D4TAfDTArs1uBDBi4'
    '2LZchKQSOjV88JeInWuADohufOUR/8XDmcHG+rkaU/xBrkLb9NTHYIPX12hYuXzqOVnGvK7HWwPGXAo6ZmjQ0hJhuksJYOqygOHY'
    'OXcR1x/WtTfyDNlrfV+qvC9/W4YNJhSVSXffn9rSwE8wMiFTjMq0+4EJy2xfTwvUDINR+CZrxYGFO/rQNQ3IBqthXlz7Al1v73a/'
    'Ha3BhrRmiPekZAqi2D+jpW6TT4nDAHU9UtheNVwSS796St/Zp3blUPJ6tHXeK4f9Qamm16rYnq+2dnv+4hAFfSOS1q4/xM01zHT5'
    '3oPIg2JiesQBIKCyjkQ1ObRDVMYsrYglR8ps2D6gSRkJS0ivCAgIWCk9081X950RQbvaiDi/TpTpdlwRDVa8paS0DdsxDXE7yLl1'
    'IHdM0wa/32D1Cd4hZESzgGpiunI+L68Sc3TlYnLXr9TlbEjOmNzB2i0xnkXZdCpdCfh85tEdX9Z1KYg7ByFccpX0yLHQKQAgfXTU'
    'hRtlxTizwkgx07WRI5yPf5BUzvp03vHp5JlZeRrggDj9PstORevfFykjS8alqZPHD+QN0cuBbcnnWVUXk0Hyc8Tj0696dal5crMI'
    '9zmG2R0bTmouXqXVIHlxWZd7zEELvCNEtoUjANrhZQS0I6mnrjJCewjgNLy0E+w2+RrxNI1zeztg5EBMuFyK6aELW9rbvbfHmdVf'
    'Gmf2t3EN+9/CMczZ/Rmfhak+MNw4p4aY9YZ89GjouR4pAPvEbIoeLTobe2t9EFJU031BDtuMiBemhaCgGYoGZhgGfpEMcOqFQF8y'
    'ocMAXUnbciEK0rFYcg/Lew5q9tIG/V5GwO/W301ePpa8xkUDPmr+N2fYOcAe+85z1NoPRv7TLqk3GPlP+yS/6zgsd8IRAWMSPRv7'
    'Z6kfznlXQj+L9/LX3PplhxKsS/lMUdZfeZn28044UXTcvAutWFDpHVQzUBArDbeScPBKvS4CSc7hsAkJuhObw7en1CzMecyopeOL'
    'gcAmXZiJkZSYbrJScWVNB6CnPRFXOOB9GotPGo+RNl4ce2IMEowq+Ohd+TUWDxxskt7cJVY2NYy+Qz6+pueO+gpZ/x2cxcyomfpd'
    'YidvcYljziYcatJDnELPdFNw8N2GkHOQLyGbmPOU+cKwS5e/EbzG2ZlUXgaVg07Y2gfO+MeIwhG5Cf/UGfnkKfuSKObTnKB1dUHJ'
    '3eoC5FsJaUjqHWx4WVw2T3HTTn2ZJc+izdZPLsdJvN2aOuyP5G9Ebjw7O74cn1hEanQbdzIqbj6S6RERUsspXHVQbtMSVj7y1RAa'
    'KbC80+wO0aGEueZER+ihL/ejtA5myPRTUNLODvU2eSTTrfC29L5VWjoblW6lo+kSAmVlfZEMGBftREZ5Ydeqi8CVK8h4nIbvBxM7'
    'D+9lGl7gjoxv4afBlNv4chspt/Hlvm4aZgw7ekH+/3v+OxoNYfqJDTco9lyws3/URR+MM55i9h4cytN4uKOn75sz2nwaT2zwtKlM'
    '33Yaxpjod/VwjTBYOmLsZaR+1IGWrzAn3QWVss+Bs3GEf741VwfhKNrJQa91ZO4nF4duMtz9De83Fl7ElphXQmymV14v5yD/xf22'
    'UNRsRP5Vjlc+xz8CbYQUAIYzlShC0hPUsLyczhhAOjc8eOUTQVMbXjKTo+F0KRTMio+5D4YEMtHlXNNGgt1NfWZIlFHM1gXcnSku'
    'mGZzQTBi3wOVYpQ0YNWVNGB1S9KAVZQ0IDLD8TCIz4cqn3WfzMeBPxmJV8R5XAdOZe2nm4ZnWVBiHL4/br4/Dt4PjtyASXfDJZ6R'
    'ajCI0x81SJT5xO6gf305TjdgSpuVeDwS6qJXopn3jzbRo02bQjZIX9iFTsJ3LJNdwOtvfCJAMKSBxwLcX5g/xQf74H0zO6Dk/ChW'
    'BDXSiw+8GIdP9OJDl63Q5g1wq06SAsjlhyhvgHQpi1MLjDVvgJug3d1bwGL8NN4Hmj7YIjsb5CasOmJBF0FoexuKXNWfhIpZ5RjM'
    'phMBFNJrQnmz4sQoypClHi11Ei5eykYJxbowVxlzOjG/j/lZOcbK+SQ8hmfAyBC/xn1SxocgipLozNTzVCvR62a8qTJznZxbqMi6'
    'K7Uh3Ckm4rL/htxnw6bLiMTx9gozcvuDB7//vRlcqQdJ0b5r2W8ESmL/Eabp90MQGSn9D8nDduzh9UGgaV7OiKrHXnjtst7thkQX'
    'jtXytcIkQu6Eo6uZnZ55HgAGThRtGxPHtJ5+EgNdmDk0FFr6liPRiIhOlcVD6hB3NsGdzWEITaIcJeR81in6KzsLLV3AZQdWxmXT'
    'dn05EDxaMTFbvctBMpvDEhWgGWlwObUyq7IqoEQZJG+waBSyQnQsEt1rpms2y+Go7rKxUiFkjkMeYVmtxXeIyFrSK2FwR3IgFAvn'
    'H+PznJmu4RDs+Ujyu5C0YCHmYWYLUG++hjO15y2wt6rzF6biXnBGUd/l48VE5dOEkD9eqtHVJlScZ5vysg7rIZ7mV9bSxEQ/xvl0'
    'IpjoEOej7HBRSjhFL9GmoYRZ5WtT3SJbTvLBsrwCEvb0kvvnSWD8xQCjn+VV80SO0mEbSamHMnumburEL9cMw6Ztd2RB+1amGVyY'
    'uX2wBRn/mEGfI/mmumxKcUsf8ydobdvU28cWLv4ZR6YJoy9401QPWa0Ptjo6bBGnqSjqOU2QPoyOCObuDDY5wRtTLkWzu8BsPTOl'
    'PhjxvsYqyrAkf8T9HoZVXySMfrR6lfDrvU/Mo8LqDm6rDS/d+JUfLl6/9lFnpFnB9M8b1fn+f27RsSRmCZW/burBu5dg41P9KAad'
    'r8vZbJ6/LOfINZdTC4aI+F4afMqFIVO9MIeg/yo8z6cFdniqA/GDubS7b7Gwv6VzE20Hrdxt3qLaapqfQWeNV6p8zjjUqO8BnVHQ'
    'F6j5D5Iduo7s8Kpq5TScMm+hR9+wKQB2PNqPvghevQtVjoAp9H01nQwaIe0NUfDz+sV8bsdz2kNRGUpgy/V22Nsds9754KuGsAlk'
    'SUqWJpIQwmwlN5K2VjRB/k4HJ227Boi/jawqTvMiSha5iGbM+vXGdbshvKX64AE9y3xTQdMXUdMXW5vuPFXSiO775XImo8eV8mdI'
    'XrI0FEiPHr7WmyPMge6NGUXN9JtgH6HfszCALsucwJW7rBJoB0KkxobG+dyZLjfbKOyQxb4V56rcpViXXt1qRhK4wPRAs61bdA0C'
    'ERtxsm89zQLAQcloh+hbB7JQSGaYabHOJ8It/NnKpuCU71gkEI5Lpferuo1zFIW3GjlgyrueozctTyzYIhkRa8m84/MtnoX5L+ya'
    'GiTf6zR4U5bG3ME1QFL5zQ33Qs5eEnfYpI0ohPodsjEgup0zAbNmnI4h29enhjivALx/ZVbsUo1cLodlsLldnk1FJX4GKE2pg5g6'
    'w+Ft2S/evPgDjuihxeAZPYnxbJtYKNvxTauW23uHlCsu70W3y3uMc/rbEUYcj2+6tTpw4dv9vy/eiJPWGKwUKX4ELDsK/O6O+zay'
    'jsJmwbRaaE6cvsWzxmKIEHaYOuBLzRtfG18cgxrfGik8spHCTh0uthDxBBU4UcO3hLPzxeao/vZI46+OL/7S8OITsV90mcAyzQuo'
    'E/yC6Wcl/Qbi+633njrTauy+jke40Y88jw0vQK9JY0inmwQRnr1g0k6r8DlA7r6kVetA2oZSrgnMrcnXOkC2tXSEyR2bkq7hhW1e'
    'P8LPp/gQ1j16bEbV3JY757xz2ELOviClCUABGuTmczE2/zFi858MEBCohrdCEyk8eV8QvxrYROMmNhEJBbj59CiBxgCJlHKguZVn'
    'XjvMZkhVitVK/Dg8L4ATrrz26t1zDaecc1WWGuNdNpGNGrhG4wDXSJTBZYxrZA4c9VJwj0NgIz7eDNVEtYf2QmQjeTwKH4fQRuax'
    'F8f+FshG3ZjYf1sko2arfmUo8Z2TviyS3qJrgagu86ill0fQA5Yclincps3f1UbV9NS9q5KeWnlV0dvfuK9lDsMsBlWV20Wx+Oyi'
    'WHAVLAaUs9HbBed9MWCsLW9spASF7XKDG1KCMbblpjWZi2g2F9F0LqL5XPyGCf3Ucmv1szr2V1EyWxdDGtEE39U2HfEd76AN7jPa'
    '9MR+VFPj0ZV4Fp/UqcFfXbukvGK+4zysNuHdjU7Gh6Asv9mV/7BpPtkE8xXp6TVHDj+d3+FXoqruO0p8YBuxNp8v2Uf9xL7m1PuN'
    '57Yy1fd3hbK39f3xHtRVnJOR5pIXHf9AUPzMasBE+Uto7WQFyp3FQLLERSHsmdbIlClKzScZRAFurzhlSBUdiV1HOOKN3dnvgTXG'
    'MbBGM2o5ONXjCs7jCsIAZqVKv56z55RtrFQqcuupkZdPDUUktboStMbQw3Ai6CRnZ4b7PAiVxJq/6JSJXE4FadSfQ4hpJuhz762C'
    'cbNcI8fG38ErDrBxbA86IYavqCBxslUt2Y22/v8Tx7lguQehFpToZYXo6auABuYAMa1k6EyG9jLQHjDAFgxlz1RgFlXmoVDk2gKh'
    '2OceBmUdM1vWiZsxYQcBdt6YHpBvA6AeJorN1mpfDpe4MK1iwO26v4nLn/v7u637RtgI+8QI+AOuAxEXLFLDSYz5Ix2V/e+7Oifs'
    '2pzIanOCp+Gc8k0UyyVCieDuZyNhGuBlLpWxvnPTTNMt/tRWxtBtKEmWCsFKHUPcCJiGjwdh0W26EofNKk1ZiGjRKrlS8pLQtbhI'
    'ob67HuPVuT5o+HjyC1LmWZ5UOdQyseCulYC7HvoQqmLJIKeg80zdRDKkALIELi7WSZUBhWRSrpDoFwGD/vuloY9oComxzMN0kLyt'
    'y1UF6rSsJdxlQt8t7gxTw+m8WBT16aDppeDI0ScX1ehXTV+mFw4CHyHALorQXtugXRPvGKCcxxTqRQEun8DedpFCtGI1t7nwNgFG'
    'QpAbOU96SqbGXKdwJH8EBZE7Hyc21Q1Ve1dGMMXIRgDDTBceYOuRMrbNOa0OEMIGsjOqGKwkJLyuergMOzRqdOhOF0IFR/f2D2bl'
    'IrzsfQQzYP7dfHErblSDMDVXq3RZDR5f022/QL4AAmgeDNL8a5tbNJuT1AOG89DeL1iVsvTRPVS//wW16xx8UcVmG9DpLZiB/d80'
    'zbd817zZtggpHZP/maaPnSKGVq65glo5Pu6iaqXP80RRYB5Fp+OQG1Xx20TEErWHMHihPPHW49aBnwwOwrThEsd2QsWRfuHjji/s'
    'TB11KwSWXXrlZ+q9ESvm9hXdvYa7Kovdb5oHng8Zvk1BHyRWIgj4vEQ6CLoTOLPJIqtxTAqcP3ITqHY2SMYqTdjY5FbwBs1DUV6K'
    'i2bgBo1HaRNzOAhtzmzgVl/9dFetFKVjX2TsiqQ+s8WFhwf3OCugWxZlJdRgY0JijZcyuUrlkKk5ujGE28mJOpFH2SbN+V5M4dGt'
    'WaRgyOkrJESlGUS2mYLMvGg6XLh6LLFp1DYEC47VaZHrQWIUooq5xOBSPjIetWxGXngrBdm+as6hYLlXHsu9kYWm8tF1VRCb2QhN'
    'r/zkuBcQtMy0ri3NJA71x4rT8nAfPwC1EZG3akYrquZeatsoj4eDJ4/6yEo9GozwY/CgJY2MmXtgl3Xd347iYjrZisMFrMhFGINL'
    'aOxK/SBXDnrkIozC1TKbrljcuOvf9RPtv+08/nlkviDujB99aqIuiNqjzvhhPKg+cQ1HI/3AQuLsPxzqWD8Ypp0KoCeq/4l7MQ0H'
    'ooiG8aH0ZhoOQ7OE65V1CTaVM4LDRzUY1hC+G1EQkj8n6S6IIAMlIJfmvsYI0S1nzxRzjiSBwoLsriRCrxz0l7iOfQFUSWfoot31'
    'L5Lzy1muqH5mU06LbLbOFiraqxNxgTwk1UZIQm5aQ9YdpKOhIzKyQVBCyQyNuAYawgKcNzpj2M0LaUf9mp3XssTtFdONNdbSldm2'
    'roU7HZ1Jz2/L66dWU+Dpic30uXsaJO9SI5j112rCvLt0nW0nLuWUl+mJjxY5M307P7DmeFjtvSIoOZsXK5v6xRxqb20OA2r1J/MM'
    'b1K7IoMu7qOG4wDDUUj6pl6nhV8PuL7qZ8RAVcCuKOl0cZ2HuTDYWN4ysgT8WSwWt/nxZZP3VyUZ0Qu72VyGqkvDdi/iE6EgAN6C'
    'qQAWLXT4QDPtyZtOXlY5nKftTfqlzN2d384fBUwc8c+2dr9ky9m2/ke1NPKSNvm8W8eo1UKLS4wpNVloW591dQngjz6fw9a2r+0K'
    'HKzWGEe06yZ7SntBBLEkaEZ4vZe2Uq9myFa2nhfIL0SvCkVUwaon3HpR2azRXwCapnSS3kDsd5Ot1v1cpdvhyuII3upLI3hdC9PA'
    '7/rBsPXBShtsHjBAcKneQzJzX66qvFbTMlyMJKNnfZ4tqfrJ56uq0eG3rawVVxk+gWxuL+CFkPKMAEbgncwYNL98VZZz1gW9rNOC'
    'hAb5j5U/6bqOtpTQ5PmZoAHQXdpWg8r7DafwtFN++Yjp+9iNNqz6Fm1iV5C6jgZMQn50ZFir1J2eLUxlvhuuT48FiKze1CiN6acs'
    'I8SzSTT40xImfhvMrzBiXPB7e2E7PKHleHZjctiGWRWc/I7hsSol+DN8tMyAfGzzc1jJ064BAClrTT3tFmZdOHQ0ja/+2Jfu3Gz5'
    'jEDIvh0y7a5gpjV3lVRFKAbWx1+sU39ttmd3tG8pVikPAgfLIJcWWq07JcRvydb4GtMawZs5oAE6fAlUCcVLqtKy60JSQyiHotB5'
    'qP0wzECnOdSIaBDCDlTl/GP+izRX9STSb/Rku2fX9sykj/4DmUn/o6nl/xaJ5UM0DxtDZqE8bIRZXHZrCnoMY5BQfnpr8vlm4U10'
    'QJs2niocj6lByEdzkXdlqA5QcVAFXj4ChDVNn9ioiMahrENHiRH8rIYKkeNfQNC16VHHSxu+1MB+wUjrEZel+rpej1MNDTKyh6Fs'
    'Y/XfrzJbRSbxogvERpq7Ejf8DB2S67GIEfJ8fCiWFvt8vG17xbiFd769n+y5/5JikcEkENy5/+0dOkhcLatJJg50mWZCfTIcrq7J'
    '4uaLMcQLaICmRlxP/ukvr5Lem9d/JD6K9chk3dD1z829S3g31OaYrUgPJxsjPWTVZjlJgp2YTX/COz1z2OcRCMgap6JpZDAxhepc'
    '3OzMtZTEt8EHN1IkLWZ6KEuVNpZgMRtUa1gFTJ1yK7vKCpYfTI1ENXVFdevD4QMPl5kZxmz+K7zdsBQfDGEoPI+f/imnHsU+rhqB'
    'HGYAzYp3x/nyCjXETplXUQrefogjZLpi5jkNoaI6Cp1LobBOfO60nFwi8lRH8Ic541B7O+Z0/ZhVO0Z+mognH7JN4+JcPuVZch5V'
    'VWM7TSANvDRbEC6AO/vTHdtcfT2A86QMuRmXPjaU+Z/50PMYxo3VmOKmIpb+g1lGvaDwAOvK88jZfHWeOSIaE9AHCkZ27QkotsVD'
    'ObRW18A2eIrYNYjjtiISCsuFNGBPzAI50IJH5lvrEp3Datvhkv52tZztMJNg+9H7VT7bEVVMKl+ipkV4+nMjfOI6Xucfy4tgHZvV'
    'mErUV2NTVDo+PGP9vuhe7rKUG/vIO/psjToI4g5UQSH1mX8PfVjGlqAMR2/cm2+Jl1qXmeGudtgT6KQNwfj3f/tvNigNGkvCjqgQ'
    'LcVqw4ONs7WspxvD+sHN7pOt6iXZcyO+8xPF4YPDvtM9dmb3s9rX2NUrDGBW/+cMIkLOX54X86lv9hOrv0m3D+PXf2+TmC8lz7DZ'
    'lQm6aTZJTNjdyOApV1RRvc6v7L6CZdV8XDaX4dEvVU4VKuFidqDrA23o24bMLbPVQfJf3v7y2jDMwG4uzjZwflZ3TMnQwYoV2EaD'
    'ftKgMqZaZ5lDbbpci/bDOoCwWPBQZMCQsQrDxswGMwcPZ16V+PramSGECjmrd8wWe5vPRb39FyzOXti8EpV+0nHTap1ciL8My+Ry'
    'XSHiwwV6hAFYNlTzB1YXRpC5ldWE5xEfGH3cSIBHQB76SolXdm+pcAwfi/xqcBEERUaHxmyAT5oN/j/u3qQ5jixJE7zHrzAiWOlm'
    'AYdjIYPJdBCAcAGD7AQJDgFmZBWICPpiACzhW7mZYwkALXma0xxG5tA9h5lLjUgd+mfFLxn9VPVtZuYAGBlVLdIZVYSb2dufPn26'
    '6+AEaCr8wnHfHjej1e/ZOe9U7puYPbOtT7AUhVXYE44F7vXUAwElBjJUpGRhTh0jiYwzO0Uj/GfgbGnCLPBmm4pLuHAZwvqoaEdf'
    'Hl7xNEG+jSSkBDXF9ik3k4svTUQcdaUwoN6lFjqxhbg9vvq46LnUlOuP35zIG7gBALPxu+PWERzXT92nH7UCfTnXwhgwXmRFZ5D1'
    'aPIN+dWgBWiM4CE6aDStEPSN65EXw7Y+Ef8a/lJZe50OphI91encJDX+ioyoxCmxmgN6Puzh+OnHdQ8jGLlP+Swa+jsAXAFZPeU6'
    'hK0obQGh0FIEB2uacqC+ePlzvvhwuRk15C5gWw5NTuydeDHhp4ZbhHeGEovpwQh3UOIZ+dMAgKisnrnTJRp2DPci0Idw/GtH/el4'
    'ImrNEefUYe2XBrrmEXkxhxKPORG3z6u73T0D70zLt8vlatxo1kGmsU8wYANBoxip0sc8jeGVvVd0eqetyXgSWx77xrm6jgwmlaWV'
    'O4W/yFrY7/6KbcnGEEQ29Bazy6zrBuyiVYG+XeMGdrQYrLPKxRKOsGYHDoFq2sJ9wfegvtcchMPO9PRVNi1wHQKX07L9mJ1mH9Oj'
    'PJbWmtpB4nz5fZzPtjgy+qTkN6owRidp+4wWeifLi3RE9RrZaDIriGKLVY0T4Fm7nh6E+vc3DtrclruD2dQ27BMLt1U6TS/hu0r1'
    'UqNWpfUiNPaB4LNzzLDlJpu2qLx4ZW4TtzYhwoCmkLYmuP1Gxav0qDMbFOIWafvHEdUFZNgoN0RU/bTBB4l6huzoz+nlPZq9pcn9'
    'TnfuwKy0yaIZtusNG/Z8oGnJhLBiT3UigmgxSmQQkD2LaZE3eA4BVIx/HE+plYDNhJ46PzsGT/ICzBQN5uUgo/F+pNvIkBUuxgVN'
    'scef/wp7zBaupEh6l+i1cgOLbtUU/Wcuioy7WvLSlSy5mXe74wslD34PK9yyN7HLQV/vbVJDWMiZ/x1Mbrmd38fs9uabqmlc6IUH'
    '9c8O51C1U61Ooatm3/OnIGaw3Vushrtq+T1/+GIa250//A9Gb8beWHlJpb6qPhUrxqfCRcgbnUbd8TmrPGdw2O1L/HwvGMgk6xHo'
    'MovlbXeQzp79tlbmbrOEZn5SuzqS3f5J7bpIvOcntSvyr7wiT+xa+OfrQrQUaOK8HdkIokSmaegIOTBYnUnKp1WyUip14NE/RRBS'
    'lpNF8+FqRj/qkZfTycKdZvQmeKkynaXoMdt3BF39aCWTb/iXMfEklm3QycTm5pLGR+f/uMV5UI5FOV50ugliToAFFSE03faK1V0P'
    'PjmmOMIXKLUee7qhFbb7sB9/RGjxrjgJriF48xt5caIvlH5Q8hkzEXI8DuGcyEvHSCgVvcFtrZm4Yw6gg8KdyWRw+Rd6LAWgGBFL'
    'RuA2oRvuojeY9VO+/WV/dPdNrF+Is0J3Ta3Sykb8V3O/3+LAGWCzwGbkOPDakJBpI3b72PB85h6XSl1yqUstZXzjHq9bqrt0F2kw'
    'ZXVOBV3pRS0tXU7q4Hz6bsyLIoQiw9NVJLFKEUaHSDrJyd47GY/zUsyBQpJZ0F8vQgWIVjhLxxpfJ4dfMZo6Flq+xAtIKZPm3Tj3'
    'iERC+OS6HrkWW0E07o5y4c3Sn1rbjYoFBzTyY1ycxAeCQuLg3A3UzSCAs/S/qWRFTnRpE1FZuyxRTIQS26gzvZ40QuCUt7xYevOW'
    '9qNmVNMUgvbSwB7GjW9Fg3XZSFpsa/tm/90ONQMy2xcHEEVEh4S7nPhYShJPm/7Fifv2lr88mxCgRv2NhXcPrzqti5sm/lzeRDsP'
    'rybySAB8swAJ2GBjYUQc0AJs/8an6cbCw6v9N9vvtvcO6Nzun6TD9LBFcHJjCiwxg7yxsNb63r7qdxA9atq53Fj4Y+Reg5clWnRj'
    'gTHdwvLmlxpulOdrghAF0Z+CGbtAOrInZs8R4Unz1SMz65jpTInT5DAmDFu9wwYDoG5q4qw7nT47JQiChpmDhOGAdyf7PvSzo6OU'
    'DSslD3uyblwrcK7H59KPKCZNkiQJPpfDYggnh9ODuLiUrVKYF48CRsCAEbEcb/sSOs8GENDw1CKHkwNDk77RqDlYGxXRKj9ZjgDk'
    'c0Oae6zgVDc5cV2Ek+SIEybopd5IISKVE7XDi9aKPuXiJwIDcSIMRzM+SiLRRQSFDOkDx6d5ow4XDsczqh7iPFyzVS5oMs7AhZQ5'
    'IWErNBI/eMyV+4cmQuyAdzRgVd+W44/Vce+TjvywUGdA01JeAQoWnx0N69Jh0QIqlOJ6pS1Cx8RgtHhEWNsDaDqWaIONFsU/IcSe'
    'LxasC8lTaOI1iEJg/mhoJy9k+bxeGJhwHxw6/DlgM0V3SywOctuhLd+MlG3EhtGXD7JDLzsTEJW0K7plb/uJSRPlh0Ub3TZ1opbS'
    '3BvQiMP4CSQvjtzsudy6B/ByQ46JXnqPT3GOCNw1vU8yzhk0r3/Yq7neUVj6L15DVIxsz3hnhwErr7peBqd3LLy/5qc6RZ3J4uA0'
    'WPPgIHvHuNqrCmrqe037x+mhfx97C0vH2fSIYtV1renV8Bucfw54vo1aJYoAOCDtwBhj7ITPx7etP4ck88ZZsNioFKlssTh2W8Cf'
    'atfjzjPWZPt0x/83JQJf9KpTaLS+ElKedwZdsX53oIH8iOAjfAnleYtDpn8vmXvNu0xCaImVpme95QsSbOELwnye1MC+Z8fiJxL5'
    'UF5JKLs2j0MsDmgsTb4riI2yjTM35Zq0uhmq5ktL2XZUqT/VE9FKW7kOwMd+t9IYpiknphy95mwRk8QxROyOLNCS9tth7pEaZBaO'
    'BOuVtjoDI4sSi+lBscgUseRJ8Yg9NfHl+1xTxhFJ840TuOpVWQ/vUs7iQyyjID/5cDcCvHM6ZrnnDqbiEeNEcciOBmqgbQ0krZMK'
    'LwbDwuUkZRVDP20IHPB02tHEaPFgI8kesWxOnbH7UAKQ47+Xh8ktWj1NRt82SkNlyoIBGWs2f1EDWXR5rHTZNhBOJ4DX3AdYxH9v'
    'K8OKQO1tw4/e2B2rcgvU7MgS5diI+2wfOLlbCRPMv0yYOOLAJ+kdngn5lTLhgnctLIVITLEaBkgsi85lzsCd+/iC3+YX6447l3KX'
    'Xrl/tuXUfMtnzmupiDKO7JvcYqYhwJM1DhO+2PtwGUy2JdZZIc4zzhNGZkBI7bG/Kl5Fp1YKAmYSdkO4TJBbXNjoGwSUESOT04qv'
    'K0wjTianFg8ubUKh78QYNMvxI34ve2Gc6TSkoVFgYndWPbNV1PfiToqtahe08fSYHbA8bFRI6mIbAggxMW3/UJ5YyQiPQI9VIosx'
    'nuzznQaDHKoqFvLGzt+NWRVJhCT0c7suHGjiScfo7SuqHHsSAAPKWy0B1XJsWh1oCbZNoFYaWmFuupB9pb2xL/T8qz3Pb2Lcg9u/'
    'QjbfRS3XHkW9z/UQrRssdRfrH2AZPs5ylrE3goU5PHe/VTHJk7NvN7d0P8wF9xpY98HcWTQJONB4cAm4jnRFdNk/pkudooBLft8h'
    'Snvh1wd1pl1+z81akHtgZUa42X9Jd9UC2i9k6AGMZOLleoQqAu23TTg+jm1HHBSrXssHwGxHSbHYv49i8ZbYsrei/NkECF/Oyl3X'
    'g4DoPcqfn6RSzun6Khqye3GntKS7yC39rtNrQsK4RIcBVvR5b0r0MygvKq6pqSGEpHK4A9aRNk4ykRIFN+Ks071iOljkgSVwAv31'
    '//i/F6WV6JfxeMg5KsSNA22IlhBVQJnI0zAtOkqm6dW1BPqlnw6Kzl/tNeXe/fN67XXkIek79HJNsfGtauPUlreie3Mn/XQNFgmD'
    'zhDZn/gWUvOW9GISL5kBwtrXzXJLMhTBjHdlZfV72GOK7P1RKFHnhJcx/2t0gt+hQ6Pu825sTp4Z879GKVhXFPB8ulYVrsO4DJHs'
    'srNUibJI1KLL0Ss2axAj37Ek7TbhMGlz0+GkuPRSbYnUwmiKpGCi0Wtb+SSD0zbM4YCHwXZzMCFBilXgBu6EoNLCd63+t5ZqY/Qg'
    'CJVnclsXnJDQ6tnnYWjX4q3NjSd3nMZ7dODFs2fgA+O4D8Pno3QKN6YUUT0sfXRUvg2O+OoQOir/MStOjGlpo6SpLZNoQlEYIkIx'
    'PF5uOSNSIQqa0RHMVwPzSI4B3gSDcOQT6xjR8ufWL9nk4XLWQkJtGiAsM2gwsxG9jo+SFl3YozgbTsbT4i8ddgxlQ8Y4nU4lVzRu'
    'mYWXJi6vM2Y8Q+l2tABSdTolzJHnNB4hJ7h7ANlrWrL4SMmWkkixN54Q2gHwF2nViP0lUNlLE66GfUOU//RzXvrhskyMHaJj2JKP'
    'bc5yiAgK/NGTgaSIiAjO7p7fuACQnqYH/GbSkhH8RcbHEYbZZF69zVQxWxrTulTaA7vnqsKunoMbSwDb3IsGRGcR7rmWzDSkk3HW'
    'Ja4sF+PGvKWRHrKJ5ELiUMqEVRFXLEJQgxEyqiFG86yAeIf9r+x4zSyARqQrQkM5Z+PjxRLLKVNXll2D8WIzJXObbQTdIIqSSOdb'
    '3whQv9x5++Hn/X/+sA1NCbBc1uM7b/liSfDPknomN9ZZX4a52PQteNgXi51Goyld7WdDjjRRyl4BwHnB06qEwK/zQWQDNo2TVHb1'
    'm9rECU7cSScq11gRlsv2k4ASQz1jUOq/RO5UGLfAhXkkl+UUiUdGcklOkXJElXCj9SDx351Bh4NIWgOWn+KOlnloYC0hzMtvERzY'
    'xSwuj3agKTJl7a846lCbxQw88aaO7MYU0j1RwNg9MotlQpFQkUBF5BeULG0rgX74oPG5aMBSMO0QaQtPvdhZCPsWhN99HtE/y8fN'
    'qBE1EmPxRqR449e//3tDAnKwo17K9kQu8ocbwalQzuzqY6J1ND6PGibG/Fs9NerHHhedLsc/50s1VyUSPZsY6l1E5ii4yGg27LKD'
    'bDdFlBQ6aLyicLszh8LBK315TVslQZdhAufBqnGhL01/yhOneed0jAoZdQATA12RxEUk+X5lxcsY6pnuWk1wKPo0kH7AftGO5GaS'
    'lF+0iXXhNYIg6tAgPaYeXPJO3/kduMP4v4c3nrSjIbJos3DHLP+EHU6QhMvNvJAtp/81DOfui9TUqo9bkRVwdX+KD5a+W/z17//2'
    '63//91//2//49e//3+H15/7iQSs5TD7ni8u6oma9OFaUtC1a+ZgnbcQFdK7kmQB1aRWjRLAxmUein9iaM5T46T2eB2OXN+qTzkJJ'
    'xrrOm7epIWDaUTCGrXAIq4fKFTfFRxUH1/oB546b8nctCYVDHNTNDNEP1mDsWJn3t5y3KGwnnlP2qpXh5rh8OwPWkg4kJuBxR6Ql'
    'dIPqLeeiOMglI9c9B6mjQ5Wnv3Ht2nxL1K0fi5xrAhyIMRVNJYkKO1XNWOLZLtXjwzYfEkkgDnmWGQR+q5MQK1wnoA+RDGOMm+XD'
    '853t/f1tJRlLXZjC9V2FzTO2enmS0hFVRBNnBWt/GflornG51/WOTRwRgRgXuNvp2OJOB6Qj2DWaS/sBnko7I2LOJnHPsy5/DiuB'
    'Vpbz37i31eLBJnNwSvfybZ+PZ84x5/V6wwC3R5yhIY75G+Hxg0NB2hcsxr7Y4pW4OPRTOPcDe+orWac2dxL3dCB22fStRq64gStF'
    'Klma9MrXGi4UyeJoq2VCEIQosXQta1fBeUHjfOOObBuSe4n74MzXeq5UntZrYeOrC1eCCylWhonygGSWBiR7LfbdRC8+dPbUBlpf'
    'W0j6wGdQIUmOqSjdohiDaguli2Xz9DzMSjppaYZotEzNcv54Do7KSUeyfp8Yzxb6QSgwDmiphKOeepevRfs+sQQnteUBJFcTgGzq'
    'CJu2UelTr1KWBDjotZvRKxtBvVdllvZ3mRZWDeqSvABNEaeQKxMibKGkBOIh+XyiOKQa0HJ2b+VtXy9jYLs4W17tOehY20AuCerP'
    'MaAeZp430cytcqfwRLPeRO6d1Igvg0DYKaJEeeelh7KJjmq+KX2B/nl8ItgATwY2SrgVk7WJQ2z6NL0JNAQV1ylTsMEychROc0MO'
    'O2qfWGdBbbCHGC0YWTzaTCS6JeELCVTk2/Uktzbl1LB286XB0OHdu+zQ07H2hCSJYw44rpm9Q7odrmEYjrnmXFWVziJ+hdx9qlAc'
    '68DU/giNr/OiyF2K5zoz5oHMSdGoiclSZjjsK3AbpSiANcZQdeZQNZMc6CTRj5ui9gtu2X8JCzR79YqVPUzrS4C64QBV8IWXAu8A'
    'b9hk9vGKoBOxaJb72spQwpYCO/S4ZH+strVlPwK1rI4rhslecc+ZwFdzlDt3Mbs0Xhcbla9IPHjIi2FZK1OEPJadqdl5GtkG8JvH'
    'QswpLNE9nSEo6H7dcfHoJn+bTWxv2Y2C78CmOb+O+R65MIzsCl542qbaZY08zKfK/VHrNOPwZIT7ykQqU+n0WkqY9GniAuOhBn1L'
    'VCNutIYJ2mDTsYF89cNWjMoNJlTIBL60ZttLq8yFGjWjou+hBMNXlMILwCSHvpdW6LBqSrVFl2qbIc6OiQv6g5LrHHs5siTmx93d'
    '/Z9fv93ZWa+Mm2eKcXPMaMhVUL1BQEHj7Y7PwZLq/hjrINExMJb1jDsieMNuGLt+GrAAi8sS9MQY+9d+s3lifROCMN5k4Su2AgiQ'
    'L+tuVTA/V85sCXCN6KwMmeABnmacOk0jI+j15Hi+XJ3D8RWccRzGn3xhcrEG4mAPxjM6FFR2AFb5ZNZlEjC3eQp1WZOWH9Yntlu1'
    '4W0WwJPjpI78NHq4wrmw3jxZ/mbWhWHxFs/vJX8K5hch+CRXsVPlreJNeJ9ycmdEMpVNYWCVCR3WhL1nM4FOwXYCzjyAXlzyi5p0'
    'ACzu4PY8daaLleiHSuS6Cht8/dih1N1BI0lICIMMgWqW4RLTfTnqwVyQ04fBqckq87NpdHDA98vhYcSqvMiSOzkivEPu7eWpVLRl'
    'ebCkzoyn7J84J5lhGAnAc15nm0ZriMtXr2+KALzEpHiffmu0XtrRL/ru4ZVX48bM5YsRXu07TXtHuerjsaGp2550mihpVQOVKHrM'
    'aeTIRCPLNuJcEcEava2qaJwBmZB+mCIrKQbWWsHxk7NCxbS+wCvnEy8y23VPIZmN4nyu1UaZun1ug1xK7KgO2y0iphFsmw2T0haK'
    'KpMsiEalQK0XaadvqHrAQ96qMypD5X3uz5M4J55BGcECRNTIZCmqpD1dQhfRsjD8zayIWB3F6QdgxM/h+TyBvi9E7c9EeJ7eunLe'
    'qHKD7TyWacBZ503EvkipQ2J3bN4/EzjCK5M7s4ubUOKuK4EICYEAc+SxP7plSwjEO5JEvwJq76H1DpgkG6Q55I0h3/U4lYY7Pl8e'
    'XmER6cy8nBV8lb9kHq5xEy08vEJvN/hLBb4wB0e/zaHB6005bznXpDpGB/NFnuVYmfieuiVvj0fjqRjpSuRCYuq3B8ZhnoZqfOrx'
    's2S3utWKG9+q6on9lIUpp5XvNPWoEW4GZ8Ai6KzodNWO1kb7qSo5sQ9l27XyaGEMROMxwPzAuVo8QFFfZVlvscAqd2kSAXKA8TjA'
    'j1XvNMuGhdzurXWZ9FjmXHUNp+tRveBtE2b/7v/F5stOjzinfxamVj3fblkGYda9heC0dgb3OF2ZxTscuUtvhc50msESL8bUGUEy'
    'zw3kI9eqXBY0igGcHKNuOoA3CIeDB3ZN+/NXvsb+CiHFNsoL02R9OkiRGAW2RJeuUsBDwQhH7Gt/iwbdatnn+aObhItGY6568SN1'
    'bzc5Rcz1ziGE+I0XqUGGd1yGAcFMqMl2DSbajydXF71EWN0HA2mh4URTRpLKI+DqsL4zAjure9sSMV27FPihRqnUVm3cPEAPxGne'
    '7R4nTQ8eaZQ0tECeWK+/P00vRRM9x01/1DmzhqJzLrFyNFpiIPuea/y9XN9DeQtTxXXylrMLjtVxYeK2n5lANxyjvamBKTdQ7juQ'
    'wosoQb+Qly2dTvzcn1KEDX64yIVnQinNGMdirrmpbX+HmO71g5OERRtacFHqfWfyiLLlPpd4RusD4OdV4lfrdvlcWA2OJ8zhRI3D'
    'iIYCDf1CQjLVBPDcG9JFfMIy2xEn59VEmp1ckYGxKxASMgf30xsPaZtwg7FDdN6bwowiDlJ0n4Ak751kk5wYJMGAYgNX1e+H4Z9K'
    'pMacfGIiemesX2MUetCjHe9dQuaDSC5brWJsckiBEz9ghw0CBqP8HGb9JVD1S4it3o462ZDhUKwgODT4CVGQdBvYHu7ti96M4CgJ'
    'eVN3XBTsNfmGIAmeoViivJG0xkdHhMKs6zrCOdUFhWIBlA2hFPf8OA4S+old/YMSi0EJ19albYsjP/X8WA7S1uVqucRiUKImzv5g'
    'DMMmmnA2gjT2QqN6wx9mjKSNHYx4iMi7UYw/i1JI3dOpzCKVlmdNhDVGhOG2iQmrCZjaaO6ZNoR/uf02epJOtrQretGWhFIewysR'
    'dk020iGiCtCgEuV+5avkKOWvsmmeP8AFi5qA4zygu9PmU1fqwu6P5heWBSZSEftBWOAIyi9qrOzcxLGNxW2plMCjKIWtjMW1qVjh'
    'heRoAqkGL+ViE2oYD4WxgfSsIHMxwqftTT2Dx1ws8fltxSFB+Hx3tOFJBcJ7mv7rjJBQaU04TYNn5n4j15StfUstR66LQ9mL8aBv'
    '2VRetkIDENDB7spHuLfGo6R1dE6j+iPi/eJa81t5K9G+5rWTmc8P7G/CODYmnt+eRIUARVDXkH4T69VYn6mpFcgDCcUuPeL4YNXG'
    'byESa8IP1ccZAsTadmiBp5fCt46pkRYcg9tEF8YHwuYcJmy7GDjhBma+fAwCzsgeBedqge8TBIk8IdZskDqhGY0ttwOdx0E1kpom'
    '+QuAhW6421q9nUUznJiEkqqhZ4djcdI0FsTcjppJC17mBTYIAcUh3PPjMc0jV3kGu5N0pAQdDUp8YXEknGdszXpTL6E0nv1XT+la'
    '2xmfwzMqT/3ongMdzi9zhxK4qMEEn8cAG30TG8rTh5jmLhvzCfFbK/YYBK24xSoA5kpcJMqFFVOrwvhSJSowYWWRSl6SqNR2flHf'
    'uSesWq+veNawli8ck4eZKxkBsmcR8K1LwoVM0j51p+PzHGGsWJ6hcQXYxXxk5Oo+F+i2wJNaf2QaQMRI+XlWiL0/s2nKwp0T6wSH'
    'Ue4ZJx2hEoTlM3H+3WmJWQzIPEZ3fJG4fiCUYiYQXtPcvoTvF5MTDnGvjRm9rTVzU2n+XIY0sOT0JGYmaJsfwlDuUoviiBw8M9GO'
    't/5RwUpSkY3NY4EAaE0o1apR+nx46M8Ff098N/cM5Pc7i0ja+VwwAn7e0uB4boNjRjFzK6b3G0l6ARvxXTGu5AHJmw/vf6hpXNte'
    'ntt2yUN8/vC6dzSBi/+W6tkd1eXGnz+DDXb/0ofFWzAervB4dW47S3dVXZpfd2VuXTFKOcoQuEdiZYUBsX1Nst0S9fVxHtm3yFLE'
    'iN/GTNSmysI2IShUv68fD/E2Di5CbyVfr/FTfBpqRIKRWRa/bnwq57IG+Oi7La7S0flUsAnn2UXklyjeg0lvM3q9xrJhHg5Lb9Wu'
    'Hz/yxLcExEeOPGcmS5d9Zayn4iVI/21FcXUFWtI5y31A2J3KnaoBlGv25rZgi9Zd38hOAke/exEc1MSeOOvFc+q/YjWrv1Ev6C5g'
    'e+hb4NdXfcxrWTdcn6L5OIdD3d42RRcsM3TdDmINuWpHGggkCaKCiI5DNdJBwI75oTRuasfzfEr3/E56VMyn8zpnbCqwMmdG3ALf'
    '9Lc2cVcLnya3Vl9B6sTb6iMaxV0tVBu45fzOxVkD47Sh280BKFQZJSpFMVykEzMvTihdhkwvMIJiH0jj4ybSXE1+Lc5znPGiD7O0'
    'ipsRtKjGKyVnnVXbchGswRI7xxNj58gTZ0oJZrRcgmNQcXJt/Yz6VgfpOwIQhtjPikHqBQ4H0ijwzmo47Rsr7s5Ef+Yi5ekLz2i+'
    'Fcvsr/+Wj0fJw+XMBl9WyVlnyHatRrdq7VHioSw1cNSnEffbD70OoB9XVwMb5AetmY1/thE9cjat/hdRuckra3RPMKiOGM2IkWKD'
    'MXIDUcC5pJi6QyiAx9B2+oso+rzm1vzWbozizx8F4mtzxLAvTmSQD2bHlsmP3ba4FT346fP556XocNH4YfixrfndEpxSfH6L17Dk'
    '6ERLxkAGpbtkbhxLAnXeRE3opElhUTJabUVvdvf228Za+yzrMLjtCXC/MqkdJxPJZjjozJDbd4pI8JyzV7I9svpnj2AyWpY/BL/L'
    'EXhNQPtgfJyb5LDKpbC9brTWil6eTMfDbIbTAOe9aO+SqOJh9LzXg0Hs8w9vpeSjVvQBao0IIofBuAMnG7EsB0kexa+zKfELF9Z1'
    'Jhhr245JYi5wKK6UMxKLx5gxQcBSIKcJ8zitvQ9vX21//BkvjZSF6n/I2HHlAZcl/NPIT8bnaB/Dx0cQHjRQacRUnPCH/cuJeMBc'
    'Rf00702zCXpvRw1dbrONzahD858UbUJpgWcbjlujHR00FPs0DnFLHJpeXr/d2f55b3/3I7vEhbDRxnKpJxx+fuhwlH9Rg5x3prT7'
    'r8zaVuOiOrf4Mw2xAXTbxxuIEdeR2/Ccte6MQV1ASfval6uLtI3OwZagHoCywTKKGhjBRc6BzwXh6DI+hwCbGkBTcM4aDW/JW5Nz'
    'iBSY1hZ3lkJPo6E47b6XcTZGNAC8LNgqihk9rBx9lcB7RVicXjTW+XVYofHr3//NfOBZb7iJSly8vCGhmmiKBgEwDUY0QTwasj1V'
    'LGu+FR1QO3DPOVAPhmBBXAcaJmOsQdKFbzfLCsm6hYWt6Mvn0cMr83wjlgqJxhaUJTPN2lFgTpHYOLBv3Zw93Zr3RTAycr24Rhoh'
    '8rEqTJy4RLWoOLmDvWI8hYc1FLCENGIH/hUV+pWF+abtu6nwe5OEKlYffImEg0vxiItP/CMjMsDICZPsZBU0/FOGmvLijakm9f2A'
    'E1bq5N/gciLj7mDcFRuXctzPeeDcka3rtOgyOJqTEQutgk5v9d3Jl7F3oETqaRTNihSlLiuRdJSwIGPFE5cTss/Yn0Y9O6WF0vYU'
    'Y15miRgl67tqRdu2BVsbhmUvaOzxQdB6nBw2XZSoCt5kgXYp7U9nksUThorumDUwVzeB9riQ2CMbZaBkCs18nc44pEtLLjxweCzB'
    'okPHHkFCOzZMaoqpswWY2hRCRykcFGUkV9EwpVusT3P4QCDfaLL2j9PKXsEKifHJEu6SRt00iVb465KMdmmftggXBo4OUQ/0AFET'
    'plqJ1oWXnJFWrLQ1uxC1viezZBEGXdbnvPrbRMFPY10Aj1NH6pVOMcuZPn+88ij5mjYMk42PLG9VXS41YMgNSD5xhZ9CzcS4rOh0'
    '7Xb9zaVkamEtYhNdQCmvK4QOGE/bduduPEeqaWt8CtT0txYXSioj1Q8oY6apVjaWYPybGktykmgamZrsdjC+UaoeywASlaYaEsVM'
    'L2dnnQ6Bw7nJ2e0Z9Q2MxSEML9FNDBml2BejM5gbQ7aQtKK3R0H72rC4nUrhzOSb5vHEYCKEZGEnKxZ+ch6nb6wAfEiUFjWF7KuS'
    '2qQpeYyosRy0Zj42to7YuKNOxsFkkBObrjjxxhwjQK5Spbokws9QQ+zkT3QmUghjSCoGvqSiQE0qYEkHR81oatw+OyMDIJYxsxG0'
    'Ot2Wz25FLK+eFBpOgN3ChBZF1oIRLw0LoV13LAA2JqtiRUA9/YAdsFmw6MVHWRAvQDbMOyAQrwklwHN+PpkoQWTLAcrAuO6NZ1Mi'
    '+xvLhJmW+esWn9sNXNbpCEkHP318+5I2g4ZBeN6dbAFlrtKibwyqG1Eg9g4GmzDyk44kGklwWK4YFajg65iZUWqQXeo6EQFrbzbZ'
    '8q9K/5RbdtMsFx2ZUt9OXuiW1ERuk2mLAD62xA3t1BmR0PApSEqU1cJ85Mxbqtz7OetEkN6+jKoBmwabEO6bwnM0AmV+CSP8MgRx'
    'gvaFcFwvkImuJs+Ykv/TcZcNbvj2MXsSqEIAw13YsSgnxgPbYsdbYDRgheEYVzsre+xgVU1Sgn4RLcolg32I/VumsdxochYiwgwc'
    '+XGJ1mqa4n5MCAc6z5g7Vr3x0Zxh6hlBEnznkVtS30XR0WCWn3jaRj+YpsWlljmTA2m+34TWcAF1wsvsOdrflKiX8HslByDkuOn+'
    'OBbSzKcDzu3FIt+UkvpxKuoeGZsUOG9xM7GlTFiyaL55MG1oS21RSEyftvRs+Rt7zCU0lOt9L3Yd1QSQrLLhcYukHi/u4XTpkhsa'
    'OhucraFfExuOxNErDnXkElLpimnctkdmwzSxHZUINCYwzMynOulpC3WdEqAyZylodQ1GSvVG98mkgpA11k30CvgJExFoKLFpE71I'
    'Qsx3uiyKmJbmoGRhgdhi6WUWiQLES0Ji9GZzNoVVal+9LUqDzo6JMywkmZnhMWh7lj+rEMBFW7JM1ZYr2WbpU8yMlZEahBzVlUMW'
    'ga/UvN1e6uS84XZgt+y175s0bYnIfGBiS8+Bgprt1y83igHu2MpblFIqwAkmXQ8/8lQV7sTexN+z/NZbB7AeRKb70p6bxA4nHDZv'
    '/VRmr2Lx7nhaMK3ZSAIbjBvmwZUV9BBL0/UdoJTwraxPScRDrLv5ravs4Kx9yzdAUbSvx4C4hw5bDNC54JtSpYyI3c+CvTQaT+fI'
    'EwX+K4InoQEqh0h0ypauqADuLSCLqg1NDBbCILrUEREUSoiUCjTWbd1vgDgrKtzVMGUVUeH8g3hwcmjnVW0ivjJg9/uJFYmHZAZK'
    '5YveSbaXs1s6GZj+OYGhKwNhIvQCoPQkvN3sTf4PHQhQJyzTTJysohZuNCgcS43Koz6yYzxyd4yt7ZcX8LiHIEjZ/D67ISDMwDS8'
    'YtVjwfMBKAwXGUl5RfR/IVYJKfxQAXHcWbz1l+2Pe29336/7TQ0zGmEhvgR1l52vZ7agy7wazgLxau/T83SKZeK11p0mDLHvCQuZ'
    'LeQYB6zqYi6dhnomgwTHF55xCOzTDiGC2YTG5YeBbGgH7WhhH6ZKGiEGtHknygOQXQi01nMvyoCeLAWRAFP8QbJkeSUkdyb8/EXw'
    'xCunqkJVWomjZp2f5i2+mRLO9vlgYKR5QQxZtZioShUDko+YiPTNeKhkomyYwMVW9GVXuAP1QGvq6vZNTB4FILMrMSs+jCAKVgfC'
    'MLNnJtuIJizm1VaNVoxPkne+ahylWF7twnX6QSzV6tGGr3SvTI7mRmPdeNb4URsj462kYos+HHJYK2QZqhD5++y03n9vYZFA/cRl'
    'xhc85r1Y3mb0aIUZBOHPJNapFaSocV0ghUo98Q7uNFEf1blV0SVK+Nstm9ihIvlkxrcr9Nl2rMHsmHDmAbE1Hm+3J8NowDSViFhm'
    '6r4JL8WjENsEovPjiug8Sdad15Mnwj5qmYd1X9Qtr9+z0Niog45a/Gu9zKuphStbRitvR9zviY3O9i2AYSNuLSYPlyX3VxUOHjwY'
    'WttXg9oIS9F0Lo3KZK8AMhTkjKhdtjOctJExiY9KJMISvnqMTD+tyFqGB6uHoGoliCnHK70HCdGMgtimleClUDjMBRlh72dMHYVg'
    'I4utbJpQ/XXWDzW2DGJH144+vP9BLBZE/AHxvInHGdotaKitwbi7P35BKP3JY/j40KORxX+ADpdAawrt5mZAjeEztu4ji7CZ3Yez'
    'lxB7cuyoFq0d/UtDNpYAzQaiz3FphIB9nsO/zVNZ3IimW/S6I52SRhtrG39EplFF/2wV207iyoKS84wVwYa4btUxb9vcuKeCQVCo'
    'Uf8WavRONkrGG3JRba9tw1FJPX/lZQHuYK2Ug9o2qxIwUYFl/W0c1fJsBARHtwhdYBzj4FrGzfRmYrhOH6DZXRrtOwEVYGua8tVf'
    'YgLoWkpHHYk/S4V1TWDoeSdhXacX86QlwcSVrAuyelXoxMnomBVK40mRV7RAE1H540Kkcpzxjm4OvsxYBM6IEDVb8gBDQ6mzIZFp'
    'Ya9ncuVFwh56DD40gLMJe9jRoY9VgsxNlaRj1ZykEz5HcO/60Tji9NJsoNk88fW7aC0R1zD/64n3tRxc7Muz/Ow4uhgORvnGwklR'
    'TNrLy+fn563zR63x9HgZ+r1lKrEQaZ6/h1c/3ixEJ+w/hqc39ATvnRfjCzxKulzq7CbCw6V7+BH/UOlNhJ7AGtw8Q8NIAmijOw2P'
    'FYmIi60ITYbHLRlqg4+JeOxSzUUa9DqRJnTNFRuz4mjpaXOO2JyqezI7NCj43pfkBZhNolG4+AugEhJzJe91jjrTjKYFjzob+dkE'
    'AWb+9y8/OAGuaHS4Q9+nL6d72UKSPBAkLbIUFk8O5nq36H0JEZx1cjXGavEWccrW76R9Oggt2Sr2BDRv7SB6xQUHWCDCgCW9xBw1'
    '1vpeBs1YAB1Byk3+kC17NNxbkFYS8VHceYoLEApEd1zyHDWBZCHZI7vH67YEx+kneKb/0+E37ZCNcpKK9qcdiUge0+Zx6foKTkRX'
    '2c5eqxjzoafNVK/viUZ9r+AHz/bceTrNY0e8S0MgyWAXCGycMA6dUc8TCQRf6RIa0Ht26C4dhdzOWXbcQdZ465yiUukDrMJL61gP'
    '0u/Kn3zbjZXumMMw9wcIBg1kiOQqppVGwHNeeQlaNHQ45Kmds042YGTPglRIViEl4guc2m04j2Do7M5PxgOnuYttMD8N/8NnizPe'
    '0HXHwSPZsKRp3GRzvnVGIrHSKMpNjiWPDugm6J3yxc9U9OpaNG7wuxZUcLSUbEypAZsk3jK60LZtuBqYo6lNg8087Hwi45EzdAzN'
    '+WoDTftw2gLS24okMw3bxxzwBh2yiYz5DZPFgsCG6aDdMAwNuwyzblaWBeoju3J0PO06taI9CarbllSeXrxNb8omdH2lmXzWtSse'
    'n6wlrei1C/eTI1q8xkoCFaGB5c0id7HiElUeEVpzowI2lTX3KgFaVrSiBYkwvIBxIXko4Vs4hXMb7BMOJZ7syZJPybL14I+sW3cN'
    'swpzwDb2gBNRvZ934HnNvkzUPlTCbKaP6BSYnirsXd5CJohyHDgOts+gFD+Pfv3f/6/oRZs7odFL1Jfn6xE+/J/4IG9eJOzaeyK9'
    'mZCZeCNDGo11HO4D6/sJ1heK8YL0xjrZBfxccPygqP88I2DMc4+j9A0C0yFunjixlvwiON15+37751fbr59/2tnfY9cC+WZQv1Zh'
    'H55R30rkEAirJXlmESSRwJrWvnF4WFON1b9hRVQw1edXxALc1WEzmt/cV1bMRlzvJlxFkffnNkiANjo/pP6gU7wzcfH9bTCR++ID'
    'OheHzANxZkZO9yjG0vEBMSjy6QAjO0xEpasf5RXbtFg8FL+PxxrRaGYtq2GTN1C/EEQqih9e6eNNogZ+SV08/Rc4WXlgtTn0DLqb'
    '0ZCYtQwvAvNrxEN4YC3KmywOyznQxMAFLMxyYAkEE54Vfgj4TtSb5QhRwAJgg3gtGnPk+CwHSRODC5G4xcgrSBRJouH4TfBuv4BE'
    'KMZvWge3ZiN25ZDo3hr6WMv4O45XGv8OwbJbrRb3F2RYMMH6NyLORDAgvIr4Ih2kS7c+8150kR5Epl5CAVBJPO7GIEMMH/CG2ojg'
    'vjY3RhvKb1kepH3GvZbtEvEdtVsVlVvKjbfM8KnSFS8s9TaEoK4aw/zUH+PQhK5zI4W85BQDNSNcCYYl+RA8N44gJGM4AhHXXOk+'
    'eZ4LNaHVhxyuL3eGCm40w8pojMnBvFmVZrRWntJq/ZTWHPPsSagZ3m2EZH+eJ5U5Nna9FCzQqFaH7Q36iG2q0HwJUI4soHBY+vph'
    'H/GwV72dcPiLDoxarT03UdBy9d+l6+YdMWbgtiWkXy5HR4RFgnokajxd/Z/4qrJEgyTCcRSZnGd0kw8JHVBR07Qts244po4OnIgK'
    '/aRR4iRnuubA4CgLknfCiwKEge+PTdvxSTHkNZdxW/ssOyy6XL799tsGgWaZ6+fgzsJ7vtp99wFMJbHhIkRFJKQ9Np2MvzyD5SSx'
    'sHlnROT5L+pTj34T4mf545emBENdxlui+fDSYY4XO7sv/0w9Lf8Uf7h+s3b95tH1p53r3Z3rnbfX/O1/+7S7v3394eP29f7zFzv0'
    '75vt56+u91/svvrn6/3Xu7v71/sf6eX1/qvrNx+Th8uu6TTvvZO8xISCZAlAU9KeOYo0Pvj8+ct3Px98Pny2eX2YMGH6+fPDVd+f'
    '53zagYAiRi55D51xDmxuFYjfRItywRP9mEN0oXUQm4XgsAt1ZmHFvjGRwwmNIv+8d/jdVsKPKgC2QNpBtBb8f9bXX11r4GMSfrDk'
    'csPE1DdjBBjJRdNorNci4SCctgl9i5f7JscqYgO19rf/uv/z+91X29Yt30UAJcLmMhJDrktQxmx1ttslYM6IpBQ7yzxNvdzCrOyj'
    'YS2aaIZ/Af1QdfuJrHfUcvz54PPBwU/07+Hn0eEi/Uu7peQCQkrwxmTRP0Vrusm8+3GRGJ+lhsWGUSkslHE6r8z+gZn99g4x7O/N'
    'ApRrO76nh5znYl2fjUapM0GU/aG2e/BoeM9r7sswC/X/ZLdNfdjb/7gL3tCsFMAwbnz3XUMbj5MkiGXstfPWb2f7XaWNezSxVxrK'
    '2z9v+29ebe+UW/2v//Uezb57/vHP5YobG35Fga7YwA/CP2XHJwMINNaNd6DNbTDm9FkIFpzM6fAlbVnDGXFBzCUb5az51s1wDI7g'
    'Qm3+01JWO48bXxos4f3yhQWrXAbs6ZcvzJl+8V9+aaxbmCoP6HnDnTab41a8FFjw9LwgRNKdFSldm/QarjvG7UfXyOOag6Nkhh9L'
    'ec6n3uUYshvSwxZ8+oT+BS2Md0IIs/OCbQ7K6S8HWpJjsPBR4kI3h1rR896Lk8/5Ic5rVdSYUPvlQ1YB1ncekJs5NA5UkMh8/5cH'
    'B+i3vD75tNfweyi3/OJjTcOfJTR5FNGPSkXCx5+u9z69oP//cA1YJVwsgn7ESy01pduB8T17eFWEDoo3dClqAboIaz6Ho9amtYYf'
    'CsMnVAKcL2lfotgRyUk5PpXJdyVx5uU6AN+yWrkLBhxfOh0IgpoirpB/JQwyg9nECX/nbWMeHoQwmzEfNWbq8G7s7jQEArPFxZsW'
    '819LyGQ+60Ym0xMfKJuwTFoyHNYiO8X4PTHbyHEuaXgOsR4aVqvHcWRrrzMfobM5Ie07qA673RaTJw6XCbXF1CdmwSO+Eel9OoU0'
    'X7E8jSuppMv6PBLaYiQWZd2Eo+BWyPOeZPTytsGA5bzh+cMCSCDeJNqvAyIp6qdmCyCKzXl558qAxHIaWWva1iCMFcw9GsW0kRzy'
    'ZVywdBkFi6mdxaEVBxR917QGCU0Hgtt47Yq+f0XeS3Jo9YB8LhPTIP54dN5P10Q8EM3w+ZqbeLj6+fN1o2zYdYBKzOJKAiabfIB4'
    'i3iRxhbiH7p5xG8SSHI1QSjmhBn9AcgNPXM3ftLvB1jIchIZQ5qZG2qQ+3kPaDBcCYvLazu1IeyNBswu+dQbO7ez5EqXx2XJVzuO'
    'sBtqOp4a4im6pjVPSpDjYxkzisY1347Vyny0rxsBXXvAW45uwYA3TWU3fjPopSU4gFdb4+nysMVHfVVzMVKzpRSEAZyz5NQkZiuD'
    'upXLWIw5YBto90550oFKYhJf6184UOZqFlDlXkqchAb6HK9lk7ihjj73j8Q8Sr2WVmXOhLmoKtq4kt41Pw10xAad25uapxgnt9K5'
    'he/YWEfm1pxUvZ4/eHTZhYblNSt14a3URTKfmnqz5lOlbx7VEFde0/ZLuQtzpV+AGDLcMV9W5okQvesEdMS3Jrj5w6sLdhf+8t13'
    '+Pnddw6xzxu1Y2wb3iAELGkvLORyIko/KaXNNGpHLMkbMZRNORcD/5jOpcOJn76DKvavroeSzXG9umBKKhNV/EWuNkMCfx7Rq8Yt'
    'O/dpx9+53R1/Jcw91rhlBm8+Nmo2sOGMd3hRGHPMa4IFCn4r4s/SK3VqPyONhtmj4HoNDkoNwaavtDJH3zdEyovxGLnUwj13DsRC'
    'ZewoHad2uIRd+bhxkOpa8IC8e8JxIpCEYBBi7rK4Oz4aBkkGfAzIcr2hrtewb4+Xh6a6LFEMJedJyQxIJGobUZcR1pakGOE0USWJ'
    'lRRoaci5q8iJwLocrFwGMsgaLsWC/+FkTc4mS7XaRrpVwmAmHXBXdBUu/eeX73aM3q39HdtrSAEv6ImoDXxk5ncv8lwPoBrf8o3W'
    'VeO4Rg0sBsMP6qLHb7+ygbWaFm5vwpWOHOlNM4dQle/ZJa96mOQHyygKO+xmTsy5zTGYTZ0odDy1KbM9q5BsauSc+dhINjkityg9'
    'w8RFTObUDDDgCsqLMciCwFW5jy74bOjU5KPmdJLcN25RBKt5xzA2Kc47nFAZBRQ5Bpiuvl9+1uJ13WnbXnMVzcFXnry6pVNma2sr'
    'WknuDcoWfjZsSzb0sXzTg9SMnqyANp0LaMHil+BKhuGfy+quRbKuck61kfJBRbmkUWrWwz1eq5W9vQUdeUJ/TnpaXTGgH6AeO9aG'
    'vxRV7YOHmf0b9+pR80YZRv6kqQgE3lRjsccBsdRotZNHb/bf7TQZPkzcULFyx7ljMo1TUfwwHh8Tl/dq3EOUoh/HUz8rrbaGlmLn'
    'zQHBvaaKZ1PGjWhp1TOaGggRS20zIazpnbkk7H5xBrmFRWri2fIg23y2PBtsNiRW5tISW0qXsg/cBtmQDlqRoG9noVnDYOtTwNdi'
    'RIxwBv96f8rAV5i0xohlI3bU0soczSr55q6bC7FCfYWHDyfePj6DbCDearNB61JvYyH+fL6YLCRbm9jb+Odm1OOL/AsXjHLYh20s'
    'wMb9eDomXLrE6cbaD6+uomOE+ceN1v3T0UrnKW1FdzCDB/O3nbT/9OiIXkw4KmPj26Ojbr/fo3vvoHfIGnF6k648edK4Wdj8kngX'
    '2F3X4bPJ5rNs092Jz5azTboW07wXV08cxFyTTf9+9FDKA4ePQ2aic8zJ7vjsUM2TVQT8aEeiijxZw69HmIm0c2gvcvYk5hB7BrRY'
    'Btc5htxNBsh4RWRv8ppHTHQ879LNl/WSAOvGG7RcLpsMoUkJpp9F9nb0AZtA+hnBtoL14qIJYWjvAxmzqbtePhNSV2qYT95EzD0F'
    'mwYDg1+e9bOzTTOhZ8t48gIXsbWgXSiHddA6UAgs4/koGJv4TtTqj3sXYv70SzbBIfzrux1xbGxFL2ZEsiImBdx1kL8deWmadOcj'
    'OgZS+MIgTS5zGPxiJpIwbAQrp+60g8ACEnyATZbQdzM4nPFswsbxhEpeIahywsd1h+qmu0dHxOG3nEX+y48vf2YCHnRxnFSN0KC7'
    '/EQo79GaCBTWvn/iUsoCrY0kqSd2lL7Rj8VFZotN5pp1V/RUip5S0af0BwU5E3H0Bw67t3Kx/erF06eP1lainwiFRZubnLq9HenP'
    '9ag4GHFeWH5eCbynoYBOYhvwpzftPVrDcbwsjEOBGdHKxWv937qPLC84NeBlYdLb2JU5oKH8FBGf+wea4PeHbmxPnbs5F3ENJ3aA'
    'Hp9AoMBWkergygbw3mKno54uN6xKtlkJMBX77Gkh4uempJHoDPSJcymIdlkiN7udyySI1PgcwrY3hJNhiPPsWbS6Gl2b1+/o1Ers'
    'dvrwvXu/J1FjYswiWg3yJHH8JC32mujOf047kN0vRat/errC7fyJ2jEl3hFmOOH7drXchxswK1c5fQhDxzc1JgtYsFIqV/EcojVr'
    'ibokVt/LpnFoxPKibkuexXQM2nbQFkE98Y1sa9EmQAcwBgBy7pBWx5SK1wniH+NiPE58Sazm7XGb0uEcE3jg0/NihuA1XNlxx2dw'
    'ApQjBgkptenl6/NY4TNFsMGtgyhgNKT4EayXL1Yerzx63P3e0KMD0/Lqk/gxomqZhoMvT7jm05X6r0/ZVMUbj/9xFZ8yFmBVa66u'
    '8WbUfKSJrj7mha5vGd+fyk5aarimjbW1O8rQINaeiGtHqYzm/KCDpRyF8cqpbHjPrPBjWae1lVVvhXtzV7gXrvCcL08ra98rLW+4'
    '+L3S+gaLH3x8XFr8nr+4T6qL73/HYOsWNijz+I4yWPyn8xffb+sxzURQQFhEkJ3KVj0XncggDLrcH62of47TcHnDshe4eEdoChNt'
    'l+7dGdGXMdhQSRUKmXsLd8CODtjknrn1OK+tmcx6wUGmjX2y8j2AxS5OGm69UASlBUxLAFBXqNQZIEEQUrkN3ezK4nr+DBIEDxl3'
    'cRxYF6ALRFO3wfBY/GPEaRfDwXaOg8E3a+4psf/wbHOBldg9DZbW+AMCzP2hM5ysg759xk+Dgh82+eFYHhb44V9nY3pkmjupRtoD'
    'WcXDhfv4B9Fs+1fojz+/3wOHpQ5Hee8kHXbyFihJGrKwcTk7IJ0T0TSZjhEglq6E4QAeSU+WOW22u+8+3ru5MZNVr9SdRhqbpgN2'
    'Gc2RQMxrdTobGWuqL8/O29NN+oeXtM0xyzcWQAQiYhJ8mmSlY6bAqdgm/p36zk20aR2+j8D0NJESScxKNzgQpvYxQR+TD1NYmLHz'
    'zJa8Fk+a8/ZZZwAvK/52s7Cs1C/R+NwWdy21aexmLBN/FMO0n3V8O9wrRafTTP0QvVMItxta9I+8DrHcuSwTkYxnFfU7inEHng6b'
    'W8Ykp2/7b4fH7KNn87d+YfcGJFNt8RRu1EhAGlHD3sr4Qrmz3RodLf2ctNU+rJ/lxf7GwsoC/3phf+3YXx/xa/OL3t+LaG3SppFA'
    'XtRjj7bexc0CTZZ/XmLNUYLg+8M0yvp4O6LvGOPGggI6Z4fVgr33Zz9MO5OTrMfppWhvnnXax96bHVbNjcYv2cf+eT5Je8XGwiqq'
    'L9fW98dqm/JaBfKLZtPMevPdchp0ycypUhOUhc1n9Ks9QbP4MTqjiWHkeKAB6cxXzLRNgtxlVwLlMQO/uj9wvO8iyWQ2GGDs+B1N'
    '2xxLHQ3SbnN7nTaRgohjhp/GYQwNex+Wg8bKveQTWfOLo+kQfwkBRBc8+Ev8y31AVjRvs5dd1ck0L35Ix8MIPzYWpjSUBbzvnO3k'
    'OihTREclnS+b1fTHthxs2Kb3LBsvEMxoxAK2Qymeclc3rfaE0nX5YVqHXOhfD1m4c15zyKs4pPvksTJr4kO6yWznU75o2aki7hSE'
    '+ulbycFbLxuoSzvTl0TTPy/ilcRjho6yYns4w1TOm9EJ5/X7kf99k3ic4QW7JuBL79JYDrD4KMbb6LsIiQPPVeJMRTa1hSup6pXv'
    'If0cPlIFmuq6NIgXkGZYIwnJ76gq69B0GjY5jMSaHKxnJPbONgF0rsbTVh9QjMV8YDbRJALwsmK1QNLyvAvQOjs8Yi26FUQrjrJG'
    'REdPnsUFPc2xtPASVcpCw5uyRSuNP7Taq0/XnjKBu/roj6tPXFCMDhKVUf21bES892rr+2zkj0WE6xs1CisAXQafq/YgPWJvYSg6'
    '33IFKxhy11iA1hWsYwNssfoBJ03jERzk8fVcg9nFEmJp/EDDf5uk8L00RwKjwgXOQSLb7J5LCHcNuMBaOX0pm1CADGGhIbZCFh6W'
    'hyoH/RrnP9HgUQUv3Zw5w1pX/GDU908NzAIzuLdmzUVuR0N69GSFQNlpKNSZ5Kmy9IsoYPKPwhJb+1CNFJdmGdVoRigYzHeLrgrb'
    'J1tDw+f8TytrT8y4z4lairppcY44ls8fY5zH2Sj/BmdEQlCoMBlecix3MyEmypJYSEjUReP9bOgM+Fypj0xDiNmoF3LCUhaQ2XKA'
    '80Cky8oy6cUQE0xGcDs3TiY0ReQfb7OJ2N6V4VTsXbjHNWrZG6/hYIJ3omrpu05sH1AlQuiXsmekZhpUAJDwuIQj0g6qFDlzC+uy'
    'fJw2ueicUvkP739Y/i8ftn+QRGrjETVVIOMCB69lAazDJuiBKK9cmSNYpSV1yY/ZbctPfPxgZHRHoeDYq3jQxBVwiOqhgsBUFbt/'
    '2MwtPwPWotIbC/HBTwuHi8nC8nES2veYoSJSDHvtzzO6zIalQAH0RqME0L+mrMTFMV7/zunfc1+uGgHhPIiNz/JPDqt8BlpRY0QM'
    'zMMvYTFCNlvlgoyANBOpFXt545QsdRdF1ZbnXr7/nuc/zXLUIUjqDDhLcOD/775J9l/PPaASACDwuBeHe6Sek5HDld5EaPFd6dd1'
    '3XhhyiZBdmuJvcXCgF1lxN629ITI8JT6OG+XJ8OKkvIkLDdgNI3Ia0j8CrGMEzoTmSTyE9v5qerq5TQJWcxZYLOp5BpUrPKBY7KF'
    'TiUXnksJ24i0euxMeCEaDSLMXo/hIUwXSt7LiPim5czHg06+QK9Ono/y0qte7j0vbwYtd71mu6VvmfctK33LvW+QoJ6mpQLAhF4Z'
    'VrYZpnLl+yePXq6Wh4K7R2vg2rRqSMeKOk0d/3V6ut5lZ+SUdICSUdGBwEBaFU3dZToYjM8bTAP4/c44bUR5wDPTLUQBg7Q8WFhW'
    'c7V8NvEGDdz4nEY9coOWsnQy6Y+EUGRCgeqlU332hqQI/EIpminTzBdMF+O3I14Meu8VF23PqRDEjyGTAIu4OJvGi4/T84htu97Z'
    'zgQIMRPeqFf+2vIj0ZfmDOahC9xfhwP1faOuk5Il83+4Y9t/qGubJ4zJRaXRx5k+akpAmqRsXh16f93p/3U/DzDPVcQ3Cr3dk2vd'
    'q+WMYQ1UspDmwzQ+ouX9bWKlec5dDuf+VgevOaavp5JL1rd2DS1M7+PVhX2M0RIugFarRRvZNQYmZk9dq/d29KppNrt/s59ubWh2'
    '/4a+xouspqf8K3r6FC7zpw+3tnxQ8sc5vH9PoQtbTdtA5+2KM5eYgIivgMHz9+lOHdjmd4eL9/6j932iGkZU2GXhFB4a82s+bwQH'
    '9oQO0BQXUjRti+BPGZO43o0t4VBXNeOXZKLh+Pl02x78813vPVbFSEIRGyILWYdrvccqWCkb2ll6YiAis5gkA7PdYnoMYzdCA5EZ'
    'QGRg+U28JAb0T9+vfa9zoqcnj74ncu7Rk+//CGlCUoegfGcwb62Oyht7E2pY1di4pGP9wPEY4FJWFnyxxMsI0ysSMCtF57q+wKvO'
    '96yfTkr3jjJRs+Hb/lw/MMdTsghglVZwcDawji+0hE/59rZ2ntLN+v2utlvc2b7Coe1/lqOZ9ej8EDMMcASCKzocKndY8oQeMZYN'
    '5pZVvQgCaRKB02E5Ksvf27QnH/jE82Jb+g9PN7bE2777wo8i+DW1v3jj/Mc813SWxtqfdziw6L0XlBuvNQZG0JY1sHgv/7WQpYZn'
    'F9Rd7LBmvbFWvTN+l0NYkw58UrI9L3t3rToXplu854y+l8CgENP/EbwIqau4QCailaSmHxsT8WgwHk/j2AEPr9Eyj4VDMU0l7Dau'
    'g3/KSzwFPea/bCw85h9Cj60wwwZmaWPhxWv85zgPK7LlRnnNG8V4Aj0pusXf7rgoxojH3phyGl4OOQSr8Dfu518a4k3I3lnSlqUp'
    'G/+EeCFpjWO/Qwo4DEV3sCl/BOTpx4808HNWZmB5vuMVuMFsIKndWOhfdFjoyQzKlmnkLUtsuRo+VMortvxiD8WiqflCFoFa1OUQ'
    'otV9kGI7nUuM2rR6lF2kfTmM9PElUQrvOjwBHhaP5OlKeRC4yZURrf++HLa2bBamZtg/TLM+jRlPx/Tz5XjgLxszgsYCnEHIzIrr'
    'fanBxgTVhBsA5DWu76lmPmhJ6ETGmsF9wVwR03aVc8Eiw1iVKKVKPsMBwJjlLL5EoERahDy4OcLRcgYvr5868mLk31TuIKrTJfoy'
    'Fv7I2buSRN1p2jn1iQ0ezyLMDKvc1AkjnsqMgpI8CaXFih5DS08BvVeG81ENkI80ZbDZ5j3gO4f3A206mwOzGOXE3g09yGQ9TIAw'
    '8HiEVnJj4fUa/gNekDYYRHoBvAnM6RUX+P0i/it1eOU4IWoE95+ZDsz2nsDCpVGnu4DmQjwApFefqL0Jd3xdtuEZb5w8sG3nvRf3'
    'pvagadmJefQJWI+ELkB48QGQ1S2mFlO94YjRWh+vG2YveGyynh7jW70p7fwJDTZ4odkdaP6C1Vyt1lE2ljhiMHJJa65XxkwbTK5Z'
    'R34uS5v16MmKoYA3ouAOKt0YHdxBUkuWY/Ki7+O9mltpdc27lp56wPj8Cf7T7eB2GoHjllXVsc7IYvuSco6xfaiNK1mvaJSXTf2x'
    'Raus9Damw35DSVDbp1ubFc/ieb7FJvAEdSrHhSs27WpdOeZeT4pwC/Uuxl/hZPw7uBmX+Ks7iWRqy5ckmahKobPyPcU9JQfmWjlO'
    'rcjGEx64Re8FKOrutZ/Ls97qtOyAUwII1XSNc+Z5KV9xx7eJjZS1RYt2XqVGLOBW+QgVuT68shfeo2Ywl61ojUbwiOMtotn8JDti'
    '/e9KwupsViPfsOsJr6YMZC77e4ujNAZuXHDNFvgMw1xH57nLe5fPc8W/Fha3Em0qzhRRlWUoNpmzL9i8CgQ195JyDkpSzrpQVh6v'
    'GGCe33pbC866z97UO3D7DN3KbWfAk0O5q8mgfOER6pH+Ew/nr9axIh7OL8/mFg9wDET9v5WNXK+VypTAr8KrlnDOHNa16hFulusm'
    'UFTnu0fGyuJB2QWN/QxLVibfSPIiqwUpOzBaHUzV8MSqYDy3Ti+q5tPEV8VwJEEC428kXNSd/a00vTCNrhkcBlgKEb6oc+RejVxA'
    'SM9EIliTktMaL0pg3VVH8TwV65Z/2ETHicy+cSwUd6mkXMasWaBZ/P5P+E/h1FB89ZjAud5FASKY09lv7cYinHqvPtexJwkEIaNZ'
    'w4W6uaf3pruB2YQo7iYVZ8HA/9hgbu7LXMeNfQ2cGjoOV4yrra/688E5kjQj8DWYZGdeAs8+ukOQvRmJajmq9TkHAeLUAGygdoTs'
    'JWzSw1mGvMQGauLTKtEXk9Gx538mhoBhojgTZ/5KMl20AX4iC/FyC7RNvE4eSpsuWeSo7Xj2+0mFtOlXXHioq1aXixv7NUSyl6Tq'
    '0cl40M/V5OqCTjqsa2yLdsnV9GwCZ/6GBO534u/+GYRg1mQffkz+mzWwad//8dHq93AJePJ4BT4j8zi3tccrIsv4W89eXLATnHoM'
    'isO0ZnyeeSBsAxcNkpAHxaIW0KK5bp9F4poMgjJwMA2AnVJCqwx5taEngnJrXM4mfJNvgVS2wYbvX+ZLZsu4GHi4TlK7Wiui/S0r'
    '5Jm7q6ENy9O2CEWYzGrUXWtlQcL90TQ3Fj7tv14i9gsp9fqdwXhE2OUyzRe2Nr+BHbpphpOqCOsMfwdineXNFG8++m/OJ7/BWjv0'
    'jHglH02Lnd/QIJwqTH06A/+QATlIGrYnwB/QfkgIoFKC471fRKSwuvqnFaZuTuj3k6ePnspGT47fdYDWizEty+rjxyzcm0rCGfMo'
    'BJN7ltvLPMlp31j44wozyUdEbniPx7PCigEAQ2ZoyzpotrnWTfTtno/Gkgm7ztqnA4ffzDf2cW/STl48z7NO8JINgPRRpckqhxcj'
    'j38MBrWRCgRuCnxqyrBc71J93LTGLZgpb9ov5rytrcne5L+8zMvvBh3GafwuHS398MK/hJfLPUzKT/MIFuxqhmmtPXlsHj7OEDCA'
    'iXmle7UPv9XlcI52PazkamKVRPSqL+WUtuaCb/sbC+8B5QNeMHZW0fnpa573v77mk6BAhIp39WVb5/u80ri85bYR072/O6rrdgQr'
    'u1uHM39Z9cJZtiWUUHIb/X3NRss7b0e/brLmFqnM12QcWf0954zkl+9hpRQugOTW21h4tMaQFZh9U0Gl3nbcXVS/UN0qfbv6+tFT'
    'gtDlcB0f1azjo99lHdfmruPaf+I6Er5fKPEXtcu4et9lXHv9/eM/PSkv49qTGrzz5PdYxkdzl/HRf+Iyrj7xl/HJ3GVcu+8yPl7B'
    'f5VlfFyzjI//oWUMte3ltcTXqKSMv2VB74O7zKx6Yqg86wz2pEh4E5hZmJ+5f4VzujhW0v76938Dw/frf/93/vPf/kfDczk4Gkoc'
    'h0Y/7WU0SFbnwnhqJwXpYB8/joedkV9Ry++IP8VG5PlEwXkJPHs7+hNElgiGk1kLFaGBQQqzeYJc1OzfEpwjpndfDz3zW4z0AGHg'
    'Hx0qmUxt7Hvg+U/UHAQaNy37+b9YZgNU04K/6KEoQJ1KMs+HhPU/cFVkGuTRk5XSPUzNl+V2RmXyn7Mk4tFSuxQPr3j7K8v1P2U9'
    'rKPNP0jpuXZqib1ONycOu1e8n0G66D29ZQ9OFOFMMQyxrKUwyPCSKNP+O3zjrVNDAWwii0i8pgL5zK0drn5th8F5urXfEfc38vsJ'
    'Oi9f6yOvvu+3A5F31jdAGLRKUNi/md/yKo/4K8B7lzZ8CtFKPZh7n4Ob1Kvpg9aNnZV7p/Nr6CcBFJ/ZmMqZ/O0A+NH3nS+lEb2F'
    'byTEfQq/kar/Pc3fbzPCwk/f9llBky9E+3wjKfu8nJu3nHF8Y0Ge4bqGtaprh3as3IhdGNdO4AXH2yoe6QCOoexgpXEq02K35VLz'
    '7CDjmuaGllHYOE37e6hBu1xg09qOBrUdWfNR15nTrLQkm4H59G7cp5rbF3SZjfgODgEp2NWABc6ENz1gyBLffKQpVH3SzxhRfohV'
    'a5isxr8dtrix3whTPRnQEigYwJRygxGmPJKBAPYXIh25LGVnMhlkkj98+WzUL/WypD20AoBdVGir6QFf5ncwv94EsBjUs15Wc2rA'
    'w6y2Cn+gOhaZEE1WvGe3fRYgLVvvstsHW7MaEkrD1i8H6mjZL5ArmVWaOw7v6P6uo5B27+w+PPG/6whs07cNggNKjCc5Ae40/fox'
    'GMhE7SXn+2Z6XOajtPmFrqHw4P6MQ7AMgM5/hwP7n3UZrJZRXxjVxeG/KoTPuRbWTIv/yGiXh2nRwRoul7bBDai6zdidErqt7FKl'
    '1u+wV71JG619sINU+rE3+epFmD9tabLvRMmT2XQgguPeciqOrPnyamt12ZWlK2mY11bgL7bkRZ7NSVi+uvzXdzt7PPilbITJ9yBr'
    '6/farGRz6j+XeBCXnv2OkuxrO55uhlnsuZD59EzHKi/SfkQjMqZx+uXHRy9f7b+GwtGF/msV47d7u+p2l2giBwRd+FNy8y/oIGiU'
    'oKOyUzUQUgF0CyFWG1FbxWFdW8E4GdYVD7CkreFYkNpKgmP8wYX4hmlQrnlY0qtK6kcQTIkG1/JCApnmhaCC6YOQVKbZYcuLFqTm'
    'B6XAjo3f6YaTAPb1WcR3Neb8PRJ7W9kDEVjIsa5SIGJuTTL4SoT6sckaZkN+eOnIz0Al/Es2CTORu1RjERdIWrQqkGjgTxIkDUGi'
    'ItsVQnpB4ycKXRvgCwPFw4es52WBN2YSNmqZH3rfhiprR36ofRgzsHvpUKNRs10Rv+Ew1CawvTdDjDHIsg4woDab+GdemvXffUdc'
    'QvZgb3jBnF4ejulIPS35QIPc5SabbD6bnmVnqQ1nXYlfTUdDAlhLk78l/7vVdnuuvDUbJRGxvZ3yiiMSeKkZ2aC6DeckCpV27Iaa'
    'hlz6eZuA/qUkn0fyeCxIOnc5rCmvHzb+ztXhjMA+WJb7VzgBzGRiGGFbCMKb21gSZtymFBTNUeeskw3YY+cknaY8G7h17xEQG5MR'
    'CX7vpWUGzGrvuxMmDILczLfBY5NPZuXcYrjeSf04PqcKJ1m/z9HNzRf4fPvvkdz5wlRlZFEugV4eBIjIFO++dEetXGOjVMObOsdv'
    'fpeOZjrj8m1gkXHVp6lF72eNJCHMb3uDvVWdsc4tzRx0plln6aSTT8aT2eQQDXYRtMJze+IShN7p7KZ9oE62W5FbgI45hp8jaPSx'
    'y9Quzipp/zhlZwtNB1EU49F6dH6SSoSKYjwewJoRaSLzKO4Q8HJW9PNsRPgwgZtApyBwG6EXToyNfJCIaIbabNctjUd5D8EYODoM'
    'ERh9zmGPMOtyhs6y9NwLgg8Vxe5oj6vEWERZevwS9qnFRjq4Fa31k4qPOOAfFSPi9gUiahHWIvCnhUWcNs4czhZDVOypp+Fmc9kN'
    'TtVFP56ZQlvmx5L5RMRBS1ZOLc45EAh9tzXq3i7ZWm0JUwy0zJ0m8yb1hR+ICk//Gj+84rI3kwtkWqQrpN/fPuOMCYSEkK6wMU1h'
    'N0Qbb+zVvxZK24QZ4gOB0sMEIBbuARCCn7imGB8T0uNj0S1GNiUtm2TRSwQwx2+lqBXYWG2iAcYAaF4MyBFirFFLLSiyNKDMXtYd'
    'SPoSIoJELs2LJaNcN7HV5WyuG/hwuEKrmfXWR4w1x5waPG8m01CPIyNVAU/C8GBkt584JZ9NJ3zy7KJXN2wyzmBVxUQFh4nd1Hwl'
    'D+B7BdasxZPLi62WbtESDiF2xp8178o3Gt1K/qcWdstEdU5PoyHignkfbfT2/Tfb77Z/3tvf/Yj47Y2c2YqlvrAVbTaKa3gbTrPf'
    'xzuk+p3SXxDYis7kcBLlygXwEktuJ29+6K4yEUyttQq/NKZumk00TNJg3OsM9ghMIUegGkwueMNm40N3290YPM/DIAzPJxFkA9xE'
    'aNLG5Bjr0pBYK0LRDcdjTVEX1GfeSy+jk/EwLb8vN7d3nmEgHFAPO4Cl5/bdB7sl9lbyG/YHXD8Ts1QPUG17oMAOUhvh/d7Qyzix'
    'UdyICRrRVZ8TMkCsA0HoaJHZj1Ff8pzefMMBsd6BaYkb8WSaHhHvLnkvlpjhTts8bsIKNYDc4yihFobVLhUUMTx7EF9qXbfTvAu2'
    '9bi6reU95fly5cRBYdoyQeO2zA54Jpx8+5mF8GafX9Kwh9FsRMxWHl2OZ40zDnUHE1+6uL6pOUyohsw0jCTa0gpjz5STv59yciW+'
    '7FBooAr7YhyWFPO/0jm0ZwtVRR7jsQBUF8bHRMxImq0//AFHSsyDD/TjoWWyrqJTupJ5CUanyBLT/Vu7pjxcvMUIqR3tvH2//fOr'
    '7dfPP+3s73E5P+Icx9Lk1MW2+/cYk8+8cv6wB1n+cUyXR56wK44OoyAM2miyWxMx8DqevMWLdH3NTjrzRoKq7MnDwGMDR7Ot/77E'
    '8xqxIuLXv/8/D68k7xyTziOJ7DEb8QFFzDAryni0ktz8+vf/98t6SNJiYz3SzllG+ztiTqp7BxzgXFZw1cB9rYHWGpzc/pT92sSm'
    'nbZDXQK+8H6a+IQPr+yM4vdx0aIVYiVdktwwC1b3vRgnkgDtC4MkQZlfqmDL/0RCFpsRK30cjrcwZvoNoQSijoFQ8BR8omthOisY'
    '3InrIMKtM7qUAvQG02yVjdBBKN5OevAIsQER4fdj3G1lspjaqKkn5EPDmrR3W/0sB0vT581Q01u6QTt5DlTVEnIlboxx2z6g7SLA'
    'lTU9QA/mSoKk8BBZueiWUuisfk94Z7v25Zk12jVr/oJIt96Jz2PQLc4wwZwJnw1/jz6mOQNVZRKmwCuafMjmBA0ykPnld5A3/K7i'
    'N8HlDoCKMb9mxGzbXSeCsXJh8I/gjeEw875WjoEfyZH74G/eUuvy9nm2kWwPv1sXPtp7QyOy0o6Ayw4S4nKAGzkWjHqakdRuS2Xj'
    'CnTPAaEFHY+tttv9G4Fl6zS9zCXprc2Z5nWry6ezsNOz39dtTjJ3KYeXw1hAKr7PrlRhbd4ueYctY5f7fNZFBcUkIIlN+j5vtAld'
    'BPSlNWeNaVGDebrC6/MnCUcYAcH/ELjzJnqKeR40mOECo8z8LH6wxyZ+MOXTKMPhqQlPr2nKiDNuCwPLeDGPBnzm8m+i23Y5mPw/'
    'hCnRGGGmGoIMyNnxFAaXbkRlxsKhUYmT0E0sHijjvGaI7uqYDppZZ8jXxAmi3DMXMY/e4bKpajDuL/XkFXbCIbTR4OgpF7fEJM1G'
    'k1khxD0VlCtBQjpEDRlHY52/KAKInApG3rM7Krx0JEIL1y1OiL/VSTZM04YtaGyDswNYSPvNCAkvcLFC7TNoRTspRG1ZEaXDSXGJ'
    'L2ynmPkMMjTUdCjTjqR/4KmXhEj6kuvENAAd7xEtRG4GLwSoS5bUH/OZZfrYt6HActN7sL8utgC2BBX8wxaZJowcy09cZJexNvqg'
    'OpI7omxtZcV6yVxQleH4jFe9NFk7WBkRj5Gu7zNGcNCY6cpLtGv3ydOl8TlQLCHYPolcRbpKQpRlP627A+tnkvOH8eDMUOZcI+zq'
    '7vYQoh0gFbvw3liM6rGmGyYQFshoWnkxnkAP1zlmnVHs+fKluJU0LiEgsmHOVezlybHz8Uvnvc4kdcWVm8L4kvkD7A5mUyuA8jtK'
    'TKY7n6tSuWKIIAChLLLez4bpNJA2QY49zI/LtwNQAX8EEitKVC5fyqiET44WpKHHDay76pbgl40OxzMioW3vqGQfmBcqTCGZot+k'
    'wq62ypC94uW8yc/Bq77EvcKmSh93d/d/fv12Z4e9+D4839ne398mogKzkbJpXhIH+E2wLZaE3OENs819w1zGM0HrEQ9vY0FqRuJK'
    'ZbJgPrzq3SxUs1225T3D6sbCPvtXKh5q5HrztTVMO7MLEvCeMRZCtE2pdHd8vrD5jn48W5aBsFFje864vnJI/LDpWvbtWEurd8+b'
    'seffjOaO62mmBr4RedER8iKUgIJ/3BcwDoiWMuO8pXyzjbbN28kMyHE6Hh7kRGZx6OEhIXs4eeaJE0VZwt9jDYxgYMNx5vGDHC3E'
    'WY6FBytOL7F1dBEYx2xAyqrXNIfThYK0nkkSl8RJOoq9OrQUg84kLw1IOn9wikBVxHzLjGwdDoRfKl/XYHh2861WT79xbJ5tlrQy'
    'y2rr2FY+jfrjUhcEOeO9gqDIS+bFZT+mlbLTtFr2K9QzLQE6UcvMZTl5xx0VJSc3bzGx6dM4p94O3yr6MTPiFl6NwT+KFsGdHQa0'
    'LZH07h0YAe1hqxebjpGa/nRLHupLDk5d0YavS6N371i9VQIF3ImDU1uQzWSrBfnbh6xX10Qta3LQ+PboBVFhnFD96G3RocMsv/eQ'
    '30RcIKhIdnxsfu+d4Brjn0jEI7+E18bP7Hm/DzL/ITMotfApPSbzd3UH091pHZ1HmxvRH5We4Zo6wrvrZlzQVZRRJ5YepZOQ45XQ'
    'N7YYzygohUAiYSGeYY0cXELkc3yUOOdsLThi0Uch2n79+7/zOYvUkR/PdnjZHvRMla3MPvINWN5JmwnGr+oNmb7iJY/6nR12vj2c'
    'nDjTDaHJoQAAc5C3iGo+6eSZ3aT8daefzi9+RF9tUZwcFo7k8ysw+fmS7zrXx/NZMZ5fBe6f+5nEHjf9MHL1mAqvA3y0RX9krU59'
    'SWh8HBkx5qRnSBeSnjWjoxGTIQK9lctOS3j31Sg9/wqOi2OoSMR1pHNwFC3Rmh9SVqvarzRkEP+DzugUjzkzaSseezEdD6GaAEgE'
    'eouAI0aQB6leEGynMTAfcjQjLOXYEMjM/Zv2EmPf8D49tywnzBleFtPB4r+AsdLU5BEdY9ZMAzeKVhzHgC7BlHl/Qxm4NaIyUgJX'
    'oF+E81Gbj7CZ8D9CSxF8fJ6XPz/PbYGXCCjlfxfCkvaSv8S9GeJL2OK42v3SVA6vzHfDEXslAj7btvNaRPPVXvEhdv3BXEIlmZXS'
    'sFra58Xv2VJQrgur4JqYFX7d3qyQorbAB5jRVJtn6xpYrcQwcGnKs5ECVXrhRv6c9fOvbsjwJ9LOq5nY3gUD6puXbl9FLV3aCn3r'
    'GhPKLdgNoMg9VQnZgsAbfrGCnt1eZUV1UkZ/TQem4c7Nja3E5JBXC7SQ/cj0TzAq76MYsfGd7BVhetlT+KctgkyER5GFxALWXddd'
    'HGPTFrVNuMU90c3kHhyNwI+OtuBHQyXgAegDJzJ48W48TXGR0xyAHL9m3IjFQoUht8qpJUlWxCYyHbDmUzVNiDGVZkSDpr1WPgi/'
    'TBSbDqNY1cznrCYZZKcpq0iImCLeCc3krdssAkrcifDkZYkdGwK0OPb3phpRNCPL9URKitKrjMdq7mX6pYRPnfmA7L3RhVV2/uq2'
    'NVwv6dFKLZ5WoZdZRnxyqMbTmXjFfcG3X9JScA6EVW7pl6qeP5s2y59/eCjD8Svi/A3HwT9NQVV+8+H9DwGSDVAkPfvft32T3WpT'
    '+iForqawZ2RqinqGeihotPhVQz+qUGf953pUbqyy0rJE5ntwscir50KT37o/MLoZDEyNftzoMjyknGXqptIkLsT86xtlVjlsURjO'
    '3zJEY3zg2vooYpG7gVHKhVAoNiBzLwEx1JFhiGmEM8QJrFPENgKEPb8K+hBZQKUPTwZALfBQleijZkAI6ZNpxzJo9i5jEMBbW8Rx'
    'bmGht4YNkmIeUxeOSSzd4qVVr1fL89UW9UpajjC0WhHr+ngk6zpSfsuTCwlxTlwKsmgSqZwic55r1nCXt7fK/Nn9G62gOZWsBq1W'
    'FVtd3YLMrrNaBjZyM3kMxNNvjVi35XpmrrHSL3Nww2P4KTBTS9/cxpsPlTUwUrYjf+Ls63CwAq1uuBZsyikm6+CNPSkaC+IkelaO'
    'EFxHPvgKY3nn+htms7wFwdyVj71j2c3KMXsbPO1xckTNVVhwBj35i8m9hRzV707Yyuqq1Wg1HS2gDg1EpqTpL0CiKs8X9STrJYpx'
    'v3NJVAci1VG7oDjW2RJexLZsmzmKIDpFKlU21Bz1xWavytQGqkPpPGTcTEFWa9qpMRNfCxCWl6zj6ut6q+/LAYBIAO7fF0QCd/Tj'
    '2vZEBvfvwZch3LsnlgTcvw8IB2qA+a61EtHEV0wF5W/t50YI6T8D8k7TS/E0YOqZGL4cUSaZwBbl5iw3SmLVAXlEcVW2qkESDaWr'
    'j6LVtI+q4m3RGd3uEB+KuKRQU1WJ7G4Y0P/Fp/393fd8Ow7HszydTfh+tAujBGtZ89NtQdcF1pwmjlP1kS+a3S4H85xqqYlISYiD'
    'o/aZR6O24d51yUEhk6Q1lgpxfnZc1adrFtbOiJCgew2dHeZo9C+9zogjSEZTOPJIHZPptBlB5pe0Ir6lCRcQPyJBOIkLhli9OJmO'
    'Z8cnpTyp4gBD7XZgNsmsBhv5T9PuLDOxKtWZXVilvDcF10GzIwZEvBOB4vUjsVWQvLCikYbbKKJ8OMONj24IAUl2wxxCLbRIa98f'
    'IG8J3WwgzgvXWXx+krEmCxFvqEI37XXgucKWap0ZyMJp9PzDWxifT1NaJQgi0Yv6PGQ5hw+lFVHJpiwKp3jv03p0cskn+unjTs6O'
    'ChJbgBiWS4Dc0RIG0sFF3XJm1LzUH3ibRBQ6Er2KalC2g9cvxsTr015D0ckvXo+naiWr5Y260Xv1ks9lwVJHDUfK7z+ymZ7a2Pqj'
    'AcVmQ9c/cAO0UjcpiyxqP7/c3dn99HGPQwuZdJlQ5TI6RabMhrF7cZk2e4rXuinCsNKiwgIziiWjWhI9g7fcpnbyfnd/++f95z/s'
    'saWQGCZ3jqOlTYnCzWr0BKy0WgywtwCVYDvDlSiejYDm2nqtOcjLOfcwrGA+cOqqFx/lD/8rGf7451v+d/sd//kkX02Zt3/e5p+v'
    'tnfk1Set/knaxALxDySA4x8fPvJf6vXNapsDjtIhW+NPbx7Jn8d4/wjvv7e/nphfn6SjXfmzI4NzEdb58bmM+52M/81H7ZDjZPMr'
    'zsYiv5CnUn4hV6X8+qiF5I8UfPX2LzQEXC57H56/5wjQr3ff7+PHNzcGHl593P1gtmr5p1jO5TXrlK6zI2KE02v5d8w2b9d8bq4L'
    'urjhpXI9GpsaZ8fXdEZProGer1lxew2H7Gvor64Rcusa1NQ1o+1rQe3XgtKvQSnRmexcnxFkja87s342vpa0wsnD5cxXv1azgvpK'
    'WE68fHeKUfiTcQBZNLBpMo7iQTQpdyUaVcE8p5OYZ4HUz858L9bzDuv4YiAlMD9eMg8//zXcNoigR6navBCSnJoDfd+WJ5Q6aNGl'
    'Q3eRyJRLg4TdMOq4psrZQ2drKytdNuFp4L6rSU9dHcncFBUWxCRLxcjLNDQ3sTbQxUbkF20V4080Jc0b2YymMzbisajmgModBpms'
    'UQKLgbXXRCq08MFkBDfNRqcjGDLQRgjmmeCe7BwrAoKdA8DAa5uHZ5IzVlIrcXp4XZ66lIxqtKSmUWEijAd0CBFNIN9q03nKBsW4'
    'nSxnsnIcO+eOGZViNQeDRc5G1tSGqcIRYPoaAVquj7Oj6/O0O0nWcWCfPG4edJZ+WVn60+Lyxuf8cPGhGUjNzDiro05s3qbybTnn'
    'wOA8wvKbdxWDzfm0gkzjd21sSJg7NIhBHu4IUhDm1ZUX14TaPTEJT9arVacp8/mjMYQfdE+PxuwtM4Vx1fr8lU6qLWGRascQ5sQM'
    'muK0p9g1/+ZuZaPeYNZHgvtqYybjaVIzAv1WOwhbr3Yc+5ILzD2/CU1sOyKJMKn4kGZufM4/D6tHBHaDjJffjuqgCdnXV1dKJ+OM'
    'E2exod8z+rpSnV2nGZ1VopWXUKH6suB/3imyb2+MPR5/5PzwhOd99xd69D2zjJqW2FihuNVP5cEDJcjZUmf5WZwNj685z8X1yTT5'
    '3LVHSUrx0dHfDg8/O/hp8/C7zes/jLr5ZF3xsUKqWHrjjnHXo5POIXRcxKrEZsS2oYHX3q1K4Arp6Ftjipo3Y1kAWzEqPQt9dGjq'
    'rFEIuG9aAqWLW1mu5j7oEMthgMMUMJasfs7tKtpgMpilp2rtiptHW8ah4Lb4szEo8gwaI2iIheNk60m15CPek5tl9XapBDGV0uVU'
    '/T7KvuJGRHpVVqPPWVFjSVtiCMrm4obD5lQBzG+MR7VOZnHeOTM8NjivrGjkcOLBS5Dao77cY2z7qqqLVmjX9t4O07MVeOCbhHkm'
    'wXL/m7GryRIMwt7b1wzTccmdTB437Lyp0QCOjLOZS/dnewmc0mx9Y1KhjBRnryiZlcFBu+ox9kk9xnQFG8kcz6g8TXnphMXzAR9C'
    'IgK20KmhfCrmQ4TsetYPJ4YqW3jbtgBxy1ps+UvhVbHHzbMCwjKEBLRFPsbKy1TrhWdUKzcAtCwskUADtkaFWfWgnhMWIwuaDHPG'
    'qlPvzQ6V4CgUaj0CPvLH7DSTxQ3XVjpjQQ3SF1+FZryOlU7WQ77aE+a4nWhGj2G6FfEhg9WroGvDc2ZTNm6FGp244LwYTy/pNoQR'
    'LO41uvvzaJjlUPyK5AjW+0S9dy8dz8xu7O80igx6ceIxnEde2lzOJotmjxF8BWwFnHIKYpFbiAbGEVhydaQllrtLXDj8JzuEECAI'
    'ocIdmiFtWZ/7EOPcDvNBaKUVSVBjDuWifamiGsIhLhNBcNISIRM/qye/LAkqnXPYEHqHPgh/5Aj13EF0iJyV47MRDxuRbTs9kdTk'
    'RKSkfkAAbnNIJ/yMGoWRjl50/aTlhCMWYpoViGnWQYxDwzSd4iUi61Ysc0Nkbk2K6KbFzrH9KuMuH/zZjpYzmDPif17EK7C1pMV9'
    'qQKhqUWIpZM6/75qQvIOC9CgWUb6d91jBMPbo37cKUqDQJPyavfoKE+LxE/hgCjFCHBRjG2gL2ftqmM/4GJNLb2I5irFD8uOgy/d'
    'Yve8y6IXumgx51tdjP1pmv5I9BVdcjrDJnOOrzmtd2vvze6PP4OdBZc3/+pX55aRJJelMRkMwkQpexUg2xHHlmBuF8b9cgUh2Mfa'
    'euV7mCtpIPe0xx+7pTPO2hIMYAWt9g5WDpFzFhmiB5y8VjZtD8uK+AlcYCkaidaWml5d95LgmLZWpa3V2rYAANzSatjSmmlpxGng'
    'xMbu5pvSKE0zX0UuGT/LYIyJX9D6lcw9b1FeR2HlIVHFaJiPtYd4GGNcMqIiDh3PHUXJjKXANRKYtlksiCEy1dOFo3UHGabgq2CR'
    '0IDQRuKTPNQXXwR71JS2ZO4vH4Gg4w0OmkegcO55HEoNpm3Po6USbmIWhZe8jLOo9Lo5JbxJ5QLa8Ba32/ZtKllEtVG93AOCDAi0'
    '1SmgLN9qcQ3QWyIrcwU0gh1eNwV1tkMMepNUW1Wngk124vIa40A1PmXj3fKV+xuGajEM0OoWm4X2G2yfZtLpaWNt1x+kHqVCfGu0'
    '/QpNAZENEaZNxhMf8eNy9TAV8YjeerSrC3zbEtWRWnzvoi3hmXx0yZ+4GVe7TAOFdM56hSZy5Dp8UXLLKvyIgGKOV2DvHSGCOd6S'
    'c+FpMcFzlE0lF8FIwkGBCIjOsjwrcP+Di7BHzTs3Pi0rO3c/Iuwe1GyVshcWpHqr6EkokbPlnYA+RrTwhj2P9Ty2pYUb0Nr8q+0Z'
    'ZGi/hjwOrDUkDsCIdfwhN/QgJIVDn8AKmSzOnIpcsb+vsmlx6WB0pFYEIyNUoOfQX1G/BUHUJW/hhoUPx6FUWXNTPAlV+YYaNqbV'
    'GRAq8JEh1qCe6Y/FJpqNp5M2rlzQc7ORUKmKwRD0FFm2CbQQ6o5feaAIApWAzAOtqp35/Wl8CTpTZqcjOCEuRx9N7CJLxno0LGv9'
    'jG8ihgByXahe1mhyqJhpjumkU4zfi6TGS3KrhWduLsKSgvk+FGpAoHpClLn0KQBuPHpOVx4YFp9QvQrVh5WKiMprhSoV9AKBh+9W'
    'MOX25dhpLZ4QLfUurmIbSk5XmY4flLMD+sQB1dwVH3fs0qunIBVn81t6fcoFWSKUsAeidGFCRhGk5ZMxXMQRwDIajlmP2E1PEAlA'
    'YJD3Vkar4DfM+ksKn3HHcmQwYUii8/Fs0Jc+/jYbTvwZsNN/JzoimB1w8hXOPnnXBjq4oA9nRtgtKEQVxSBIf79tdiipRp5mL3OB'
    'grqe3OdbYem3k3quA402KWGi7EKlF2kPeJJOX9zQkBw2f89eihxANBoT7Qnq6kYQOko0OuKMP+ycgoiMnk0Qtg+mBtSXsu8hUfJy'
    '2I97w75GQYmM+VkoBKuXXroVrzkUJk6sozOTIEpaMFtWuv6YFScv9/bcBJ3YsrYWj1qLSgiXOgKijl4w+biB1PBNSRe5WTftsjSk'
    'BL6yM0tFASt2QG+soUAgnWQjOBicmQgacUMsBqAgqDc9SCS4Fu1dIElBJwgxiWSuvDutCGtF4zRNH9MJoxspK9S4lC55rqBsAWEf'
    '1yAMPwaEkfqX1BuNeHqegclhKY0YHHCT4BkQJ7XfErwWzG0CflmFPxDHOFuJ6WzEoQvheOLVAbRlOQtpkNxc7h1cJSksOdN0Ij7V'
    '0reIRDAASJBgSKgL56Fh0A2yE1Lnd4JYPd0s6p8nOkkHJeEJ3qAz475bL0+hQl+Hyoy3lwpmYVgkQFWMvQVnStbXt4vUr9QZhwE9'
    '5SzWhW+nOmQ+X5L/mniF1vliqHbTOpxhLdocgo4cGvmraJCUjuLBQoaQG8rBAkNT4EDB4LIBs6QLuinqAM27bs5ZdHKrWGU6b11v'
    'MxyAqnVuPVkdVOBoqHOKzZHjuH3BauTKGJYlNTz0UFyzXv8lEQK2xdE0kTY15/cFe8D7EhtV6kq3wuP5AjJeWGw+f0aAhcLZZWBc'
    'yo7KjT0tSd54vTzJW8QmNsyamgpQOwbF6YUtfJtoiVp5VlMAAaYYZiT02zgJstrzaDejlWgrKMbx5dCfBPOAJTaCxxQSz8J24Q63'
    'wJvp0aGLmpuMAyYIrsSMPTbJvFXo5cs3lvOHw8L8Xtvit7CtxMd78qrkHs7CZm458bYLeyVdxIUXE2VoI9XKecPh8pA1O82zoSDg'
    'gLHyWJA92w46JB8YM0jmxNskvWz5epv4koPgcDNOUDhsRlBKuNfbo/4LfsCUZBYxPMxg8h+lRa8lt5tmR2cVgs5yPDY5sHkoto/n'
    'HDsIrdn3ECxSz77Rkdl/M1Bv8Q8Y8zeF+Tlkvf+BDBh3Of9oHDajA24e0bbwt3FYYwfQzVg+zfQmrT1UB1YqWTaMobK+Xq9qZGKT'
    'K44nMF8fClPDmMEIM/FJzQFiag+ilQOZBbu0VowHfJD0wNxcxUD6ht6t2lFESP4wx/xCGzX9iRTAKP5B18StViuwAQtiy/vjMms6'
    'vMUaTS+xyqzEiEBnk9x7uEUwUoSJHppVLXxDCr0F4U4wm+iBYOAsWGoLXlt9LFg4wKzhuRB14pSJMDSFaMjYb2GU0pHt0lDw0R7h'
    'XPoxMcdh6a3Tc7HGWdAQQDF06Uf2Kq9aoWPNmhHyOhTTMTjJrBmldEhmTYQ27bHdSD7D9xkHaJY4zoNA9wxjq7TUOAIxUGvdaUMM'
    'dGwIrJow8wcEBbePsJEchmoLFXgN+bpU/2SHCvFyi3G+M4i3Fkb4OMcmiEsO5xkMQbqAuhMCCwBBBXbtMTExsFy2e4k+Nte+w3Nv'
    'MXvLFJUhjqgdfHUIlC+Fg5VDwaPmGxCcfPEvt2gpWj1sRnM+VG9ftYCpZXERlM0wuWzfXMOHBVYjEAG/GIzhUXWnMEi0o32R3Hh0'
    '91Z0u4bSswgwBptCv95lQqqdcUFH+nlaQ9dURYLQT/mCF1LRhPOtWpooK1pOr3Bn4B3ucQlCozw6EBAc9g9dWFis1fj/5+3tluO4'
    'svTQez1FEuK4qohCAaTU7TZAAoeiqBbdEqUgqdbpASEhgUoAJVRVlioLBNEgOvpq4kQcX9g+jhhfnHM7N34A33veRE9y1vettf8y'
    'swpQT4ftaRGVuXP/77XX77eC05LhUPNJWq2J0LJtZDNHID2TYR2MeiWsbDn1ULAuYw3Zlmh994I4cfaon5190kdam+NzovjK/psX'
    'AWtlym8ibBBUt4f/Rp6wkRdkRh/vlhwzQbJnCF2l2YbivSZ0qMaLu7g9+CBraTpxDeCdqVurIslXLJlNPfo6wahMOWxNeALhWmP3'
    'TnrxfIa0KhdjTU2Ckhkz5jBxEgs74yVrdZxoqqvQd8yTqhkqgWhTzQkqNhrIHzdrMVQY84/Odh8fISHubLeTnkY5uhqd/islaOM4'
    '1J9q+arnHfm11BWY/r7bm5sdd9Qv5hC9Z8K3z+RjokJJB0Var4inwcYCu47SMFHgI9BzX13cUa0SWcyC1/Ft/sZSWhZYv8SP4HXa'
    '+T8Uc/Fe+hRNIqxK66GnUNSZdVS1Qu2A7tTc7iKFQmP5Dx/ndLXGehfVMXt7gxxn/sfjzXxXXScP2QBZJ6/X0ovG4ApQ3hk/6JYD'
    '1kM11IhkU38Z863juyj/z7YFts2I6GqeMy6Juzzqo0rwMLRww1S6jgenpQpsQDIVBgX/dFlQBRQqK+UyxcpDiTln5hXnvwN2Sv6E'
    'pSIjmG2F+tSwgmZQW35UviNO91EBKPzSGcJNo00THzzdyvciP6gtsDSVF8L/BqYhJF7ps4JhzPT+TWH0lvlz50BgPF4VhuC5U7JC'
    'XsNyTP0JMDouFkl/rbPbyiJCnQfD0lmu4g/0fl5jAq8kzOWwFBpGfaLMKnRr6uQiv6VTkeEJLCKG2D0uEIGlViI5SjngtiKKucqz'
    'Z6yOS6hhgL855qWuPSjmdz2K17myz17h/KYSIF0YnBDoodqPpB/nGq6HqED6SCjILHYBoYusHR0XeX4dWeTGYWNW13uZpM7fwacj'
    '09mojufSyguZYwZBXuvlJ8RhWuSgBZpRzVsebb3hvEr1vbogqu634jnDni4Xi3Kyrcy9bQLocQtdbRoXOTujkyBNVNGSs3qe9S4b'
    '6PMw9UIyi9ERN7y8UuU7wBf4jIduDz9iHluIHZ7IXf5uVF5UjvOWu0wdUbr4GMYefLZCCQeq6sokSqygex0dOV6nRSOT+V62Hzba'
    'S9DA3U+mIQBz1JwQgx9mR7btkcr9fLYTHLoj3jfySLLhhc3OOLeQPNAfx2iqQeOErR9gR+EPaRjSkXt1YC4v/n3f9di2My4jGW9d'
    'SbxcOxP3dCmfHLl4SVnf5pbthlYJwkvwcvV++erDi69/37u/qTduPDO9nqstNPJZmGSqYVOVjpt7BcZvpzsso/uItduO9ATrLmQo'
    '+SD1GuMZMsj3v7uLWHbrgtheSVT5uhS9GhXaG6ykQ9/X/QT0tgw5zWA8FvJKakNd5ki1D2ZedEHP+VXsckbukCnJ5smtAg02/TRl'
    'VkLesir21ThuaGT1MyBqJE4184Z/KO0405ZpSwL1RGKLRPb9RLN9oNEpy15TWm74qytCezHeu71lNdS0ZW6LarVRo1qAqpbvB2cF'
    'Fbh7fBZEzeWsA7gA4Yrkpfwp26FCjpoprxXlf3hjdJkeryMXjWz9cm44//JW6CFvnU6vhXUQ8VuZB9kTqMAW+O73Xzpv/HBpOrt8'
    'PF5Ju3K0uoLpCMYYqSZf3lIoS0AQzAupgs0DzS1Q/PiV4C99K7viP8iqECRf7uz17OG/F1EXY/s6X5wNJiKW6R/5++57Avprsr31'
    '7FPF97fkeRvy2wlG9J6ONRphCnC0vi2rERYF0b7fItdabwmr2lq4O5NuXPU8CjQb2z8elNzkL6nwc78OlMZ5Up5WzZW4UyfSkst6'
    'UD/Rx8nh3PEXa06NI7eO18fkCyERcpfUJCtPm/keTuT7Dw+i6ylliMPK41S0Xqo8d0/hRwN9BqEmyKfXj6Fyc1je7BVPdAV2G6wb'
    'OHiEFAyLfGx6YFDh6Kzx2z8UV12sRDFOgr9doIqO3gnefAqXgjZrdj87J8SJ9DkkGWE1rcZrE/7xLjV/e4pcy7Awd85WTUM0OC8V'
    'qbpm/YgshbcZaZsfpNbZxvtenFZwMUQCz46/W86NBcuPOqkmmZwUNiBSvZDHa2rjXGUHzqqoCPWNBdAcO5zAHa+lM1W1cmz872A0'
    'HRbvvzlRSgWk4kKdi2XRZeQbD2V4D3tRJp57rINqdl/QW/sgAZrNnfSbwqOKBnJLmy2jlYUOyUc0GMXPQMxq9invL+e0F/NOaj3D'
    'mEf08ZV/HrNyZVed+Tcbra/3NMNLHLLqBHBMdxSeqxtyIIR7OJIrOfkV67E1bBcvzU8AgCSAookbgXrBVWzrgn44btq/ajD1WRTE'
    'oE6rnnbwZ2KhdlGPjmC5zfcUKozPmWtbOhs//G5mmqZoI2gYYaocijcuGdsnWaPuvrPnR3yYeqKp3CR1TmT2Tq66HcMDcyKELN8l'
    '8i2D3sGmxB99ZhoiDB+3W/AtdUwg/Qmz0zI2z3DLtFAE+g2Ejk2p7vFq+MvaHRCHx1YLxZi7FRnCtPIptaC+vo0+sAKsfxTwwpaY'
    'eoAzCVIo/UaYpxMPS172u+p1r/f+I8iI+vxxeL6RPepFXj50h+Y05lM6ZFmWucimJ8c3DgqGzqtxNN2ZpLSI/yQUJRo5iYt1GlRl'
    'w5MVrf69RQ4AxgldtjzAq9gyx778LkwYTlXMIYYj5Xkgva8K8IfS0X44ddERRuLy92E38g7e9lxYnNRliVZj5SG0c/KZ7Otqlh8X'
    '8Rl0qSii5ED3lpw9e+tuNqnDX3K2kWr3pJ2aEZQzitMN+pyGWGLE6u++hFzbniEzjwrgiqfKL1MKeZ0gPEBzwORCceotivyk6eJw'
    'zJ13y6UX+zMo4ghv3ppX0nFvuavCTAP0VruIZCzWys/XfCSOo6m2b0w5oT2r85HR0yh4sF6fLWOoEsbUJpPRD4xHozJ+qeu41L/j'
    'uGE5P15hOD/+tfqr4NSB/evZ3187MW0XYONkubbAEUfa/Fj5rGG71P3j2uhUXktZnvjMOsgdzElDVlfoE2bUNEyzrlQiVMg1gsfc'
    '4QAWsl2tt/iwLOeD+K4YDYtbNhyKrBQes6xJMfbcZ9HmuH1SqZoZFn/rNo19iFgPHX7qG8zW5h5LhMhW7jD4FLXtsbM5kKiV82iU'
    '0WSksrMchX78xBNRo5d2qWz1QpLHWEC4qYk0T1UgyZ1XqAKWXvMW284+of8N/kC80nW7I95KV95jFTWWGCcdOesnMtReg4d3AoN2'
    'U8erNrnkfnCoHncE70h80lRAaKoO/22AHQ7nCcZmJ4Cav5z9TPmKYOg6fLyY796/Pnx8/1qe3Jj12H4cwgtKxtPFeqHHFUyO8sGh'
    'bKB8aFBkr4tFd7kLj02tc1asWzj5evfxAtZE6Yf0DdjPHbZjz9g4mSHA4yAT2MIAzbQ0csHE/WRR8BSoQ2HOCP+An9paMJIfJgdt'
    'ogCqq32SbECQB+ENRigcmYzBWS4CdC92yszBhHlZAT8bOv5+sEVlFvmTD5k7kfBto1h157jDYPL2acQT3sPcD9o0hLozGr7ki7lT'
    'KwT2kUfSaxsS7q2dKx0ZU+r50cW8p1imDAaMqk7RSon714m1g8TmNbD1RADcWibpMUrvVbyvVxzOVHxtFVylu21i6xKhFZbgYN2d'
    '78T5xuUhgd66NJOjZAPh+tj5wXnG+CAQl+ltBuip80uUCo5Tl7TjxIlxqm4nTtF4WvoIQoWvtEs12jJSawU7/AgxJycR8A6VWLKh'
    'EPR2igTzTbI5p7slV3+PSwqcQnOe07UyWR+i09zMbcmLxJBUq/rpEbMyRTQZLamrjrPT+crOnO09P5U9CcRDqPPqnVqAjHJS3OLv'
    'ywE48KTVxXMu94Kg5NuN5g8Iq5U7wzSlKNLryIGXGGpIL0g3Ld13c3GzbD6kmxRoas++ElnNT1GclNfyj1ep1jZs59uOKgW0M8pn'
    '6BwSVZzQLBPPGp7ttfRzD29suY9p4pOfNuTjntr84lN2HLlTto5e2Efday0uoiojj6CZJ+Vwv6EzUjot8x17p4a95LxFCSnBrTOl'
    '6zy3047XTH2JonWahId17ZNqitLN9F7vYjlhR8VxOSkaO0qRvEoLjt5rCNblWMO/W8TpnVvmDIuxenPE67lXm6X0nKQdqtHOtDtR'
    'U5QMV8mgmAip7ojgwr0QuMEbx5sK9UnUu5bB6pWtypxma4m426JfMAbNbrvEydfP7mkZ3fSnZT+yxDc9ZD9yzEUzlloxvyO8/KY0'
    'RiOEw1wK4b3emeTPxbzcYNbvjKKLZyZ46Ha8lxRFMoQsWwgjVAnwV58Vw765m8OXHYy1wrvPK0MKE8J2oQnCsV8vy/mQGgc1CNPX'
    '0T+HGFcVEFeOi96qeOJ+tqi7/jJueJXvr8cpCUFRK3xOmrFGDm4xfhNc/RQitlPDzGlDN4oFt34Im4mr9cmh80VPA5dCA9FBMaIU'
    'PqxV045fu6MJN02cIALThnUj8UrB6GR7+Tky2QYhVDR0FvQQ7jHACJvrte2trr1oBy8DWPzS/czYbOZ3c+ldlsCpZavr0dGkp6M+'
    'psR91wDNGIFAlyWp7nMNtu72DGYiFTJXzg50fUtaGpoCsXfrGOJM0te1VIQNAJTVdbWkzTYRphzS4ne8mI9hSWDHAVMtPyJrYOph'
    'HZJxNJNlX7fOX9p510/NH1AjjY183S3GjiRUoP77XoolsPnD2+pBd2Nj48PbB/j/H3788ceePHIeRvG3SThVz2cXb46H9G5NKl1T'
    'oDr2FKa04egdkf+hq1cysKR6zfLi/cLiwPJyPvozaNb41YXTMiQzhDXj8WskNm+f/BiOc6e1KtPVVHdcv8QEqdkc6ZiCP29p4nxp'
    'E97hvP172QH52K2/Uy79OdbMX+mF3FZ3gFnyZXWnewvpzpIpjnedfXu2dAgh+tzqk00SQQ0iETuRu4YQi9Q1ExoYBQApY0X/tsZ1'
    '268qs/wOEzJEAYuR+lEL9uqK4PDFSNhjCA5M/fkZXV0hSpTn6JoiuPDVd4aJdCpUrbyY22W7cs5rR3C/c8T8SvjPRecgXITnK1cB'
    '+/w6O6KthhmaRttRkqYL+YGI2TnNiNnN/vnBr1mZ953bmiaI9nnxRlN+dFbQHlj/66Ql0gBCF3pbY8kx6ZQXi6GUoxwElcd00Wj+'
    'Xtu836KjJEMSe4HE9KZRuv16u+VSTtMghqtDo5G77ZdHz8VCgfUUtidEU+O7u9EZhzAgH0CwBLEpFl+ARXgjApZ7DMpzUiJgExei'
    'Pr6Uv2x2HRh3nH4oikLxIgDpypKxLOvupSxkeTnAMevmA8ReyGn4kSmAY4D0fh0gffV8zywbrJ/vtiXz+HBMzqIKNnR/PJox89Dn'
    'woHtaY4xjGX/IHiknDCT14oQJo9Vja/rTpZLoqgaSGS1voAFxr/dOIGEa0ix+GrKXj5sRqlEbFb/lkaIcMzxrJ7w4Tw/FSlt7uYc'
    '01LOvhXhJj/NVd645fty1jwftZUBS/xGxJVKNsK/dWHuta3MTvtOaRtNBPhQVrf7Ae7ZzpIS/6fNufz5p1vRSNFVaaCG/ClPEg/C'
    '8Nvd1A6Ta/6rfAqTT1c6FbYOhh1etrctt9ebBJiryiYX1YJezQvKxUGVZ6mWDNNr4AI5qCcgmBfs8DBqKZQaOMfTuaYMrn6+gA/s'
    'jsyL9BXCGbiFE8ZwqD6egS0ThTx4Dxlebf0u/GnwUZuK+tPfmVY6bNAjy8m0OBoj+2+ndzcLMscum1GNcADszv4h+x2UZl7b34XO'
    'jI972aa+22EqsjSaPp+P8g3miJPTc3j/GvXdADCaphr5k+M9jB3lz6i0Ly0BIY5WOgIqtOfF9MCnQYMr7U+Uod63hKxS1izp9f8T'
    'h/FYR4XL4CcZxE9hEI9V0SWb1JpkvsU6U1/CIcWP5V//uTYW3P4vFDbPlrNj+v+WPG2ajq0gc+/TsMkMdF3C7hVfUb+TfuXzhbd/'
    '1kisGr7ZSRO0xiZaZ/Dsm3XWdsWNiaQ3H/19Iplv77C7INK4ZZfvz4KIW/L9+YtFcRdcOVg401x/N7D+cVBtab6n4HM+WxC96+Mp'
    'Dzp+/W35uLXLvpKWrLdeLQyNMLVp5fhiAtNBMdGkYAR7gzJNiOdyv+Mm/OidoPBqsN8OdLbtpcUhCKevA5J27t3rTvdu88urOeUF'
    '3rfusvsrNpjuKQ7cdtVwVOEXlCD3rINK7X91reA777hVg5wYNqty05A8puWU/hIGCJQW6f0tXYsHfFvf4rMdmlY/BL0En40tVXyU'
    'vZJxpbgJiVIX7TQD7/dXoSYUDDLxaVlU5id6VV4A8EuhKAd/M93w99Ny2hirwpockz9/9cTtpqHw78kjtKcIZodeTE6bOYL9m+VJ'
    'gh3TmGYKXponuMGzVHGiU9Wf4uQkmdC9SkjX9HPhgBOYZOokGOSwKC2DtNCWHdXU01jA7JIOdnQQ5Tl8/eP36JqmwNww1NxtXSJ+'
    '2tkxjMuAh78uVDcfv5YFlSGAi38hdKxrtVn4x2UvzhtDbMiBduWJ1LGedWbvOwlMhV8ITUza6bXJWiWdE+vK0VUSFww6kG/eRQrq'
    'tj7RzEUsra7wHZNZlyjM3/PthnwemNBHv9sCefRvH2Rbg3/f64UxhcYvZt7X4dq8O9Cf9lGZzzb+oTS9vOQF5JeLWc9ZObE6yZJU'
    '6ZL042RVbeNnuqo6agjHsXQN0t4uLRa6ij3+dwZL1ZAdghybbUsu1yulT0LK6CFF6sZcjAx1JCSC8EoX4yEI4MQRQOfyPs3fjUTu'
    'KrL8Mqenzmgx+Oh2GdSZK1KxEaJhtRdZnb4AaVhmtcAE3SKt/p1aUSAHMy2eyToBalTEFmHHZyqvFO+FtAwrpSDHZ+XouGgnIV++'
    'ePnmdQsBYa0x1qdsyS9HjOA9g1P5tcHFaLleC6/vbF5QO97jRzvRN29YSj5MYOshb+xlo2PQ0veKmZJ9iV3gM9dAoafvXdJnK/ba'
    'lyCi/vIzxRH3XVudh1QRbtU25o2S86indZbyOsxI+zx4Ri6aCeb3SxnQYJbx58tX3Eqm2X+NjpDOJ9A2/kOfPKOe4PmsnBTQQ28b'
    'GrFHWZ+CIYAh5Wiez68Qr5bPNZdxLRH0mzjvMZzsqiT/clWvCsrCIZTqs/FFpa2qnzEYEOCDQGc3pDUb2O2WB3oIVlqqZkoAcGiW'
    'Oqyv5vCuSym/nlkGKXySQ75H7oUNZKlXHD7T4Mv/LiZH03w0jrIoYzJ8qmT8cFmSXdddRmR+XJlD5dd58Pv3tWav//j7bCZzMJNr'
    'aH2yGE0Ka2QhEjIusBk2jVW8N0Br4PpnsebJ3vIlgWz+AlSimZmn47deF7WdzaIzKjQNIKQpmlfIHCJyNZKCyHW4EJo+HSkS6v5v'
    't+DnyAROhE3k78loerFQGMVHn8pvobhz/vr38mOYX/HvTwef/EZ+XhbFOX8/fIQvZd+f8eeLKXL7LWQ3da5kO3UODpx7G/IvVjVp'
    'Yh9cQz8DBBMxHdnB2IkMeRdRJnW/8zG8yJ2Mv0/GZTnvvot8/qbeRcpGibn96UKjoXD8D+9fT28y+Y8UvJF/zJW1Q2rT6dxgYg9d'
    'jpt32eYT9sMl4lOG7tIHDrkz5cXAKRjwsSVAgEM5jZgzeoBqoosOkWHk1kJwVxxw6vYXVWPxytJygo7jxQC77uaD/eDuw698NpPT'
    'Kn8fel8MbmQ6w55T0e6cUvW5kBg+36mj4/HO72enBbIHn4+GdAHpZ5pNEK7q0/NnF/N3EDjw91dQMlXBm7F6d/pGfb46gTobqsex'
    'BTrh0utORjJzi6L7H19/81ITJ+ufmowVkXE6XICcFJc95gZOD2KFrUOKY+QIFsCLmVSLZOsis7iYhS/mxPKLMk1wvWgIFNHvFG6V'
    'ICpTkKzsz2VJIglxKp/rHSsy/WgaSKg0N7Y89XIrDRLH5fk5OcnqWGidEec+FYJHR+V7uNdcxjv5aAAGG8fwt58iNO8sfXlmL5k+'
    'rhYydjR4L29RwWb2SA46/+0zev5ocMVXZ/aK/1rIhV+fw8fyd4bJ/ax8D2Sr9zgXV/jPJf5zdrPG8OpiDjP0TITCV1ByP1l7//Vo'
    '+Cf5XzYpisVaRl2jbo8na9CfARhL5+Hm8aa0scs9GV1d8RZRZ7TRlAkbrrPu37j9EINJJETWZ3u80j3edy3GuVXtUQuYHbiFL2Vr'
    'dO+QwLSebDFW5slPvXVacps62HNcvNGl9JoPOgb+iL99TgX3W6NlIlC1L795/cbjESaXmS64r1uIzkXVWeYq4Yr9fj4a1li1w8fD'
    '0buM3M6TNZTZoIvq2u6f4rsfigQ9HpUcpGKo5+O1sguf28ERMpV1Hx/tphzohqzkxfvHm0e74A2aryf5MVHA5YyiUG+AoIEXUyWp'
    'ThoQHgPCg4WogtVADg3IG+oATL0wLnWrdfB4U4ale7Puyn/LnLkhy7XBW+OLEQM0lRdyk/DLX/+l40G39IOe3Qu6uyLe1S+b4hnm'
    's1G3syn/3bQ3zp6tJ6hbzD0W7y093XT5xqVdSnnmmiM1DCZFVeWnyn1QjWHA1AogJ13lHNYW0JKUxlwfpiCqr20+02FHIUlyMgp3'
    '1hqnRQN13Qi/UN6S8rCMs1bK5ZiYF8+rYwe6vwhuevuDB+t7P9y/vun2Puy/PXj79oAue2/f3v93nTjbjAf67SpAN6TnKiB1OQts'
    'dcz3vTaocPvEiuIf3w1sv1fF6fP3sy472mVFMPh0Tkdw4J5oJBCoJ4io0E/+eRhTLs31ZQI1hSURAY+L+Uw2jgMYdwm3jMKgS9JP'
    'vDOQAtulHQUij1PVTUcinLcM31AK4KtmMPZN1zWPm7IhHJomNdxaMUWOt4MxjRWHiBXTTI2yXct5CMCRx/Lnhw80uuX0ItPGRjs+'
    'gaKLErmJcUoeIx+hTV6n08xZ6e/bLfPY/I3BZsT4MRywVs9SzJaICOyteG26WqecKBx/cpQQWfmxsvaWAVNq70VOpNU6t2PWUSAK'
    'afpxFrWYVpicoPhoBUDRiOCk8KE/t9w2qvQ07Ld0UW0HyEc/m7Ms++qB/T8ry3GRT/3iO8u8E2DUmg7g1JOgWHNZzB1XO6C4d/N2'
    'ir/Jl+ufmICbw+Yuc/Ap6JmB/fO4S41Bs7LoNVOm+mW6zk6EKTgu5yIcazVxogLrUNpwUrNblps0zUE8G6Zfv3pdco/5OS8RYubU'
    'zDRKyIA77ByiNIRVpAoyH7heUDFQPCsnsNoIS2jP+yEBQp/qgClcC96JCEbciApOXhrOsh1Vi88pM8guz93fPKFcqEp6141Lc45Y'
    'Vv+S06dD0kK19Nnpqoc8E7dcUroCWtwmwoQd9/QGRIOCm9EtCG6awtTdwZWIbhNej7/89f+9f71yj9/88tf/79Dm5vDWag+j4Fbh'
    '9rG9w7YWfvUEobK1zQ0qWhsZfKyMturW9tR12zNhJkMUi9wdjQnUSi7c0j/AUBHNNCzyKvtf/zOzsEq8Z3rkG8u96B80R8WzRg2r'
    'VIw6/IMbj4tfVFHF4LaTwnxwQy48vG/OnonV/AhKC9t0vZuE80qZTMwz6oSsyyox4d/mSggdKrEJ7GvZXE7dkzW1Tq2Bf+Et8mRt'
    'ay2jkQ61OORerbMnX/EUucfU3LiXgPa1YPu4UxQqINtEkjoiW8FFWvGlfX5czYQ1tYqO8uGpCElIdA+thMhI8nLXhuMatgx19glU'
    'w/nYxqM/lo7oNbSdsjtUGYcOqxJVf2+Aq2NUr7bQNlIE+vgpqE0C2kCdgVHyBEm3czoj6dfY2Q42GX/fubBbHx1Dr/Hd/WueuL10'
    'G9l5S7uLh7W+HqZTz2eRdBDS096LD3RPycHgYqo5aQ9ra4a3EDjW5Jyq3PSyuHwmD8OSQE8qa/EySCV+WQ6XuaRpo5pfqIVwLpPV'
    'XhrkA2mknHpSSUztSkpJUukkJUcxlzcRJEBlNq+KxcCJDhUlNCh+IQVKY/TTZkJQ6dPoGAqAPgQ7aoRL2r1hIoI8aFpnSogU6ZYp'
    'nrsQTkxS6Csqdc91vxdfRS1irk6sw3APaUytum4b3+XfxSzyiEBeXa8Adp1Tn8TADR0mVKH9uMruyJIjgL1v+8yIAcx6G1ra04SY'
    'HCBOVuUAdS0YVQ3S8D4mCEaPIjz7eOJqYliqJzja/SpdkG0u2f1rzgnw55Mh44pZy2jblPGPi/cbwriMqm3sibVdeGs42qhn0w3c'
    'naenw+EXtZHYicrklfVB+OaU1jW7sKt7vxhSUElMHLAeg+/D1FUXRzas2qamoGxWjWDVpHMlVJIYvCokB25uQ1LE8vxN+UrlAG9/'
    'vjdEgl7Ml5QRQW7S7VDV4rD/nRoSUd8uD67ljRpkvFacspm9ya/23k67fzL9CJLnjhaaroYXPaI3Br1ECsaA3pSwVQWRIupoN8n+'
    'OS7zoU0HtG1qI1vI1/AXTpk9CLo1hULxPp/MhM3VSde9ZrgJT6furRvxtsls7LdngeAeSTU74fNVBD6GsxkSLaq4VFPxYXxwWqXY'
    'xOvTj7N5fSNsgAvi5Ymgtdi5dXZif4x5i4YHXSGHQj8/tg4Pv3hS58Yuzikc4V92uUUlZDMXa3c082lt/LqNzRcJlfUd2MO1wb4E'
    'tX1b18MnsUA2H8j+QsSxZqQOWq35TqoB0jjyO3a9RrHvHEShXFJrcMJ+xEYddCLkYzzQiISmY3e0ZlrQL9i2teV9uqxpEQw5RAxK'
    'PRPrI/R2q50oNLTe248j1qETCbXFpdsgvVRCWTFmdDcaMUr30tNAg4YbiO4zuoPcugxLAyF/fZcsYKQercjAEf8wWx4mdNuALE5k'
    'yZV29x02Wbm7ons53mSTXnr8EkXvZvJZvMMm0e5CEe10xJsu2Tj+jsR0rWhYRu1atRVXr4jAGSImzcJ+w2lOypX0Vg7Od+3FZCvH'
    'HhZhH8eFcIvFpZhaInqP2yl+z3vhzQVyb+djVxCxbl+ZE3zDzzfxuybiZDFm+pt7LiUzrD783L2Kvf+orNbbqd7PN5q/jsWOvizG'
    's1s7yhHBfNvsqKw433SdhdewFJCPDZIlhRrKjnzUi6u0jd02+tu06vdWFthpsMZhYo6w3g2PyLDEm5vZ70vm1IP5VTdrrJIWtp2O'
    'JWD91cguI9+Wh/SMVbW2YuDMlb2qc0CRj0Qlt/JXBWNnvReTwkqAN24oog5fg4GzemDqoJA0LI9VwgUBAlcAGJa9SHk76Crz8uGn'
    'qpz27m+OiAWA0vIpW1KV097hTtyHz8en8Yx726AvgN5IiSireiD9mVxOkxGzIEyLuvZJrZS4sacV1fVuxdvaDVaW6G055eqZ4jJ5'
    'YXTeYxahA11tqGcOldny6qK+xsEyTeLlnI3jRJJHzgDbPRqMhnoQwkzRi4N/wLU7ef/5qDompq4UGbq/5cgov9JJc2PGxJR1pIPx'
    'fQhfq5cBhwj3psib0SGFLZuWMJmJ0+Bdg/9b+ZRm926corqFFY5P599i8Wb0mHLHCTqH7TzHNEYnMXCMrhAxiay3EevcLMTlpd2H'
    'tbqo+KgPnp2KMhdRLANQlmdPIayd5CMwqmahtG0S8VPBDaCW6AFTU1q+T6ERPgOSp1+mPlVNBf1KTPcipS8gbNUyAzVnn7pXXIGQ'
    'JRKQAaQHkuX+tqDF2cfz1vwO1NWG0bKWMFLD1dwV584uevN6kfNk7hMrKvlNL4QFvXV4Izqyr7tM45s/Mqvtr2AIl7o99FeCZqzE'
    'xliGJxHwpNV9gsqtHg0m4bd5oqQySt3/QmWWtoD2TcNsMZIBlAz9eNmxvc214w6wHQmBCq0pWpBqAIT6FPRIEhEkuRzmVWyRAkOf'
    'NVhxF6YsZWsCAp/VJYRlUxOBrS/vdNsULe/dXrokrdgdtbSV7ErZWSUudL1UgKP+DXxHvs6PwcIyijI4JfNA0wM46/7yn/47NUYA'
    'fgA6lRycWT7MhHmAZ2oVp24RHmZ8JTWqv1KiL9SU881w3zfzovie70LEKETu9sT3fTsD+fFxMWNs13bGWM443Ctcr9XxfDRb9LOP'
    'L8v5eCj/kuR8RoQvuSWjFr548dWb569+fPX8Pz5/9kYuzearp8+ePf/2Td9ryn2QrNDhLu42HSEzmBGmWpjUnmUJ8thKpUzOH6A9'
    'mtbSxDfSKK8KyiKfBn9U8mZnTviKXUuRNhmlmBBZ+bq4ef96J/4iqo7fRb/rX8dFW8DWzm8ZgnqXZ+dHQwe1dp5yqQb9K8t0Xnfl'
    '+uU//Y9OBCIpnTJMZ7iQpt2oZnfrB9SV6Eg1S733o5+eE+5o8iFcc/Sh/F//M0PsBW/KU/NMKREHBelgNprCMSUUtY+li0MXMtX8'
    'UFHbUj/3RX5a1RzXP+Yzr4nVnEy0iCr4tXD3XabZ/OZIWLVRPt2G98KCRoPpBaIm5I8f+zB8S9ubCibD0M/h6BSuygNzj7/S2ALh'
    'LWZ0CSXEivbdNae6O00SrtDw83w0PUKWzDkKM/8tSLJaRcCi7CgvmSmgJ8buzVfmy6+1O7djpPGUKevqV2C3TnP4tMpcMj9OJvck'
    'sz6AW+xFXvFvnv4eTmLdHz7sv626u/2D3sfd/bez669u5D8vb348iH+83dw4eNDbPL3Yce7u+emz/PisSJzl6VR/Ykgi3hExwqA+'
    'rb456U7j5Ld7A3PsN/Fm3/uOLxRGlq3QY3lqRYNBLmU7Lc2UFQsy2uP9H3YPHuw6J5vwQnO2tjwXyV4f/zt3IbrsLA5pmcC78NHh'
    'DYtDI9PZO6B9h35ck/1HB+lN1AuIFO+p6N/8Yf/tUOZ13WFmvY9xi/3QGSS4mz3a2trqhQk5Fu5x7nicUDZMk6x5HRV8YcwsAvi5'
    'aWRW1VJgaey5v3hstgM4Zn3T9jORxmeIJqWYbp92LYGZFUUzUyTrOpKXVc85UtvWFRlsfuVjXaUj+VgRl0cayZrzRJlL9qQYLyrN'
    'v0kEV1aRJGs6fSZ9qBniECELjTZgCPQ1f0Y+K5WmJOv26p4vOeTHDYqR9UtoihM7rXpNpza3tXsyE9bg/uIg29sL6Nw9qhe73z79'
    '6vmbN8+9u9sUqIHlvBcSsOs+3vob2g43nYxf2q9nhDCl7DinhoD5rLGTox4fDCoqTpleyTvgpZnU8qNKCmxkI2Ha3Wg8emKtRA+o'
    '9Q+jZEwz1QVsGMqi5xfOVUo5zx7X60T4DD56zPcA21C0bYyiS0jXbD0772X/UPtQ2rbGVhT6t/YimjqGW/x9+kNjlLXmv+JH7eV1'
    'taWMvdzHJwaua9uJlRhiSEQT5MvEtB1DQRl9jQg6MT79bwg7TMaXZE80IdGBHVnhnllADuGhgqP/8f1r9+5mG+5BPIpGIKcaM2/7'
    'Orjf+dp63jnMIsQGuOfcNXfYyirQMRa92842UfKni8lMhXh/p6acxNfmLgHLm4N/NydPF3xPmxztj/55TsxVe+rYkF6wUg4r88P9'
    'yKX5GGRrYFrWaCyuIg6iSi/5gQIiauJhve8Z6K/q0O7FFDp8JiA+oRd+MYzvex27CX/6A1K3/vUCyv3kHZ+EAl+NqvQ9Hrg4On3y'
    'pQWaHYRKhcIpJUutryPdI3dQOLFki5406mMsxtubz3T24jq0qFenRjueYlHoUqNN1ZHGtQSAzWBUjVuNrqGf6TBY6+sSb9tjd01F'
    'N1oEKQXULVABHA13ydOtImZd7srrNPxqTTKAo+fQK4Dqtw/PaA3jmzF3tl+hHMd5TSVwpO2aDkYTIM11LHKTGtiLKaWtYSe6HtTV'
    'NNwPJLI/9/zzrSgJFd79nEB6fax2QXc50nOZntcPTVMYaAqvOTJi7zVpYC808slOaKD1i7hROhu7Lx+56EH/PSYoLv5zVPrTnbay'
    '6motTPnbjR83uwfwuGbTl2j6slZX3OmWyjzl/DnpZFqSWyuhs3HpaCH0EZgCez1UX7R9/hBJ6cCznPa67lSM5BEiWFkOiWjX5EgL'
    'GriI6M1R9CY60EZtXDsO2fnhI3Wy0nVyuUYb9CiLyFoi3IbK1cUXSRcaHr6Ww96rVxQcF8Aye7CTZgjn7UZDeNl1JXs8DtHOR5h7'
    '9cW8wLlhBkBENJv8iDPiHV0SL2GKuE+iG9KP/xMd/qLpY7Y49e5WQbbeJqSW8i83O/xTHo2m598QR15fwCf2Y3NEg69Ym4tYuy/v'
    'yVAq8x7BworDZZcKvRHc1UZScdLHYblo7+SbL59//fz1vrODHgyOu9VZPiyU70U12qvUv2viXEgT8pQSpG8jgvSdXxY/TObgqW6S'
    'ern8rmq93l3xxHM0mqDaVVHMf192R/FFMU323v7owEcUuqvJi73TxAFLaKYaLYfJ/egY2lm0TXfkl9upO3zzsjvruZ3JyvngOEq5'
    'Z7y2tgBxApDhuPxMuZR+sBP1xcVmZWaCkBkfNqwQMcdonjTUEk6d8EW3ENc6fAPfjJAwhDMa3avLMfyjmxlebiu/abFarIR5dFit'
    'zWwyqq2MaIxD0KMGsQmiUaLR9SK4EY3MD83Trd5OW3X7UYmDvbtlAFeD4K8zNqY78RYbxVIYWrfz02EtqyzYD1ZX6Mi6F1IjGh5A'
    '/VOmdB0yKdeve1sPmBn27u1rKFn8ZqPW1s2t+zDBqIcTyGhSiKDWdRvNPMPJp3r4Ea/PRdqNdw5ZUk3WLQztjdyVv9nq+b5wW90N'
    'ySlyC1zmATWCKUl9nm7dDevzsOvVYE1LTCK87e8zxOTgALKTsr6prPZVqtG9nFOikO9A9PWzhhpYo1ZGASXcaadoJmbCna4QVEIJ'
    'aEUfoPGdUtModUI/rM8/rjSDxoFwKtmbM8TTauXm7V4mgZfwBu5zQxS0D0PbJmviIVEUdjmgu207YosnfkQoCR4IDVEOHGRMWwAV'
    '+uW03iRV1cwiRa2yq9ojk+mnEECpgStG9L4BthKvYDh8yjmiMCGjOhUuJRItv3/xhxfQJb/df7vf3f/hLYJspx8+Pljvdfe29z/+'
    'cOCeHTzo7cm/B5unTo8cbuYg2+xRtdqQbd5WD95O5T9BiKEYtdMmhZH7beJokCduk74iB5tbdYKaco59XSX2gIIAZAPj0LvOuX0D'
    'RvsldQpPLFJ41yuXP//m62+BhzHv9hQYA7ZXyyV5+Ngy7vEjTg8895lbDzmRAgI0bYWxhSjoqbFWqaL64YEL+KCD1tcOaiuECete'
    'Jvru1ALtdCtGhxJbMcDyvuJcEoNQ3bimV1bLMZZaLspL9CrSO11Nj+HRoJk3pqmNlBYup0b1s+cNAhpV4de+lwR0WloaWT6yPlxA'
    'zyHjeRzIaHm7vzn6Sc6zCuskrBrg5ivmio0HWtrVehs3ZgEi5AvkQ+W3xhwC3cwxTKoQx7KRKMbaqfft74+lnYN2HitWCpdoA9WZ'
    'jpKJpSlCWseRAxwib4mGa9XX5Hu4UrEI1IgvhuvrOw7PxT6STwgcAzBWNLTN2YDFqR/RNucEVet6qou0l2aleFXIaaWVwRHmi5nc'
    'E3Jq9ve/GQ8VQOhAZTHYCZg6CXR/AawQoWG63zSh7dG8yGPAnTkqL4Bs/6o4qbrlePiGpjrZZG8031h9T4DXt2K3kiSXZh3fWI23'
    'fxNCvtKU536XIeluPaR77gxwhizQeSuEFv9XPYAQypW/Gw4CwNXwWXfviXx+INS71zFoghWqICoaTBcle2leqCXLnUzN2zYQdncR'
    'hG9noWux1UGJ0NnfR9dltDsOdolRjYHa4OZTK68BGpQaTUnT7nBUSV1XtNjSinUF+FP1EoWplmo04jfE6Jo/fv301R9e/6o77MOv'
    'tpwC5ZXWskqzjnjgqJCHnBefN/jK7nfZCi2xGA1mmihMJCmAZy3KC0YvdS/nOa1yH6kHAGGMLLVhpTlVmTiROLBqDbiYhaT347I8'
    'j31WXI6JVJ2pkX2q472D64phHbc7raTuIgtk81vmLhJtvglV71EyLn+xhWVMDGG433racVVWAVsUDjIL88feziZqiyMwg/8lW3CC'
    'HLEO9gHXznZ8W5rDS5xopGHRnex/ctC7W+ts71Fob1VfZO+jK5/ULMzWozgPNBpOtA+1DFfBEm9JN569fr038BuQCmbgVsqkf+nd'
    'ECgbeQSCTpMqXY6NKvlvoN+ejKoKe6/llemzas9rdOeEBtCwL3uNIKVV6cajVAkn3D5yXaku1SWIRkbx8AogHfolgpyZJoW93I65'
    'zBNNiSLvLgEqbSNUO2/wAJI5jaaURvoOxrFxieCES/hWLi1iVXb89K0qLB3s6GQ6v9U3nk0TuilTCbIZOaoQt5lpZYVBazn9zDDj'
    'AXB0ajSphHf/XZ3jImjjZ7cnxFiSQYLtwoK5FyW42LF+xM9/VV6L9tTEd05r4To136unQwwdc+++iXrnvPjx9V68m1WqsFwlWjkz'
    'rg3JHVqdu0/cpo0ePn5i29WbYW+Uj7fklLkGquIYAzctkZPXPs7WXK7Tfra2ka2ZDLj2cCB/qz+U3C72cFee/XwBjjWnPzTaiQyf'
    'iLnZyR48QBKqBw/62QNNQSV/HR7LQERI+ctfNFXUX/7CW/zJE7+PZbCXsJC6rirC3risNHBd5miQUrEkN+LxWQKHSYVjmtrSs1fy'
    'Ms5vCUYLj0bVs6D2bLBZsDRIoSThZN/vgSUZMfE64PHfa+Lxo+2WfADDIokiVRWoC3xjZLD9enuxtZVv1bLuUuWX6dYx3a7pgoKS'
    'ZtZHSr1+dvZI/vcJdkVfv+PiCgmJEgHUEZO0/rZMBnzDDFVaJk4ZuGfPtt2TuOrZvLiFekuJQL8NRmlLTqE9B+lW6jSPj1zSf5IK'
    'MKilidOxaoET6ThyxH2bvfvevVXTiHRl5nPpc8ppkldL+ppb1MCUvGcuY59uUBTBpi5dLkPdYhd0Rt384ePrh/1HN5ljIRa4XfZr'
    'aTQ6Z486BzKXKP1J/7e3lv6Epe3m3s06bYXC+ncOLCQGDexvPFg/iOuHrGrzg1oUKP+7KX3DiiHdArRrD/cHvdu//Kb2XcBr0rji'
    'C3jr1uNCklUGXFY9aVNwhKWaTaRD5lEQqUVlBmAHjgyO7P1iW9lrhsYXNUDPYgVjoa1oTGZGoNnQYp+YlM7JLWQI4Y5jG1oubOuW'
    'DQwIX2/6jD5Yvd+tnKoPTAFUJfBZnjKpq3VMK0iidGk+04TgS1MW0X9Eq5JJfD06GpM/UahRmDlcNlztqkMxhWx/MdX5YjZkXQ/A'
    'ByzmpVxPgDZQTxDINf5kXZaaFIrXzVRjcTC/hg6JlA0IvTJ4XnXTbdOet8LaY58Ji+0h7Pn7IRz4Mgt/qeWA9ux/inaYuqIm0xyM'
    'tM1Fc8m4adO+zjoPOtvCt20is6oIow9E6lzv4cf9TZxUOa7o6j6dd+Xt24OelasOIK3ygwf6u7fXs8+QVPLhwQFy6WntP/4o3/zI'
    'un/8Mar5gJrorHOoxQ6l1CFLHbIQrnIrB+hqlvnLX6TQX1joL39hqcoXeaJFnjyRIk9Y5MkTFsE+1VLZzf7x2YGCpNThoqETEK61'
    'D+JNwGjMUnrlTRwoIYXB7jx24L83qTtBpgmHkzti3shz1iJIaDae1ac2EtfgC4ALbk+FR3u4nTGRg69s9YnWYu0H2hscG912JxXZ'
    'HJ2oWgsbmOxr1x5Jhx4exI25BCgigxfjpCk9s02534nsnV/++n/7exFqR3WXWJSKMq0aiH4SKhlS17huspEu/9tGUfii7x1LPVdd'
    'T9NuCqTflzUbTx6kInr3wRzDS1mugC6v6sgRA7FU2lMFVumFGGS9VuRZxJxGWTODFaIeOuk83Osmi2XO7eZx8lJ1Kl/I+RDKdAw/'
    'NL82Zpm/m/IWey1V3upFqB6N77fZIEGmHwGD+soeAFr64aMtJiqRpXdJqGTqhtvqvNIxR7bt7NU337z58YsXX32FJAz5rNhWE0XH'
    '6YLvplJsUffH3lBNm4vaeFLP+4Z5IXj1v+yOnKBvHqpfQ1emcMG2/msGGb92GPybeOAWv8anYaFWAi+XLzPAuZwNNOwpq6LdwL3Y'
    'NVNLDtO0fDYczVXCAWop/Por9a9FI6o5hA1PdjUshH01GDKoDecBrCod67sIMmCgzcloob6q/qQoU6PR+AUsgbhr//WfaeZZA9QS'
    '5b7zX/76L2uu8FG5WJQTU8DHI6C3rVZ1dKUrJTIR1NhHF6MxHKsQNpukrFLbUmwpkgFGS9nHPjpObH1H5XtzVeUUs2An0q+jPKWU'
    '8v0dzOepIAbvm2t+GXuNIYIUz5wdG1vbxZUGiBe7YzSZ43Ib0zhfIJxGbTXy7PUILnljb33q7ovke0BmhuHjiVmruy+UFdLdXEvs'
    'j8NvV2KcFonJjK4NTkUp24CbDNieA/0LJkfmUYM2CtADdSOYZ/BeFyLKW7pOv/zbiJfWmuhWQONOvL1sl2CFKwhMv/zTfzXDs2xi'
    'e/LfwHIC3Aowdv8tht+vrsAHWJ8h6OBLhv3LV/Dvil65bHByV/GVFPmviYcdIuA4Ptrn9rIuB0wHPRmUmigi66+ynLChqDVUflp2'
    'Xc0t0f7VS/Vzir7zVtRODA3a5lo3Hdd950bzCNiybRrozlKFCV02Jy9LIy/oApVglbs+43Xq3MAHTmbduwSa2LguPaX7leva+MjB'
    'V5L2oH+wNd6sZdz+DrluPFDSpIZ/ZCAI4ZT6jS1GB0dTaIHOraY6raN6cgFR0/f0nscuJEGdFPkUKHFrSXdT9MbT0rp7WqI6Dpr9'
    '3d3fbzgU2tKnbp03BwcBzXFpO8LQWUPDZFZsIJ87rw/r+9ruv/5zhNRXw6hs0h93IuvUqraPNgzXk3RSq9Xsqt5/8UaHsF7/EunE'
    'ZBfqWgOYbzqWC0FViPjBe7u2jOHG2Ha6kuCWE8Ip6EkmdWNEBBDU6rVGDN6ex/MQJxAFQ4Fxt6Q1lN2oSB4G8DNylzIyz6Jv3IS4'
    'RCzkTFMRWYBbHP1LhSUBIGLTWagY86IX0+R48V5WRZFmfru1lT38ZPY+u3/9xTcv31jaFvqCteS6Oy5G4y6/l61bXczJaGvdFvoA'
    'WHT+jMOPrRJh137nU97FhiCsAJXc4D+6416c/ZQHJVeWZIOzj2tyXsqsFONyelrRuh/Ml3a5u0SHyEDm2JAIdnu8HfsaiGSogYbr'
    '9Ys62cU3Ox9FKQddiTvDdJ2WK5zUTssDaDCGxSqkOHkbIXidlgwRiZl5YwXXT0vf8dOyCbfRyhJWEK1qVotiHIwTMmlMb5Iu1vow'
    'chQdsgr6kii0hWt27HhTf027ZIV6HFSLYZ1ftQZx31Pm6yUH0Kcvh3rueWy1W5bLeecmyDd+AZqp1epn1hU2PcwdWmTozyjx7U1a'
    'dZhBJGFy+7JKpTc1qFN1EAMrFW6BBgy8OpAlzvjljAcvufIWvIgST/G7Defursq/ykXXT0eIcVri6bvaXziZWreXSFh7zXyrgSq0'
    'f3KwFzMGFpvTmrW1pfu/ZnuU0Z78KLYbuHr7Tg5ffWBcFq76yI3EuisGsES4AocR3zlO5qM+EX1mVHNhZG0pJJx3YxQQsxVpw8aQ'
    'e97RMlNjt5ToOO9+5mHrZa7Ik+ydTbv5pNmLmDTUMHLqJ0rd8BJ86TAfkLUx4r4TC7OuPoy1MIhqLGNZmHGR1Jo0A9IacwTvnf0P'
    'cNy5z7mK/Edd7Bl9ttoUMnXtiipoyl4NzGyiGhqL91yifLmj+mWSKl8mf1/VS6ZjjXQfd9d+ZBbhxkUunWMlBx2SujTGvtJjEB/D'
    'ZU44QlZ446Lowu6KQz+cBqbdL75xMm8X8eu32srTHd13Rq5rvurOui6UXqhhtY0krUgEQhvFhH+mvuvP+V5Tu1LCmXkZa5A9rXut'
    'HxXHpWW0wwOPMkJwBECIIGQ5z9Y+s7/XPmJysIrWLu9E1/e+4yzMcSrjnnXXeLa3obX/BsLNwcFazXGgA9c7WPvluBTjYdWjVggN'
    'WXxnBc4LPveLRX58Rh+0zYECT3CEcKunOpitK4QiMs6VMvTFVdadmW+IA0/pq4OaokOgHc6turVpGuFZMa0Ul+1ixsLO9FZRy/Ri'
    'onMMR2T9FoDRwIk3YFSNqh78eTQzUw9aAYtbEvotX4Te2QpEtEnqwQ1eDIM7KjwPg5JZjpumOKUoGTznj3776dGV+kLKn9jF34nc'
    '+juR1PMr8mzdfFEedeUdAoQJyjA4Psvnz4R+0Amh5xzpr/LJ+PUCYh8zaB927l+bnftdZOjugPatdTprvZvOYeQ5zyn5x9Gs266t'
    'dt5/hnlU5Scq+waMSxWADd/beY73CYP3zYkhcSBHfOTI3ev7lEHwJ8Tbp4vY03u54+kq9/yaN4Qc27jHicf+nUIBw/3gYp1zGAjP'
    'QyCtai27GAAduFs10Pbx4f1rfA9g//P1dZcHhZ/Caazl0x2bxH2I8wcWxJCaG/WUIRKtmh/32cGGZg+6MXlrJrLNH0DRtkfIbf92'
    'szubnn74aVacfjgdnXy4LI5mvR1U8ttP+939fOPPWxv/YX3zydvqYB0IpzXjWiPPkhmk3qt96eFBGyAbGtP0rLNTzHezXGPa3cwN'
    'hHNGbqhlSyB7yK/C0nl3lYTpx2duBaxxzb3h3DblOTMG6Sm42YxJm92Q0idOqz/WXbp0RnyasR69mvU4O2yrbccld2e2NwrllLm9'
    '/t9pT9UmPqqCO2+uuD5BZecjeYLYnlQhF+0gQu2eltNVOuqJ108PIgUiu4FVvc4Gg8HY3e6IN9DbXcVQ0yvLISuQo/dGln/c+3Vw'
    'A/GJ6LucSeAoXPSBcFBUnnDIcsLf98hGJc+uep5fMgyeFssUIdv2O+Cy4CRDLxf8QbYKfyAdLN1nZFsQJpsubywy+jNLCHV5bX/i'
    'yiQ8ss8UfmAGr/3zgwA+jQHhgfzedzAuahajKgq+V/rXPbN36ScDj4C1YHbTiAoqwP9+Upf0K3BsTKanm1BfDUhK9DRYMj2UZjug'
    'lyi9w4r1hBzeg240X9wcHBxyj7tEfFls0Qsss0Pbeej4z1AVS74pnQNjMPz5g3SPrvjdbkzEQKgO1h3dCmQLnhO9zdNRH8F8sill'
    'XL0YiDhrmQGO/dDOoSPVnlMOoWJwZIoHHunsoZbVeYh4ZttTIyYSM4+pEOusM4W33p0pTErn448zx9LJFpIDxoI4ieQLDhEkqZnT'
    '5GQc42SgR3EfYmQsHvFV8Uz01lKNe9Q5+XhJ35RTZsdQyFMI6Rf02ipH7jnBMSzl9jZp4rZGoGwDJoAJmaLBgIAsGQwYveouw4lo'
    'VvfaiBHIknQXUGpT6X7RhS5LHnTHRg72eDxIIdwjUKvrG1/ODBLXSaiTFpH179lOSDpmRJXZUsYe8mLX+zJQTMew/ETzzFmKNR1x'
    '6jxZzshDdUSc0AXotgFT7B+qdCAEbTtbi6bXFcYUrx3CB2//QAZ4qFw5sJmMt6zn6GYWrx5uPWu60zm4y81p52owGfoLk4MwLdjb'
    'KfcCt1d4Et2i0+tP+jcaujTlKwvIQATTtNOMghCe/rOxcNGW1KcDPNbRMVVkm/Kuhs/gWcWFRi9pbs9mOOr+27eb2w/21h7vfvj4'
    'ByFHGky10endTS+D3KHZzUca6ZYPTfYAvhQheACFWcAULH/L2sxHoJ201e9rWgg67B5lNweDOqr3xVQqaiSSP7o4MdY6SBhdhdJm'
    'rvUcDz67ODmBvN1TRRMDUmV9CCYgFQyO+L7XNyISwBo1YSqK+Ij7R2TNjDHDewcm9w5u1OjEJ4+6dCigOM2tuvV+67dbv/n06Ddb'
    'PVS5seEVmMyKCgDEM7Ab6NhzYSLm3bU3EM3MuxMrzdGseR8bhB3UGoQe5bdOiI9jkJCKdgs8AZMmhs8e/tZ9tuVlf+ShZUH5E2Bw'
    '12kOxzNiWcc1zOLv5RaCrSntGko8CiVwRr5iwH69mke/i3of8dvzvKXwJ6FGKLGKxtBY6JEvxJSjLT379FFLo5owicsBq9TnBXwD'
    'Ebo85F/cM9XFEfeW1iITr//Kf2yEvVY3c+0H+i//ifvrXjxya7js/e/8mOb5pe1O3xnzIdfW1rkcsVyDgSGmwnClNgOMsEWV2RI/'
    'IRYSLjwjduFobnNaSHj2pQMHgeePgatDPb9bWo+eUo3yrGYyS5pMOqoaRLkAivxgNpoVb+SMXJyesRCWZEIgWCENr7VUxyjLhnwr'
    'A+sN0EwU0Ka8iizTk2Sd5C/dZOtuJ7VjCVpy6gmcrX0QCvA9kVdNzpphGljUSdVX2Lu+BpYAtzRXjcqxukNe8AfY603lrTc1hKSP'
    'dkyBJafTKZ4GUaCorO4VRCE14FIjY7ob/S7FSOi1BJi8Kb9cTMbdyTAmpab6skTj8clHl6uI0SaGbbgP6EkLP1rcCl0RhJQTPUT4'
    'wdYWoJiG7tqUNxvZwxt9cxj5q6nVyDEWCUfMuNWDDxqy+vYDfgTABW3whA0ibYmJ/HuRzC+yvfrqn/SYTRJsPm2gxeSoGMJkdeKS'
    '6K4xb+YhuQhyZm0d0g6QUd//oUf1gfwrT3quOxc6/paWLmgXa9Ta3Xt8717PRgrOHpWfLRazCm7PbOPDJBduq3Q/e9pa53Genc2L'
    'E6n70dru/YePN/PdTrN+53Bt7tYf1EWaDtKuz17phJSHwvgTyAw4DK39VQftS++grY7c3b17bx/0EEH89vte5IWN55d+dmYP2drs'
    'kW/x/vXsIRw/Z49uHo/YuPxA46O2xtUpmy7ZOgUVB17txjyKumXTKVsLaf75h5Z9vobutUhjZra2um+HMiD+6bo9stnBbjaQrGM1'
    'dxwAJ4uPzZFyJ0qcOeXJmQyjFuZvp3vG50mXFRiPfzcZkJHDdTOGA/cz6/RcdHxO7fyygGFt+eTp09g+NYLpwruPR/Ls5g+Hh4cW'
    '2oJvenVj0LHGhiGzxijYfpb0jsJWvUpOWI8VKU2wh+vrByEzDvrnr43Dx0LpoymP2GfMPF4e9nZq7vA3XtE2CfMAbBD20OsLu4hL'
    '+u2NnKn17uCB0IoeJ8i3HTu3P36SPSIFOXuE5Jwkl1SFoRfyjLTj8dknLS8/YQ9XTHv3bfVgf+PBjwc9SAHy435tFUKXOo/P5rud'
    '1dXtrlrDnyNSvnLt0nps4X6ur1pkjNx9W+1t9lOB4oe3+3L6198e7K9vHOwBIUJ1ha79aJlDrJZMYe2u+rm26lHZZYuvUwFgig8D'
    '+V99UnWEfI1ube9tUABLBgzu9iCYktOjUAAe/0nm0EdUEorG/eHD2w/eKmv4l6D0b9/23n7Y7AUlh+2WY3dC/dw4J/kcbDfb066D'
    'UV/3WuKaC+4dl3bZvNgy01NO72zfrp3StqUjd7P7eIG+yj9zwPnIn5EiR97Jw2NZOvkj8g3Bg/kunuqnBgbE9vH13L5GlfOkvqGr'
    'b9isr/aAlcq/7OVhPL/Ld02XMYIf5CZAxB8oxKpDNVoUkzvP/h0a4DLQkIOy14+EKLxuvJaq2K6H4u419H+TSXQjBLInzfea7RsJ'
    'DBpBMvMA9WErxsQPixnyN1LrfDIuRVydkEyGG26h+gFEW3lV0Gb2CBecage3hVkbOjQJUknnKjAhAERMPfaz9/+n8HpKOSaPiO70'
    'KIC6drID5nfp/PLf/7Nq2X757/9F2o3kEieZYBD78YSBGT1Q/fK6hiGvh7mK/SjcpeR0oGm2t4vRGAe0q2YATk+rLnZBtHHtBsoe'
    'DGw60P1yrOjB405oEteXQmnJfidm5w0wsX6CrQCeb76g7bWfZK8l43MbZP+ngwH7BXWFdTD0Tte5XtCXs97vi5TZJ+76AcVOGXT3'
    'p36tfiFN1mH8EyE4v90cC2snKyi1QKX1GL9xi/1kGPDNq0z/H6tbxwSgAnez+laJeXPD2g6lsrBGWVSLy8KhdUlVm9Fk+gPrvUgw'
    '7T8FVOal0xvNDWq+y+R4kokPktHfrKBJTi1BVYijMCvoS20PGx9mvM7b6oNwZB92P7SSoA/JvdBrXgzoxRLGzXQM8j7MT3txG1fM'
    '4snasiwovC6yI+GPj8DvgNPbPew1hfMEjxbS8xdzmUIE3kHN6+OXqxHTbq+dF1fb6q24Zuw5PdGBLB9jMZyESrqLGnZWLTBz84eN'
    'jY230y6wrV8fPNjrvZ3ywd5miM4JFuV9+AwQajGKkDVlt2bywPaD8uAPCu5nFugYbQ18fnmi5uVIfqhhnMneq7O7sqYbdTrvzr5u'
    'HDbLhUOf9u3BgS4TigWooIhK7691Dj7gP47f6TWPc3NI3nL0rsGW77+9zDZEfNvGJq339t75u3r0qz1mehov5oQW5U3odmqQrw3U'
    'hJtG52VN3mlFj9KrQfmFzuBBx3FR76Txd9Q1Gkp7P9t4GHurmLvKWh1pafOHtcGDtbgaTbWOymikIHSivNjxqcavW1pyfdaBLR/6'
    'AR0g0/O0z490g1qlUdBv74BnrKaZV++vP9JJ1iv16bqrP6De0b+cxajQTEFQFGz2um8HpTlgfXgrHc2rs97bTZuEQtPxRe46DmSt'
    'rcrNt4PJ0Ot74m8NH2ARSc5O9qeDIKKDDGpNqlBLjyFcaUxsFGlXnr8pX9liNiLp4jbkDv10i8aBe9L3k9F80j18A2Kjrlpw9rx/'
    'HX9wk1mSo6pMYE4nOVR8WTUuLwfZM6QZysrp3mHSuDk6vlL9Y3vFv/z1Xw6jqVyUxNHGG6wxtcOBr9okW5W+NWIjr4B178zCWhsH'
    '5SBP2TYDPnVlCvs+SjBQQmOuOmg40crPPf5Xak19DaM2jq5cA5ady+0C3BpsaL+o93QwK2fNtBTFQbypjq6+DTr/lfWurAZetsgt'
    'CmZwXpz0DRLTs4LyDB6ktCJ89+rFs1JOzhSx7PLC9fhjzm1iPBiO5sbxxcPyNjcQF70DN2t6LR0W04x1kU5WZhj/5bRz9WBlkLZr'
    's0O5I/k2rM4dv8Uy8dtoZEvWoq4zM5U33BZIZ7gWV+YLqwTROSrQggAd/As4S2hBqv0TChm7crnEwW1CWwx07kDZapAMjjwCdfxA'
    '18RzCdqbgu2TLfVB7NRCqTdPuPp0JPZYDcVqmpaJjoh9/MZDYYXBhdvJnGHQs8TwpHHUgbvwlp48ZFe9mDPmtjCP3RlM66A/p4gi'
    'oLHWV0NfVOG6IvcWMLywagd24OOPs67z6vhAFwrhibrdve2NTDjL6V4P0JET1aueqaXE1te1s392QJ4AYPJmYg58Tj0qxcUjM1ji'
    'Jsmv7Rx7eq09jSFGf7inIKOQAd1Xvwpk9ID/Vz3oLHOQMcGopthSTOMAlupLO7fUZUA1w9E714qWTcJ50FjD7QsGCdnYVrwZRCjv'
    '94PB4qCp81IChplxruMsKYSOIE/0erCbG6QhU5gZQxdk1mWSRbuZ+zjrOEW4APT42OHvniSrKE+ptlb/LU37hb92Ml0khH89Xcgk'
    'Hl0sCpkZPwT111IGy5fstqyNeeAtuzyCakMZjIbHjjqh0CfYgCWV++p475TOgXMnhKMJ/AmbJVbFdSQgUsBaAGzjuYiVDi7W3ObN'
    'n3sUfOo9qKyL+ozDy2cGUqm+2aNKPSiU6hBy0XV0YDiR8fD0Wduw+CYZzocoRMUlA+rDlLXZo29OLRHMV2rLYPdiZOuG6PGx6ZMb'
    'oWr+I7lSgbzrLsmsk+ajZEvg0exvt/rQXSkHw1rs0MTo455XYrIkfwiBMPN0+JN0b7rAaex2jgg5VdDZUkVd2ju1vViyzVJNm8bN'
    'gBr1/Q7rexrZdzbnKp+OFqM/W0b1OjFA0M4EyKpSzR6dHJHtzp1HR+r8oYwcjWSXfUbdVsSLbtdui8rgb84KYSwWiB2g2doCHaod'
    'c9RNgjziEINBxNirlRnysXMLw9+j4TcnaT7WkFDyxdD5WjpoM2YTU5/ZLadT9JwpPWg19GhZxBFqaIk4irkGwlPYQhG0ZcQNMlow'
    'rXskJ1xOFYMM/DMJ/ygCX5QWqiQYmn9VP88X3VSnW0eOOodaiZBRWs5Y1W4bxHkapIWZJK6qdLXpko+ZTmjahKPkoMDUYS2mtcCu'
    'ic9pYFVyhtcng/dUXZ9n/8Bx9rIH2SePtrINHfWD7KEFgEnJK5aMlMnn2aZ9hHQmUvjRoy2/IBNzWJRvamuT+jeL1P+/xcN5sn8O'
    'pYH3cZ7qb4QI4I9IOeG2h/OUzKtqdDoF0st1LdqtFtuWqGkCgpBIj3rerx0Z8G9ver0Ijdw9TqpJvKT1Fk4vYCuzE+7fqTlIyw+n'
    'YfAOmS4cfDr4EYdB2rQsnVFAYA1MbjT8gnAOZCl2dW9CYLDwHjyu+ya2BDu6m+TDxwebkJtaFR2RhCaLTZqhvHDdNT+NDGDnPXST'
    'DGxvYDR0GBacFe7z9UBpqQ7WQCru1kKqtuPnP7optM3TpvCSJj3fAU0/ZjR+2HPdXPrWvIjh6RuWslnS58WaDrBVG9kAHZXALapF'
    'elYUEcwkqY0j6pSY8q270AaKFkW8vEYUakOXuZGJQNEdPNjrbUNL2NvzvkLqQSMbwhIWTCZhAtTaFDOXTBuh0wRY8DI4V9emPLhZ'
    'xKRVY/gg8bsdMI5GofjHNBHrTqHXd5SnwjmjK4X1FghFkwgxpdtotZmKAl7RNL7RW1sDHLNJAuceeXZHLuEadkhvb/mzxTE8PPWO'
    '34Frvrnzzvb7xvZzHHE8FEbxW2GK5LhHQXki7lCBNJ8IPf5zAfLGmQbfQyw9oXSMxBlqXH6Fm8vF0W7zcr5R/M7K+Ii+Is9EfIAR'
    '1duh2log1pT7TpLEhLxDK/zwPLrahFG7JFbtMGt0wP3DaFh1a7zEOL9CXLD56ioQ4WyubtaaAUIVi1KoTyEeikD0xRIyAeDklJlr'
    'EjC3Ew2OR45kcIQGDHo2GhZfgrvpRdrFb2YFwkHvX8csiikXFRhr7f61n2aNrb75qBSu++MzqYs6Yt6jhmuiIc6IS+ZHn4/miGzG'
    'S5e3B5By+HSWnyKp+nlRcd/MClPSIuvUtoxfRw5n877GvNq0Dz7C18/HLeAIw3l+KuLgvA7YAfHxjZC+6qSY7w0g71R7kV4Uk1RB'
    'NG5DiMDGWtFgOWsiMZxQ7kwb5dD2BrJHAr5brOxtadrKiYQqcxB8HgcWMGju83IznhXTbqSyl/kmQS3m9LTQhV57Vl6Mh/A+5/Zi'
    'oDBneDtbg8PsfC6krqpkTfRy5U2gSZDHKrw7gIpoXVvgbQhq2ZySYDhAAikPf8FZ0SRPJxbyApFlOzsZXBZH56PFq2KcIwaeylwk'
    'mTGeVB2OT8AY6ew1QTa8R77qfZ2RoM228W+fsJbwesZBkoDHOeAQUq1+x4CEN4CNcmpQU1l3DeHeOArlfK2framGaLgG53B0w6Dq'
    'CsvyHeAKaRAVWoXwSKn/8/JCXmxo8u3cMCvkFFVUDoElgVCnXuWGXwjgKDpgK6aVXrXIU1QobqhdlejwZx64kD+RB7ucd+IMZ8A8'
    'NnCpIWDKRXbMx7HFNcUPQboodyzGdQPM0qzbvnGyODHhDYhCbfnegzCE1tlNZWlxY0Pc6b7salhWj+AWLzXV1eB9Dz4vFHOiEldR'
    'iSuW0Is1lQrcvClyFkSEcXGyYLjRu1FxyXYgZD3I+PP8Zvb+ECswC0WuWOQqKWL3nq/d7X+bcbjd+pi2PTsVvnAzXbl/5ROQR8+q'
    'KE+BIg2nzfq0L62PG8llZSl1h0DdEBK8RIvqOPJ6loN07/gPDHWm1vqvAp+Jd5TbOc3pcinBGAUJXQns7H9vwJqbZNPefOS78b8N'
    'YyleI4ck8rehLMU1ca95xKMVo0qSizb6It9W707bruSj8RKMtfH5Cvg04l8Ek/D4fCnylKds6+PzAHskn/tB1S4CYUgqQoQIl7jI'
    'lYcD9XVp4hqXA52NBrMr0OfJrDKQTgbVEZxjLltFWt1Rol9eACb2uER5oI92hsW7DhuYEuBDQ0/BGVuDjpQ//fbbH//4/NXrF9+8'
    'xI35aOvRbwcPH/L/th5+IvOHAt99+/nTN89//O4V4WMZwbC9uTnPLweno8XZxdFFVcyPTXsqu3zz+68/y6Gn3FQD14YxbZvgkTeH'
    'skqbQoOg7MuPhKl9OptRHLIp2o771Hf93XZY98f59IVOoX9kUwr/Qz4B6dXRvXj5+s3Tr7768fWbb149R9/TDm1Pyw37eKNEsKB0'
    'q+YFMS7z4VP0Mko/9eU3r984J45oBKppyWejbmdT/rvJV51ezazHk+O+GrjlR/KO2kwLKYkXB0SFqxpIoPxCs64umz89jK4kmbVi'
    'zs0KmpcAqqMCuRA+ly0yLmcMt8MWoiH4HbTr9bqjGr8QyvirKvyjda+tXkTF6V+fy3R066+FYPdNv2+tPzsr5HT3Ajm+V59Sg6L4'
    'j3AU00fDbQOAJKqprPp0WDE0A0ioY+byYW4+2FOk6xfklfQdEShkkSGzKsNEDTdZFRmzbYbYcETTgIsMfC2ckfCIUIS9EAmrK2v6'
    '4+vnz186ca9r46zcd8zMIV0QcYfcJyO3R4tthRtl8kjmxwNC9RWwM2RQAAcCP7ixGE2Ec/PqJKtyz9WNjdSY/+3sHj9+dTHtuTn+'
    'bDGl2OYADgE40hlVG9KyB5qJR1fVRtdvNKMmiPg0AMzKNoZeTnhg5/sbDe911Li+wE6V1IDWOsbe+I6F7KLpZ49+s7XlofkXL3Dl'
    'CWew4oNPtopP3PKUJy5Lp0KNGek16OeLGVFKmLN5MppeLJgxlomYb3wWXTcnLTTI5majKgro06S9P7rdkNtW+O7NM0ScqREGy6uA'
    'TZfAkgKq1Hbm6PbWo8HDT3/zCcCos7VH2cvyHV+tRS6Q8UF71w87tdOpO0PCoXx4/elN7+1A/ng79P9uMhsJPNaCi9kk7LB1F4td'
    'dPGfgXS/uw7tVZ9ZAzXB+bqmG6RKVzZRgZKmJPbZ+sAhD/MrpIS/kD1NPf5EiI3Ihh2KTvL7qsjnSQHMzz/KmQAu0ptn0LSbR9PN'
    'RyHj7bg8NQcRJePx08hNAyfBv0qpXUrXTaWBM7udXYqYSNAxu5b6PrOw+pwhBtRokmxroNwwLFwIelkYOpk+4kXvjqglnB1wFPr1'
    'i+lJaUyquyhfL1CrAkxy80aPMQ3Q0mC7a5o+g9GW/do5yUdAkEqh6/3RjGPzF1OT+xyNQGRyeISmLgzCXspGBGRRnp6Oi27nLK82'
    'tFvShXv3wlh6t95Y0bjlntEzS6GYd8zyq/DXX3PoOhWM9VYP3UV2/zo8d1/eANiI/SEes+4ARJCt/dFdZe7Kd6ustHyNxM9HLD47'
    'E+5POP9A/qJZSm8aiuErvUnkkK8ocoQCsxUFAJeOMoQnXloLb1V3LzBZAdbd/Po6Mj1uya1EbWHvOKuGgTVbui0G1cVkks9pfuw8'
    'JSFym6E8yQzy7XNTIlpfTsu0szMRDKUKOUHyJm0IrF+086aGO/+5SF7gFHE1+zqX4z47CEiKH18LzXBoxVrtZ7lCL19M7VKKEjhh'
    'ZoUTEZmweyTLhlVx99rCvyjf201LZhMnLxnEymOyJizAVDNVMYtMTo9WpqVGmoTZxdGYua54HzLSH/KF29Sa6XdAGEcwFQ1GVxqg'
    'ryxFFdA71Gy0sPZxQtDQQ0+4sALP7Ecs1Pzy13/pLPvY6Bs64JV6rDCRirKn80I5QcYq7C3ti8s/sPYnzf+B9MQlL+nBmveglZkP'
    'DCogonGqXzJuXvUhkTqDV4+jfbhsqHYoTxsUARYfdyUFR9aYJCgmxbKTKm9Hx+MCJ/psRbGzT2+jCzPikd/NlW3YJAfAo++4t+kG'
    'jVmUwjOPONJFTKL5oZHoRLyolVI9RbzZG4ypN5prMNeyERUTyHNSptbhzgt31wvRGLpzyFRWZlQ9q31ROELVTtAKs/MriDSLyLq5'
    'iuXwnfXisZlVKyoyS12G5Y0mX/DbCkqNUXlR2dgsIV60X8Mmc3uVbM7L4rKAc4GjA0GzAbQMmFuZb0qTT4Fuh5NB7bJjgaYlZnxq'
    '+YAauEBCuIt5yn4E0TtOh1uXuvWkbh6rgOh9SOeD/J1QAESKyqmdB5fbJG2qVuaQhgrYA2pS+To3L3o1+Kkqp3uLJ9hwZHPlMoDR'
    'UjonbBuYrWm5QYAk8KA9Fu/GHPPcb8ndRNKPuqdT7kmdGSXhrHuq+Ihdzb50lo9PvPjRw6z/fDEq4ARVCrmzz5H0SJnL3CgfqTsI'
    'Y4VmgDmSfT/a+GIUbHG0uU1KQg8bBK5jVs+JukyOf5B9Mx1fZbze0E9tMiasa6qWqsrGQsfC1ySfXjgLged5qPVPjQG+XJ3p9TfE'
    'Tk2y5DrXhfSw4uluM5zNmMVWK7rXUM2DZsKOMZ7FrIdCRQbXzrSjqK5DzoH3SJQrlHHEOj7UE/YIxHat5PNRhfTaxdDAoGOmIZav'
    'g1f4sumyO3GnYe26w8XoQNSbQvxNJKH4vqZiimZWV4uDiilrX+XIoZJ1T0gjYGcz0lzT2oyEwnAvNWSpPrUgZrUfHRNpFImYgCaq'
    'apxcF5rJbBM5J5pCzhvuYa0USFENKeSOzOp2+j7eHvltnKkCqoZ+/L5s9OKOvGitjuGoAhEcxhafWpGmSSgUkDlqKXFTP9UR7xqJ'
    'ju9SVt2fIUoWaSdutfvVUZ+pi3PXg08Oo/4TdJ4nx3mcqzGXLJUxnMj0YlPGzSMLQzjaElC7lOFkMUNwRxokDli7O94bqd5n4/hs'
    'LnS1rAbw6d97x3vk3fLrQ2GvUpelfBWb1/GF88GZevhLR6yY2iXldwTOhRYO0AH4Rpij4iY6xw7sSDV+np6sHk0Hhc3fw3XiliPl'
    't20xlNsEali3FqsaUlP4FXyX3feVXnFDl46qgIcWjdc+Al9ks9SM10Ks3jnVrMXsUfOrZNFJLbOU2uBWVq1riFGq09Vko2mjSylr'
    'PVkvUvaEsxv1W4mps0feNs/f2SeQlXbcpbiMiwL45FXHOqSDgoNEzw8t9oDYubXtN37UVGy/7Siw/UAl7QZlarkr4gyFsjp/wsq7'
    'cMpRGjhhqZgBqYbZPS1NYpUrQ28RQvG7nM6q30eYlVPu3zaYV1o2mkqpITyMliTFbFQ4xt9tJViMATXvW9nRo6pQgJRItz3vI+rU'
    'BROZ1rLGxijl6Wx2lpGRHUtIXp6Tz7BIOxfWFryhAMj/7qaDUFRmgK/ZsG4+UtU/SL3Ip9jR3eAS5ol45BHm7wMpFhXipd/0HLte'
    'fuEsO6/hWtnzLJOlw1blCVuV/QDjEZR/jUbd2exKoZE6KUKzOb44VbRWi9YjxhErM/VnVJH5m6mek3qdYnB8MYcD7huXAWqJccVi'
    'mIJ9JXTam7saXY55Z2cQN02045dgzHIHgolON+aj0zMoQOdTACmUTA6cXY6mMn7n2+g88yjTWQl3yro8RGhG2St4n/pCUZbYniFZ'
    '2AUeGSB497ZplrGRzcvO1nuP0yUNnRYyWzKBn0HqkeqejUcyqa/kDutCvX+dcVTbGcNjvkcyub6N1559WXDYN5GG+ft5PoOvObPY'
    '6axY4MYkf999+Kgf1ZZtyDHRMkhsE5LUtddmOWXbqrOOoD4rlVZ485FhZ8oG/OZIN2w3nrIe4urxuBvNjSw8I2kuFjyUt3yokwwi'
    'kbvwukrxoPvhyRcMvNrO9ju6GJ0DbsmmVnNeWGhF0pga+E0DznNe5/iRS1eY1rVtIdHnWX4KTo3XrLNwkSQrQU7Z9dRAyB3E0KEy'
    'NKEEkk/u3Ws1wia+AXUrvUXZnjGjrNcWBd8D+nj7597So67y6gGeDJ2BaBcLt1+wAFZTYsRGg46Zxd+9eunWq8j3o7qqiA4CBeX3'
    'PNGV6kP3vIaqJmjsZS802zKIBPkoJoo3+7cLXVaXXBrHLaeDMlnQAlAnoIx0rAR1etg7tytrXf0dmk0ck63tGpW2+HMfwB+4+joX'
    'NHJLZBq45nq7C6ndbO0crFcuULQ4xfBe9tKdgL6OPJ234PsZ1qkTTfNda0invJMoDlIOLzCvI+d2U3d9dS5P9XlfervXqMLSKcza'
    'an1ZtlWp573VHyE56PLpw9QnZ2nDNQ8uOb4lGINWP95FMds4utrAv0KKqgpCPRwCZnOk7zr216ellWI5oXrKmmLzlpYCRe42xDfI'
    'FaGa07PCpTOljo5MYuGEHKn53J+C8uREc7yOAA9QsOrOO2mZetgFAlmUYaji+1wrGpOYq4NYjnZO5DLJDRtgoQjNqHQKLlG2Hg4f'
    'At6B/c5EkTItQhyJZnI+ourQZaM6KQoLWDgv0H6u3ABT2F0EF0sluG++e7PUV8vNfyfyMGaX4H9zjcr2BvhNP5WCaDpW6+fPv/rx'
    'D8//BI/Y6uv8mKhy/+l/qLKEYmLHtX8xckDJh4+PXOrgixFSRy8UNdeVhAc6lVoorDlMYlgup7fAD8cBWYpBy6ARB5jTAUx3MvJk'
    'dJNYEh8CzSaVw9MVOLmY06uA6nKgOZRA6GYqsZKCFReBPL/waMIxUfNVqd+IrRPTWo2Z/cxQsIv3OSC1IoZNpvZ1gQysNf+Q0E1h'
    'traAwmCj4bOdyO+f+0ezvwy7E07RJCSF6XyNq18WO2fixVCLB9wBRCvABCydFvJhEWtoVL0qy0V3yho5ddPmjMW1BL0S+3RnL/M4'
    'wIkqVUtfU+v9hw/ZvUm8GXpunFLu27NyUcrdA0/OURX58aGbmhTje9Ot84yDzLkHE4TI6AMs3ghGWRh6Kk1iYaBxzZl7nH3Sy152'
    '8TkNiNJxZB3zyXfQ8n7jM8VGfYEhRWA6WOAt4sDEy6zQf+j8V6Ba7KOj+8/y+ZHsn+GofC/zk3SVi3W0fLEey1olHT9KOi5t7t9S'
    'RW0QFqVlAZwWc9XbaQRM+aiozlPhymArAS20Q+HC23HAlLQjQGaqIHUxCXv+7WvMiVR27cLUOt8XY02GWNau5E5feQXGXncNkHq2'
    'Szu5v3Uu87G7Lowe0/Rj592YZdDgYdnnXaKneUHeGqpC4whabyVAFZhyTBoOV1R6EalMqZ0gwWm9g8rpcVG7ewZQ1LBzpyX1ZBqG'
    'IhQI/os6BFSaj9V15lzEgrRPjhYvRrO13RcLCxkjX5U93DLDVxXaEaFUmse4p1cqT/hMYvevL4S/+9d/7vRu9PIzpQ8O1Zgcieex'
    'tOielHTytCUgW5Qz9u8wu+kna0wDN5mriacKSBIA4V9efyxUGXHprev9nKa8KslKaOKPdinPHh/t+npxHTnRfiISBPJvvoB2y81i'
    'ZZmz1bB3hJiQYU6TrcyaIjGm605fWWkijghiK7JjI5W5pfCs8is3F6NjLvgcrljvRhV5GHqqaijR4/Oj4S7DDB5v4k/UpwR2xSI/'
    's6ilEN3kw5YGWuPrs9HJYj2u1ybLp+il9n7EFLFazU6GjPCaYuFSBPYKKXzN7YTrqSszpPug99JpufC8Xfn2K43gVOkuEcqCLpGM'
    'JtvjiLRuyf743u1gvwX8EvfjmX6TH9l8wN6ue/gF4UuwkeEZKmusOE5Y3R7diKMe4bLDicRhlslO98ibq5luAkLrEBSkdY2XTWfr'
    '5f6wbYImcCU9CknEolkyZ4VV8+QH0zpF8aZZMUnWTjpL09KYLjMKwM+vPkt/QEDQaYlZ9M7lEUkgRqDUL5S8CGNEMysOxEuY2x27'
    'KHRUHQCOAZh+OUIYBL1FXdwyzRXMRut0c3Np/cjo6l0X5pP6wvxeRBUZG6/3O25bhxhGunwGsuxHoT0bEXhGxAo936UCCHDGQorg'
    'dKOFLe5XRScWrsPz5npgP2G+L0sW41RbWZ+FUttasQCfubtffeKWDYRe28N5Ln8dEbPH4z56tDU3vIjIT0mV77A45H6PvKhwdAu/'
    'W1/Ar0vci7p30Cg4XoCTFAyPoAbwbrfVd5Xq6Lgev/zTf/7ln/7LL//0/8jBsYXRVJtIHIc1gnLb5sCCB/VKC9TdUkg3qA0pEaUT'
    'd53ZN3YjVQH/KntTYpXVcUkvLtxPOApmxe3j/TAKi/WltNJtXZfji3klVGHMCJGQcxTrZh677o6lE0KdfULoYLKLbeOs5mqUMFXH'
    'Nn9yWo4RNZxrHG28M3jNbVtCn0y9O6uQARUT+9zQg1RigpcgBaZ9xZhQeRUYl7o93GZjjXUhi/kVQVasHaB66p+W5DfN8Nl8xxsS'
    '+YtrW1Flb+MUZD+WS/fhkSv68dF3LNe6I41+eJahRjPuX5se4CYi/Fx6GZyydz1wUFVCZU3xWFvilyVoMV2yFoqdyHJs59liPl7/'
    'x1obGJ4eCWnjeWDcwfXKG9OdoNS0UK401KV8jqtxXgypNm2hFYalRiUIkgp31AjeUSTW6Dknu7EeMIvppIn4UyxfDJRToo4F+RaF'
    '/R/At7jj8jjX4qVEnoN/psPe1uLHwmty8DrfkQTkCL+hpyVZtjKzaw7r1AUbz7hKd623751oHf4YLp7T0TuK4rzJ7RYRwdSRedAW'
    'CjqhiuhjTrLa3s7KsbtLllxgTULB6j636oYXmiMS43YjCLwJuFvz+5NbUuqfgopC5afzOXTShXMl0b5RNY/lMUQ3mBURugj1gzIZ'
    'JHQMU1uU5R22o+6rJh2Y56eq+azsZvqbLiRWkxx+0Pp5OctIjhkrF69xkGw2LCX5aKH0HCaCwEDybs8dzIJSCFzzfttSqM8pWLRS'
    'iwYXZ9e+3FojvUImskTvAFL9VKT9DTztWbiZjQZkgpD3vEdPxyNg6pHuMCCYF6EsEAQSX4Xy7xE7SIl+xDupI1JvzrmAE4u7n4r3'
    '+fFifAUtsrmkXObIGUkCHUQu3XTrwFlhfzBXkPm8esTrfkcRMV0xJwlORTGZLSAFQ9isCya2OhhY4CU8R7DqilQUrF95SVqm2V97'
    'Tbq2eC9GqW39G70bG+cASEfZxWw54UUBUFpTG8HBYMlZSHYZWVU5C35ncOfDjZVRhNj/8zlYpngrToscW0Hdi6lAoYJmOOzrHmTK'
    'V7pYea1z0L5UsgH0PMEOMo93okpaTvElohboR40uf6+nCJ/1o48w/EgVIyPBXYDwS9mfjEJhF6vzyIGstTnTP6gXlvaVdFo3YNLY'
    'il0LLwtnU2Ot+ViOrDKfMunCIVxC9eAO12mxsJAvDQXUJBWgpsJtvtMkutVChLTTs7tc7Qv2j9Bm0VPGHw6j7dFyyUMmrJZusuoS'
    'ZrHi9kvcGIDSzbQJm5yJbnggAxuW3idL7onxUT7vuesZCh4tx+slvQrdVN5OVH+PizhiLNy6QwmDRbe+qe24Rr1V2WWBvSoiI15z'
    'hP2LszOVQwmzGBzuZ9zlNoXZST5UEiVH4MQuzbE8uMznw8rJDBT2KJlri0JNmZ4AN8qtxwKn9pX2ycZQxVo/MhyccKHilZ1Vmzy7'
    'HNyQNEPTHfYVweGa2+YLALcRp23pzjn5TKRdIU8nLwi5ib9eQwUNAVhejk5P9a/XwMHEH18oVKcUKS9ZwSvhLxZLNt5XMB/msGqB'
    'MSuPYWOd9+NNhVWSPlZtV8N2vHcuxrtIOgThPOsGZuozvdd6tk0whvj1C3vNnESuKuYuwso9/eX/+q9YNvu1jr+xayqdARzuI84A'
    'B9Zex2u4DrkPKVof7RI0lGvenY3gPn9Uvu9nxXg8mlXqnqWZcJjKJjeSJt/BqIfP2NLjTRlyxPYyzwRJ+OKyHGS11k33xcWwOV04'
    'RTD3mT9o3GOL0lD9lukumhclZ/5eAGeU61Cnm38z2bT+hcHrnxhPY1N+a/x9bUs6i3Rzi46eDofxjhsBCFa24ugVve+WKbCMglN/'
    'ha7nTrKIdVYRKXSpDgItdE9Gx4g1y6m3A/WTebZB/PLXfwnywtEuiYmue0N66FkZMGAsArYemRL8/aHsblN3m9AMmhST/toODduW'
    'vVHPxOoWtrb0tUjLoJp7Cr1BI48LB7v7FiGQbd22AsFuOXdkr1uXEJi03tIk9ELNABrdpJu5X0NFi3kBrVmORrQWkQa51zLNkSOk'
    '2aoaGaSPSC7PZL3UyhZgLZlSupYn+ntisHley7QmDCDWNURTtY68gNqMtfXralO6Xi0i13aEkROLQFg8HHEo74Lmy0AJaGYMer3T'
    'EtwXve1xpdqlfzGZrmL2fZJtOChUzjsbIQcyvUe7H3NH22RRXbfBJ5g0/nzwABP34AGV8m5e5Pn+PmxvBwdOrCOSXkPo6zvBkOj5'
    'ruxCBVDu0e2M6Pd0/TN32ORTTN+mzSKYyIomRkcRr9QuAtKany7b7pqxCDyqeos0t7+Hg7Y/o4x7+z/sHjzYdUDJzsugcV0LmQp6'
    'lcv8apU6R8Gv/01qm/i4+ArTE7PpTgtc/06kg5UKrzXhsa/8nrSXD08VYwWHFssxwUxTf6/IKBfHcEDC6GobX22HdhWyHrfSF1O0'
    'zEMOf9N4hWYlfNsWATK0uSweJxw5vAaoKXIBvGnhq6wInUVX1FZfPt7F7D+lhOVrB9TfFWJgfe2QxgrxnM4O1TMyUqbiEmqNZaUq'
    '6Q5s60NzMgIkEbiUkjDGzro8B8svzJdeaKoZPdol4TClmBKT0bRvvAMPjPDc5ysIh7FWiEihf1MkKqCzUMY5HthMv6a38boDvfyI'
    'gXzni2hsaSRMbQC619WnPY8mWls9wk/S7+DSmTVWL+H5Up4XeMNIb1Gvro+B0sVwOILLIlQM7jwSspPkC//T42KR1rVjUtsethmG'
    'qo5zDiSyciSluNNNaVYqRpbFEwDC0sIJ2tRsIoynkjUHDN8Lu8HcUU0+WqHKcUkk4hXxQJBuUdqO48oPsl1fdethVPjU20+icJM1'
    'Edr677wJFN/ZnCR5pvJKdXN7ZMkcCGzqYRQBm68cRuzQFuW3QqKRg8RBr6+ZJFBBmk0i8nVLsVl9jghFK88NrXw7skPubx0QRn9v'
    'L8Pv7GYngVzN3KLUN7rS6wCAmzp7UE1/URUrKJTTxCuNcUjR7mQY2iqgbWOVA/m/BpOsh45arPxKg93NCdewCrIRj1i53WpLdBC+'
    'DZhdymmxZ00v6biBANNL9vFoNwAAP94crfIK0O6KpDQsVI2vaHA4RJ3KDdQYPZ6wTkU7qWxjwzP3jlFKHdmN0ZT16Od9VVlouLPe'
    '76hUvxaOZ6xITTe36TJajXCqRKxi+y4qXkagUzj6aPuTZlvOdr2vRG4cD5Rb5Z+XjOPhnz7ZiAGttljJibyW6zS0u3IdUbvUvqG/'
    'mRaMXggyY4WbSS46X5dsIuw/51hoilb6UtEZ92KKvU9FZs07pZ8dn5Xg+2X/fR17g/WVjc7v5JuzQpM2WkTWDyoJzGzA7TnIwhHh'
    '3eQ0nGq6CscuDHUVOadPVfCtWkG/XYl2ZwdfVZ0VjrISpev3BfOytK7fU+pQwpc82ifjEuolu/1EhOlH6sExV0T5dpAVXruwtACu'
    'ACDfsIfQvfD2Rf2i1jBW0hGKih6k8HZYvoj+wq3ZUowg4XoOImRMwcydIfscVrM8TujUdrNTunKWs7tyVKMKozOP7aWuAZRfgnU3'
    'XbfbzR+3qP8T/QubCluVTlgapBHctVRaUSG3jCisl4qvRP6mLkzzMOgJPpOCV3KZHrWZnX37z9/PKHarvq6p2kWDGE5k66be7WK2'
    'ykRs44pdyyxmKmTOdt5IJmJFWu/TsnTYLz9f8GqWxok3frsCGXO1zZPY9DvgOwboNTXM/1jCBk3vg2ntnI6WKYXvX/uADmrSzKMR'
    'c/Znqc4L+9XxvLT5hXDiGNyAo8NYEDj8hYJWB5dSnbP6wajcqACfdG68p5OasZevu+5LDCyVkbechg8OUXPn2a2ijnMWC2ZfvyLt'
    'm8Bw2qeRVdzf9ZEWRyeHThW+1rpBv060WeaJJmzh3zft8m+09Bir7gfM0HCJzM142fyo6iq6fbZpjcmfG0gbtpttDbZ+g6ubJc+u'
    'ZuWia9j5G67s+35mWPn+0VWPWZt7rvkgtbd6cEcBUsleFIYDNKuzio2lSo0XsPcVJ8w/A7CIXCNb6LtplaMb1ojeLwDQQsyn4wup'
    'kvLoBma4Yj9Xulev2BLfm2E+d9XkMXqCxjQpIgKaAwdDtpmIyK23eaLWugd+TAHZ6jJU/k7J+HLd/JGUKWLlPB88rZYefT1Bic0C'
    'X9SV5q/dkVLyl/hd0s1DvrOAU10FDlpJ4ZXZs0mANUBZIwRACAj672K7oim/f23APIemC9auIoKxNZBAN4ci0aeR9nl1bnoWbBZF'
    'd1brgSIPQzyPx1PV+10V+Ry2wCu33I5VIzA8FYsZrEFg+DwOhos42aabFYI/vZp5VLWHjgDg9LC21QjNwSC0UaWm8QDOMaqWoHPk'
    '2tQQWmuPs8LG4dkFeKeKO4lY12PCy1X5iTNs3rRv+j/Rxw410RPCTWfrcNgLP33OdnGHaw9VNi+150ym2eBg9PHdGRgtn6jkikJl'
    'U9dXqg6cH5dFTLYYPbndv335e2dZMHXcwmKoP/3Xf84q2sSw1dWUJNsrn5+HowsHIdXQLpDYyBxc4qswNW5K56RNCzlRfhbH7ntY'
    'cr3HWRdHjB5nvy9LKIM/L4+ZBKrXz7zFAAI88Zw0AIW94P4PLn8qlDp/vxbrZxpjAo9HtZ2PvFO/Kf3lop4dlfl82A94vrTK3WEz'
    '0A2jCIvcdHmTIQmnMCxWk0ShHksvG09Z8tmM5QzFVWpmSHl1MSVXMynLaUR31N2FOc0WlwB01VWmEcd1yhEFZXjMmUfZDhUD5d45'
    'uZM3wYIDqA/fYaaCflXFYm3ZAOlpHfjee9lTxuKZqyBd9ybIBz1v2+k1g5eZtZzbSiMKxN5XGvGhI/dedxSr6TSkGdTBFda3eTit'
    'r4FMfiy7qknuDfGDFJ9mQJP7hRHjXtOEUPLt8trbo9Fc6NMiiRnkldXmAuActSzJbzshjBxj1L49t4tw6rUWVLDrZTQuF/R1OSly'
    'dbp1wlC8TaDr1H2OLXEQR3KjtTfW8Qjw8155/qZ8Zdav3p3jdRN0OL1Uwq+g31yRqvBonE/PNYHeWGGbmin9Quzo8ix7IawU8yQj'
    'ROx2dyvNhBS/GsVh1vTZfBKCSvdHPkcWA94114OC8DikKHlhzxnMyiB74a77rIwK7Ok2V/V1sYAiWM+u5VLhhwpcqWA5K4AVfLR+'
    'PzPk/lGvDqRCJBNpF0Rh2Auh5AqPjOdY+L0Beh3l5TqZoNdnqjFQEW9Ryr9/gNb7DJA/Zw5LZYEkK0swC+XdM6RdbECmsGlq3oVU'
    'um2HnTGjxzz4GSwGUiICn+cGO/v+tV8Gp3USmeTmUAroED0UgtSJG01/9UiGQ/YS6ZNiWilUkKoln2Tdh1tb2YNsJCJPt62dHiGC'
    '/qETVfMG5LR9aKS0cVHFjfHZwzFRk4V229C/otKfA5S018x15buf5l4Z8erZiko8fy+8Qa29eMoPHxsFY9olOUVP1oykrCnvY7+E'
    'XWC53WZ5YObHfq6+6KGH37boeo0Yt5695ERYcphXxc8XI7goVsRTUHDIgGGxrVAqJbBtL6YItKs0upnqE3pTVzw9UOnZ0hNgQcM5'
    'ACI3JRTA8q33B0+AiSe+nTU20mvpC17YJANy/KsCF+NpSaBxDmjHNRVh6N27x7oYgg0DdFKz/8DhZ6dfI1tCGYaZH5XKOB/nczqP'
    'dfwc87tmigcHod/PQi/qyVmR8/Ak4Ff+fCE3oeosyvnT8bjbGch6bZyKOMi0nOMWtLRQ4P+v7Wp6mwaC6D2/wkVCiUVqQEIIEWgO'
    'leBStagUcWhzSElSRdCkihtVAfHf2fdmZj/sdUUOPcWxveu1d+djZ3bfG8W6RlwovHX8l/tydQtBuU9Doko8q3PSHDLjpG3RO5Re'
    'rBKUnXEH6vb4kboUy1TWOjCuCKt1CIf4vTpv2zvJx3L8Kzyfq+HEDVi2PbU1VBxA5gw2FjYCK4md4eBwAYwF/oSui+yuv4DgTaS4'
    'raZQipeaRfmAoFKUySoIqOge2uG0J4yIoiFOl/1T57YcAG4CRXnwGSuO73n4Zb5ZuOIH/cklnr4snhdvJlJ7p8k4zeI9ekFL72qj'
    'VjZqMYD6TNlGr5vQPLmgKCU5ugHfxLqGth8aqsmo9Cc4HKKGlmXqssBGcpdE8frtK/FtYpolHXKkYRIAm+9EAZl6Lepj0JYHkyW9'
    'Cn1k3Djkiqg57b/ZzHeCZCDhfFPdjK8KO0VPMYC9O+xvepjCb9O1Q5w1V8XgG7foEQ8CB78eEKojPGkZQXscn51enJ+dfCURnpsX'
    'MhsCuRsW+leyLP7vcnWH0LGFDuP1AaNEKIO4Rv4fKcgvIwUkXlzFKNkQc0Q0G5tCzl2r+xNLjslMjPHWVO9VSNkNPJ3aHqMsfvsG'
    'uT2jEh9zGk/V11RgxmrDY5C1f37fRtBe7OahX6mvJ/2NAeFIK3IjAXuU5rOoNRJKYHNgnbpVLUYXc4p9aSzBmnKFGopo/VNVvKIw'
    'oy+oAIJpB1VF+BquAM4M+J0AFIGEeJcpuJXRgUIsxdcZtY2OmVqI9nqxgKnVlgiaW6zznceUmVvtNYOwOU+kHJrAacPinbKs7a28'
    '8AKP6S5e7/D4E5jdJ9KYmVmQ3JhOhNLZjyIRmr5vA8U20GErsJ0aP6y3pBhPZkTTjhwlSljMmypiw80zb/3/n92u8rBV5THGdQaF'
    'L4yrKhEF1ymL5eZ24DzXqeIAmFIeX62uVoStwVlmG0EvAr2MRbxuUK4M3SjaX2Z4PRKT9xg/HrhnnMHreYaeTj5fL34nmbK0vlMC'
    'f9XFG+uqjWhjD64TTvf0kcrJ6DljASvAwJ3OeJwWgsBfrKU3SODkpjqawh7kWcble7RwCT+RHnyzhZBo0r+QtFMzCr9DwFEXJ8UW'
    'U2ETIEyI+nA5gQX+CeFnpJHBixJJic7n0Veb6H5kPxTsvOz9Jl7ZQES2sjbSYw+fnuGEsiCyuTsS4m981xhSu05pAB9pkUorF2vX'
    '1QrcTqVGkGRpK3Ck67QZuDwehxAT24XcmXsfhLPqauo6ADsQS67B+D2HzlLOZDhWjPf6wO+wMDplCTVRhJHGHCgI72ZeOz14Ealx'
    'edf4fPYVO/Qamus7mD023WKZwQzpRYTBymY4b9TzhNHhobYDKFcDToag1wtfaJI6nuGCeRo2Q402MTPa6gxIaAMTdF2PPZgtN/e7'
    'kuTsTliC5PHJFtX7K4+7nt9wrVwDNnu7AgiopyjZaraX6bBoGs0URi+iGB71Prysf2yWd/dH7uh6PdvhF0wHR71/8nRS1g=='
)
EMBEDDED_ICON = (
    'eNqNU02PmzAQve+vmHoPDVIx32RZQQ5VpZ5yqtQ7AQPuGhsZZ0n+fccmVN10Vyqy8MybN7w3Bsr5tYfLKORckcGY6TkIlmWhS0KV'
    '7oM4DMMAGQReOVu+qktFQgghT3GRwwNA+cn34cfEW6bhG697XY9QTxPwRslnMAMDLn0LCNUr2DnAd/F8HU9KYBlXyy50MKPwbLoM'
    '3DBQ0nVj6+cZddx1Emf2BeahbrnsodNqdJy21i/+qFpkNw2TBnaPafPUdp0HRjmG4P1g7ihxlifs5FHwfTdIy7r54JRKwSWr9XeN'
    'OpbL24oYLhiBS4TzE7iu2yVeM9wicriZLGejJlBdNzPjyjb3GyWUrsjNFwneZ0d37NXixi6Dt76c62CzXWrWGMD3E6Mjd194a4aK'
    '5OhhYPYA1lgjJ0oJdFyIipy12D3a4bxVpuzB6FrOndIjTm1DURu2i2KIYpp5MDe1wJTmeb73tqdIJZn1rtULQ98djnjL/JuLmEZ/'
    'IDtGU08V0eos2zfwL8Xlht+mbrhuBIPG2sapmuu64/kkaPm9ckIzV0eTd4w4XBnFX/V/Vfa23+kUHz4p/w9O+pHYVJsB8KM64qkW'
    'PzMaHaOUPkEU0kIkdO9HNDlGiUVSmooYA0yOWI5XxN+gwiLYBRnNoNgUyqA/PJT2tz08/AZluheo'
)
EMBEDDED_ICO = (
    'eNrtnWmUVNW1x6+S92K+EKN8yIeHl7WQsUERUeZu5qkB814n0ZWlGYAGGhxBGbqBAnpg6AbtRuNsgiZxwsREEkTRICgEYxBDHAAp'
    'KiAaoAfornnab//3ufdWVVdVd1V1lQxJrfWjDufss8/et27fuueevU9p2mXaf2mjRmn83k3rPUbTfqhp2oAB6v8v9NC0FVzXrZvx'
    '/ys1redcTfvud9X/135L0/Yv0bQrr1T/n/sN7r9a03qzDlaprdRUvby4YsLtinRfp2Zdq52Z2ePiYMa1WrZeZ2b1ZN97yrtQ3Iv1'
    '97iCx+nCdGW6nWe6GrZcIbaZds5U5UxfjbN7a/WzejA9BdZ1NVN4ZlaPah5rO3OQsTOO84zdsGW72CY29rzatBs0FPdOy/d6Po4W'
    's3p+hylh9rFeD0MXMmynF7YaNl8V7UtKvuNzB3N6o88w5k0mxNBFBmzeIT7M6WP51darYY6SoXn/w++9buW+xy9Cv1tzHL7QT/5b'
    'a2Df4GNC3+f2NfzvA7lb+TjUM3SJUK986qM1so+N7Gti//uAYcxxhi4xjhu+afVz+8T6XtJX+T+3z1XMDoYuUd5kviO+lkTOgTMl'
    'vcR/Pi9K+D3E0CVKyPBRO12i7g3q77xOayzJA1c3lvTdx9ClTd4+5Wsef+59tab5/bTGeXmgkPEydInjMXwV35vmwX95r2bo34T1'
    '8LkR/s/vD67gY7GdoazA51kTX2+aSvqockf0QMfcDuqJZ7vhs9Z0Z3/QhTnIUIfg8+vsgpup5aGfkev5VeR6toyaK/+Xmu66To2b'
    'qh7Ich/0hQ7ogk7oxhgdtlP52kX5fh3oytgZygjDv+ZVheTf/waFvW5SrzCFzp4mz9aHle0ydnv6+oss+qAvdIgmr0t0Ywzz+HTA'
    '3qNMV0Y7q9AZB0OZ0Z/OLRpBgX+8QwlfoRB5frchZX2eVzdIn0QvjIGxMGbm9oqvuvh+9/VAZxwMZcSd/cj1zP1sc8CyM+zjcyDo'
    'jxyCUw5qXjFRjZ9MD85520SRtV6sQ3RZigIyFsbM2F7lqy6+3zMA6IyDoYxgu707non43tJIrifvJe/rT0TOX7+XnJtmsd39k+vh'
    'NshA1vz78b7+uOiCTvOFseQ4Zmqv8hU+a+cUOuNgKCPuhv+/iPX/Kfb/jadi/Hc9XEzn8LeSTA+3QSbGf9YBXbH+/0LGzNhe5asu'
    'vt97A9AZB0MZwba4f7mo1fnv4XM38v/Qv+zUsnKSGj+ZHm6DTOjUsajzP6B0RZ3/GEv8z9Re5asuvt83EOjN9w10MJQJ0NlcWkCB'
    'j3dRslfw2AFqLhvFsgPa0DNAZCCb7IUxMJaMmaG98BU+w/dmRYf8F9geZ+UtFDiwI/Z6FfUd4N32KDUvuDG5Dm6DTKJrP3QGPtoh'
    'YzR3zHcyfNXF9wU3Ap1xiG0d4b4bqGXJcHI9Mps8L1WQ97WHKHz2VMQHdzO5+W+5Wc6BG9R7VBltkLHkua/3tVrRBZ0tS0Yo2Y7a'
    'qXzVxfeFg4DOOFoWDqKOYh4H0y/vljWx34NfHiZXzW3kXFdE7sdKBJRRFzp5OOZ7z/vK2hhd0J0VG9lXw2etRaG3ZMn/WNjeJcPI'
    'v+/V2D+F+i8ofO4M/zH7BJRRF/3y7/u99BUdWbdLfNXF9/tvAjrjYCjrsP3OiqkUdPydUn0F/3mQ+0xTvufCJuWrLr4/cDPQGQdD'
    'OeH+QeTf+WzCa2Kia51/53PSJ2f2KF/hs+ZcJOiMg6Gsw364q39A4YaTUQ56KfDBVvL+qlRAmax7HhJZ9EHfnNikfNWV74MBlwdz'
    '3WDKOuyD77UHYz5z3/bHybl0OLfdqOAy6qLPBd8fHjT8H5wLHIbPmnPxEKAzDoYyw9CL99b1S4ZSYP+2mPtAV8UU9TmYclxGHdqs'
    '+xzug74JdSYcKy0chs+aa4mgMw6G0oJ1uWB72Uhyr5pIrhWjuW5whEU3kYs/2+Cn70WubYf3ibz0jdbDdWiz5LgP+oqOaJ08howF'
    'HRh7cZo2KxyGz+z7UMDloVw3lFKH9SwvIN8LK9nWd/l7/QiF+L7V/+aT5F4znVy2seR5bC75/7yZws31UfPgY+Sumqp8MXVxGXXR'
    '9/3og2smdLhZF3RCN8bAWBgTY8MG5VM6touvuvi+dBjQ3UuHOhhKmWX54lv0vY3l4xefsp0fUtjrjL/mh0Pkf+MJcpeNYL9vFlBG'
    'HdrixFmH+Mw6478o/WIDbEnLdvYVPsN3d6mgMw6GUoKPt2/zA3zN9lBGL+4X5Gu+7/nlQlCu/5nrgi2wKWX7la+68n044PJwrhtO'
    'KVE2nALv/z5ig9dFwYNvUbj+RLx93IZzIfj3Hep+r9W5EPeZswxk0Qd9484HHgNjRbfBFtiUsv3KV118LxsBdO7v8LCOlFhRQMHP'
    '3o2c78f/QZ7VEyjw51/G+rF3C/menC9tHttoCrz1NH+xuZN/lpjjvf0My46RPugLHdHHDWOgDWNGrpXvik2p2g9flc8jNM8yQWcc'
    'DKVK8K9tf/7hM/8k79rp5Fk6JOa4+X61hEKH9sSe71wOHdorbTF+cF/ogK62Pn/Yko7thq+6+L58JNAZB0MpUTaMbV3c5t9scM/L'
    'LJvPY0X1w9jc11MxkUJH/xY5f7jsqZik2iBjyY8UHdDV5t8/2yJ9U7Vf+aor3/NBev4z3pVjKPjOc4mv/+yPd8MPYn2J6TtaPm9L'
    '/vBeqUs4FuuArtDRDxJe/4O7nhNb0rFd+Qqf8zXvCkFnHAylDPxYPY78W8rlfA5/9TmFHB/J36+vpojbRyTv29r/Q8r/5GONYJ3/'
    'J7oxhox16D0K8NiwQWxJx3blqy6+2wqAzjgYSgvDNrFh7TTyVk7iupGKpH1Gkq/2RxT+8lDkb5rLqGuvn4yHMTCW+G0c43TtVr7q'
    'hu+Z+x9DfkrHy//EXPb3cPz32leHpS01f/KpY7ZG/PetHAV0xsFQzuBxfeum8ff6/qSXMrRBRmRzaYvyVRffV40GOuNgKGfwZxb4'
    'NX9nBPxR32XHhciXu19kIJtTW5SvuuG7+O/nOoZyBXwK/vHB2HudzfcJ0fdEkIFsLm3xR/nvXz0G6IyDoZyxku8ZXymP3O+GghQ6'
    'sJ1CH22Xsnk/DBnI5tQW5asuvpePBTrjYChnrOb734dvp3DjyaR//2iDDGRzaovyVTd8B10DFWPtDOWMckVw64bEcwCuQ5spl1Nb'
    'KsYe9VeM7cpogYpxoAtzkKHcwmNXTeBzfDWFHTy/a6kXUEYd2pR9ubZDfO0ivleOB1cw2xnKPcZxqJ5GwZ//REBZ6tD2tdggvsJn'
    'LVg5QQtW8TGoGl/N0NeG2DHW4GscV1EtPrPvcgyqcAwmTGW8QZyflzbwsRA+K9/HasE1E8DVwTUT9zF0aTNhn/KVfV47VmKAQ1XT'
    'tNDaifz/iSX8HmLoEiVk+KiFKgut+O/gmknsv3AVs4OhSxT2beJV8lmvmRiTAxDi/4fWTQLDmBMMXWIcN3yTc731K7R+Avs+WQtX'
    'c/v6ybeG10+uZ+gSoV58gm/sY2jdxIQ5QOL/+sna+7Zifp/C8lOOM3SRcwK+PL9mpvgGH9t6QUaQc2HKMGYHE7oI/Q4Ztg8LG58r'
    'SOXFfSLUFF7FlDD7qKbQy9AFjhe2MvPE9ihf0nkZvluw3quZQqqZWk0bpm5nDjJHmWPnmaOGLdvFtprCqbA12vZwdWHGecCsU6MN'
    't8B/xfopGm2cdgWP14Xpylxznulq2HIF8Wdm2blhqrxn60UPsr6NYJrSfSFTMz11v3bi305Exn+D6r3Aq971s+r92w71/s2d6r2T'
    '+b5SvV9mvmv/eeX01fp4t/48zM/J/NzMz9H8XM3P2fzckQ08gPlp9D4R16a+T4TabwB7DZzH/R5kX4aeae130FDcSzt1u672BxAf'
    'ZA+FfKaYKWVsOabUGCuf7e7SYOxVcPoOvd1c/frZMfsTdGXKWMd+xnke9hzAmPthA3ON2DRbkfC4IwedOTm7G+yfznx4AeXKH4BN'
    'X87pxjb2Ejtj9weQ3HitZWZ37BMwg2m4AHPdYdNMZ/G1ks/fOCeS6910zyAzx30608DtdGEC28RG7dRdA9V+JCV5Ro5632sa5vY5'
    'cBHkmn/ItnaVvHLkV6v8ci73LbuI8qVhK9udZ+ZId2H2sz90UQBblc2S58zkM86McoaNYyL5pyn3y1N9pF9GecrOpvlis5mnXMxQ'
    'WsDeu66nc8vG0znbZDp77yBVl0I/yKIP+kJHSv3iKRbbVZ5taVp5qvP70bmyseR953kK1Z+gUNO/yP/R29S87lYjnzh5P8hAFn3Q'
    'Fzqgq81+iYHNRp7s9TaGUuM6OnvfIPLt/V182I7jIDUvG6dyIVv347rm5eNEJm6JjHVBp8phTdUO2GzludpSzhG9qz+1rCmy8g6D'
    'Jz6lAOKYw2HBtXlJ4hxU5MJuXmrJoQ/6qrzIBtEpubup56rCZjNP05ZyjiMfI+eDd0jetBy797aQ57frrbVmz8tViXMxuc7z8hpr'
    'jRp90NfMwYZO6E4j19IWlWdpSzlHkfvKeWDmRAX8FDbi7cSOTTMT50ByHdpMv6WPEXMRPHlIdLaZgxkPbDbzBG3p5gS6Ny9WuU6t'
    'Ylw9L6wy8rpa9xkgba1jZaEDujLI/bNF5fnZMsmXc/Fn7v3TI+R/9yUKO5vUqdH4JdffTs33XMc2Xa/gsmvj7RRq+FLZzLLog77Q'
    'kWGuHmw289RsGeW7IXcOuYnIr3yt1vobQL6B+6l7yLOlSkDZykFAvibLtpj5fOifWa6ZTeWZSa6ZrWO5ZIPIWZpPgf2vx5xL0fFD'
    'VvHD7SIrNnQsV8wmtj8guWI2fqfMuZmP50ByPz4vNkcWedLB2L0DIANZla/VoTFhs5nnZet47tRg8u/6jWFomIIfv0OeXy4UUJbr'
    'PsJyWUblGnU4V8smti9GrtJgm8r7SYGYsc26m8m1ehKF/nXUilt3lU+x8rBQNuPKIQNZlaeURF9qwGbNhVyjxUNskq/TFpIPNFje'
    '3SvHC1IH29lGd80PrXyawJ4tqt7M6+Ey6sz8GciijykTo88Yo117lM2aaylyZYbaGGoTjFM5lfzvPEehk58JyGf01P2EfC/Y1Dli'
    'nOvBQ3vJtXxUJLeJy0EzLphlIIscH/SFDksf68YYYn979iibNTdyXZYOszGUnKHkto2m4Ievx8dmuc5G4tSirj3+t54hT/X3BZTj'
    'cjy4j/RtfQ/IY2AslY/Tlk1is5mnYmszrwP5Ao/P5Zsdl3UOR+fUqe+kRgp9/oG8mzF3yDOXPHUjNi9OJip3z/zbwRgYC2O2k2sC'
    'mzVPGRhhYygZ0OX7dallR+CNxwVzL4zgX14h76Yfk2flGPI9vyxhvg3q/NwGGciij7kHR4w+HgNjuSU/Y0Rb2MR2lSdiazOvomwY'
    'eR/+qXXckMtv5vOjTmzHeCI7nLwbb6NgVB4R8ji8D96mcj8gg8+T+yTVx2NZORPJsUXledjazQ2wFUicfUxeA5dVXk5BrGzpEDnW'
    'Ko8pTP4XlktdxvoSA5vNPAVb+7H9Rl7CS3yt+dtWAWWJl1/RKk+Aj53/RZs1VxE5fIaZ6kuMLSrPwJZyjDpi+xOVo2LpkTMguURW'
    'HsUeI48gP319ybFFxcnbshYLv6ZQ8l7iYuC5Dm1ZjIG3RcW527IWy464bSNnPXz8oGDltnNbFmPYbVFx2rZsxWIHXlwemQfselYw'
    'v6/QlsUYbJuKsxZsDHUYxFL/nK+z505H5gDG9y7q0KZiqLMwVvlY2KwFJFZ4bGn2YpDHUej1OiJPS+Tk5zLqrFjh7FAqtlci1ndc'
    'sYqxzQKwEfGUzy2gEJ87AGUVw5ylMRTFynaJUy4IVI13ZjUGt/Xxym4srpP15fO7GWPbhdkfXDOBLgpgq7IZsaGaETdYdhHFu5Yh'
    'rjO4VuJ7xX7mGq47cBHEah5Qtk4U2/HyL883YzSnMw2hdZPpAqXBsJGv+flR8YUSW6n51k9DLNpMpuECjJWETTN9NbeIrbA5Nk5U'
    'xdERt4erp0xnDlxAMX+wZTpVfw/xm2JrCvF91zBlVFO4n3Geh3g9jLkfNogtKcbroT1Y9z2JbwtJzJfEgBUwxUwpsyLHlBpjFWDs'
    'kBknWHdLWvF2Kl5tihFnFx3DlWPixipsM15O4od0TZO4om9rmsQZfVPTVBiREZf0n+iv9OK4Lou8m8fRPK7mcTaPOyJRuhm/6WPF'
    'aV2ZPE4rKj5Ia8Tvwszs0ZnRmWs7CHR0bjB0J/ptkZjfEJnVM4+pODOr527mCHOsg0DHLugU3cZvdpi/7dFg/tZHca9OzAzGkcN4'
    'IUf9bB5jdq9O6rc11NiNKsZmBte1MJRT5vAYGEvG7G3GyOQxjq/xdwUcjWpMTeJFSvIqzkO8RwXia5rm9+vM7G5z/3PEMSAmA/tx'
    'm7EZcTL9Wsnktben+i4Z+87+OnMk+d7m/ensohHk+f1D5P/bNtnbHGv6reVQhzbIQBZ9JJ4i+Z7mh5vuvA57Ondn7InX9FVcgnfb'
    'Y+qZKJ5fBPzkfm5Z7Fo+l1En62nyjCMsfay4g8Tr9Biz+7l7BgB70vXwBTdR4LO9FHafI9/uF+V5g2/3C3SOdUT2U75e6lTbiyKL'
    'Pujbxjq7Xca+9wZgb2tNG3tK43mfuZ7u/eMjsWvp2M+Z66z1c2Mf6nbWyTFm9+YFNwJ78j1iB1JL2Wjybt1EgY/fkbW+4IlPyFk+'
    '1doPFuXg8U/Unrcf7xJZ9DH3yE0CxuzesnAQsLe5Jot9VLG2uGgI+d54UsVpfPIu+Xb+Sgh8slvq0AYZkW1/71W7jH3/TcCe8nru'
    'ygkU+uIz69mT+UwKdWhLY/0WY3Z3LhoM7Mn3PryZnA9E7U350B1qveOrz8nzi4UCyqhDm7UH5QNRa3+JwZjdXYuHAHvCtTSswy0r'
    'IPfqSeRaOkzWHH0vV6jllK215Fw4UEBZ6rhN1iWxDoQ+3Nfa8y8eu4y9dCiwJ1qX89T9WPYVDJ12UGDvK+Tf8ZS1515g36vkXl4g'
    'BIz9atEGGciiD/pCR5J1N4zZ3V06nBlmj9tzjfUGD76t1sOi9gINN30lyHrfoT2C7Plt1kftCYq+0CF2xu/pZsfYnmUjgD12XWY4'
    'eVaPl7VdxDOZ63vB/dvIW11E3kdmUOiz96z92FD2/nyGtAWNvSvRB33VXmfjI2s0Eewy9vKRwJ5oLSOw7eHIc8rGL8n32GzylA5V'
    'a0HY54uPN/Cum670c5vvsWKRNZ9zQkeSdRKM2d27Ih/YE65FYB3j10so8Kc68j06K2YvJ9+G71v7saAcvacSZNEHfdW6R8J1DozZ'
    '3bdyFLAnfe6P/Y9WjGDyI3VVkyn00RuRNYCP3pQ6aw0AstJnZFvrAnYZe9VoYE/9WT6f70/Nk33Ewic+FlBGnYyV+nN6jNndv3oM'
    'sKf8fHzVKAo8OoPI2STPruWZNpdRh7Y0nrNjzO6BinE6cyStPSkq+Rr8+iY+z74QUEZdmntR8Jhj9UDl+M7M7rT3hKgaT8G62wT1'
    'bDbtvSAwZuegel5WmdnzzvGKzJ6XViCn2sijz+N3x9eY146xMKY8mwqqZ4QzQusntzCUY1owVnCdypnF8zLJNa2e0omZwThy+LzL'
    'YYzRKRz1rC4mh7emMI+poJrC3cwRxt5BoGM366wU3eLvlLjc2qjna1qoejKes3RmdKZ7B4GOzsHqyUZuZ+yzsp0qJ++y8/A8A7lo'
    'nTAL/66RU2Y9p/hW/HMKY44unJlxbaczs3r0PjOzRyHz/TQplL6sw3rmgbn4XJWrw//Xmbr64p7H6mf1dDGeNHFxX4fS0UtvMHWr'
    'OT7+vzOL8/mdopN1N87L68Tz6bpsz9V5jlwH3Y3z+vVmHAl/I25uH6a3ek+nTeh3jOnF89FCxpVortpS/SPy8PyqpW6W9ZtX5m9j'
    'oU7aWCbJPBc6C3muWcR44n4/adlYNXfCbyqcOU7Nld9TcfaIq+cy6tAGGcgm+D0m6CziuRzwxMZWX08tqwvltxqwBzXie50b71Bz'
    'R8Rdb7xD6mQvbJaBrMxrY+eJ0FnEczngiYtX5vmO5zcrKHjkrxLr43mpkud2qg1l1KENMs0S2xsX7wydRTxvAp6k878lw8n39maJ'
    '+8JvtsjvtnAZdWhrY74HnUU8HwIemRfFcJPQwvMYzxN3yv7VwSPvCyijDm2mXHx/0VnEcxngiZ3jDCaXbZzsLY65GOLtcKxdqyYI'
    'KKNO4jxZRmQltjBmnuQR3UuHAk/0/Mj72BzZX1T2Mf1gq8RQym+wPDFPkDg5rkObKYc+reZD0FnkLhsOPG6137DMURDrJfOaxpMq'
    'TuGtpymE48JzTZmDchl1ch8IGZZFH5nfmHqUziK+1weeyJ68w8n/hxqJNQQoIxbLW8Xn6+d/FVCWmC2Ra4rIYa4RmUdAZ5HXVgA8'
    'MXudYv7w7ELBjH/yrZkqe1UDlK14qRi5mHgk6Czie3XgiZ8j5CuMuUHw7aeJED/JoGzd/0fLxQKdRXwvDDxt33uPptC+V3heVy+g'
    'LPsjtn2fDZ1FfL9byLjavCcuH8P38T+j8N/fFFCWurbvo6GzkO9DezOOdvez4vtka70b5Xb3v4JO6J7Qie9TN2X7XpR11kG3sU6t'
    '8/3hzizea+4UneuM/ZrUfabO1IWrCx18P+RiPGnikr7VUzZBl6z5GvfR5r0VbZzWiWqm9ub7rkKmKE0KpS/rsO4JU9yHpSOv3mp5'
    'SO7ArPuwbyS+D+N7p8v5PqfgzKye5UwdU5sEtJWLLPqoNY/L+b7lbi6fTiNH+TT68H3U5Y0leQWNJX1PWzmnuE+Z3Ysa5/SO5KEi'
    'Jxh1c2NyU0+jb9P8/uWRXMN+dHbBYHI+Op/OrZ5mPZtHGXVoU3VWbmI5f9fXxuSuPb2QQnyd97//Gn9XDxRQRh3aWuW81fJ3bW10'
    '7pKz+jZ5lhr8/ANqWTlRQDnw6bvS1irnqbbl/ptq434vqTSf/Hu2UNC+X0BZ5bLE/R5SrXPx4NpIrsEQ9V24rIACf/kt+f64SUBZ'
    'nh1ym/UbKopa99JhtRJnvmQweZ+cTyGMefgv8gw0sOdlAWWp4zbIQNaITa/1LBtRK8+/+DvK//xy+d7CszJv7e0U5GsekDKen3Eb'
    'ZCBrPDOr5e+CWvO7wVc+nvxPlpBv/S38vcH3cR9uE1BGnbSxTNR3SS1fi2sj1+bRKm4RPMz3YqfsAspW/eqY63ttoHJcecLYtjWT'
    'KPRqlYBykpi2cp73F/C193TC+KOqcYrEsUmn0ZevZZfzNeduviacTiNG5TT68DXwcolF2Tjtcr6OFfC8tJypbYdykUWfLFyH/h+V'
    'j56/'
)    # Windows icon (icon.ico)
VERSION = '2026.11.11.1013'        # build.py stamps each build with its date and time, e.g. 2026.10.19.1534
UPDATE_URL = 'https://raw.githubusercontent.com/WMBanner/spider-diagram/main/dist/'        # build.py: where published builds live (a folder holding version.json); '' = no updates
PORT = int(os.environ.get('SPIDER_DIAGRAM_PORT') or 47615)   # fixed, so the browser's autosave survives restarts
TOKEN = secrets.token_urlsafe(24)  # only pages served by us know it, so other sites can't use the API
IDLE_EXIT = 120
DIAGRAM_SUFFIXES = {'.spider', '.json'}
SYSTEM = platform.system()   # 'Linux', 'Darwin' (macOS) or 'Windows'
DIAGRAM_FILTERS = [('Spider diagrams', ['*.spider', '*.json']), ('All files', ['*'])]
EXPORT_FILTERS = {  # kind -> (file-dialog filters, default extension)
    'png': ([('PNG images', ['*.png'])], '.png'),
    'md': ([('Markdown', ['*.md'])], '.md'),
    'txt': ([('Text files', ['*.txt'])], '.txt'),
    'docx': ([('Word documents', ['*.docx'])], '.docx'),
    'zip': ([('Zip archives', ['*.zip'])], '.zip'),
}

def config_dir():
    if SYSTEM == 'Windows':
        return Path(os.environ.get('APPDATA') or Path.home() / 'AppData' / 'Roaming') / 'Spider Diagram'
    return Path(os.environ.get('XDG_CONFIG_HOME') or Path.home() / '.config') / 'spider-diagram'


def documents_dir():
    """The user's Documents folder. On Windows, ask the system: it's often redirected into OneDrive."""
    if SYSTEM == 'Windows':
        try:
            import ctypes
            from ctypes import wintypes

            class GUID(ctypes.Structure):
                _fields_ = [('a', wintypes.DWORD), ('b', wintypes.WORD), ('c', wintypes.WORD), ('d', ctypes.c_ubyte * 8)]
            documents = GUID(0xFDD39AD0, 0x238F, 0x46AF, (ctypes.c_ubyte * 8)(0xAD, 0xB4, 0x6C, 0x85, 0x48, 0x03, 0x69, 0xC7))
            found = ctypes.c_wchar_p()
            if ctypes.windll.shell32.SHGetKnownFolderPath(ctypes.byref(documents), 0, None, ctypes.byref(found)) == 0:
                path = Path(found.value)
                ctypes.windll.ole32.CoTaskMemFree(found)
                if path.is_dir():
                    return path
        except Exception:
            pass
    docs = Path.home() / 'Documents'
    return docs if docs.is_dir() else Path.home()


CONFIG = config_dir() / 'library.json'
SKIP_DIRS = {'node_modules', '__pycache__', 'venv', 'site-packages', 'Trash'}
MAX_DEPTH, MAX_FILES = 6, 3000

last_seen = time.time()
live, closed_at = 0, None   # tabs connected right now, and when the last one went
lock = threading.Lock()
summaries = {}   # path -> ((mtime, size), summary): files are only re-read when they change
last_dir = documents_dir()


def applescript(text):
    return '"' + str(text).replace('\\', '\\\\').replace('"', '\\"') + '"'


def pick(mode, title, start_dir, suggested='', filters=None):
    """A native file chooser. mode: 'open', 'save' or 'folder'. Returns a path string, or None if cancelled."""
    start_dir, filters = str(start_dir), filters or []
    if SYSTEM == 'Darwin':
        where = f'default location (POSIX file {applescript(start_dir)})'
        ask = {'open': f'choose file with prompt {applescript(title)} {where}',
               'save': f'choose file name with prompt {applescript(title)} default name {applescript(suggested)} {where}',
               'folder': f'choose folder with prompt {applescript(title)} {where}'}[mode]
        # 'activate' brings the dialog in front of the browser; cancelling exits non-zero.
        r = subprocess.run(['osascript', '-e', 'activate', '-e', f'POSIX path of ({ask})'], capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else None
    if SYSTEM != 'Windows' and shutil.which('zenity'):
        args = ['zenity', '--file-selection', f'--title={title}']
        if mode == 'folder':
            args += ['--directory', f'--filename={start_dir}/']
        elif mode == 'save':
            args += ['--save', f'--filename={Path(start_dir) / suggested}']
        else:
            args.append(f'--filename={start_dir}/')
        args += [f'--file-filter={label} | {" ".join(pats)}' for label, pats in filters if mode != 'folder']
        r = subprocess.run(args, capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else None
    if SYSTEM != 'Windows' and shutil.which('kdialog'):
        spec = ' '.join(f'{" ".join(pats)}|{label}' for label, pats in filters)
        args = {'open': ['kdialog', '--title', title, '--getopenfilename', start_dir, spec],
                'save': ['kdialog', '--title', title, '--getsavefilename', str(Path(start_dir) / suggested), spec],
                'folder': ['kdialog', '--title', title, '--getexistingdirectory', start_dir]}[mode]
        r = subprocess.run(args, capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else None
    try:   # Windows, or anything else: Tk's dialogs (bundled with most Python installs)
        import tkinter
        from tkinter import filedialog
    except ImportError:
        raise RuntimeError('No file dialog available here; on Linux, install zenity')
    root = tkinter.Tk()
    root.withdraw()
    root.attributes('-topmost', True)
    root.lift()
    root.focus_force()
    try:
        types = [(label, ' '.join(pats)) for label, pats in filters]
        if mode == 'open':
            chosen = filedialog.askopenfilename(parent=root, title=title, initialdir=start_dir, filetypes=types)
        elif mode == 'save':
            chosen = filedialog.asksaveasfilename(parent=root, title=title, initialdir=start_dir, initialfile=suggested, filetypes=types)
        else:
            chosen = filedialog.askdirectory(parent=root, title=title, initialdir=start_dir)
    finally:
        root.destroy()
    return chosen or None


def dialog(title, save=False, suggested=None, kind=None):
    """Choose a diagram (kind=None) or export file; returns a Path or None if cancelled."""
    global last_dir
    filters, ext = EXPORT_FILTERS[kind] if kind else (DIAGRAM_FILTERS, '.spider')
    chosen = pick('save' if save else 'open', title, last_dir, suggested or '', filters)
    if not chosen:
        return None
    p = Path(chosen)
    if save and not p.suffix:
        p = p.with_suffix(ext)
    last_dir = p.parent
    return p


def reveal(p: Path):
    """Show a file in the system file manager."""
    if SYSTEM == 'Darwin':
        args = ['open', '-R', str(p)]
    elif SYSTEM == 'Windows':
        args = ['explorer', '/select,', str(p)]
    else:
        args = ['xdg-open', str(p.parent)]
    subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)


def write_atomic(path: Path, data: bytes):
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix='.' + path.name, suffix='.tmp')
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(data)
        os.replace(tmp, path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise


def diagram_path(raw) -> Path:
    p = Path(raw or '').expanduser()
    if not p.is_absolute() or p.suffix.lower() not in DIAGRAM_SUFFIXES:
        raise ValueError('Only .spider files can be saved or opened this way')
    return p


def info(p: Path, **extra):
    return {'path': str(p), 'name': p.name, **extra}


# ---------- library ----------

def tiny_png():
    """A 1x1 grey PNG: stands in for bubble pictures in homepage thumbnails (keeps the list light)."""
    def chunk(kind, data):
        return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind + data) & 0xffffffff)
    png = (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', 1, 1, 8, 2, 0, 0, 0))
           + chunk(b'IDAT', zlib.compress(b'\x00\xc4\xc4\xc4')) + chunk(b'IEND', b''))
    return 'data:image/png;base64,' + base64.b64encode(png).decode()


PLACEHOLDER_IMG = tiny_png()
PREVIEW_KEYS = ('text', 'x', 'y', 'parent', 'kind', 'color', 'order', 'collapsed', 'bold', 'italic', 'size', 'shape', 'fill', 'imgSize', 'line')


def load_config():
    try:
        cfg = json.loads(CONFIG.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        cfg = {}
    if not isinstance(cfg.get('folders'), list):
        docs = documents_dir()
        cfg['folders'] = [str(docs)] if docs != Path.home() else []
    if not isinstance(cfg.get('recent'), list):
        cfg['recent'] = []
    return cfg


def save_config(cfg):
    CONFIG.parent.mkdir(parents=True, exist_ok=True)
    write_atomic(CONFIG, json.dumps(cfg, indent=1).encode())


def remember(p: Path):
    """Note a diagram you've opened or saved, so the homepage lists it wherever it lives."""
    with lock:
        cfg = load_config()
        cfg['recent'] = [str(p)] + [r for r in cfg['recent'] if r != str(p)][:199]
        save_config(cfg)


def scan(folder: Path):
    """.spider files under a folder, skipping hidden and bulky directories."""
    base = len(folder.parts)
    for root, dirs, files in os.walk(folder):
        depth = len(Path(root).parts) - base
        dirs[:] = [] if depth >= MAX_DEPTH else [d for d in dirs if not d.startswith('.') and d not in SKIP_DIRS]
        for f in files:
            if f.endswith('.spider'):
                yield Path(root) / f


def strip_html(text):
    """Notes as plain text: block tags become spaces, inline ones (bold, links…) just disappear."""
    text = re.sub(r'</?(p|div|li|h\d|br|tr|td|th|blockquote|pre|hr|ul|ol|table)\b[^>]*>', ' ', text or '', flags=re.I)
    return re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', '', text))).strip()


def summarize(p: Path):
    """Title, counts, searchable text and a lightweight copy for the thumbnail (no pictures, no notes)."""
    st = p.stat()
    key = (st.st_mtime_ns, st.st_size)
    cached = summaries.get(str(p))
    if cached and cached[0] == key:
        return cached[1]
    data = json.loads(p.read_text(encoding='utf-8'))
    if not isinstance(data, dict):
        return None
    # Version 3+ keeps bubbles under "bubbles" (several main ideas possible); older files under "nodes"
    # with bubble 0 as the one centre. The app itself upgrades files; here we only need to read them.
    key_name = 'bubbles' if isinstance(data.get('bubbles'), dict) else 'nodes'
    nodes = data.get(key_name)
    if not isinstance(nodes, dict) or not nodes or (key_name == 'nodes' and not isinstance(nodes.get('0'), dict)):
        return None
    texts, preview, with_notes = [], {}, 0
    for k, n in nodes.items():
        if not isinstance(n, dict):
            continue
        if isinstance(n.get('text'), str):
            texts.append(n['text'])
        notes = n.get('notes') if isinstance(n.get('notes'), str) else ''
        note_text = strip_html(notes)
        if note_text:
            texts.append(note_text)
        pn = {key: n[key] for key in PREVIEW_KEYS if key in n}
        if isinstance(n.get('img'), dict):
            pn['img'] = {'src': PLACEHOLDER_IMG, 'w': n['img'].get('w', 4), 'h': n['img'].get('h', 3)}
        if note_text or '<img' in notes or '<table' in notes:
            pn['notes'] = '<p>notes</p>'
            with_notes += 1
        preview[k] = pn
    if key_name == 'nodes':
        mains = [nodes['0']]
    else:
        def sort_key(item):
            k, n = item
            order = n.get('order')
            return (order if isinstance(order, (int, float)) else int(k) if str(k).isdigit() else 0, str(k))
        mains = [n for k, n in sorted(nodes.items(), key=sort_key)
                 if isinstance(n, dict) and n.get('parent') is None and n.get('kind') != 'free']
    names = [' '.join(m['text'].split()) if isinstance(m.get('text'), str) and m['text'].strip() else 'Untitled' for m in mains]
    if isinstance(data.get('title'), str) and data['title'].strip():   # the diagram's own name, if it has one
        title = ' '.join(data['title'].split())[:200]
    elif not names:
        title = p.stem
    elif len(names) <= 3:   # matches docTitle() in the app
        title = ', '.join(names[:-1]) + ' and ' + names[-1] if len(names) > 1 else names[0]
    else:
        title = f"{', '.join(names[:2])} and {len(names) - 2} more"
    links = data.get('links') if isinstance(data.get('links'), dict) else {}
    preview = {key_name: preview, 'links': links, 'settings': data.get('settings', {}), 'nextId': data.get('nextId', 1)}
    for k in ('format', 'version'):   # so the app knows which version to upgrade the thumbnail from
        if k in data:
            preview[k] = data[k]
    summary = {
        'path': str(p), 'name': p.name, 'folder': str(p.parent), 'mtime': st.st_mtime, 'bytes': st.st_size,
        'title': title, 'count': len(preview[key_name]), 'notes': with_notes, 'mains': max(1, len(mains)),
        'links': len(links), 'text': '\n'.join(texts)[:50000], 'preview': preview,
    }
    summaries[str(p)] = (key, summary)
    return summary


def library():
    with lock:
        cfg = load_config()
        paths = {}
        for folder in cfg['folders']:
            f = Path(folder)
            if f.is_dir():
                for p in scan(f):
                    paths[str(p)] = p
                    if len(paths) >= MAX_FILES:
                        break
        alive = [r for r in cfg['recent'] if Path(r).is_file()]
        if alive != cfg['recent']:   # forget recent files that have since been deleted or moved
            cfg['recent'] = alive
            save_config(cfg)
        for r in alive:
            paths.setdefault(r, Path(r))
    files = []
    for p in paths.values():
        try:
            s = summarize(p)
        except (OSError, ValueError):
            continue
        if s:
            files.append(s)
    files.sort(key=lambda s: s['mtime'], reverse=True)
    return {'folders': cfg['folders'], 'home': str(Path.home()), 'files': files}


def route(path, req):
    if path == '/api/ping':
        return {'ok': True}
    if path == '/api/open':
        p = dialog('Open spider diagram')
        if not p:
            return {'cancelled': True}
        text = p.read_text(encoding='utf-8')
        remember(p)
        return info(p, text=text)
    if path == '/api/open-path':
        p = diagram_path(req.get('path'))
        text = p.read_text(encoding='utf-8')
        remember(p)
        return info(p, text=text)
    if path == '/api/save':
        p = diagram_path(req.get('path'))
        write_atomic(p, req['data'].encode('utf-8'))
        remember(p)
        return info(p)
    if path == '/api/save-as':
        p = dialog('Save spider diagram as', save=True, suggested=req.get('suggested'))
        if not p:
            return {'cancelled': True}
        write_atomic(p, req['data'].encode('utf-8'))
        remember(p)
        return info(p)
    if path == '/api/library':
        return library()
    if path == '/api/library/add-folder':
        folder = pick('folder', 'Add a folder to your library', Path.home())
        if not folder:
            return {'cancelled': True}
        folder = str(Path(folder))   # drops the trailing slash macOS adds
        with lock:
            cfg = load_config()
            if folder not in cfg['folders']:
                cfg['folders'].append(folder)
                save_config(cfg)
        return library()
    if path == '/api/library/remove-folder':
        with lock:
            cfg = load_config()
            cfg['folders'] = [f for f in cfg['folders'] if f != req.get('path')]
            save_config(cfg)
        return library()
    if path == '/api/reveal':
        p = diagram_path(req.get('path'))
        if not p.is_file():
            raise ValueError('That file no longer exists')
        reveal(p)
        return {'ok': True}
    if path in ('/api/export', '/api/export-png'):
        kind = req.get('kind', 'png')
        if kind not in EXPORT_FILTERS:
            raise ValueError('Unknown export type')
        p = dialog('Export ' + ('PNG' if kind == 'png' else 'outline'), save=True, suggested=req.get('suggested'), kind=kind)
        if not p:
            return {'cancelled': True}
        write_atomic(p, base64.b64decode(req['data']))
        return info(p)
    if path == '/api/about':
        return about()
    if path == '/api/install':
        return {'message': install()}
    if path == '/api/update/check':
        return check_update()
    if path == '/api/update/apply':
        return apply_update()
    raise LookupError('unknown endpoint')


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def host_ok(self):
        # Blocks DNS-rebinding: the page must be addressed as localhost.
        return self.headers.get('Host') in (f'127.0.0.1:{PORT}', f'localhost:{PORT}')

    def send(self, code, body, ctype='application/json'):
        data = body if isinstance(body, bytes) else json.dumps(body).encode()
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        global last_seen
        if not self.host_ok():
            return self.send(403, {'error': 'forbidden'})
        if self.path.startswith('/api/alive?'):
            return self.alive()
        if self.path.split('?')[0] not in ('/', '/index.html'):
            return self.send(404, {'error': 'not found'})
        last_seen = time.time()
        html = app_html()
        html = html.replace('<!--spider-host-->', f'<script>window.SPIDER_HOST = {json.dumps({"token": TOKEN})};</script>', 1)
        self.send(200, html.encode(), 'text/html; charset=utf-8')

    def alive(self):
        """Each open tab keeps this connection open. Closing the tab (or the browser) drops it, which is
        how the launcher knows when nothing is using it any more, whatever the browser."""
        global live, closed_at
        if parse_qs(urlsplit(self.path).query).get('token') != [TOKEN]:
            return self.send(403, {'error': 'forbidden'})
        self.send_response(200)
        self.send_header('Content-Type', 'text/event-stream')
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        with lock:
            live += 1
        try:
            while True:
                self.wfile.write(b': still here\n\n')
                self.wfile.flush()
                time.sleep(1)
        except OSError:
            pass
        finally:
            with lock:
                live -= 1
                if not live:
                    closed_at = time.time()

    def do_POST(self):
        global last_seen
        if not self.host_ok():
            return self.send(403, {'error': 'forbidden'})
        if self.headers.get('X-Spider-Token') != TOKEN:
            return self.send(403, {'error': 'forbidden'})
        last_seen = time.time()
        try:
            req = json.loads(self.rfile.read(int(self.headers.get('Content-Length') or 0)) or b'{}')
            self.send(200, route(self.path, req))
        except LookupError as e:
            self.send(404, {'error': str(e)})
        except Exception as e:
            self.send(500, {'error': str(e)})


def unpack(blob, text=True):
    data = zlib.decompress(base64.b64decode(''.join(blob)))
    return data.decode('utf-8') if text else data


def app_html():
    return unpack(EMBEDDED_HTML) if EMBEDDED_HTML else (HERE / 'index.html').read_text(encoding='utf-8')


# ---------- Linux desktop integration ----------

DATA = Path(os.environ.get('XDG_DATA_HOME') or Path.home() / '.local' / 'share')
INSTALLED = {
    'program': Path.home() / '.local' / 'bin' / 'spider-diagram',
    'desktop': DATA / 'applications' / 'spider-diagram.desktop',
    'mime': DATA / 'mime' / 'packages' / 'spider-diagram.xml',
    'icon': DATA / 'icons' / 'hicolor' / 'scalable' / 'apps' / 'spider-diagram.svg',
    'mime-icon': DATA / 'icons' / 'hicolor' / 'scalable' / 'mimetypes' / 'application-x-spider-diagram.svg',
}
MIME_XML = """<?xml version="1.0" encoding="UTF-8"?>
<mime-info xmlns="http://www.freedesktop.org/standards/shared-mime-info">
  <mime-type type="application/x-spider-diagram">
    <comment>Spider diagram</comment>
    <sub-class-of type="application/json"/>
    <icon name="application-x-spider-diagram"/>
    <glob pattern="*.spider" weight="80"/>
  </mime-type>
</mime-info>
"""


def refresh_desktop_caches():
    for cmd in (['update-mime-database', str(DATA / 'mime')], ['update-desktop-database', str(DATA / 'applications')],
                ['kbuildsycoca6'], ['kbuildsycoca5']):
        if shutil.which(cmd[0]):
            subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def install():
    if SYSTEM == 'Windows':
        return windows_install()
    if SYSTEM != 'Linux':
        raise RuntimeError('Installing is for Linux and Windows. On a Mac, just double-click spider-diagram-mac.command.')
    me, prog = Path(__file__).resolve(), INSTALLED['program']
    for p in INSTALLED.values():
        p.parent.mkdir(parents=True, exist_ok=True)
    if me != prog:
        shutil.copyfile(me, prog)
    prog.chmod(0o755)
    icon = unpack(EMBEDDED_ICON) if EMBEDDED_ICON else (HERE / 'icon.svg').read_text(encoding='utf-8')
    INSTALLED['icon'].write_text(icon, encoding='utf-8')
    INSTALLED['mime-icon'].write_text(icon, encoding='utf-8')
    # Some launchers skip an icon folder that has no index.theme; borrow the system one.
    theme = DATA / 'icons' / 'hicolor' / 'index.theme'
    if not theme.exists() and Path('/usr/share/icons/hicolor/index.theme').exists():
        theme.symlink_to('/usr/share/icons/hicolor/index.theme')
    INSTALLED['mime'].write_text(MIME_XML, encoding='utf-8')
    INSTALLED['desktop'].write_text(f"""[Desktop Entry]
Type=Application
Name=Spider Diagram
GenericName=Mind map editor
Comment=Create spider diagrams and export them as pictures or documents
Exec="{prog}" %f
Icon=spider-diagram
Terminal=false
Categories=Office;
MimeType=application/x-spider-diagram;
Keywords=mind map;mindmap;spider;diagram;brainstorm;notes;
StartupNotify=false
""", encoding='utf-8')
    refresh_desktop_caches()
    if shutil.which('xdg-mime'):
        subprocess.run(['xdg-mime', 'default', 'spider-diagram.desktop', 'application/x-spider-diagram'])
    return (f'Installed. Spider Diagram is in your app menu, .spider files open with it, and the program\n'
            f'itself is at {prog}. Remove it again with:  spider-diagram --uninstall')


# ---------- Windows: Start menu shortcut and .spider file type (current user only, no admin needed) ----------

WIN_APP_DIR = Path(os.environ.get('LOCALAPPDATA') or Path.home() / 'AppData' / 'Local') / 'Programs' / 'Spider Diagram'
WIN_SHORTCUT = Path(os.environ.get('APPDATA') or Path.home() / 'AppData' / 'Roaming') / 'Microsoft' / 'Windows' / 'Start Menu' / 'Programs' / 'Spider Diagram.lnk'
WIN_CLASSES = r'Software\Classes'
WIN_KEYS = [r'.spider', r'SpiderDiagram.File\shell\open\command', r'SpiderDiagram.File\shell\open',
            r'SpiderDiagram.File\shell', r'SpiderDiagram.File\DefaultIcon', r'SpiderDiagram.File']   # deepest first


def windows_refresh_icons():
    try:
        import ctypes
        ctypes.windll.shell32.SHChangeNotify(0x08000000, 0, None, None)   # SHCNE_ASSOCCHANGED
    except Exception:
        pass


def windows_install():
    import winreg
    WIN_APP_DIR.mkdir(parents=True, exist_ok=True)
    prog, ico, me = WIN_APP_DIR / 'Spider Diagram.cmd', WIN_APP_DIR / 'spider-diagram.ico', Path(__file__).resolve()
    if me != prog:
        shutil.copyfile(me, prog)
    ico.write_bytes(unpack(EMBEDDED_ICO, text=False) if EMBEDDED_ICO else (HERE / 'icon.ico').read_bytes())
    # Start menu shortcut, starting minimised: the app itself lives in your browser.
    script = ('$s = (New-Object -ComObject WScript.Shell).CreateShortcut($env:SD_LINK); $s.TargetPath = $env:SD_PROG; '
              '$s.IconLocation = $env:SD_ICON; $s.WindowStyle = 7; $s.Description = "Spider Diagram"; $s.Save()')
    WIN_SHORTCUT.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(['powershell', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script], check=True,
                   env={**os.environ, 'SD_LINK': str(WIN_SHORTCUT), 'SD_PROG': str(prog), 'SD_ICON': str(ico)})
    # .spider files: their own icon, and double-click opens them in Spider Diagram.
    values = {r'.spider': 'SpiderDiagram.File', r'SpiderDiagram.File': 'Spider diagram',
              r'SpiderDiagram.File\DefaultIcon': f'"{ico}"', r'SpiderDiagram.File\shell\open\command': f'"{prog}" "%1"'}
    for key, value in values.items():
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, WIN_CLASSES + '\\' + key) as k:
            winreg.SetValueEx(k, '', 0, winreg.REG_SZ, value)
    windows_refresh_icons()
    return ('Installed. Spider Diagram is in your Start menu and .spider files open with it.\n'
            f'The program itself is in {WIN_APP_DIR}. Remove it again with:  "{prog}" --uninstall')


def windows_uninstall():
    import winreg
    for key in WIN_KEYS:
        try:
            winreg.DeleteKey(winreg.HKEY_CURRENT_USER, WIN_CLASSES + '\\' + key)
        except OSError:
            pass
    WIN_SHORTCUT.unlink(missing_ok=True)
    (WIN_APP_DIR / 'spider-diagram.ico').unlink(missing_ok=True)
    windows_refresh_icons()
    # The program file may be the one running right now, so it's left for Windows to tidy away.
    print(f'Removed Spider Diagram from your Start menu and file types. You can delete {WIN_APP_DIR} too.\n'
          'Your diagrams and library settings are untouched.')


def uninstall():
    if SYSTEM == 'Windows':
        return windows_uninstall()
    for p in INSTALLED.values():
        p.unlink(missing_ok=True)
    refresh_desktop_caches()
    print('Removed Spider Diagram from your app menu. Your diagrams and library settings are untouched.')


# ---------- installing from the app, and updates ----------

def installed_program():
    return WIN_APP_DIR / 'Spider Diagram.cmd' if SYSTEM == 'Windows' else INSTALLED['program']


def shown_version():
    """The version to show. The source folder counts as a release when it's exactly the last published
    version (checked out at the release commit, with nothing changed since); otherwise it's 'dev'."""
    if EMBEDDED_HTML is not None or VERSION != 'dev':
        return VERSION
    try:
        git = lambda *a: subprocess.run(['git', '-C', str(HERE), *a], capture_output=True, text=True, timeout=5).stdout.strip()
        released = json.loads((HERE / 'dist' / 'version.json').read_text())['version']
        if git('rev-parse', 'HEAD') == git('log', '-1', '--format=%H', '--', 'dist/version.json') and not git('status', '--porcelain'):
            return released
    except Exception:
        pass
    return 'dev'


def about():
    packed = EMBEDDED_HTML is not None   # a built single-file copy (not the source folder)
    return {'version': shown_version(), 'system': SYSTEM, 'updates': bool(UPDATE_URL) and packed,
            'canInstall': packed and SYSTEM in ('Linux', 'Windows'),
            'installed': Path(__file__).resolve() == installed_program()}


def fetch(url, limit=20_000_000):
    with urlopen(Request(url, headers={'User-Agent': 'Spider Diagram/' + VERSION, 'Cache-Control': 'no-cache'}), timeout=20) as r:
        return r.read(limit)


def latest():
    return json.loads(fetch(UPDATE_URL + 'version.json?t=' + str(int(time.time())), 100_000))


def check_update():
    if not about()['updates']:
        return {'available': False}
    info = latest()
    return {'available': str(info.get('version', '')) > VERSION, 'version': info.get('version'), 'current': VERSION,
            'summary': str(info.get('summary', ''))}


RESTART = False


def apply_update():
    """Download the newest build for this computer, check it, and put it in place of this program."""
    global RESTART
    if not about()['updates']:
        raise RuntimeError('Updates are not set up for this copy')
    info = latest()
    name = 'spider-diagram-windows.cmd' if SYSTEM == 'Windows' else 'spider-diagram-linux'   # Mac uses the Linux file
    data = fetch(UPDATE_URL + name + '?v=' + str(info['version']))
    if hashlib.sha256(data).hexdigest() != info['sha256'][name]:
        raise RuntimeError('The download was damaged; nothing was changed. Try again later')
    if b'Spider Diagram launcher.' not in data[:4000]:
        raise RuntimeError("That download doesn't look like Spider Diagram; nothing was changed")
    me = Path(__file__).resolve()
    mode = me.stat().st_mode
    write_atomic(me, data)
    if SYSTEM != 'Windows':
        me.chmod(mode | 0o755)
    RESTART = True
    threading.Thread(target=lambda: (time.sleep(0.5), SERVER.shutdown()), daemon=True).start()
    return {'version': info['version']}


def restart():
    """Start the freshly updated program in place of this one (no new browser tab: the page reloads itself)."""
    me = str(Path(__file__).resolve())
    if SYSTEM == 'Windows':
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = 7   # minimised, like the Start menu shortcut
        subprocess.Popen([sys.executable, '-x', me, '--no-browser'], creationflags=subprocess.CREATE_NEW_CONSOLE, startupinfo=si)
    else:
        os.execv(sys.executable, [sys.executable, me, '--no-browser'])


SERVER = None


def main():
    global SERVER
    args = sys.argv[1:]
    browser = '--no-browser' not in args
    args = [a for a in args if a != '--no-browser']
    if args and args[0] in ('-h', '--help'):
        return print(__doc__)
    if args and args[0] == '--install':
        try:
            return print(install())
        except RuntimeError as e:
            sys.exit(str(e))
    if args and args[0] == '--uninstall':
        return uninstall()
    url = f'http://127.0.0.1:{PORT}/'
    if args:
        url += '#open=' + quote(str(Path(args[0]).expanduser().resolve()))
    for attempt in range(1 if browser else 40):   # after an update, the old copy may still be letting go of the port
        try:
            server = SERVER = ThreadingHTTPServer(('127.0.0.1', PORT), Handler)
            break
        except OSError:
            time.sleep(0.25)
    else:
        # Already running (e.g. another window): just open another tab on it.
        if browser:
            webbrowser.open(url)
        return

    def watchdog():
        # Stops a few seconds after the last tab closes (a reload is back well within that). A tab from
        # an older version, without the connection, just checks in now and then: then it's IDLE_EXIT.
        global last_seen
        before = time.time()
        while True:
            time.sleep(1)
            now = time.time()
            if now - before > 20:   # the computer was asleep: give the tabs a chance to reconnect
                last_seen = now
            before = now
            if live:
                continue
            if (closed_at is not None and now - closed_at > 3 and last_seen < closed_at) or now - last_seen > IDLE_EXIT:
                server.shutdown()
                return

    threading.Thread(target=watchdog, daemon=True).start()
    print(f'Spider Diagram is running at {url}\nYou can minimise this window. It stops by itself a few seconds '
          'after you close the browser tab.')
    if browser:
        def open_tab():
            # A tab left open from last time reconnects by itself within a second or two: then use that
            # one rather than opening another. (Opening a file always gets a tab to open it in.)
            if not args:
                for _ in range(30):
                    time.sleep(0.1)
                    if live:
                        return
            webbrowser.open(url)
        threading.Thread(target=open_tab, daemon=True).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    server.server_close()
    if RESTART:
        restart()


if __name__ == '__main__':
    main()
