#!/bin/sh
_=''':'
# Spider Diagram, all in one file. These first lines are a small shell script that runs this same
# file with Python 3; everything after them is the Python program, with the app packed inside.
for py in python3 python; do
  if command -v "$py" >/dev/null 2>&1 && "$py" -c 'import sys; sys.exit(sys.version_info < (3, 8))' >/dev/null 2>&1; then
    exec "$py" "$0" "$@"
  fi
done
echo
echo "Spider Diagram needs Python 3.8 or newer."
if [ "$(uname)" = Darwin ]; then
  echo "If your Mac offered to install the \"command line developer tools\", click Install, wait for it"
  echo "to finish, then open Spider Diagram again. Or get Python from https://www.python.org/downloads/"
else
  echo "Install it with your package manager (it's usually called python3), then try again."
fi
printf 'Press Return to close. '
read -r _
exit 1
'''
__doc__ = """Spider Diagram launcher.

Serves the app on localhost and opens it in your browser, giving it real file handling that
browsers like Firefox can't do on their own: Save overwrites the current file, and Save as /
Open / Export show a native file dialog (macOS: Finder dialogs; Linux: zenity or kdialog;
Windows and elsewhere: Tk, which shows the system's own dialogs). Works with Python 3.8 or newer.

    spider-diagram.py                  # start on the homepage listing all your diagrams
    spider-diagram.py notes.spider     # open a specific file
    spider-diagram.py --install        # Linux / Windows: add to the app menu (Start menu) and open
                                       #   .spider files with it when double-clicked
    spider-diagram.py --uninstall      # undo --install

Installing and updating also work from inside the app: the homepage offers to install, and when a
newer version has been published (see build.py), the app offers to update itself in one click.

build.py turns this file plus index.html into single-file versions (dist/spider-diagram-linux,
dist/spider-diagram-mac.command and dist/spider-diagram-windows.cmd) that carry the app inside them.

The homepage lists .spider files found in your library folders (~/Documents to begin with; add
more from the homepage) plus every diagram you've opened or saved here. That list is kept in
~/.config/spider-diagram/library.json.

The server stops by itself about two minutes after you close the tab.
"""
import base64, hashlib, html, json, os, platform, re, secrets, shutil, struct, subprocess, sys, tempfile, threading, time, webbrowser, zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, urlsplit
from urllib.request import Request, urlopen

HERE = Path(__file__).resolve().parent
# build.py fills these in for the single-file versions; when None, index.html and icon.svg next to this file are used.
EMBEDDED_HTML = (
    'eNrUvcly68qSILi/X4HUtVdXehJJDBx1zlE2JVHzLJEaXr4FSIAkRBAAAXDSqzTLVVqZ9aYqu836D2rby953/8n7knb3CIwEB+nc'
    'm5l1B5EEYvCIcPdw93D3+P4Pmt3x544u9P2hefDLd/wQTNXq/djSrS18oKsafAx1XxU6fdX1dP/H1tjv5qpbwWNLHeo/tiaGPnVs'
    '198SOrbl6xYUmxqa3/+h6ROjo+fox55gWIZvqGbO66im/kPCRnzDN/WDR8fQdFc4NtSeqw6/F9jTX77/Qy4nPKltwYBm9+lv3pv0'
    '9gS/rwse9Cyorj+13YGgevRMdRxWSsjloLppWAPB1c0fW/hwS8DBwveh2tML0M7ubGhuCX1X7/7Y0lRf3U+82fuTcgRfBfhqeT/+'
    'JMt933f2C4XpdJqfKnnb7RVkURSxOLwUcAoO7RkWFAVRKBfhP/j+J6UB7Wh612PfACRddU9dVTNgmgRDwwq+YerYxkyi6vh1Hn2d'
    'ydFT+iqF7Xq+7Qh2t4sLE5TBZ7mObdouPvqTrBQ7Va3bhe+FzEpSZiW5VFb0dlSpkAScP4zG5eodX6DRywRo+I3hAXwrE3R93ej1'
    '/ei3S3UknCqha5gm/hq75jaAgLOyE0HQE3xXtbyu7Q5pzvCHqfr6tiQLkpwv7QiEVttSvlwuV3biDVq2pbNRuvZA5yPs0pzwZ7kQ'
    'TDkvxR7jqDuqgy9ce2xpqVfvtmHF3zFIO4bbMXWhw4ZGs9CZR99pipVoYEuLK/lSWB5GtaQGW3VWo7ZBeanCmuUg1TbqpPyFOsW1'
    'cDmq3xeIAq5hEWutUl66lor5qiCJ+Zqp5Cs5Ka9cSwo+KeaLpgxf4Mc1vJbZk1zwqIZPoJZQypeEWryTQo9/IqEqjS3GVjziOLm+'
    '7fnEKryOazj+wS+CUCgIdccx58RQ4H/gMm0dsE4HdHI9X3BUw/L3ga0M9WFbd3UNWKMNTG5P0E1PZ6xp7vn6UAAC8w2rl4dGfXcu'
    '/E0AfjseAvXkgy8NU2e/gftA6Tzr7odg2oDKj77tAj/K93T/HJrb/o3DrDEuuU+Ff9uB1gXhv/5XYXuo+p3+tQ6vt3/bdoCr6a7H'
    'aBoYLpbdFzTVHez8tpOnoron/KPwGz76TdgXfjORMH/b+Sb8M7TYwQKfgZhXx9rfC8Fkfvf8OfJxQdh3bdsX/kaw5nLt3r7wa7fY'
    'VfTuN/jpqJZu4hP6B58A34bfUhf4UBV/D8e+rsGTcrsiV8VvvBmkQHioK7qkqVhM7XR0XJtfGffCR317orvYttQV9Q4+ce2pjA/a'
    'XbVbDZryfJjp4GkFi2k2NqTVtHKHqtkWA1uv6hxIeMIhaNc6HVYLnnHYtaKuhc3DosBiJobIHi2M1LdVz198wsvx6rzVPkPEXlvd'
    'lkulveD/fG2H5ky3xjmvr2r2dB82JEl0ZoKCf6iCuIf/5qXSTtCaTYCUqqKi0UgGfLyVbplNHDzh4611tVpbZhWTCEZYgC/+OVj0'
    'vyCm5AhNcJd1B1t/TeKBJEnA/+N4IKlSRxYjPNCLekmvxfGgJteqqpLCA1lXJKWawAO29cXxQC7JVVmP4YFUlqpSO40HUlEqSdUI'
    'D+Q2tF6K44GkyWqxmMQDpVgSK90EHgBmiNGKhXgAi1uWOwt4EI00wIPUkwBf2Jxl4EF5T67uKTIggbw5FpRSWFBUNb0qxrFAgmmT'
    'tCQWyN1yu1jKwgJc5gAJ/gxcpG3Pcp7xAbxwH767yMTgEeM0f+kbmqZbf0VmY3iOqc73BdyvhX8whihSqpbPCuaNDpShfXpfkMoO'
    '1GfCRPCra+ozVvcb7fzBd7Zf7wudsesCWhwhqN8S+/6+IH9L7fgwn7inf0vv9uFzQCffAC6dUwHn4XFOcfiI2mPft634eAwLq+cQ'
    'wG8Clc8ZwNE9gAkA0gGa97HnG915jovP0YseglJKNQ1TkYepnsTmo5iYD/o1VN0eAiwSbPghB+2gpL8HS6HhrhSWizUgin/6JiDJ'
    'dE1EHLZG7Akwd9s0c229r04MRGY2ywQeNUgI0VY7gx5N1b4wUd1tJHZASMKT4Ang8k5GL1S/a1t8IAUpXxRyINmbeo5trHvCIUr2'
    '12rnkX6fQNk9YetR79m60Dzf2hMe7Lbt2/DsTDcnOq6TcKOPdXhTd0EB2QPlwfJynu4anDTDpWJrhH9hn0Wh1kDNA8AeD60ApVEt'
    'Am3lbxmDJBYGgwqxHNZrCOOA+fds09B4MUQHvtPmgQ/FcSUGwNTFxce/S7CGkAOmSKD1dlRNIxIDdCFCj3WwG/TDAQNxfylUi6NC'
    'VsnB5WPvS9AWrhHSNdCWVEpiXJUQjvCNSk05YlVEwLJpH8YBEpja0RF72ACx8V9BykCFcintDA0roFgxhUy0Nex8SwAlJ4EqElBl'
    '9nAWkr5IU5UJFLAMD7vw9ZkfLiqqQGOPU2U46XKwDPGBLGNuqeHmrSGUWCQ37DYXPdZN03A8w0vPQ7ItDQWtBDPkMOZMvevvcyAB'
    '5wt/JmF1bHnqRNdyoOBbPZAJsT5sg3MPVFrPaIM437enOgABUqnVoyrU0Z8LsW73aX+FfjMIfBGfqDBHKMNyxn4eGDNbd0b3htUH'
    '2vQzVjO5aJlrm1gSesIWbhHhmZywk72yy4k7i4mNfbYrRqubx8pOailSZL6cqpXYSHIuI55yNOTgkRQNL/ZoKa8hkPZNFCQ6fcPU'
    'IobAK3NsyhMduCHwEn8M0lF6jZfSXYLuy0j3hM6hEr8vjB1HdzugRnwTTFCVAArslpYuLxb1YXqwcnIbBC6um2h2+FtsxwgxZyNE'
    'TLLrZXPHNrQkilQSmIbYV8MnAcNwQFSgxcxkK/G5woXm+wobFiOlfcv2t/cBXVSgQG0nc7OJkxGvG1QI5iZ8gPwFJ9cH3MsXI0A1'
    'vauOTT/eSJ6El8XuSPKNiCUxwVwGThMHE4MTIOYd14BlnWd2ERIkb+VXUpayOgxLLqLZYl8hd4r3GKho8fJoJkSJKGKviriw0JVw'
    'Z0XhOo9cFepwHFXHvo3o3I0RExWzVJftwAEHK4c79K80smsoFb1m7cR6MTw/VjkFFnEG4htyCjisdhCJpAtyJgkawO5dP6ICMUkq'
    'iU2EMJ9LFwk0zpdi7JnJj0vAyFyNRYyO1cwP2qGcyncxNj+bcaIFOPpuyPjYaNcLRcFOgwgQNvorKm/JdZOrCcEr79u26bHeSZ6D'
    'ko7tGUysdHVT9Y2JHkeDY9tfreak9yqc6WAscgr4iL/NYkog/ovDXCP1BfNJsHlTbjKKSTI91wBFCP/mYAdz0BibY5Kyh2NzdNXf'
    'Lu8BpjuzHY6eVRzBAhJy/Itv3AlsZFvSlNukgpmW43PDfoUtiH/YPMVg4YxyoY4c1omYX1BlqBpYiSaNzRUMH7pHDTRB+inwJdrp'
    'E2wxjucSI79sZmiqbd1EhbEzWNQ0losgpQUa33yHi7r1hqppbiw0MFxDIwzf1bOIJZRJkmLwovwcwNpzVW7hibA8uZ1QlzsLZehA'
    'CLqGRQBNv8cPP7ZZHRCUdxA/9tjBhKOidQEfLLbDhog4yhCVb/hspHlYfguwFicpBnAbHsUnJK+5tuOwcqG4iYq9pnp9fUGk5UVy'
    '7KBnX8iVo+1GtSaqF+MyxK2Tun+IJW3T7gxAdrPHnT60ztaCbQmAae2B4efGHopuTN7grzIeBaVZSx3ACgAxoQ5xuPKWremxyQgx'
    'LWS5truAHWob6Bmw6hvgCZtt1vASpYobbTi+xwS8Rd6wTElge2BS8F9i+mAwp4WjyPK3wHnKiCjFZbZaopquOjTMeUzgTdCh4+o5'
    'RonBBHBrgmrNp1ABZuYDetaQkOQQHdGQ6K2YWrb1Spw9c9MG/Qp0jwqTS9iK5UBrhAaDpQg1TjQiQcuBVGJ4AvzFF9QKUyyFtRYR'
    '4lHlGFdczVoSY8xDFVN1PCAbYr7Z6jmbjlB2So+K8elwy0FSrKZZprwUvgzhxyA0i3XNYVtadLXakkbYpHKsxCXZQVsLdW/YNmi3'
    'EcZGbmhbNmHUnhB+zVStCGiyUEM7tNBdY0ZqiC0Mdc9T0bLg9UEA5kvdt4e6g2weBKRgxSOUo8rIdHCJyWDBUI828ZgGGR0C5+DV'
    'npCrkqgRajpiDM1LYsLsAwyosw28bjIVcoIiU72lrGFhAWioaYIOLfQ7aXG5mCG4VbO2V+qORsVngg9FyMveXjRy/LmEzDiewwo8'
    'LZDaHqdaTmh2l5ZiChMEC7MNXJU/4SeMUBx4qcbONEEf1b2dPWAgmmAAbqJEy21A0MlzWrTlKxjwhQyWES4MnqtwexQpBnH02BNg'
    '0vkzH+gNrbdRr4e+9RmBZtE6JH6FWhmHWFQfgoUNLHIMQKbt7AU//6LCEHL6DChb07UfW7471vFEjOGepndsV2UzSANHSuZ4Gf4O'
    't/TwxCGYi/wEj4dJgUjxM470lbjIXFmmTcSazBteztKnafltjfadqpwFFhcrVpgA4g31VS83djQg9DQk9mAtFLHKn4KEmlYtkAHZ'
    'gkDduzEe8Uv5sifoqqcDBudAAIA9uIuuTXzf+N8G+rwL5AMcL6zyN5zZhA0GsT7GyZjvSr6CA2etDPEkXwgP8l1dG3d0DVhyIA7j'
    'bzQMrR5nbAB8awsnh2uuxGUDpYNRaMAc/yTsCoylBuaQqhiYzwM0AiF8u4TGjL2Ip/aBp2LJncT5DuuDSDGmmCOoeKrwGUqOnW6E'
    '1Q+SJ4RyNaEeVhdIO4FoUTPtDNxYOOhIVuHb9HoxJJ9RORQvMswbGZUTlqhoGnA5H33VH3upcxllKUtLVSOIQhrb7Dwsi63SCbMk'
    'rzK78yPknewtMYsQlx4erhhEO5NVrKoQrATDO9Beukn7WLhwpt375BzFTOLxhUm0qOKBsvnZ2V9sp19MHupmmOloGwkVPuJFiSbo'
    'C+gJn99e1xKBlCKCZHf6MMRfdB1CnuUOVTPVRLapI9vyvNaOHSBf8gxVFBbBdJLzmjnU1MwW+cyCbLP1qE50gZ+y/eOWQOOd22MQ'
    'bfGFGkhdXLyhp8dmL0uqMiza/+PSbbH6LW2Yg+8dPb1S8emIK5dKKSCOoOPVZ5d5jUDjzBb3gKKS3ANCuXrn26cQuppkJ3iSLBNP'
    'KQfy8adO5j6nIwWMK1LG+fJGbjQ7sQnoy8tJjcSrpdp32MQmSBVvNjxjptrZ3gPRPPJNhbb46mJNPBCcpk/5fgVBe8EIkJTnZTEu'
    'z7NfESqKobhQLC+ICwkZgetdKRHhEx4ZcXEgwplyiDPV/zQ4k5AhMrlwKdDdAtEvpq2W8bybhD1anMASI8ZtL4k1Yb8SFuX4KhTL'
    'k358xuRQS13ENerzCT3yU7IFQyh+Mjz2PyPFrUVzZbk5O+orMs0sOzlY1NuWykLUbFvFo6FglrLOW+RsGSU4uVq0NybaNjKky6Th'
    'dYVGFLcL0MoKebnkRUQbrFHATkjDTbElWQpFRqwBimWSA8G/lYUSYzOrSNKtRBYXqplGJNYGeKkslMr7hrOJ9FxcqBlZrRJYE2H1'
    'Ov+PJD0zEEO3oCztePXahyttqZMINxeUh6RpqBwf1g0Ma8mRfSk6zrBstFIBkiFHDju1u92kgpnwoMyyFSUKdA3T19nRw5wHUuyk'
    '5rudHxvBgBJUuXxKPsdJS1ki2HJvMYDrGIfxRRn1V6msKkV1GZtZ6r0c6zdoKXCYTWDAZ8EKxtSYAaEv2dTDgtRLz6TdOzyDWHJ0'
    'kVjn9LkQ4XnMSADtnmKzILtuaOQIaoQ2Dt4Dn5zY4VhofKCjwca6k5zYCcVKoy/83Ul7hmXoycusuzGzNxrFk75nC8csK45wlp77'
    'fOl8qVarLR4wrRMzglOOrkFm0+Vzy3wdNjGtv2zzCQ6Xo/wtLveX5ITc/ycQ6/DoamdnneD1R0hZWc7EsQk5R2fD9MHnoiV3jdtu'
    'tMFICbFpid9iaUEvXueOluFNyAdwxdyA4qJcSURRLm1lS9XZ14cO7Ar7atfnbprc9eK3Gxu2qjbsN55AUUG/LZ79pmw7xY30/Mgu'
    '0f2Uaa+6uEUWM/0OspWirrbOfS2AiTvKhqiQ8LQRl9nG486cYUvkvruxV8JSr96lOx11Qorjxo4UmW19xsM40j2KoS8XguH3UjLN'
    'EmtMQgrLOmqoLTi0EM6CcGN0yM9oQfmMMaqQQmlD3IxtoQj1aUNEJqIG3A/miBPS8qNF4oXLjsRpVtmIQ16ddcj8peiA1TEloWYc'
    'LlSVHWDT/5knlpwqfg9NOvQX5Vvj5rozt2DGdWNSPTijD2YzeRaQIG72a8VZAG/iIDDsc8qGf2NOm8ylb4URBQ+D83TkHZPKpZWS'
    'jBhI3NxLLGwxtf7IYYLRiMt0zl/pxHaFG1VA3mw+YlxLjg55gnNDwOVvmwfJrN/1udK41N86GsADufMk2EHaISVHyEoSjRixhsgK'
    'VY3vHwBljrkIxX0DopXXvU+fRlVXH4BsEgXExhoaWYJ1X4yd+V22EzZM5pr6udOGYtrtOLlVrhnpysiiPAz1Z2OhyoEPzj8HTigY'
    'se3ivOA0CUh2KgVlfxM8HRijhiGrnu/toTFuAB+O0fHHgB97gq+SUETWeGiqATM8j7kshSkoEJX2BNWPPWFRDOT8Qo4LUxth8Mjg'
    'J4wdEBP5rMIqYQF8TmQjtHV/quuWQIEaHrTte1gaC8EA0fDvI3Kin4Y6QF9AUFKHeQZkYlm5qzVGERCn4g92lvgfJ13sEyrbClfw'
    'iMSUNA9REixXidjmJkBu6iG+2FZ+yZi/Gs2wpBvmxdFXPcd2xs5fs+Tq375leyfyCYnbapW4jUoJSSe5CrEwnQDYZEBr0oqVWSQy'
    'DpVDEjF8eKxbnqDGXHoSQw6ibJI6dXmD9V3r9p4d5RdwgyCAavOaa3h0suHd6Pv+Pk/xsMEKBnsOk0OYi1p8NcvxOIhsgSmBXBwE'
    '/KJbWrYjQFbJGMxZ53NQaJiMTIg5TaA4lXKn3yDUoJgeDYjtulgup+O0qtk2V37cKLD/yJ01BQ2ztnV+bPVcYILkFpXorl3riipG'
    '7GTVaZvckypRRdW1KukWWVUc4PmLVbrdtqZ1uBFwvw9joqwG24jZuam5s9QZKrPC0PA8IJqdZZrbcr8v7ti9pF1f7S2HZJmbe0IH'
    'ZpRK+95mgcEJTYEOZjPigPDBpyWKuD1Dkf+Ubc5IAJy3zJzPxaVNfQ4WpanPRyRmAfL7OEkstByeIMQMVIkAl4WN+dPBGsy3Im4Y'
    'Ra6TNcqe/UkfwHT1cE9f5ei4WBHQJp3lIG6CybDpbji7eU1fGpYSO4JYOBMtpXa6qLVVMdALFQxuiVxhN1Q2sBtmyAhx8s0UITLd'
    'wcNY6cXQ8kW4A5/WjDdduzOOsZME+Eu1gDA+IiuMOjHNZttMRVQntNQ/bYaNMOhoAQJdawXEkYZ2yFJmhJXSfCrSAouB+0F6UAvI'
    'lHYDKC24jbRdXR3kpgBgGpa/cHEFZxD1lR9bXdX02D643OsvrB6YhRelH9CS3G3aJ8mNqG+bmr4QwRLSy1LjVmzW0sfMoUQWKwPv'
    'B5sLAcsqrpMEltVbLw7EapLrT/xgPZGQgFxQxNi5XqyikjKgVhIVWSKDYkbFsbkX/2mbWROaOpTPascY9jK8EGJ0lIwHC5xHWEdV'
    '5jWfxUuCsAPSm4Nd3kNdVR+NVZO7LPh9leWXEJD+VI9c4CgL5Tap6IjxyEyCwIPhzh7UhIpIJp7QMXXVZbqybtnjHjRog4aiC2pP'
    'Re2YVGWyNXGtODZwopAEb6IYIAKVvqXil6l8DiaJAtW4ETpcKJEWSsqaYcx1Gf+pxTbxiDmznElDY7YNGr4H0vFejM2jGLSXMJ3t'
    'pAwvtNzpLEQgvn2CewCgKWxfDVNtEaRF2WGJM35iOg6EWBKKvRREiZeLHiThMXvbzDlGMqR1k4jk6h7x5Z2MRBvhxMbC6MNuQnEs'
    'wJGEgzn7ldw8V0QjK9kq0urpl0uL87/c0JoFfd6wftYYgi0GFtm48ED0sCAtca/1DbYixodGY9uPuzBxdpM8zY/bVhmfU5adqW/S'
    'seOu6rGatnEmeN5Si+aSaEye1kqhtFal5SF2KRDVlTpnfHP5emYDtvMkxKUuJW1M2XvlT8Q4ru+dRTvaQ31DP2dF3Fi9XJKCjMaH'
    'PXJnv69bm1N2f5l7nX77ffKChSAu5NqqJFMf8Z1oWWKtzx1jLHSdPEjLyLmw+iAtOE4JonOWEyR2+gibOxmlsg7TZVncxNMiSbny'
    'spPndd4nm+evy3DWiMayUiGKuf6kc0ggR1u6GwR+XbQhxHS8BOp0SWT34vS7EkU549oMQzcKzl5+gJ7tKJIAO8++fC6NYkY8ErdV'
    'x/zAPud3xN2w1uyzmaAvuieLSX/UTzooJzuxbH+58QvXo616hpfIxRPS9Ub5aKLimbSJx+ELR8dS7ICcqi85ZFwX2pc8TSVffnGx'
    'WfbdC+PeAqYRF7yiOmG57MY382iKH71LKY6JcufmxgHqlyloafmV5qEcUU8qUQ6pP6uFXOwwh0lQ9xBi0O225RK56UlddyfAp47q'
    'auuOV1ZvsctTroQWxwUF4Q/wCoyv99o0cAsh9hHzxUOJZJi9FPjX02SFdi/6QZw9FyRJ/NtaL5Ysx4/X7RwPgcmwfGEveX6C9/kd'
    'JMpclNyUadXzfn88xAhJ1XNgUXNki0WkEwpAFd/W5cn5PXLkLObHYTaz4uc8JxLjwfsaFk0bK9LcxFrg2XAX/Tg4kn06KDPDksph'
    'jcfSJM4jFoSZ38Xdg/VK13Vs6j74O/brWYbj6H6kyEdHpov2jE/pWAtQLwZfJkPJghRElHw6+MF81U11iOv2LV4mZ7sGsd3AyrI0'
    'vIdjkKr1lnkqRRF4TGOtLljfs8bPhY/V7paV7BCM7FyKMXBdfaKr5ip4y7HwsiXZYxY2yHjulcxEJlksNQAmyVrR7AeSbwRo3I0u'
    '4pAsP8XnXCDj2ziPGOBTz+OOg7PXteSyJO9aKlojBDShTimJrN3sVzIvuUSeGqGEQeb6dPo4CXh2Li71FMVQzP/U+Rgawxet3+yE'
    'P4yZ4fcSZEXFxcRcKekmuU7S9HTk29F5cPAwR4Ei0YRVxI3zPUUNL4rhof8KlTFjRj0l6QXBbB2fzSWfX55NPugwj43iFkBtZ7WW'
    '0CdZAjg8vSK/suTvpYnTOq7tgUxguLGlWJU4LXQoJeKP5wBhGRxDI4wUc/wqpX1FE97PUjlMh/czAb3y+jDeT8qN4gbRJIFLMT5c'
    'Ew3P6umdT7pTVpNkgg3sJhrb3CuDl0n5J28maijJSlbSBit+Os9qth/nGo19wYaQbC7gBJ9LX/kVwDP8ub8X+E023wv8TjSUFvGC'
    'GxA42dVRW+JWcLkVfqXyP7ZCOgvIbEtgroOETTz9E16Q892bD9u2iReCbRmYbcLeCq8U26KkokX4b+vge3TF0pYkb+H9SvTp/thS'
    'tgqZr5V8id7DXpIqIYusRG3Je7wqindRW9pIeYMyxYx++OVPW7/71U/YeIFN5+LM4ja6ZGYjgEqCLE1yVRVtHKRM5aSc1M8V4w8E'
    'aVJNDEMBIFRZkJnyJdAISmYlV449lPNlQTQrQrkeewZNiZNaVCoH385K8d85+WPloIAd2usGVYNZE4pCzSzlSgm44Vkfpq+k4vTh'
    '/wwsTAJ4Jkkr+3X1tf0OYTKhY+g0l+5YFoXaWS3Vscg7VlZ2jJefuHij3+q+y0JNKOO/udVI4Zhjb938wTDkvlREbC1NpOLK9mZr'
    'MaxKcEnVa/gw6QK7lQ16Y+vT7KCYJjJ5QtesySJ8FvM1RcA/JqhJEupKQH6VfBlgwr+xpwhbX8bFos9yXinyMrlY1VperLD2oqcr'
    'RzS01y4fAquoOE8MLWr8X8ROKVfL1d5W9kCHD5uQ+llEoSLS3kSKPYBPWHY5/iAntypvycmFZifFVCVAFZhN5axKnxX8RISvrgSa'
    'jClLgOZXLAKfF+b0l288UjXaefC7i5w9xYBrcQYsx4EfIv8p5ZS8hP/HZwLYq3hVBv60mgeohtW2p+smWgY8qqgSnlYF7cMfJAR4'
    'HK5xDpZcxOmEhxEkRUFcCQIzia+FAJ6JqXWsxsebk/u5Sj7OiGGnquXytSvYVGCnqdWjyhWkH+WsmMYcJYkEbxvAnUP3+/WcDCcl'
    'X4JVqcX2Dtj64LF4Jsd3Hilfg+qw9+AGVBTKiQHVSthMDHDaXlql+CYFE6HE5wG10Brsyvkqfo3TAryAmTiTqvHqyGhWjnugz9s2'
    'KMRr8FwmPC+GeC7HJCypHMPzcInLQrWfFyUkNP6lGHyp8i9VZGP0RA6/lYNvFdBXYC9cCTwqXWu5CqYSUGFTC7GlVIT/TCUXewq4'
    'JlboDy5UBcDJV6Q0W5GkRIVSMYft5AD3Es0D86WGsIlc0M4KcWGDQQylar5aRA8OGVGmIlO7a8C/BjGugv7WFcK+iiQkK2WBCksi'
    'TxTYZ6p9hdaiBr+kGi6FsmYlPH/dSihCmVZWCZYYvgSIAEutMHxgn9W+tL7DHClkurYBCkD7hIrYAftSxS9FfDEpXiPh4oYKj8+K'
    'HZQoZeQhOcVDaRNJPbd6GTVjYmzA92joIGkABZjFHMqAbGeCDRy+5uDf1aIWOtzlWODcuq6KQqVV7EtlWEDYV8V+GQR46A8WWMSd'
    'ViqZgAkkSgB6wNfVknoQ77AOUQFVJGxtovQVlG5RjyCB0sSh4lsTdJQc/K+iz40UirjAsUyY8dRT6OEKwJZKMHOy1K+sBJJcBNdP'
    'SwknRSqeFT/Ysktl/MSniBdr5Un4thbhiInVVFzfYBzVs0qosUiIVMDmw9/4pF9Jll8tmviga3fW4n1NKPZzNRKJxLMSLjsoGPB9'
    'nQLDQgDWj7I4KcdkQpQXWkhLMk7qOp2hM9hASEClQQKmxtWV5eRn+956obyUkMlBp12ipC8vUMsqsJxqdNP5tKrAtrxIVcyLIGer'
    'sMlw1Cjlq0AQHZSZ4CH+T9tnBRnpavJwVa+/CY8G/gSYgzSS0oMrKUGljIy7VUyJK8W0/EHsVpqU2R46Ka/b0jegYanWKQKTBkYi'
    'VHMVDxgcfmYbOqTA0lFaYnEpxd8vV/t81xisN1cAUZxFy0WSu4JMHnfvFEMgviOnSeU73o0NH+xyR4IDNhehY6qe92PLBen+gKyv'
    '8acUisifw5sgMBoAap+RjYWXwyu1tgSyQ/7YOjJtuiLb8MJsp5hPvmejFzfeEzO3x27wyoNBon0tbCjTdvZ9DC32Xb37Y+tXbt6h'
    'ocGAvhcYVCGQlM8BQeS3FkZw8UP2rmFikwUsyIdcgDEvGb0Qnm1kz8MJtIY5tgO4ebgwh1xIZYJngRsBRDf6dI8Cc2mC8IbGrQNs'
    'T0hOiYCWkA3mJTCYLJ0aHBsC3Q1h5n3QoQHdm4UHl1v83DOolxoxQB2O4BF9VQRVwFMvvqJbBzfRjzQIqaZuSSvibd3SROC1hCjx'
    '0DLRfQWaq/YETMVmW74du8xgZ+sAq/z9X/4nW3M+lkF76+DId83dW77Ea2DAjL3ReDBLbxx1tw7wUXYHj5t3UPdSXdh80hgy0jPV'
    'WzqUx77R9Zf2F0ffn8DkBr/n7CuYfGQ78z3BUT1fJ1zWxg7IESzhNuWd2jrA5v9oxNbDIXwFsXEQh65qdfqJcbGcDxQfr2t8PDRI'
    'vC91jqfXPX6BheHDekGN7EU82gxdjsb+Zt1j2og2gcsu7HD1oQ1oRECM/WwYXjaD4Q4XMoSCfglTjOnBOJ6O7RgAiYrZBFj/wZUi'
    'KSi3DqhmNiStT0ByaWheChrbMtnMBHnNLN3DnqObRDiYwDj2kNx6RkDZyEqiNB7jtsdO7TwObtASb3gVQW44huOAGMIx1BG6+ZJp'
    'W1hcC0OmYAi4smFb2XAd/7Esoq5pX+UQUDVcq20c9UCfAwa5ujAaG50Bnuo+qW0aewMP+IC7n1ue7v7hPEMNxvQlloHhS4kxhjTB'
    '96oFmvi0uEMHF8EwBMagFlYf5m7D3chogyjcS8PMMC/AtATgQC8/DTXvdQFsWurNAL9WjUhWqFs2wOgKlEMLxAWVxw8i2dhTi6+B'
    '7v004NdBB2ugO3H1OHnz+cS3DKKfBgQ74M0uzOKxPcYgxg5whsEfywCOmVT0VSbwqFNeJg9zNDFJrm+beiRr8eb/aJLX4qNIkH02'
    'xcdmKXDb2IpeZxSg4W4dXFFUaWy+eXHm5sArcJMFn6EHPae6Ll4fEb+ki3zLMXkv3qg4F1giItyLgXntCSj1YGDZBHa6IMpVQMEZ'
    'KBjlsYj1sHh4DMTl/bbt2RZNiVeHHrYOBPwA8LX59wJBmYDbSQwSz962Di513fFCzo7B4QAgOYoCZB30zZ0aAA7Pb0WGVYJ8qPLQ'
    'X2EbycsL438HmGzYtZANdaEVJndAwTm9hMc7+e8FZ+X0R8rsEjmPzRHSdiRXnNgmF+kiriJoyExo6+V8hc8kFQ6LeYvMYWmnddPM'
    '6jLY6/FiDhQo0amRs+FAOqHSAWPboMcGEWG8v6bVTfcILJiKoWKe1WYKedM/v0oZj+g58ynCOOQYRqHlfdSXgqkgIQKtpyDnYTyC'
    'RkIE97WHVcKkB32cVnO+mgQaQwfmQzgLbNLh3GfRwgpQGyps/wy63zzyThqDOgv47jG9z7O7PtOVTHgwVV3NIwTTLc1bDeEJNAIQ'
    '4gdvF0Zv2oAvEV58CtQrojcivVAkZsW9Pk6ryrsJ0tzNf4OHgPBzHAnFHGPWcN/u6bgd54Vb/CCC13ESiGLR0w6G3nXtIcnejIai'
    'meHyBm3ov62ZAIT3CuGDcsIRq88T6cwZ4FkTsAF/YJUCJPvO06FRn3jtYThhZ/YUjyojvQNGLvDMGrHUBmSqYBo+GR4PvtsOopIw'
    'Uc0xNMMuit86uKHP7wX2Nl0KrwgZw7Z4TZ/LSiE4WwfP8HdZCbvbha5sgg0vF47KFdhADzJmLZyUK8rJkJgSehTTUi0LXsGOQw5x'
    'C4PtjN2JrqFWip/LgPR8V6WTIGAO7NtGYC4ykU/uBg+BbwMfzSlTFHXG3kMmw10gArLbwx2NdrMvSHaBO0Uo3D0kG9+AES/ZjR/0'
    'gC1kjACY4d//9d8EzIASQh/fo4lCKZel7eSFpqXZmL6DNYX7RtA0+ucm9+AEcOtFTRIPcOJWSKLZ8meTnOCyrM4E7jYpwW87X1gT'
    'cq9bKjkmEEZfBgO+4TAwA8GXICGHu2xIfsq8N8PrIRIyr+MaQ9Wdf0WSZ62REQjaR4cmlDhVxgP53kuyhf3Ha/D64siG9ON3E+TP'
    'aYDbdzenO1/iN4xrPWJGjQQfxStY0lPq6uREDHxvgZFKWwfS//d/LWOg8laosx/Iy4spWwfK8rfFrYNi/O0mG8QR5wvxoTlW7wkv'
    'VFkYA+xAsKFRWkr4ugwM5hMAW09iG0iWoZtaDo7h7xc3igy5aJXwgUOK4htB/oj9isUsbCyAJNT4HnvElfe0VTppEAY0RKEJ1H2H'
    'uVgxo3NAHhlUv0jxQXvIqxr8AALaxROIsJ0/RvS/ZcxB2NbszniI0WubbW0sNzNpZSrmjtIoIxrIYSZouSwU2RP+/i//Zyi1g1jW'
    'wZwjeOCJRoe8cG51zDHKotHN8MHu+BWdMobunOOdDKOpphUN5vkZNlshGLDHzvxgC8bHe8KpbfdMXTi2Ox6pLldG29Vvu12jo6e6'
    'hE5TNGB3ZiD7YeuFRDvbeXy1s1Sy1JAI3QHpt9v5oba0pD8DVL8zUZIg3r6dhydLS9ttz9AMFVjXLf8Gb8YmVvswnKhaciIDqv1Z'
    'sW4pQa1Sy505x8gkkfEV/SShhU2tojcmGwRUxzuKU95nuVZw3D27MzoPNOzlXIwX2xLoMWwVAVXA5s3zoqduiN/QEhS2fkPkSpNI'
    'Sq4XZGQHcgtokfCckS7SMkxyHHlBkkCUXqDJZb0SilG3wZZfF3h6DhgK+YjvkerpUMIOVNy4vTiyIQA8TJEE5vKXv9DXv/4V85YC'
    '3mL+bLIpINnizPDGgSYCNN8LT21gypw+eXMIeDGEl3B3AB4UpOLGHQPzxNONL75tc4iSdANYgUZk7BO9HhyMCPwZyXuVQwc5FWWJ'
    'tU9j0O0M1cTcDqprCXjdBawYCmuP7Kye2233QAHUHVTF8fMrnh0Iw0ZCOBMuMsF9hHlEAwzPss9MOXQojaGvQ1v7ynEGhTKsEcqj'
    'L0nHGoESmXzOvebJ0CKugT+EIEVhYB5OmSp/8yJktnTVN+cMJR1Es1AZZKbWwF6zdfBElt4V83xiRKfR8D00SGNCxg7m7uT6jriD'
    'riv+5upK9rBvWDxH4B9jc+7BDm4Z5QIW2jB+l7ajxbsc9iLqpfH/6qvAbhiQwcHip1efhZmE6jrB9ZND7R6Sv2cWAuMbDvHhV6Al'
    'T9JNqKh7zt09s6Bg7zgc51+BgzuTbgTJ41CFzcBdQtHsJRdACKAcAFT/+3/7t5WNHhq93rI22bt4kz+wyd1MLTO+7SQ07PThKtq/'
    'vnw41lcddvhPcePLfCqojz9IpY4p1V40lPQJmcCtlwv69QZawVJlKCHWMOGNTUhczO7So9SZABqYnUVFExYzODRbJq06MM8g3Bp4'
    '9JFdAsWmg0N7tuw9y5CC2gn7slSK1lGMpgtW0XNlucK6IO99ZsJOEG8S84VP0tPVpVF/frYoLB1WBT+WjtOw1qntlEoGdBb8+D3m'
    'YSMtuvuge3rMrwoFmfim8psXuzZI2GanSezSH8KuPZq1HTSwQjuxssu05dUnZ8kfn+EwlD7i6156dGCywFm4Exc7SgmmFLujyPpj'
    '2w/n9I/nO51ogJ/lO8S26PKPxOHEijFvHfwxqwQK1pf9pEItjB+Z/7wDEYs3DaWXP3wJnWD0/y4bR2zejbqmZdtf0MsJ8NvVKdF9'
    'ivKDCd8m70ZAfVgQmzuzkv+x7aD2uPPzU3/HelphZfvkDpm2KBv4JHKV5ANDRrbA8R+h+lBdvvVdrzt3vEIHF7e3dM97gQIvuVSR'
    'lfbkJBUZD+TQGjtdIf9WvlrIivH3TzPgnzlTuaIQy9hZeqY/Jx4FW3N2wB08Cx3b+dVwA6EP7CByGevYrvU1XYV4eIhxCNRKBQ+P'
    'cr8ssaKMuCcQUTMTChBWZ2DpnrfAcPkx+BdGoydG84cHR5jhhPwhZ0lhH09IGCQsWfpG1k6Yy96WwK7rAJbERfSUBBTm0wp9bJYb'
    'QKmpSSDYhYvKxLz4LJvp0HUFAxGzJz0e8XWmKCv2iyxQWEa2EJZj9vN3AybI2IXdoB1l/mOrLBQ/C6ONpswIRvbzj4RRzIuSUAzi'
    'yOKAfg1xuPPJMsSpEz1vgjmYHCtmreGc4D8KeXQr5oqNkLBTIZTo1ak6j/wbMIUU7vddOrJGhrkfOmJxnzvbCtj3zu80HDnKJMSb'
    'IkWMvS8KZTNXyRUn1Y9PDpqyBS8bNtqYfwfwq+FqZIMvA/RfAr4Ne2ISdg8vWcXHgTfc7wH7Z6b+8yP8Gg1SvovlNPgUbKSbkCHG'
    'IEXGYvzxe3IjynGWyH4ofXKZ2R10MUZBP/+DuASJKPHZ+l1IZNV0fZ1zr/BbQxEiFaxGnmvsWICOLkmBNLwwICV08LRtGHLdcUxy'
    '42Q++KzQerdibDlpTDmkEwbmxMlWmnoQthlrZdpUz9b5kRf3ph57eF0UcykL7Cqb9U7+n9HJumuQj7vXR+cZpiPZfODY/Z6g53t5'
    '4b/gpTPfprY7AFkU+D77zcTwWPREKI7voHIDbS05ll2E6pic7SOpgPneh2AI2+zJVyR6FmAfCsG8aTNDst/YUTAEmx3W/kFHisGc'
    'ZNnfwwlaF/9GZ7fugjLxO87oSv0o8NtPOu3H6YqOryPHZoJ2zDztjeBsobCDJ+KspbWnh/HDe4oPDoO2YWidju74P7Z4lPRe/t2z'
    'rT3VYVGBoGIX8EFcXVnSHB0vHxvulsByYbPspTYeKcILw4F1CNpY3ogx7CXBIntH4c9R/yyXJuYb+P4PuRyenBmdwIsfj8eB++iY'
    '+pmHs7gwfcFBN0wsOSZo+9yTGkp5MMI9rmmin0JXJ/9xvBRONc28kMtBR4Em59uq54cmvvCxxWDYCk9qyW6ou9D8oRqdFrFiW4Jr'
    '46qrpu5GoUGRhZTVeyLzfobdmb1OuHAd21PLtFUtlSHBS4W+B0HhFCm6uGuEgI8d2Nj0LMAXYGVFl8LKXp/aC84rB016g3nfM31f'
    'WMUr+N9FrkkRfUvhxdU9Z8u1DGJGF5+2FGA61YCkf0mmgoh1mhj+L2lyjxU89K3FmeDvUiSc3QCfEED5xMytqnKzxLH42LZ+Q2fb'
    'AbsB8Qscb5bJ7QLSSFEIBiHpx2YvwUZiLF/DV4wu8D4Iu8cBGNqaaiYsR7Qfm7rWnvNWn5gTIJuEvhx1x18Av5D5W+fgvEtcQaPR'
    'Y3qMPeZM0+mjB4QneMAh2BaCdwlSCQoGMm3Pj9xkFtKcJLZuGqrhdci96zjsKcLgjc6XqJkj2A5QdmefmaRC5VjGiTRqPapZxswl'
    'KwRMhYWlZJ5IxHtEroaY/HnrXitgt4y+mYEPo/F+Qw+TtP0A+sFsSdHshMQHb5jIdpARmxof0RqrW3wdsTfcWCK54+fZBesBlusg'
    '6dUE4CZHczI244OJS0vJiT9i3nl8EPSLvFn4hK72IOFtPNKFRktjJeKetc/h2ixp6wopNTaDSLlLUQ23a2yRRXLxvZeTnoZJCaa6'
    'h8l0XM+nVP+66ul5Z44hqRQUgDaWebRX0yGQ2kYLPnOLw9hPvmF7Hddw2AEGa59YChM2FkSbg1/+8gsluN/iMG3tC1uyKJfzkpSX'
    '4G9VLG3t4XtvPCTSgvcnxox7Ej2qXcANVBGu1c4+2eB7aCrhXnbBfmzZgZsREzo97m4UDAdduvDWrFi5DnBE06OAOLtLGmSewcG8'
    'hwAK3rfRAzVJ17hIy46c+Y25tsM6Eto6Pg0F3mkfs+EEwFI0XnAxQBCIBmMb2hQ7qpIfemI4HXsM4ig/KKIOUGQCAsoHE0JaGhsD'
    'B43phSSJgZBmcSEsPDVjYNozcmdEjAAYAVGcMZpsE3MUmxEQjH3DhKZcnQxXeeEQbT3ItOk6yPzWL8I/761YX/hPlJSF9WX3EaPG'
    'S5ONG66Ayh7M0kCP+5buE2Rkp2QZKHo2OmGSeyD6QvM7tvYoGQWeL3mhIyGMFXURwgDWHYI9HMOgAfcNJol6up5e9SfoMN4FPy5h'
    '+bAohQlMIqMMWENglADaNg9hDY5R2K3GLBAaw7OoJN2btLMX5s1gfsX4C9omYye2DJ3AB4Mb3/FjZdoxqWeiV9jOp7AYoKBTcBaV'
    '5ipahOJD3e3pbB7y/ApoFopL+SN1l13fvEfaOAj9obsvNs4AYJdEB7dGL70mGloHEKkHxjj6JB/TlbQOZQuh1vCs1mBJQpjpMDmJ'
    'VIR3RcfPeAKMrilrsUzMS0WlvIBlzB8xXHULhFZa9CnZIPAahTCfJVGpClupxhCDKGGPcJIIG60VHQyuQyAx9myPe34FfCqI1QRa'
    'd0CEYu7aRN3k1OlhD2lMiyKXOYlDSygu8fic0P6NdByVxQnmzscx9/Qz0mPbc1wP7PbHD2zzx49v0Rg9oCDdwRaNqBMe1cAnn6Xg'
    'YR7uHlvVgCuA8uNPbfJVpdXbZ0DH3HCQJQOqb4fhyY7qqsy9msxsAc+mNQU6wKQt3h5z444cQ+MES3iRZ8M83GOf5/yzSQVjM/DC'
    'YWEyJ+MrnGsSWbrkQUgsGOHHLSBYVbaYEeG8j4cOO3mgW1sYPw3vRKcEOOY8z/xKGUWxSUV2gcjB8ztFEY4c5tedvMDCc6O+6Cbw'
    'gMqHIHqY5NCPV4N7ATJRPj7YFwCxeRwArBxSk4uD8zCyxgrVdHeMbbl0D3u0OntxRGQ2EDZFLvO3phQVHrliYwGWsi0OZ+Rk4YUp'
    'KtYRpgh/S3JxgTCTAhtxfxqWFxe3uGm0r5pd6HBoWGPKaoUbq4FyE+5jtLPGbA0eM1IA+w7Ck+koKU14Td7DGEOKkOHqQXgFS1RF'
    '600bj+Ow+x15lgIGUlnos1B+nDREgylajvgIADt0H9pgRRWRn055eDWN8E9bR5wv/P1f/uc/bTFZzTeGeCrPGmBr2FUNEE3YYAHv'
    'fqMgjy5ZiTVb91Dr6dh4zaQRRDIw1YsZRUmT5fZd1NSJZ3vsUC3Y0FEedCMxEXRaEoU2W1FxYUVZYoKQ1TI+us/ygNDmEm7LjFK4'
    'FPRbFJ/dNZgMBC8RTiYT8WJ8jMwZfmWykfRKM7gQwRgUG2Y1ELapG5iZf9rKTFsAa8dJNkBi2vcw+oi3h6lSgtIBHwLyRw9+JDDS'
    'LIH6bICnawfNq+EcUD30kgc4mElaD2aAX8EWz1yVPRlo0o8HHMQzLcX3Aoos32GTzGWoQEhlIg07GYAWkJYENqfkeOX7KqWT6+b4'
    'GS1PO8FtACaJRWxboGY4xIjIoR/KUNf9JFYIHogdiPIcudlcMAxRmfACjBHtNMwtNM43+ewBiPnAfYuzaMIoXeOuOh4zzazF9yLo'
    'KHJtAd+bD6eNmyfOqvYFh9SpwK7JTIUWClEwHylmN6AEPD2uRwS8jvASjejIzOjqdZi2U8M/G7ez5FMNuIsJDBBRlZVCky4M0CfR'
    'q42E5uqYTlVjTR+qFgz6TXcHxTJixvM1e4J7PMAaqYsLXJgLsQgXiJ4u+gpt9wADATDgGoWgoQKzhea4BgOYfksxVxFj9o1ALAoz'
    'FPAGA11kiiVQqQrkLpo/RHfKWoKAMqiI100JxTCfR3dMbnMcYia2aIHZlhEWJ9aHRv34usEO3MMzsNjIQNgBqVrvc14ECpZOErIz'
    'boO0QjujGijPxFVcHeQKFDS6wTrg/PsunVFtgFxirVRZwkxjDJOdA4apE8M9uY+ZTSL6ot2EOBin5SiEiNhNxG0iKvHS6PVMe9/U'
    '5hP3bhuLIOyxrnACfHWge2G+JTpfjQldyGkByCjlZshjuQQ7JdpQ3Q7l2un0bTtIbBHuwbgbwMqDqjsF8o04KAkkjJqYDhSxUapr'
    '+BRM5WVFUoUaeWI2eaZXFKDaDAfiPoDe2uVUQA0pLaohAcA4XV0VSIEmL9yAGGSI4dwQgNnBALwg43K0q1JqJNz31Y4fREBS+Bie'
    'xyDUbI5TQCeXt5HRt+eQHIkg0L7SRdYeGCXQv4Od8yXWFZm50RN4Gu2YCSOW4o/NMVfBuioXuLkyiGXZ1Zls9Xq6zwSyPM+ZCPVY'
    'glQLVc0OZalWPba9dA1u2/F0VDL8RLgchdCx8sF6c1GKJp6hTAxjO/1AKm/rZDI10PlQZ3IIK027Odt4cPTxCWZwqBbPLMvYnJFA'
    'XWus9SgDK8BHs6KyA/9w4Ty+cmFiR4zc43IeEmA+2D08xiPpvB4b8X1Kx4fnapjVgGJd0cJHMmWYAIqkMW0PL92MJ8FlUmGcvKPc'
    'MiQSbILwkrK4OT7x8Nfglk+S73E9ksG1IJ54pCKjHQZpj0DfiYx2KH2z4FvbSmYhh/kyiV/jaeRv+BMb0GjfyNovozPKaOV5PGQM'
    'q/HwDleE/hCnwgDiMBT41EZgaWB8NDGTXSiGG2wLDiAKzj64FA8jJvMgw8pg4IReNPq88BzommH0MkzDHjZLioiXji/ei81FOLNY'
    'v6/yCOgMcCgdEtt0OyS4BFHOzMRjC4FrfQeEtDl0uRYVZNALpMWtrB6KFiQfc2RjIhg3LEdHFPg6Yb0m8RGRO9j4vQg5IpMMJX81'
    'vIC7ZK1/0CBHSM/wQ8RnZrkcU4M5YNupOeZHKcRCNAMFt51YZLjKxhaaPcJz74UTBM4rhNBqTrs2KYqBRV6odxmHDEQd0nVDGw4q'
    'ATAMc6xzTS7ElIAjMttvVB2FdoMp/T7XJnqE+CyHPXAAflyMe8CcCU/j4ACZtEfSnrBgoGDENW7iU6zWY3JF2OqGiRHRersJFhVL'
    'yhKBiPKSMQsxLVykS3hcmuAaBSExk/FCM4DBk9EbKcYd8BlO0YAYutmNDD5sG0F08dV2tnKJm5vmqlMrG7T9iL0+5tgQtin1GgNs'
    'L5bNL4CVbZr8qGEnPjY00G44Po5rKFmx5Ns2ycp8p07KCLR8OAu01HSqAVIAZkRgtotYBtPkhAjnXcaZsAojEBVfINox+wy3hjME'
    '8rjZFF+xUxTWLaliZCnmg8MaQcKFuNjB66ksnfAm6KQUF9HpCO2cHm68FpNMuXhPyqGGizUHvf+Y6ViYAYacOv5pay+ykoKUodvo'
    'dNMeG+RfpA8BcSahNMYpKNhJ0KiRsTWlujACbCGzE5FPFhgxGxUxh2XjSIALAgozewC4XhzebQfEAdtS2Ku8M99JDCHMJInbAYgj'
    'OCJmP6fzGlw21+6h8pQXHrhixDvpMDXW5J7c0ZnjJusmZa/bPDRjxpQRdtJFFxYw4zgePQwdDEHn1hj+GOmdWfiZgTu1HMn295nN'
    '9iicwUA4I3LMuExA2OapSxKm7ED/ZL5RO9wS3ApMqVCNy35WnCb30tbtsAIxVGYpiOe9Z3Jlog0mUmelzucm9ReBGb9ZKvroEojA'
    '3hbkbCJDPZ90Jo3HGYfHnDhUJvam1oKxltgq8KMhyslJybqDI/iYpZ4ZLvVwwUh7GiQSF4NUkORhvwVLugq1xLwsgZySscPUU0c/'
    '1HUkYtGS41UvewLPck8HbjHT3wIyPS1vb39NUyAY0/XhkT2MeIFBJzhzD3CIR3LxeSWU5bGDGP2YQ+NHsL9N7RAG2hwTEw2CAFuh'
    'UNLBcrhEt8E1N3//3/9vBtXegoTDcDRbyCG0QxdflkKaJC523pcQ5PPCNbAOtacHRlr4E4rfIVBoltlkYRU505OAQZMUagIYA5Md'
    '803ktop2ZAEK0/iklhfa3V/RbNrVMRpd2oGSbleY8xP/duDFmQXCDluqJMQo3HlcFqS9lif/wR24a1i0G7AVYYTH3dsEFuC50axm'
    'mD/ZrKZyhgHLtTk6sxSPmXO2rhLbV5hEQBdPLGZYYixjj3DdYTY51hgmLWOD5ckZMX9qsj5MIhIfs1/jRJAZqc0Ix6EDIG4XjFZ+'
    '/RwVMw65gn5z7PCTZmE/ynazx1Ld7LHjRG7chv/DNG+hgpOexjUNR14VPKEe24FSDjPbAaayoo5q6SZn9LQWGmW4DoITBjscXMJh'
    'OhgJLwdhZ042y70WKirxDRIq9mjrK9BZBRvpPNzpFkfMRUmUM5jhLGQrKezhKEO71ZCh3PrFksVypsmCWU4C625of99PW/ADzAkI'
    'kVwCAmUN1YdFvF/ScMpIjUyUTbk3ByY9ZGfjwfEH0wKCrB/RwRmWyalTZCVoaUypNethhQn75a943Rx5dcWcFunetiUupfguB3tF'
    '6BoqHfycS19qkr3vBWiStc182QOIHnXQafqBu5nHf1GegD6lecNrK/Ah84v09kJMZWf8sCbIQwRhG9BxZ4tmlM5SdZ+n3maH7nRS'
    'EfhYLnHkWxppjoDiDvrVSG1+t1poW7LJIpBEfnad2h8ZXp2+YWf15TrBmFdeEEeaABA/7YJf8IuOX88dog51hM3/5N1yOIIWTW2U'
    'Ss+1Fmc+yidIWeNDlhokn1BpIwrPP2CkO18eamyU6X1wwztjUgOk6wCXpLvMvB7wJy/CWXq74Oeo6dp205FJnyerIDPiHmwcKpJ8'
    '4sZL02i7MBt8db9yFxFdP/s7k9QTcPlYthnM1Jhrz3OUuTEU9pjRBG2nzNSc2H1jW4Fm/2yWRyGYw/Wk1GBznOIH1sLch8FFTK3j'
    '8GKKJ10lPXrrZ/eWRrLH9aCfcBQIsxKxg0lmMef4QcI7239YjOLP3JGaJvarJC5+mdr/0+TdzI4s4vN8h9LnVkK2CIgwDIvKStZJ'
    'JXm2zkS73As/Uc5LeObHs/BQDTsWlv8YKq4LaXhcvUPZxB/o05wHHvbLsurQlbYHN/A3K6lO1pycuoaWhLznUoaP7NCSIQUY/RJL'
    'BIgpjNi9xbB45KSvWhMVR85+goJlUnu94Alq3KY658+CEIvv6OAJSK6Gd3XabrAeGTJSUgZ7mlNyRDqSBezFpoPmYlGOFGOD4m1j'
    'betDdWbqVs/v4w3ZYqo3CliJonepw8S8YrbxcFLDdOJbGUQDJZ/sXs+MJ3pEfZl7Wwz0OeWWjpSVL1BJ0EhM+g1aS+2RTGoZtDV2'
    'YyB+CUO/YyFxUTF+Qx8V9PgtftklH/HYnZfExV1S7BhDo6gQu59sSbG//+t///u//o+//+v/ASo3L8/SPWWWjtK78rIWS9G6vHCB'
    'F0S+sKRcWMSwtFVNHfFy0ZMWf9KJrsVd1cBxMCHh5Z4rCr/xwugXvKqcGEIfW4lFDoGD091UpFVETOz1Of5OkcgJ854LkvKSJzNI'
    'eir6npKzccwHjWfgdknn/7yKFAFyZcQiehdClsghIojx1UNeHwtF5DmFk8RMhR90L5467Zhyc9kYp8KSp2VtF1QxHof2k4mFoygz'
    'eh6GRGbHqlIZumx91T3szBzzk/mPZxtswYk5WZbx2vJZWgt8jAFmaZd/DAfLSOYP1ZJpBlJpPTpDDNW3Y1ex/qE5lLN658mO/92y'
    'J2fBQAc/iasMmsETDknzi1cj8WY/A4znu8YA5EUKHIhphPg0CCeI35X08hXQWCfrklKuSNuZIik0HX4xXDYKqNleCKMh5hhE0Hxl'
    'nKEZdGWym4ij4ThW3GosAEFlp7VbWEvQ54Elz4E7L6QMg0ZYutWQR71SsVVXZp8tNZws6Zl8S5Z2zPEtKsZaP8VfG3eB3i/re+Cl'
    'WAeH8GPj9p1YVt3l7fNSrP27Jcld0DLqru2Q0rLx/JiRBf2z13smM099nh+z++hPiLmnMi9HHP8LtEBukznWxHLjyHrgkQgwZVxs'
    'DDEdzjpE38XYrfOJ0LMkB0llFcecD5gGaZkK15e3Ds5YZOTSIsrWweO43U+VWt5pG6HFnEYA2j1+LM157tLlLLHLIn9Zdg9PQvDI'
    'Dj9P7+fxELwgIShe98IOLvFw+md2eNZE0yJNWtdIGIySm9M9UMTitonf5rhzHLkDf6PY10IsRpZAQoeEryVZ9fzPiQcE+m0G4Dfj'
    'YRsfxkGX8nHYvwpgjs/TzxDJkgzXViLzLc+uzCwXPLiH74KXP53CdjPBx4zDwzlfkM380+LOyv5/YtLoGsFIRGQEETr3rEo/TQ69'
    'hvXzKah/WkKioOwvikg8ZHyb3HooJHc/DF5PheXTAiYi77+U5wv72FBkIuC+LjPFZtFvmznHCO7lgl93LMfg6kzfWIupoLwWpfI+'
    'CHx62HxltbFSIKBalPemjs4yYXs40eQ+s4EUE7WRqE7B1AuyHq0n89DVQ7PJ5p10bPMKJjvsiMXv0wJ8qpF0A+4yCWjDCdR0k8bP'
    'cyK46YROa+oSRLwug+hT1RkeBw1wTPj0Ze1LNqUz2zU+bAvUzYdxzEp5bEzomJVpj2xHzbE99ct2BI21uRFvXXKtVmj5OLTxhqyO'
    'jbHqPtob2WwxNhQ3J7EnLPVq3IC15HYp5oyqeixEiielQE/svPCXv6Dd/a9/5fKNby84WaJ9SyC/FmrTtrjTYeiSgs5IwAF/DVJj'
    '7AlMaNoT/vxntDn8+c87+a2DJUMm//CtpKWFQFlpn+ramJYpBfv/+//EYIUftFkzzxvdCGJJujaqc+hSCiUaXieZxTNxReDq3IUE'
    'yPmwl5EocCHb4PcCmfFCqx7LRIT+NL2xoVF8/dgVtvmhn5eKE83h2yA5Ivpxcc9Chc7zd/Z4thp0muHuOWPmdhgmxwjdtFhuosim'
    '6I/9TIticIAZpDwzJihm2yZdc5NaEWiD2wsjWx88O8JI21TqrIW7srOtgFh7uQ3wSufhQNHRbihm8BQ8uLzh4P+R+8L9TkbCTKzE'
    'OSBPn+9GMIJD+lkwYhX6SvAyygynJEgCX/FkfmlqgVfHlJo8zIH4WR2TMnfFrkxhu1gy41d6UJY6SSaXo5Hh1o9/szPKpZY3gRWN'
    'me+qmenm4OUNDR3/pmc7IiCeV2tJIi2eI3PsHgNr3Dr42y/CFleq94WtJFWh/1nM+03BnzycBB3SyDlOHzogDBr4G2eUPNbIhRqb'
    'ozgVjbmxkXwJz4Z0uwh7hicCdOUhq8x87rYsGN25hh0W8Sf3uwo6FPkXYcvAMuIefaebtqB1CXkW8z8h1yD2dhYVnEdf+Y3O+4IF'
    'SiR7NADdkIDE01D2iG4mwme/ym1ZK8r8MTvWDdsKnfT+aSyKSqcvHzzj9j8kb8akTxorgQkP2TfngGLnWd4t8m4y0MMWl2iPYiD8'
    'yGMaHTCYwx056sfcM5C8PZ3qetBt9JD5a+R5rw7vdGzyL6ZxcMgd25hnoMCetw9YoCOwFV61fZCKu6NAZ+42GqVRxhpk/QzSjvX1'
    'eIZfhwLkgz6i84mwkwBSACyE8IluS0VHiaAiZTiKgnWj2nzx+YwFm7GPUS4s9VbQghwNizmU89teg1BFnjokKB7GtK4EtDFzdNeg'
    'IJuuq+vmfD851LeoUzzIYwE1tFZMYAgKnxh+VDK4apM7t8QWneWeSMNRgMXdAqz8Z6IxKUkvUpJeSG5nqcD43VgRxeTkfLEmVyqy'
    'IhdLJUkuiyU9JxUjOspJpVJelCRFkcSKIpZrKboS0xSki4qkSBtRkB1D0CNCLjV2sU5gsfOzFuEugWIwwmgqUXbTtCiDCFAopZzq'
    'dinwEbA2qJZEyqCiTeHWM5+lM89E1bkT4FsS1RcbZH71+bAEvyA6WY5H6zJnOmSsi8sdThVwEpvO4MO52otmivCLon7Y/s8SfNGY'
    'E6nQYVgRzF4ngqRD+U29iJNEOCYncUxO4lhwqDrkadpcPccyvsRwTREr+Wq5LEliVapVZEmJsExR8iVRrClVqVKrKWVRWYtl1VJN'
    '7KSwTMrEsjgbDAaN4MZ4QwzrWB4B/1siTbnAubydXkgt0Q5LiMPDWFW8D1LPQp9j5vjJ+wwaxGCCGEhc+4ggYgHsWe09Ix8MmsG7'
    'HnMYCBW1BXxuOx40BKLyQmg/PMDoO5JZtL1YdD/fDlhoDu41Q8yNFEQQhzk2w+GEqUimNou68sK4dpxRUtPWcDMliWlKEtMoSTvl'
    'p9J0XzXMBDMr5WtiRSoXy0qxVqqWqzEUk8pyHviXWAQ+J8vA6CrrcKwrVjuimMIxORPHnAMCK8QXHsIPpcK8gLYV30GD5dq9idap'
    'rWo9xlcED69vCwv9/b/9W2I11XRefaLwjF23ENszn0n2iOW+oDT2dDs5BSNbZKwWihGKBziDkTE0vIy9mFrhSS9YWB/5OVPqvz7g'
    '/xwopx1jJ+Ecc6+qQCjkS19MLn0xufRnTEOLotnDXPy/GxIoGyGBGAJcSgJcWsTVKO6SJ/xggSj/zhBLIcTlJMTlJMSXiz5rcUCr'
    'lOOqJNVKSrFSKpXjcgK8qtYqRZAUyiBPlMryOvoql9Wq2E0BqmTSF1mAOLPwUcsOvrvhQ9gXMVEewzT4GT4nUSH9vBDWLCTaa9va'
    'fKFt7aAeFygKEbeL5ISgMS2qFJNOoE5yz08Xj+CJd9uI7/MrerigLYekkvg+vyecyMgZyH3vk13fcFGEBequhSBLrtmsI2b5XNF0'
    'osCmrV7bk/gNJEao4WT1UA8PJz7ZC3HF8E6QFT2kuPGGS4A0sK7Rr0w5eVAVBOaGtK6DQyjJXJ0+2wu7hr3ANjN+Ifu63n4EveU+'
    '2VsTc6kWKJPquj7egj4Y0r59sie6vKPAryRYuz6Pyc4eP9kZBkKs6+L2s1yFRUIGYeAF4BmdMeqza3EtOZbGZ6nFIF7Jkimt60vc'
    'oPFCnF0X4nsE2lv0mKzO97KYrBWkEogn9qGzwETCoTBLmY1pVsIkqyxDR4aSVElurpXk5iqj4epaHZA4T4m5eratxTbYcl6BTRVV'
    'JNTEa0UlrYuLSiVfA82nWJKkWq1Yrf6OVq7NtSee5jS4kDuaVVcP0gzwvTIvUBK5eGbRUEbu2UKUCs6FEu0glXiWAPrACgSxrFGf'
    'zthP2EvoDANXjNKSZahLQeuRV1+Q6yJsdC/K36GhvQxNRmTmFGLpeGIJ6zgapeCOKYaY3iLb5iV4Y6uAoTBhwimKtdG9rCibNYpT'
    'NYl91ST2PeJt93FxrgICW0kpFxWpAiKnXCmmsU2qKPniCmyrbGb7CeGrJeGrJeG7wysZ48KmXMuLtUpJEsVSVawqSgK0Wi1flsVq'
    'pViulEulatpgUP2MWcrDmcFSDoIQWdVSZmgpZYc+tGdxeCu1fFESy8VqsSqVKpVaJQ6vXKnmS9WiUpVkpVIrV74ErpQCtw0ARNCm'
    'jYApK2DDNA287CyCuCrnxaooS0WpKFZEpVZLAFwt58sVpaRUlHK1Uil9DWI5BbHOgYigTpmVpJRdCY+BKDFQDG5ZruTL1aJcUYrF'
    'qlKR5CTS1qqAGUpZrgHoUqX4JbiVFNwETgR0ykIhpU0UBt4W8l9I4InBLdXEPCx9CbQoWSxWipW4+lQt1vIwHrlcrsmgB8qVtbSW'
    'aQGLYEyp0lJKl2Z3QUfAFaVaXqpIVUQE0EVLCWQQ5SoooRW5KJUUpVospqlNUjaCjtMP3b2KB1EEQgRxSpeWUsr0cx+PXWPmRDQa'
    'SqUqQF2swf/VUgzkCtBbVUaFuVYqg/5c/RrEUhLiKYEQQZzSpaVymkGY2h4XswEd2iQQx7d7MV8sAqKWZEWuKkBysQEAH8kD+VVB'
    'lxbFYk354gA4OVHMQ3R6JwQxDfFH5KEENaLhpaQZqZJm2My9Lc4EpZKUhwHBqtSAdxflUpw2YanywMmBn5SlUlmq1dbh+CoLnDHs'
    'BeAB7C6OZQs9QfaZ/8G7o/e+tVVPLxf3CrX3QrFev38cvF089OqH9fs6/ILP+nGh2Dt7fWzeHL9Ih49P4tvFU6MJ7xpQ4Oy8Tv/c'
    'T+v1Q79tPcybA+3o/KT/9mzUz6A9qN9gReqH/VflZlrf5B/ou+a/0if0/3R1X/8d/jEHby837/itin+OHubPJ6aKgJ0QeA9W8PuS'
    '/TaC33fst6KdHYr4rcl+z1snF8f47Y3a61up30bq93vn7ILqExDHM7991nqP4KN5un57LrWaNEs9/NOpn13Xm73Ds3rj4vW5ZfeC'
    '0u0yTP3xu4QtDdh8B/NsDGG+/GITe1JxDOfBq6NHrH/Xhz++V0u0l5jvl8N+Z9iIFgNqvg3h/d2lBd9vnuFRo4aPnXYE/+Hq8RzV'
    '2XganXp7ejipn8Jn/dDE54/3h+P66XX9qgeDPj6vX9frs/pxuyBPD2H+mseHiGzTZgM+Tw7vm6eH0+n54bRzdjitXh1NB9eN++pj'
    'o9+4azw0nk7605fG7F49eWg8nB41Xk/7onY2q3Ybs45xcXSuXxxO9bNZhbV934T2OtBe8fyoXtRPDhvNs35R/7n/KwUY7sNR/Xha'
    'f+4d1x9h9vsA+qxxWKje10+nRFvQNzxL/HPdOLx/Pav3zgqzen23gbQzvYey9wBf87weUM7DSb/eu240es3T86eTh07z5KinAmI+'
    'XBvX8sV80G40L44vHnu9zvO5eNMYjM9mTeVuin0DEiE9njDajf/TOIK+Tg57nXMsd9OH970GwHgPc3zdCPs+hPo9gvMR+j5sPp/M'
    'em+n/cMZ9O2ePRQf7w6rh/fP1+LFkzc5K8g9WMppA8d/3LivF+q3jnTqPPRm5cuPD6dRexg1X69PG0/0cPr6cNdUzdPjw/5/7jf3'
    'zdfG9bkzunkcesfPR33z8aL83nTcutS7Prf44/rU0G3pUp3evB4f/a//vgevjy8eHuzj+ybMyOPcb8i9m8Onptrv/6f4VlAvL0fl'
    'geM4z06rMng4a85376buuN19lNRHdWRWRs3bcbHy7rUPbVW6N6Tdod+stG7v5KE8n90cvSud2UR5KzVnouZ9iN3nJ119sG8KzTdl'
    'Ytrvzq7y3JGM6qH1MngcjYfDuQWCc3d+Pbcc7XnXH54bs3a3aD3Wq8P5RL1zzbIjl4v2+8gYXhSmRx+3kle5VLV2v9X8aCkfd5Xz'
    'kl4TPwZNu+ae+9J0dPVU/WiVrLPS8/lk9+5t5Dztvt1Kdx+31bs59Dc2VbXcHDkvk4dm5eNaVORh2Xl133dHxpV59zRV3qoX7/3y'
    'yfuV/DCtmHfl64+HO+vMndWePnxYNu3k4+Xo4uGpNXjV7l6tdqtdvbgXb53KlT0evw69YvWlqrp9cXZ3e1F23ncfLqZ615EK9fFu'
    'ZfKgPIlPSjDhw+Jbzx6Kh/al+t68Po9/qzujo9NGk1H5PWDJvz+9woL21RFgwoPUen44rrzKd09+/2py7jRHmunfTNrl47r00rzU'
    '7qaVcas1t423yu7o7lQ/HBT1m9tW1/ZmBf/ypjZ7Pnvov/o3fuNJ02W/e/J0Wb8zX67mlfFb150ojtZqjt/u3q5OhrD4htLuP5wB'
    'k5zNy7iLmru2d3jdPX+stR1V0WpHev9pdNwoGVOz8O76V7ejC88a9qXbmey3yq2ROXYKhy/XTelBfhJ3G9VutS6Ku+PiyW27L91P'
    'DKc4U2a1j3eNRtp9Or67aGZzp8P+yQ0Val67/wH88UnTrkTHH7R0c9QsNKWrU6ncGT1a52PxqixdFcyC3HH82VPrxb59OLm7ebjr'
    'nzSf7uy29VZ+hQ1Cuq5NxIHSq98Np7VnvvOMHi5HrQe91Hw9mw1aTntWMdVd93Fkzj8eWp1xU2x2SsPz98ll22w2xQ9Y1l5RIZDO'
    'JPFjdpEF8Mlp/ZWxtNebw3vO0vA3lFLr4slp7wYK3GAB+HnY/3d9fySfaC9nc/VqYj/oyvzOhOfPHcCzefumNSwdOyPj1RpbvZer'
    '1nwkvZxo19VX02qKI7N12Tp37Ynau2nNbl/Ny4t3pfV213opnkp3w7sXvzEp35jSa02+Pdv1ao2ZVOiOBjVVrNz5JWl45Z/dOe+j'
    'Qb0uzlDYq0vKrVK71q5uLgvPbqVQP7pWLibia81Ry1J1ULu07t5O5uOCPhq3auXdYu1IPpS18dv47WmovBae/Hmxotqlq3Hpo3R2'
    'XXlUnad3+WJWvti9dcX36vAWucdNXT1WTMu6vPDr6tH7/WmPsxV4ATtR+x6ewSe+oH3KBnG3HfwIOBDbqrABvoH9x5Y4HBaH3Y5/'
    'bp7MTly7Vj69wULSrqO+GKr1Vvswmw+tp/JMefrozTsvV5NXUy+8jZrDsv+m33UqrnE+6bfkE7F18gD/3+pST53q+tuLN5mNytbr'
    '5OPprHX90NqtXYg1V5UrT0fj5+JQn7d2xWHBHcvlhj4eD62P5rT6PmhrRzfqg1qenI3vJYT8+FosyGq5+y7NXgbSR+floerpl51d'
    '53Wujbxh6bSiOoYlWbt6faJcmeWJXhyNJmXAURps7diTXc0wrrTx8Nx5Nxud815pOB6NSq0b5IrhDB0V53ynfj50A3THoRARwLfD'
    'gW1PX/E/XNRD4/2wN/3P/1m3p8dHtNaX16eXp61zi/By+moCB3w99U4YL/xf/NvhQ++ekd0IUfv0pfGIjOuZGNcFrGSLMa4hrG+L'
    'GBe+b3Q+BtfHx92aM6/cOM1aSxXlwtXk5s6svVSf1MrV5YvX747Fa2vyOmvL3ffnu2r94qWh353Nj26q0NPt9Vz3vX6roFVPpYdC'
    '5dIcFR7eX0pnre61os+Htbbn1OayNetI2of6dGTvPr9Z4/eK3XbKp1D/7vrKuqlOXgon89t7q6jKhftZZdi1Xu584F5u4UQbvRSH'
    'Fy2/9fZeand2O8faXQuRtHQ5bg1G71eDF7PgNpul26dHVyydSCfVptv0C9NDSSxU6yflQg96ErGny/LtU+nyffd4cO3cXdZa1Y8L'
    'r3Zf/VAL/Y+KUXh/uJxI92Ox3Xq+2FWN1+pkeiPWrmCWzuryrXfbstvlR+ts7NTK/YnYlPULyVdbg3n1dGTNRn7rfDJ+KQ01Ve5P'
    '29aR6rxP3ivXbUdCriPdXkh3U/l+fjVw30Yv4ovaelJqyuRm9jZ+dqWjl6ubuVG6n7jN1vlIL8qmdekpRW08vqg4R7Sh4PKdlNLr'
    't259f/I9PDttdHEAbsDLn+jH4ej2tdwvuu+Xpq+4imiWbncldddvWla5AfvN5O1k/PE0ebk0z9RG+8K+frkrHR9OL2+8yYX/PJ6J'
    'zrNbnu8+amXruDOTuvPT15H4alUsdbfsSm6l+1A5ti5H8I8J/z+PHF1qtXTpybqeqKrycFt5dbrtu6O7K6tW19z5y7M0Mk/sYuFk'
    '5L7s6hX5ApoulOxOZX7WvLsquU5nXna1I+Dou7Y1rrRqzmjaKQ3Kvlk6+5Dm49Ftow7dufCvXb/ppO1RzVkV8EOqyFfSXGoVxdal'
    'sVscHr2OhsOX+m2vWBhVzM7bqD0X31pHuuGfjgo3d0ZJnJxqL50X88rtKrPLwqTm35Wc6vPdba/dPpU+rme7p7XJg/Q0q+mvIJu2'
    'tHGl/VhSXWfcvFJazVH5qvJUUY/nVyDjf3SOiuZHY942ne6jcVVrdW9uS0+j3Yuy8lBudy+KyhvoLs9SVe0OHHF84Z+9K/qJUnyr'
    'FqtTbYD4/344rz7deo4+u6qdlN9nzsu4KtbO/Ov35+OuKInSw6Q5Lx5dwE5+NMb94JnhiAZshmPGC9sZCF/YzvDZEme3WlNryrd3'
    'yuz67LlmXsiwsG77peieFe5v7gblmvFa+1A6H9cfZ83jkXzT/ni56Wizk+NSq1JotM4cv6n56u6HqKvWZe2+1n5pj6TXQqPpqnbF'
    'nEhO7a17cfdQcuXdhxks7bjSGY1fLsujctnUR6CVtVrm00tpFzZqX3wtnOoTu3BxPdcOPyatyXmnZ7ass4J2remz0cnupDmQuhcT'
    'tVOeqO6o3jEHbzfKxUip+E+DXr3urbFj+v3S81NfGUxe/d3xR+dJGp28Vo77+vjk4bL9cinfTB5qN+qTD4gxL5wXB6dvxtvug/FY'
    'aT1Wbt/nh5W73tv4wpKbk1f9oT1p6qbaqjSrYkWsOYNr/bIoPwxefelqfKOPn1WxphpO80U5e6o+STOrWG7K1bL0YIoX5Xm35bZr'
    'J7fO7Ma5anWPCqeVu5ePd5ARTy6MJ/GmN3PG12W3+HKjWjWn8OYau0736YVYVOnev9EuW81LEFft8qWlGsNdr3QzKhz70sNdp3U2'
    'nb6iiaVKe+7QlkCk8k65mkmv7vHN+2npzry9Lc5NYG2Xvmy+jJ0Xf/QiX8jWWfVDAj3Pb7mGp102Ks3d4dgu76rNwk3hfNpxm9X2'
    'yXvt0X2XHj7OrZ7Wn99q/ar2ujv86BjGx0P5rCL1GxXptl5+L4/nnUr7bHrjtU9fvGen4EpOtdE/tqDX+bVyPppfj2ov2ljSaq3H'
    'QuF60Hga+PdSuTaY3ZxMimr3uVuST67n9brKTG+7arl8pd1KmnZzqV+Opoe1+vSqcN3R3p7KcuuhOek/1Nq148OJ9lj0rwr38pU/'
    '605uHq3ZhfJ2OLnvuHp5OB9NPE+XHnYvWqPdh74ybpcuS4VRy3magvp7pM3vNe9prLgtt/JYeXjYvXQat8fjN73V2RXnbenFeh4N'
    'jrparzKawCTalepcnJjNQrlxuasX59Z4IrX01lGhUZw2KoN6eV6SLnpO4VidSF3RNrqjR5BDvV3XeDmplgf3pR6VunVHWrc1HTx9'
    'jLvVxmjseO9SRxWt4WikNhoVr64YtceSZXvPjZpRuN5tlQcfUmHuaXfl1u6bc38j19umbu/eF0yvW2ntvhYmF1Zh/gr7rg9b4bCu'
    'vB6OB1BJLMyrWhcr1S6kqyEs27tbOp983JwejqfAe2pPb2fuq+R0L1r3u2LZcmu3Z48Ts1Mo3mrYiCidNWt+t1h99O8u/UKv5ZRN'
    '0M0NTxGrg4eu0bGPbuZ17f1BOpz5L92XjlMt3w1e/Ops5nc1IIDdi5On2lN/iqUK7Y/rx6I8bL2NulP3fvI4ap3XLu2RfnlmXeyK'
    'EjDe2s2j6B4N9Mph+frt9sQqjU9avvGmlWdFUP+Nq8rxx1Can2rtQv38elwdXD2P7LeWa40f7UpFulG7uv1UPBpeji6069G97r92'
    'X85unhsPV5PK3cC23grGs/xSLT/f+O9duf8sP1xb75eDF9FtjycV86lovd+4o/b5U+Xl1G9d1KSWs/s2fNadDqh1L2djsdtvXU4G'
    '7SNlNNbUUuvjrjvbdW5rF5WWWq4Un0dWueZe+W7xqv3QFZuTJ8kRd0fa+EFzqpWbh6L0Vpq8tye79mO/e+Sf3H9c3T68Trqviqt9'
    'VG8eL9+a7Yc38+72vDqZP00eda+lqdW6pekTQDLn6WRSrb8oDXFsuifziuGUWw7gcFfX23VnJBsfF6XLu3pbtNqlbs2+KbVa10/v'
    'rnap99u+Kuml00JTfDnXmtXScDSW2y9vzovUvpMaT7Ij71ZF+/qyNhq+6MWWclG9PRPPO1alBf8Ad3h0YW1AcZmoI6tYf+VG+UP3'
    '2rJub71Caa60qlfqXWW3KI2fpJuW7Ly/zi+KrZfLSc/6uNUOQQuqt8/OS+6g/TEZXLWfpr7jVnar07Y5L3Ve1NJL63ny3nSt6ZFz'
    'Xq83ep86tZq7Z+dv/jsIzWPR+f/Ze5Mlx5EkUfCeX8GKrk53T3qQWAgQiKjIFO77DgIgo+J1YSMJEvvGJStE+jaX+YAZkZnz/Fd/'
    'yagZQBK+ZGb163ozl46UdAIGW9TM1HQzNdOKOnGYwZrc+8PDYHJO2EG1OLAs/tJx6g1zpo9XrB35Z5mTfFsZODzQ6/KYUw2VrxT3'
    '8jGYL/mypi0bttKrs301lqrWhAQlMZp2LHkacqwbBBGpLkVyGVTcoKPvuct57MRnxSe4AUjxcjRYu3WqMlmfYs8n5q3zSLGDKtkW'
    'DEZYV+iJphvVdhwo8jHu0UnVtJX1tnOpc9BSzAiRGniBcPLE46x5CWud/+q+XpON6EFVl6AP/m7TsaQ6t912y9Tsy5d0Q7Tw4Yh2'
    'wVkie9uhvdEK8rZJ92/xFuki3dT9sPjwG+cWUs/mqy/g7RDi1ZUp2+N97Tj3jOJVXyPEP75w3BNveZ/wsQTIeA++4RTw7mwaOeMW'
    'Gh5FXz4UFvjMA6TLH4dKsL07V6enC1Gz77ncka+8nshXbk/pXQA7Nw29hQO4FsIo3mzy29Z0pVpiqiTNoRAmPEPnvR/4KlNCvu58'
    'haAJGjL80a71f8KvfUf93Mod9bu6naXxs3Z3n+LcQdK0P+jEp4rvMsAdyt1lkMXeuc6Jeq8E+bWlj+bPL3x/zduH+OfbjYBXB7Of'
    'cy554c9h/pK/LEv48++fPL3d3hTeHPTzGSAxi0+FAb+f5Xvh5fbbaflThC9uXArf8bhrYwc+wwt/+4TdP3LWAK+a948bdN3jf/Gw'
    'Ab6u5h3/WJyOAlIgf8jsDpTovbzvu9++XMr5irMvt7X94oKif6xydH/FOzWj5KtjI9SX3hv1P+PQC6SsEAbal7/+t4/Hf/t4/LeP'
    'x/8XPh6tVs2ovfHx6OI1Bc0dX/t4aL36bIV9KBqbcqvWItAoN+Ed+h+OGrNZvZ6ug6ufRbc17+1Gs60wE1vL9mlrijb2uVi6gt4Q'
    '2yJ5YKVTyHcXxGm5H1l9YWUri8plfHb9xX5GTxrRtIn8SVS8lrejdM3n/tVry3rtuGrUywBP050D3PDeajYAVpy/doenNVsuZutW'
    'B8Z+NxLbJ2IuCisY/VBrSb197zKzhjuuKZ80d2DOymVYV0cY/1qjNRvNa02uFndqzaOxrf3/92/T3KiJqnbVvmrp/nlw8HqHKjtn'
    'i6eWYPj8ou/7Dt0WwionX1beaT9ttgc+daYTvb4I2bY4vjhF8eyxrdleFo9+a1Q9V4nuHOQcTaOdlkhG5blBHix5b9Uko7GWJP9I'
    'WsqpTVAMYx97cdk0e3uL4GLnMNrQszLf2yzkYm+7bU+qxZgvH+f8YHeeE/bgyBqbIpG4hJDc8+nEtLzoEqCl9nr1vUduePoI0J+N'
    'g+GV+QV31otst1wbzIoH0KdaE3jxmuyifAJE1SdBOS42upRA7Mlp2ZdtXPOxmVY42imTZX3NsLtg6K2U2DTlfb85OlAXZkmoMee4'
    'Aw60kWIcAZCMg2BcHH1jCjD6lLwNx5XI4qODfo7a665IHGx/fFgHJ8E03Zhvcws0rtyek8VOR1svyWl/VOU7dGMetoVuQPuDmAnK'
    'LX/gG+oy2srtQBskzQlXVFjeJaJBbKgXe8gSZbesbIHGLf85WDQYyZ2OYsdtQSAnyfS0iNf94EQdxKVMWcw5Lg9qZzYYLFixMxxO'
    'ayHZXg4j8rBUjeJuQySEQPucKLuyLJsi5RKesPWGmh6cB2TDUuURC3oxxa040fH54gLUneWaX94anxr0XBDohr31CHHt9aVwP2+R'
    'oFj6PScaXiy9KPAWLYlj2uNE2rY2zfny7PXn8/OYkAyBDvg2XR0agyEReF48X5zqIDctrEbzwDNcwCjsbhGrdrtjc9WOllBJV6yG'
    'tVrb1Jb/nMXk9/yB6fkmB/WNhaQjFevVaBSS6u58kOYiKRKDeCeeWZYNLornb+qUO4qTOl2uDaN5cUSHHY8YCCzd1hqbpqiyDWpF'
    'ev0NV+sX166jbM8s190Uq8vNvsdd+GN3JzSKTX9RkQakbooj67huMOV1K+ClYbfney5/9k6K4/aLPZtZ0vFm2QXlmbdG86q/F/bz'
    'AwkNVYjuskoF/rjTYgnbLp7OqnwZK+cGqr7dafpxRaZI3SJH+nHTIFH1406/2/H77uncP2mJ129Wlx1Z3lbLtLLn1ltjcak65Ibz'
    'z5v17BCapEswy1V0kmsK7+vVBdmJGm1lsdisvPGQsU3dbw6Do14+NlDPRrs1F4+alK2HfHt33i/mSXXoRb46N6JxJBLyySa3h8FO'
    'kCU32C4JXky8YG1JB7J83thA1xeNfy6FbPRjcQwdqnP+qbwWWuFB0HyVnvpNRtwXz3aPpItCLzYEoC8HdmpOXnYfclsO5C4z4qF4'
    '3vXXba8otDQ34RwJOCMs3ON/CpxpJ/ZZaev1B3HkrxTF2QvKZjjgO5HiSL6v+77RsTxPsd3DYtLpm+fFVN6SPtDx4tZv29berlSI'
    'JAxDAE0Pd4a/1IeBSwZGYyJOrDNavCRRae+8onNO+lG/sqhKgto5W/pCueyG0XrViS/7c9lby/O+0b34pN6WOvZBczyCkC/dCx9f'
    'atMjG/BLQ5TqxIBoUFX6JB9kk5DoKuB6l277Br3ediu6WPSnXTU8NrmJXxa7lrhd8zUpMYpTkFb5BlVGT7+TezprB3SyL8OwzKIE'
    'PdUVJ6JW9WJX3Pj7y2o0Xm8r01N7QjmRznk02eQvq/VS6lct9jBn+35yIAdqvS2250t5vqwMjD7nVPWgGtq2sWb7c6XIUrZ8qjfL'
    'tYYeGqRe9jxuQtuuPpWXh83kKJwn5GbYDVx/Inui79NnNzH724kcB4oeifpko+ydwNwNdkutr4KkN1NeC/bz8dlLtKI7taRpdbCy'
    'DqZqCQbDzzaDcEMtT50YhCt7rnHOhnPmHIjwG60YlC1JqA5aKPchLDK8XB6EDrXsD3vR9LzaW+3ygaVBPl4s7Nc4VHcNhRr0A7l2'
    'JihWXLG+HpPDHmkU9+vjvMVa8iZhW5xXJztlT2ong0SstjmZbtmXaIAI8KCrXFbByUyavG9LjTBeCmubW1G9gO4ly/hsskNG6Oih'
    '3Owe7Q2zOzUUtO0XQ5cmSjI0i1Y/dhoDOdmczslBtwRmSPl7nhVU/lzcjR21fTxxfae40ibUcLevCIAPo0lPqAdFinJ5wmhyF5q3'
    '1WliAWYJa+qkjTaNddnuNiOzsiq2LmWUvXbLfXo3c9cTKuVjNO7tAY3mwHDbh51hGo6gzYzmgFHZrUOe9seNvdr0zcuJOleC83BA'
    'EFxbaFCKY++BeBXP/P4gtjm2686G26QViTu2Ehlk1SE00z1w03ZbCARfbBi9dUeYjyxT21foaH6R+0exXRnopCvFS17yJgvpMpgq'
    'iZ+stMi3rUs4MAVjlYRrqlY3LOk2e4rn1Iq6LU163WWRjIJ5PNcdntRbevkkLpy+YbLEsn2OLOAgXkzWl8dkdxAChWnPN8FgVSGP'
    'tDYaVHb+cK716B471oEQj1vWXt4yMM58LIuTLbs/8NI+vHjVIsF254NQt8XphrLbtTrhbW6yRodfNxbC6LIK/RknTyyFmUTJeEoO'
    'VWtU7e4uHW7cr5udsxRzI9AMpYHvdaZzyqmLc6nKT1dr37pML73wkIzFMeGL4rRca7EsqNRl7kAlilb2DaBDiu8sDrG3Oi5tV1oG'
    'sRctmaEvNajZgJECqyYX250oFq2Il72T3mKIRcDq3nSlgp5fDseCv1f3imrN/WRxWVtAIuab1TIS5tW4y2rF+vJCxMyu6Ey3Qq25'
    'CEQ72A4qY8HmZrPZRKajxYmQHEeznWjsR/wlio5qtGwfvUE0mYSti1yutQczxWoEQrnbDk7zljP3l7Bml9KePdaUvVRT2vbJTnbC'
    '0LRXVPVyFscnax0dpaJN6CNmzPYYynf3kuL6SkAOXZNV2iq30IDeWQZ/Uaczyb4cWTYSe5ZjzSeePJHXcpFsrhvWQJb2Z6bfvsyW'
    'I9mqM7Hv+/ZwKZz6qi/r5cqOnkkqvdP57jJh5iE77p0iN7FBc9fr68Ro04S+KFvNeBvSSaPKTrzNeUcoMwqI+SuxQbSq7nBcPcbF'
    'vS9z7qkzCOnwNFpKxQlN063pWh93B4eLpO+W1XHXNaEb4crkukNWEOSQAUJr2nEYjgeJojvGkuUIyk2mImWFr0QGh2Er4sW4tI6J'
    'ygw3q3DGm0vi4F8ma6otJKTh98zA583gCNLNKMl3cOZKGquP56q8HIvQDmOIA65FeNMpyK/ccTl60QWdaNt8Rd7MyWFxqcb7xaCs'
    'zjejdnPCNi4GN0xc1ioPJpLmTsdkcBA1qcdMPFVfsMZ5pHcO46jNgQxyDM5uqFJFvZWQdVUlBZ9p6+4lNMQWu5xfDJ4fisMuIzBB'
    'ZXnpenQUcpw11VZSr2hs/eU8DFqsPCboqRrEpHBSXNvvxPpgaRAg3drFWo103Bo38EOXFcdASbdbITgc5glptwJNXa28pazE4dLn'
    'l0Nxwy+UlpIYEg/yiE22uydlHnsSqQRFuZ4c5+Fs3Ag0Yjjv+N5iOZaXQzKmpD6vBNVmnYwVUFTmS2+oL44K1zYCx3fI9lhmREWe'
    'l4u2XG3R5e5p2LHcMb8sz/cnReZAkmgzzvSw2ZsVrRLH56ATcQu1qTeT8X7ajk6bcEaG5815SSx6SSgsT+QpmvS83nroacog0Wgt'
    'YDwqJgmWJGm224OJ0Xc+H/piJFjm8EzvffZQrE4Nvel1rDNRBGTyTmdy39koMQfK/KQ7ce/cbUrV6PNiNYlUTxRlfR8JG7IfC5TS'
    '6lX0qC1vhkF7ttyLlANIVLTZcbJgNv2qUV8tTA/4+H7n9TrV0XKkrqg+2TOV3mY2mUXBkjkH2pSbjIzhxalslkzXEuRdOPM2/sWh'
    'Nxe+SdbqfG8yvoOy46TVKrQHqhLVDb9vzTuwJkCQ7iQSeVaJ0bFJNjR3vDC50aUjmNzJ6MwuEudQp4UwYA9JdNruRVHsLEbrnm8M'
    'Zc3oarx0OVogANllQ1AaRiQl7WLCGPOx5MmLssyZrZhhI2c3FIvBuMjpF1KdNiRQClSeGbtdz+DKG67NNAlH3yCZdWbRUzHk+kpC'
    'rhN6HxvBurIgoU8bkP9q/JB2quVt0jMO1YAvn3uLquNTRiuS2ZCuXiYV5Tw97kC1subyUJSVucm6Z1fbr5K2D2JnwLRBdfT7szrj'
    '+BY9Xmk0t78Ml0PQlZmwsiKDznh18scKOe5E83FrPnE51rc8P57arO/snHWx2jt1+2x7umw1h7I042xflof7Gn+hLF8bL5vypBJv'
    'V+GgzNXqy7EQxzOqNbDakukH1ixmW+rgsN/MmPFGWcQNUUgC2yl21MrBbDOyV97Z58Qimal+XAVWZPR8aT01Ir/XnQes5FfZvaju'
    'DrzdVGHgBYq3hDCINwtxqC85c+APqw3S7ZNTeehPK+H0JFtbe0YazJ6qbGLOdMuscBGOCR0eiv1Bf68XD5d1d15UlbnkeBLnNrvt'
    'QxR4fU/dyIuBfQLxeWQOI0UzODFpmhIxkLiow4a+RqyG06Zwmp0kylxHA9LvBUx/UtYYfcrou3F5mUiq7IuTirAfmCFf5mVyJPKL'
    '3dKLJoeQZ5pjLo5OiUX7aqT7ZykMfH++7ntem9T4c3npzMx+PG/NW3T3VGutvFljAdq2wrUqh9N4WRFOm3nvQFJb0DXlep/pTDzF'
    'mevW2AoOSlUhaXUxpC+SR9jnlXYmoklz1KmEp7W9U0Q/Pq5p6Uwsmx7TO/i+15b5lRlq5DmkVYskRH8qC9qO0Qhne9nuaq1Qmvbk'
    'jniJdBCiQZ7TQ44k1herOZNh4Qw8vxMkwnqNuuD6Qy/w7bg8OxpdGCZRNioVJwoOblWXVopHi+1NU1pM5tSZbMtz+0ieJ+JSEIHl'
    'xr56mdDdpNOcHVV1rdVos7rW5KCrj5dEc6iuGQrZGPe0N2Iu1socnFpKIAr8ymmf9X5oXc7Tk6hq/fA0l2ShyY2jQ7SQB2POkpi9'
    '15LG69ZO2dv9aOGbm9ADIGHFjr1mvX0cn85SRB5jah05Ee+7alsmDxdvaXpVusVK5sZr8SJzCpaiSMzb4ni66e3sqmipptMxRpo0'
    'JwK1qbjqVLp42mBHmASfeLTXY9rrLu37+xYlK30vVkyFVbdMfxp0GqOjULWnW+NwTM6rYNxfUtTlLHtqNZzEeoeaiOS8wYQXuzq6'
    'LEnjtKR0Kpkf6U4QnTunOBqjELenMci3Q0o6n+K40dfaJltUATiuZlXi8Oi5q55fTzq1MBzNKknUPibAg5Vgrgw3vYMoyLTig0y4'
    '7sfVizwXySqTzKvMJDzFq7herW4nfBiJ/H4rEsRwzRqGc2DOHWOsAwftgrxFzo1BL/Fml2g4qW9JUKYv8iQJecKrOurAlyyfNeb9'
    'nreiB+RFnOvGtjjqCHWVrtv6pBeKFX0fdCYuu/BWIGw2V26kd12nPQ5kzVeGDD/ZgvBhj9ULHaxVgFx29/OLVLzMG/3JXDY6hK20'
    'hbVnVzXx7MrVxsD2+8OOP53TfEw5ztDt1tndeR3Q7ctkWfWlI23N2aKn0+q+0l1IVLT024PBfraPhtEGVmdv7mm1ihe0mbNkqc2g'
    'yhrr8WbtezY7HMS+5g8lWumMJ1bPJfWqSPSFegXoqj72eI1gjCEXdpRkMOGdYtufbpNp32u3LWu1WpL+2j978imZ+8YJqN76bB6t'
    'XbwnpA6xPPtOfd3hKgnos+SIalRcZbxaTs/sSKyGiXmOfXavk5sT2T1NDq3RqDk2O4NJP1me/J4TTi5UZJykKaB1LMyX4ngpNg/t'
    'w+EQ9nZr1RAElbQuK7+4Xvuqo9RZkFh3Ynvll48N0ugehHmzowN6FsdM2V4WucOyPRSZibIWYardYFgNA2bctgTSLnonakV29/SU'
    'Oej5Ii+Ld5LqkBVZS5MZJyGYTTEsNjhzEpPivNzhypfBxpjknheDOm/xA34RD7kTq8EYtJ2jfJiTlA/km3aKa6F6ITwuGK5IdjjV'
    '2HieLPadSPGLULgBKuFIWTqOLZ42djfQi+QeVIakd+L3IRmF0SCaqv46HIqEWI2HIDkt/OA02tZkcWA1rPrMCxoSrNCJ5h+cgXqm'
    'ajW1ef5j+5NJD6peX9lMF9XLosd3yGV7POwGR9GfReuYk4I2V/SMQwA1aq2zGPlRcTIY9OXFctBfiP5Y2FwWsShNuYslwlpljB69'
    '7K9sYw1y+rHW4khQgy8Lgp93l7PF1LSxghrKoKECiRyYfMP1VhvLliV4c+otUZiwSp0MFsGm5bPjzYBZUs7A1Aeu7Zg0qy3i7XS4'
    'tzxbswLtHI5Fex2vi+3RMezTC1qoKDuPFUnQ9AJQRd2JaovVg3YSqYPuVremthTbxGi/u7Slbigz7HpPsRe5Y8n8SOoPOjtHZHtn'
    '31p3w4no8xOeqgrmXl/S7dnMmKhsuB4xoKF32kNvWz0EzJZSivr+BDPAOpbjrTxKGAqRtKh3XP7SFn1Qo0QdkZglWbGbzDLck0fR'
    'EluBRbWOHHkek7QSdOt+Es62q47YDM6r82JzRn74x1O5as3LvLG0lNNxdJJ304kwpEjRGrdBMjgNl6I+bQ4HB+VyivyO7/dALwN5'
    'y5vMjUARZM0T3cZylPSE4WR1cOnKjBnFzYFRXczEURSc5G5fOs0Wka22/KljsENF8SPN78UmO/BBCVDsauUUd3pK0l12xmFLcoaL'
    'ILz48769cmLVWixssUcqzGFPAda0CRKYu1PX25XBMqzv7TLQBUk6l0M9SooiyZ1kpdpcaULF9VVmxPre4Bxu2vNlqDpsVV3R0zVt'
    'm64/YPRgbkwNtnvigtjStdF41QZV8+AqJjF2jWN8VvrssHaIzcG+A12urolVWdh7XiIvA7852O0YGEOE+vWh02953prjqsKwG6nj'
    'sUCOQttUeDYc2moxMPgG35fKh8VqYLuwHDWVJBanJB7o5nIwUV3/CJIMX0yWDNsztSk/NiZ++9Coy5a9jswYNALCcf+n7b7dvURE'
    'Y4nQyK40m4MSNDmtmJXXcZmA8tFQDE/z5XQFqj/HaVuV3E1CO6baq4FZpfpsvLloahsUUS8onkHBTxRT6/YZghW3/FL0fTSUoF0v'
    'y8sZKQO77tRHC2E4NcIBFfuOHkuqvVz3Esug52fOCA/HuBP784o2qZQnszYdSsyMaa/WkVp1DG0y8iogm0mgTQXKQebJwNBpX2QS'
    'yzxeNtos8rhBZaHPjucJNTDsvb/2vP4ElKMLsl1rkmUponoaH6VWVK024mRY3CtjoFB0DPL8pFExJLofH0/tmSetLm4boBfRwOjC'
    '4BQuNpeJAkI+fZCFs13hL1WrWemVF2OxqMxYUmpPQGhxOrzuEH29H3v1haLw++pitxqyej7zhOHPO6618ZBb/3izWNn0aj0L2/yL'
    'D12tyMyKjSmxFzf23hvNw5ErNYpOPtn211vNaTZGUSeSdwNqKAgnjyYHRd/SqPm0BdKcCDRzx1j63Awr6lgXY5DpFpdqm7LGW0Fe'
    'c8PVIox4vW7KDcGnBmPqNBUS36t4HV1xA9mDdTyM+9QxOvAH1WzQYTx2j8QZpJWLHWiDQFkBVvrnqjUWh0tFlH1JOyyIxBcJyp02'
    'JYb35nwLnbSFFRIzrZkz7V16DX7lBavhyWQtfyiupIlSttdLaWKEgiC2FKcdtGklBtFpbvAsEU13ztCpxR1GukhyA7SINTWZX9bx'
    'as6BmLr1p7rPTEdeNK862jhoLY7LCccpA8tjB/ut6y/ah/ZYOEWmaa7svTRS4I8LWkDP7BnHegcw+7/yb9KNlZOZGAxwT9v3fVih'
    'tW7ftZXO2rKPshB7BIizujMm9540Ka9Zy0iSJSe3hUVIhWwPSF4w3jXEMJon66HMKtFe9uaOlOwrHXOtrNfypSuqRasaDceCdKpG'
    '8cKzSGnhyv46OHF+dQ8UY7E6gmzMG5dmTCdFbmHG/NKabEaSSXl6kdnQ21XcaHYktTOIInGzPBtFIzGOy8vUn0/bp2UoW45FrrX2'
    'UplsFUvUnIiwg65Hn3llLNCBsNLGUodcaeiwRMh3zrZXISrjSiwHWtIWufXhPAVdZRG3L2If6Jsal0/cXl8pcofeTEg5EozymTvW'
    'Gs7wfhiG7I6GNdE9bRYDdu0vyeOKXgz8lV0+1vYJfei17d1pbVkmLE2Z4JwEkHHndzZL3xiaO2V7KvaGQ3XIq+vhRldEa17jJw0Q'
    'EshIdpcmWV0LBtn1D6LIe6C4MWebtxW6uIE/1sXuKqE8G29FidAvCi0tbK3KB4Fo8gODoGeBYLctxhh1xA27jA4wNSo1oVzWnIr9'
    'XrtsExVD3qqetbPprqiRirY8j02HHpuBPu4ksjsHJRWmL7a0aLryeWHcDnzNFRizKl2GCQ2ySVKze91mdwwgjrW97dsgf7Cu3+1P'
    'hsf/GSxkJ5apxGd2bg6cWXCYTDa78n5epnuj0cnqus0LU+wWx91yrdvLfVrP2RpXvL4rnt21gTN2KH49iPVoLiUCLyzmoBQknFKO'
    'vQo5jgb7ZSAsYeTXgU+6SzfW6F2PapRlk6IG1IIesKSmD4V5nwb14iT784m1aYneZXERY2o02PFOqPbZBZnoYb9zkR3FAZgUvQHV'
    'M5cGLbGr00U6Lc7O6kRUSb3oeS5J7DyKV3ipavrV82bkc4EqbNm2pS7dc5w0D1XW1RzjZPRNvWtVnPkxqqqLnu/JRX5JD+NysjlO'
    'No4cj5cHVm9Wo6lRLB+biX4a98/2WZwnY9npjKQguriBkcwrzPRYPDjGYHxYqquKjcw2vb0UCfOW4M+bYcNMhmxkCBS75ymmTSqS'
    'PiB2IUFW+Wqt1tsNX1OIcN9ZzOP9YUVWgTIwwYGcL1lrttuMqoN+V2N0bTBnh4k+nHlEcTLlpm7fr/s+sSJFc96Og4mlzyjF5Agx'
    'OdOXYWy31xTlc2PbDxSSOocqb+hemY+TmVP1rW21r6sbI9C72nAtAj+f9mzmIlaGJPxX2S+1sxZVZTPuk7LgUmbs9+mwuqxSAlB+'
    'j0tauwklD9uGZPe7x+mKbbOTskRwJnsSIpZgebq+7CnOMnLCC1vhGWEW0B0bJHCa9g2Gp/lqXFe0TrBqnS5rTVoOFkvishpE5ibw'
    'pfm5xyd7IRBOrjq+ELAO2uuytpvuJyPLGiWsLrUlkLwZYVKZONNZ+SRt6N7E2JXNsBzP+C5ogbkPWnTYa/F+3RkkS3O7nhxr9cM/'
    'slaKnTKt7EIdhi/RvFjxBtJYPk/YTcvUFT82e6DOuOLiUr8sTmPTj4yDLo9VVdlHK3/hHMSYmTQSzTZjmdIXLU/zi4xwXGkhH+4N'
    'JtTlZXKw5pPmYT8ft+RLgiTOXnV64D1+ahsHQQJVm1pNZiRb9rXqpdXdDSM+ntWaftPOtptMJDUNXV9rj6vHpm2Zm0Ykd0hSHmqB'
    'ZnoXq788D5ixU5yfWf+0WZOu527HorITghM1OGguRSj8Yj9UvKQ5vKz0pF3fVIcL2qAWXHVBDseRCYKdRwzw/6ybHEbbmXUWVGs6'
    'XQW04sTzlbJwTXvPEtK82/MNgZccb2kTRUXmI0KqOAupWlamrrXX9H5UIYFC1PharTWztm9H+1in3KC7BhFZbsylJTm6KAbap6/y'
    'rfkU9AWzXyGncW/DCNFm3F5Xp6o08OfiiDsE/MRaEYqJ7lGZb2aKTwo2qx6AHFfY6cwSAYh5V5pop3BWcfy1pFuL5TgWaTa2dnro'
    'eYQKQ6AlFq0vesqqtmwBG+DOa67sk76lSOTSkGo1o7nEt3a0xTY519uzSq0eU3XuHM5XKrCjBbmMjtF5SPPDSVnWyz1GF1VeNodD'
    'acIudTYaj/XhZniJxsuQqtCKMiRv47qfebbAnNfqbjxdDT3V6/pAqX0gB65fDqvK0HcO5DpgyGHnFJypaMfvCGNHk4JjrGzOA2LZ'
    '12p1tSv9IVK3RM7bN0O+cgTJkRXNxI6W/mWqOFz7rExl4aQAjvc8EUQzHpbMZMX7IM2Ou2Nk2ph4i6Z21HYV1vetgOuJ2ngYBdHE'
    'VfZij+KNIz8WhXKt4zsO4PTEI6YiKzacS3tdkZjyjHGkaOCLHsfPJTmRQf6sHSZCfzMaB1GHUtqsrirnoUDFk0RZX9rFXqUs9zYn'
    'RzAOqkCGxmCis3XkV39cd4/9elWYrJJTt8syzeJI95yRXNnveW1X7kwXY4+lpu3OZCvLPqN15lxjZhAXe8jNT8V4Vt538w3sib1i'
    'RPvTLFd7c31I7B7DjqXzaTTfbIbSjO2z3U5xVT+3JSfo+dU2v65PTqbLDDq2KCqM4VXJ+XRi9hP2IkikcXFPlLMUuElIL/VBzIaR'
    'NVM4w70k/d2xOlXCjjiu+C65t2IikE+ROG4zFiiJgF/AHPklSxCy11cmodqZz6P9fkWC/gj8RbFBJNVawGE20yBmLI30xLV6iasS'
    'LSbz/UKq1Gr7w+v11Vpxrn26yNPGqH0GZmkUqbNfBBVYlG26Z07ky2Avyqee1z+deqfDQXWZztg4nQfIsiW258ZgsAt8glxuK4kx'
    'r/rbwLQGB55ZbFuVSuUsLlzQkOkGKbZre1K8+AtXXCrkhun2TLZfsfi+N+S8kR7pruWZhiNZcturyu3+hPRPxqjbEqNh7AO7WKkw'
    'YMSsw/G+3HVOowsZD7lZdRlPp+baCTSY5NOlLfNBpRO44wsby3V7X6OdaFHhin3biE4bs6tYJ4YTRrxqlluTlV+ONjW9Hm/Ec2VE'
    'rF5WPaf258OJgpnWlZUN00pP/ErU4puRMB2JGyrZTrb0FCGR0pMmzHS8tyKj2aUbrhqe5YHsSL2ka1OeSxM8lxzEZr3SPkvVDmBI'
    'GdSJ+nK8igmr3fQDeejFFD30AhcEe2FuJIImDMiWQnYitM1AzFuVnlCdUFa9ql3ccYc4g3x/IcWVwWyWTK2+7i5q//3vd+wT5fL6'
    'rx+uF1Pfwr3fjvzgqO8ofAg6iePG0evjNuV3ykiGmsUDRXeVozgv1zBlShoL8a8fdlHkhZ/KZcMpHc2D6Rm6qZTcYFtGb+WR6ej/'
    'ZiseABYYio4CqMVRwYbUAqRez88o19BlWWgbF0fhfHoN4S54dX4pvTVbs2IUH+WIImmh80tpaBRUi+QG+LLta3TVd09+vbpPmnx1'
    'oTSNrlsf4ku6f0zHIn/5MUuUCIKqElWeIAj2xe3SlQpfYiie4rhKlSRIrvJPvGWd+q1zYBjQt8e9FmlsLyUfXw8N8YtTesP7ea3s'
    'tnE0hlnQdnzqDUXysNK4tGm8knvQOnwN73NBV8JdesG57kaR8fbQmPozDuKdu3pdia4RZQ1Hf3l1e7QDdHDugVdQBKL/+Pf/q+Z5'
    '1hkBkEZCTO+C/49//78LaZy8F8kFHEHrHi3qhkt4rA7vjBVOLuxd07mD7JxxKKosBE+uUyjiVQGfdivo5gbUCRTQ7x7hqFR4NfJZ'
    'wLdrxToOeJYO7aEAI61bxosgijh+2Nu4AunJx1exhd9Eb8odp1LTA3j30FH5oqXCNW4eBgOqRqFfz5ZxDXX3stpXoVTS/Fl8sXdj'
    'vr26AZ16dQN6M8UZhF3/4NJieLLEEjRdRXcycNyba8Wva/gfu7gdN3y/BBh1PL0GGIH1AZ+Evffl1f3o1Kv70ZsY61/3BQWrK1EE'
    'Q9AMz1EMnb+imWHYEl9hmAqJ7tCvMOQf9+V37pj+rb5gsF735XUwvle3puOANnlqRwL8JY5mKhWSrpIV9sVV0yiqU4WmqhS6SJuo'
    '/gP9+L17mV/2A5MMfPO786YTr25Rp17doi4gEvJ6Pqp8pcTygDccwRIcdb0uPu0Hy5UIrsID0aZoiiGpP+zH753UfdkPHAgC3wSP'
    'oHrdk1d3rVOv7lpP6RJwUSBq6eq905lc35gKXeJIlkMRwAiS5V+sGwL1m61WaZqlCfqPu0ZteKNSedW1yh3kV5etU68uW6/gGLtK'
    'AsRpg1j+j4Vwp7yItcsylRJPERzJkCwFwObCHVAkWeIIBqaAoWj4RP4T+edvnKOmUVgeYG5XpkDfmEIWjCO8Buy5EcMslHgulJ1p'
    'oTC3KP4nDtG7w6Ht7qFFnq/H5ENMkTEINyHmSolzodMfwoKj2AbiYzhMt+sVMCfAVBd/Md+IcgD4CgVQsUxggsH5bXfycW1QPPM3'
    'IW3wyecU6isgWLba4cnER6yBKSSmccQ8TgkAKdEUY0FRD3EsExSWO3y+xa27HhqHXt9OjKfdfwf8BeDJOxPxXhyZ67njx+m485Rj'
    'zWnkEySJgPSH5IpzAV1O/3vBXLC8+FjSXe2Ur+kIq3WH5SXcsatU2XHdLUxw09VgvnMhEdG03uLTqAaO+rlLpabwOTfp6CkVrnEW'
    'BZ3B/z3orlJsLorjPQqtZyEAcsGx0Oc4wtFlXgpVDdc75yMvBrcrGHDYxVyv3g8U8wfBF6lX4QyoV+EMsnhWaB2F/xxCcKU6/3AE'
    'GepVSALqVUiCLkzHp1fIXyyEGMv/l4H8+4E4qFf3U1Cv7qdo3XQeWAXPKYr+WLDdfxaxfQvw+9z7DvArtYp6pVZNLCQzY2JZiD0Y'
    'Yh3rGHZoWP8LEeN9Vn2PGftKUqVfSaq9//j3/9MGMRlF7M7oWl48omjit6S818og84fMDLXxhpkRGqAJ/1u3sLTvYIWgC6HbP1QD'
    '3+yBtYXznUilFAEF+EXrHlQ6FHIYh1894gDqiNR7MeY4dqlQy+JZv7nXBTX49lKX13GiDduLsqDAaRVIb8FBg7P4s6UCDmaMmnhx'
    'pQuOW5wFOvNQJGp3k4ZEzsKCvdQ1fsCT+CFV0dNp/EC/EtevKLIJXDsvYrl3yfO1rJlhxitZ+So7ZRXdEMXNiVHvSN9ZZa9jE9Mv'
    'KrvdPYMqY7Ou/fD9L+VQC0wv+vmHv1wfNNcJo8KfC18KYeHLz7cIfCU/BtKVap5u8Bg+fc5yhskW8v758eFfNMVJlPDh6Rnxa0vP'
    'UvEzSgwjdL9OmoifUSKKFw5zm6amLw+3qtuTsQCfHj4qoJwbH8NzGBn2c6GOpmOkaAv83obpfQZxYesahWXvuTB3Qbd1nwtdtOgj'
    'U1MKYyMG+aIWmIoFUChO+DE0AnPz8PmHcrlQv4Zix8HbECvOAr6lYdo+obiNCP2QwQIwHF3igsQAG162KFogKN8Gqle1UCOwzswt'
    'NO7FgYfUZw8gLWW9mdaGLUFoQYe+PmTc5OG58JBRafyY0j/8mFIV/JgKzPgxXav4keSrpEbhR2ZD61qagddoVmXwo0ZRDKM9fLuO'
    '5nwyEf6t3RsO0ZBmIuzD9eNCmMwRaA+p6PkxY1GfEvKWpTfq/Nuit24tINuvhQVoPMRzYYRIFPwOkQoOv/IQIS5R+H6fw/moJryt'
    '+VYtQNT6N7E1X/QmY8hW+QxoCvOixrYHC9MMC4+IrCj4Mih0Pw5awKNeZ14ToMDiCZvoEFtNY6oqKBReCMJDKr9lAb5/+AFd9AOk'
    'Ad/68gVTxqydXMRqbKh4NAEoZFUEunClGU8/pPcEOYcGirUXoin8lpW/GlrCBxQzEFWjpXnQwku/KkBSIxSQ/IjvpELSEQo4ibqV'
    'mRU3MCDw7d7OUAEii9r59XvWDgbO1Asff87IKbLiWChb4QjyIardKTz+Wjg9F86wAJ8Lu8J3WF+osaz2tEFYYvCcNoRK40C+txHJ'
    'dQhZvEIja8JEQieq4xiYQHccXB5IwzMaPSgOM4/kdowZJ2QEKZzx3wOgBxCowtaAwUC9gSRTb7ixE2WvuzRyNkAAxRdG9AirH1Ue'
    'O7q7iFDERDTYzzh8av4dXQAkoMu4rtA/45Dvt5eso7d3C+TRJgi6GMQIgEMoihpC4kIXG8lueVHSGGlBt5rNALjNl8JGsUIDUTKQ'
    'gSQlcAz9mvj5hwyddWOjxFaE5u7xCRFQmBNgVjslNMMsphWU0I3rMx7fNGwlfM8awBL2p8JDGtoRVvMxUDx4t6FXsQ3vShy5AnDa'
    'tBaY6etqkua1Ke6ig3kO9LNUfS6k5ZBBB8WNhLbJEgNEbbP5VOg5oGKZ0LvbilUtBS+SG/jotrOejkuHRoRGFWC79vPx6TnF/094'
    'Oh1XR5D/WiDQH1PHWIBEHYB+dIu1+fwCSVKBJZNXCkhWQV2FzJAPiymfcrTrO/oPulv+qfDx9g8jbaY1pxoy4L2tRKlIkoqCONJ9'
    'TkC8l0aMUTSC0AQdFQgOTO658IhNIpjeANB3elMAsgIaGxIrkqwI1nAQAGicYIhSsQjd6oYhSe9DQ22o+GqyCEejR/mPyhlgQ/RM'
    'BxKRwgpyYIwp17V2FGEQajb0tFG0ShBUT5+w9QdWVwFUCMiSmQius3WfqmxOYNgyOQlkAjw4H8ofskY+pHVRBaCfgPU4tiBMixWH'
    '2Th+ekO9MbBZ8VREh3904SYpWmZiZDbsD1nah8IjCGlIxARwPjx9xsPk4GvRELHNKbuPKUbkECKtH/6lePGEm0fS7MeN5Sp4oV9b'
    'flu48IByglhxFeRgPqIj8O5CZoO/1Z7V8bngQVfxzkRqssYxULPqU/NbCgE2akCNqC+gy6NQrYoFQhayUkB3X1hcbo0gIoRsLM+p'
    'xe1ohoiYZyYZwIBNBAOCqPt9RJ5KhTmyy6B+ZuMHWASYZhsKwkaE1rf6NdczAVAs1xoFEJ2Adm5iaCShM9TPsThkgMA7L0hOx8YD'
    'N8R0fpfahs6ZzH9w3GMpbaJSuFoYoNMakJkzYO0HTMegz+EO64zogkQUqBgh8I2lQDcWNwS79/4zzpAh060bWxdrcWg9ZT3CYvod'
    'nGzfz0pZpRLiTQYVsM5Dy0nP9/J2zSPWPVATPSc0U+0Qj5By08mB0ykWrMzwt5dSRvCAYkKLbRjRMuL16AGoMcwHYvilwk/lHzRg'
    'OiGIn0cjQF9bQJEDYPnAP2E1p2+/fs+obo7EfMFyPAk0NiPApVJJf74txVSies6tPsTpoQR1K4EH8Tfz0883kq6XXvcRpd37e6fs'
    'uEoQD5CVD9E2hCWIusFSQ3ayTLkinjLjVBqgemMGYW7rKkWgbCV9KkzUPQheJTR4LagFpvgxSzKyVwAP066//x1AeCrZivf4+PUA'
    '4H9DvClDFZSwiJBl7/EAyV9A1CQeCr8U8Lg5v8degCZ+QnXh0UvHkH496rdRq+AcwCU3sYODMuPFlPGNR/0J2gsMxB0K6VWPJTPs'
    'OZGxNYJH/ZdSVs0TwKVfX6Bx+JL28Beg5MAMP4NSdqvfNgEjI+MR3Sv4hHECySsJEjnyLaOvn+GjuSk8JoWfXwjUTwV0IeYRs42X'
    'ePj44KD3h1zRvxTIfP5rNje6L480exptHJd42diviJMpAOAdm78m3zIQMeTo8dr/z3ijArX9J5x8JbEw29HZM9C6zSf/Cc2sixHk'
    '4R+DM5sPVMvnH64L7bZWv2TAIoMxrBTLvBg5YQc3/c7iQMmv6MGnF3DeFg1OxM/Pqd06S8LPOZEtpSEInAzxfnPh5gf7GeEnLJC0'
    'NoTt1zauDRTQun36rZX9lgLc1mW26u4dKWX07ukm5Q5749a/LYTVEGuDXx/wTj3SOtMNTvyEDRQPIKrX5vOJlOZzQIZBH4ECop8w'
    'UoIIPYDKvkNZpV5T6KZZkTkHfUonBz3hDS6kz95WiGYB/0MuBo8WQr5MoUMM+iHEYew/ZfKT63zMBNZCooCmnrp5HAwv+gExTNQl'
    'LdW2Moy0Cj/+mO9lKdtNCR+tEpYJnp4KWvoE5bK0F4XTXufLYYkcl8NPuBx+elEuHYJ8ObzDh8ulQd9ROfyUw3ENITj0fm6osWnp'
    'OYb2iBVRBdOMVHHA203Ae5CKVQgdxQNGHT3BaBiYR+IROxqW9REhIjDSdMRKhTYWHoDro4bw9kJatXPGGmkqwGaGFCC7IEjg2PU4'
    '+bY/ZWCBHDHnK//NFOMHJPAEh9jDInRmzkMtAUcGJQdfw6uEH00A5O6og2YQ7ZxheQOrxaixUAGNBgQL/YVx4PwQGFeZJMg0b0Mv'
    '3bHpTgb0lNxmBi60NH+5LZ2UGT2jO1/TDzkWdZW1r5iUVgAyLlKnEqT4WZaa6rAE1q5urKKNlDDjsZg8IRxIMLFDDOv+9oB4WjEp'
    'fLrVcm9hZ5ygSg3VWP4f//KV+MgrHzfffmW//7lslpD14VHDBBFZAx7TIl8PxhkxUiQeveK60LOnp2x7Oc1sIj03hfURyuG6Msr9'
    'htmZMHgwGFDkL6Bkw9OfnBxFd16RcagfRjU2PudaQ9uRXwpva3ZKKSt/ymfWMnEJA6Rfdc1rayWMGFgmCLGIgAYxSwUpIFVEYX6g'
    '7tMT1kfTl/PTc1bnVXpAQP2STglkyiC5Zsq0VJgGKItfnnA7+LGQFoaJdEpYHcEjgFUSyHTXbD9dLYRfYez+9fpSsgxnG+2+pU19'
    'v4881IlIAq7xy7XqL/mqs4ertHMv6pSwbRMAueHYG0TM8mCyk+b+Urgm5mu67dnhtpE1ApXIpeK0HNjXmUHXf6fwqq6L6DjChiw1'
    '+5xvJ4tVnm/kmvSqhXe6gvZo8cK6PWv4Fy0aS7G9x5ES7Uqgnjv6Lftz4SMIymwO178+eKZlpezqhLmYZZnQScybAKMevt2pNlSC'
    'lJyUS2B1B3UKP+UrvPFNWASYEeI47i8rQiHecT3oAVeDHl6Mjb1FnSv/j/sN1H8tP3rO9u/oHuq/b83N34+G6j1db6T+qny8AI0o'
    'lr98K94oBK6mhNZ+NlDo9QjyJJF736H3p9uC03DTyNwE5dCyyKp4Lhw/3ap4Luw+3ctnGJyCfjMpf8WfUUiAb09prYt0em7pabHv'
    'b/Eo3fd+scTxUsPpqLIswzUpTzywiv8lJ0Y4SNQx8vQtW7oZiQTiBxwZZcnWJWogqwX9pAUxE4BV/A3V/TndbEGiCb5Q/7oPZccI'
    'AKSgpjYgBVGJjxZwK+uaBRlskIq7dRFfxuiJrFEKEm28z9gelOnERghacdrII1Cc1HSbGUKAf9pmiPS1u3L2YruxAFrGDvNIbKrC'
    'u3duGJVeMgwnxylSieAR9/MVqwiNF9ZcNLH6t2xAcW1Ih/HwdKTwfYa3K7f7nH7Bw+d9u5L7O31HE3L9ipgKaqy0U8JHD0Fxq/Jm'
    'z75SxYwUfi7o2M2wkE7z54IaGMrhc4ZVhbQ6Rdehuju63XSU9/peCmE4Hx2sRNwaz7HuPFlOLVd3OTW1MigYCcIIz+ZNU37NezF9'
    'spXT40cSC/55dMwgQcpxSvqgjWKBfIuKv+YY5D/JGHtF7ttyOtyFnzfChvWesAECVFos1fH/y3LHn6xU5sD9trBx4duLlMjF7+kn'
    'PDMo7X1JJN38+HIVJ6xSlvBSnsiSS4HhWYpmPJb/GhbLWyDmhYenEuSyHwFPgFMZjzC+JAX0E4keaTu47y/mB4H1KQMPZsv9hOHD'
    's55Xd1L9D0kc1l3i+PU6RVnaXQlEmVPgUa706eVHTB1v/BVnQynXHYY07+sZB5TsvcDPP8TNN+iLR+Al+t4F21SVvU0AIEuW8nIG'
    'Mp33H5sBisjNQKY+pUiHxuGVPn0bpHQ1ZUrzrbtIWkQqQKZCk9C9dEiK6PmHlKhc1e8rGbtvB4Wl6zMmgenuT5Yr3SQKS+j37deX'
    '20ZhKf9+m8Rb5nQ7KcRU784rFeTMhgXF+0tu0ykrnG49geqOVVUko9x2oR7QZhL6dTebvMwSllAhhJDpUyG3dZXVet/ACkvX51dw'
    'ZzbHvC0C2+nuphy0X2zqmZdC6UbqroYVBYtL6TbWS+J9y34zwhxMPbzVBgUBYUDKipDW8Ya4A6W5FjPDuetifvMuC7juEWP/SmDs'
    'n4Dx3mg80kJf8OFbnZg2/1ad7yoSd3iwv84/UPbLm7IIsPu25YsxSEFC3C6IHh+V54Ka7g0qmWrwyy8FpYQI8MfCo3pPU1HaU85e'
    'AwMx2Tw6iAdmNsQbiFcR4AmBXhjnlL3rGsX2wswCfTtyUlDSmpGHCN4jAHqJHQHwpr6ZuQ69Y4tOj/ZcvYZgAd4ch7LhgGVwGwy0'
    'yZ1Xlh4hAaO3gbRBPHCPT18JWAJ6rre64UW7tLd4uxxp/Z9/p+O/vu26XixCr2+GzBfm4TBWI5g/zPh+zeglkha/FPAiuEtbZtqw'
    'CQo5OqKVCq7wXiw+5Zm0hrgzWgePkOur+Q14McruxeHuUUMzeZsJSEaQZKvM2TbNzQaN1Q0x7h3GlFJRw0cFcAM+/mvhkSr8lCZP'
    'e/cqdVAsskQY11wWKKYjQ/nn+wY1Vtkyi8qtyZQkm86j+nwnz/A1QQgIWDNStLCAdsH+43//PzIPitThPfUqSr8hP9J02w5YU3Z0'
    'JkAbQuic2RlwTUP2pvRk0VMpt16RFlqGn7+b0x0IcvCj6OVMr1ISc6tEblAC3hQhkxoSP+6p0G5Q26Zmjav9A2oaAG9EjA/1Lboz'
    'NgThX9MjbZjBQW9SjzhgdK8yLXbmJvprygf/43/7fyDn2zzXOu4+V4dcu2nPfrkD9BghzhnhAa2l2pOpoZ2Qq69L6AWgv+b9yrNt'
    'SA900s/I5y5SDtnmUGopvGYI4wArOHiXDtjpbXRR/V9Sd3UA6W9/Qf5meGPtywdT+1BQAlP5mDqRfPmAmMeHn/+CphKfJPzwL+bH'
    'P/+Kyn7/UP75L2Uo+/PfPv/wynkgtbfjTeQf0Y4qgIKecznQXl5KI7UIWdpuTnEaIEZktCwDvT0+XD3gSlsjaoA8Cf14fKD0++hi'
    'M3EbO7ylfAvTYQLLG5sQOw8WNkfkWoVE8RN2Aix4Z+S/hyWRND95y09W0/zsNT/JZfnJVHJJc2W1MrdclTQXhxYVzGVjh2zGGnLL'
    'CVMHpQ9hSj4/YJCx7oi9OzFpxU6T6VZ95r6TmXPvZp+rr3op87zSmobhZS4/6bdbQt6ejyAYIBKU6gEvfIU+v+sr9FZHxZzrqkek'
    'BpI3pPZa8dfrNyR/P76TCkuVyKlT/6AGOwYN8qa9YpsUSriNDqLXaV+wtumkxDWnjGb2AsTpdBgmA1sKkGEAq/sgMBay6UF2dnTk'
    'Do/olfNl7AGhWmolh1WJN8JjZCo4OukxS6Te5+fl89t5+c+M7Zfb2L6nSKlQY1o95v/PmDfc+OPH7FHNjfQdmK9IjPiWVzLefINZ'
    'Ar1Yf7oqJ38I9p9yU51V8Ic9QdOO+uGk0GdwZux8DHJPNuHvMXYVI4X6mrFnCoL2fjdffnjZx7sklPqvXjfgXeyzAjOInLSPr8XN'
    'nLD5lOKSk3lzI8kptxWSm6vfkdVSWcj57Y7/riiXzk9ihqaKdbx35E4sxf4pWyrIzuO8lig35mlhWIhc4HnNCWpPV7BzxZHY9pS5'
    'LKZC3G0J4wFtoNPq2CFHwd4NmK+RVMF90NAXWEzYBoeW2X1cH98OLHKXTOfj3dHFldVQC3h8b9ouYgtXERlEm5v4FCkOhTYlYKEE'
    'JbRrUzrhxxNaL1c5qVygcgotSOmvZS2UOf/+RhZLkUpKt9GuHQiRJ5J2Hxcbuf6jNDRtqV6bG5XMHQStPzxAVzaQ83VCbQQGiELI'
    'QyzznNPNIKNaqOYMjTzXxOwIOdSB8uukCItUVV1HlC03L2GETONIO0HnngJUmXV+yo14eISF9M6Ie68QNLP1pWodtipe91fzU3a3'
    'T2xTYn8t/xuT5t0nzUOT9jGfxcNZtiiLh7NsIUtuJnNZ8WMIMq7ylAm5mguS9dPTXSVWz4tjSsDv0niu8wpqPPeu3iQT9TzJdnn+'
    'k/odFiAWKTKgk6SpoyXOgtDAUs6I72T3Q2ADRKkgIU9EpPZ/RMdFCnjeH1KpEPvW6lkFj1i+Ql5h0AZOwuqcgo+sBtgnX0/D+Crb'
    'LRJSPr/2qcthbohUOjRN1jl1l76KmLhivFWVqv9YB4KepeoushVcbTh3U8UvtwH7dB3z21Aia9BtMD1k0zNOSHHI6Sl3Sy5uzEOt'
    'ZTTvgEGAkcV0NCuJzWPZl9vwHzAxTFkmmgM0cukqTPuZ73w6WEhKxdvlyIkrHWE0R4hpZBuaeGscb1NciXqO1gKRuxi4ZxhioLl3'
    '6PFYXUeiBLW2FG33+Hh4LpiZSni47SOan5EvSV6XTauuAe2HkpqRLtEcF/dyXBwtUJwLscQUgFIKgW28HKMrH3p6CXqKtd9/SP0l'
    'QhcdDrsRPMAZY7NB1CgxMhcS5Ax6Za8wNIGJtviPppN34MQCDEzFXW6+OkjnBhBV95L+YKTDNptH7BuGnMCuYhHy3NFSZeOOgDd7'
    'IbBe/bo59/hWmgGhFT5+TuXIOpYFopu08IDufzg934RILCSivc3MxxKbHDHvw9ux+FTwNraUAPf/ZUX4Xoy0mXQMHpG0TlxVwNTq'
    'gupOJdhn6GL26SrZXgVW/P0pdaDGH6+yDY6KjCXXtB3kzR0DMpzzLp6g2BqpIzDCZjTSn9GhkTR4NW4qyGTowPiYCsRXgoNqV9Ts'
    'ron71KRkFAYZKVwwyn/KT9RNNrsLSjcpDeaQzJmwr5VQqBI0pb8UHnHlP0MSegaqSj0B/05T8cunArZRY43ivr1iBC8JuwII96hC'
    'CSDrPyG1PC9u56x+v9z0TuTZctUKUXWPJAMzUnlK9cPcLjj+CMpl5QlVTV4Vx5dlkAqJU/jnApftDWROduGVD6bVqSVIyUQNzz0+'
    'kiVUSbrTnqJrjqlujjcPgPx+BOjE2PXilo4N4vChgj/kxFLEmaCST9lopwVR0r2NV3vyCIbHu3KNN/iR1Rpv+OdBy2/B5woR2IqO'
    'N/NzWjreoUQQpNv7qMJ0fz9XI/IFgrEpI/jC/I5EAfsdajAzIZodoKPY3eFT4U9/unpDPF9d9RE0gBRKaOB+hqnlPIKV8OklHiDc'
    'TOcQprCE5jA8vsqSubjgXFQJZpbKNjLQ/GfDhmzH2OMB8rOFTy9n2jvBTB8y9HinAPOmwBkXSC37d+9XbIh5Ja+hs2sZFUVjhcwx'
    'wGuwgeBvf/51eHUJgRHPnvCgP3xH3zbH7wX8G34HEP/8Kzpd+P1vn/N7WRJaXsPSfU4pFqHONQWhBkWjFLyH9BPKi+duWEJjj1PQ'
    'AZyvL0g22gFJCUNu2rOdmMLNeeNPmVfSL4Wv36ABVEhA5qMsGYojbyUEY76W3ctlNkyXGVmiuPwm2jHzTggz2y80kt+wSz8hCcNC'
    'VAUPajb6GASM6Hgr7eqJ+CllLdi4fEyPf5k7bGX+IeeTcjdLo56+4+uB6x09fCuUcztqV6eRzGEE5ATcRK6XV9eUnwoh+rp77+su'
    '+3rfqtwqiHhCXT/++HowuGuHMvsyqtFE3ByVKb7M/RMM+rXvN7g0w7Qeb12I0GKF/++IBP0clt5ZCgiVKti+NEyXDay1Ampd26Vp'
    'aGVQ10G914d8U7P6/nSr7+kOD4ICACAZ4ikTAeZobEDGxUcPNBDIb6eW0tufwuy8I1ankEkWId2j7YZRJnmlp4dCJBsqVoa+2BcF'
    'kUjMtdOG0JZgeuIjE5lALDGtTKa83jSVmnxxG2bOBWIENCbvGZopDHeePIIOAt84734HoWHoQBV+vu88fExTYECvc/qEFRlYPB8L'
    'aMU84c+f7tj7oup3x/pN6tUV7KX/whxNJe7zHPSiOHz8NSWIn66Fnws6Ji8w63gJod14LGN9QZ0EIFPQPxbm8CFw8SHKxzlSIIHY'
    '/IS/4Ow/ZWiSwo+TMtkQF8JOW6+x4465QCBS00BaNdYyfRDnUdmnp6ennAuToGzDzKX4XyL0bKaTnXlbhWaUYgXyb0YeE2aENtFT'
    '2TI9Dnad+dLNxnkuhJpi5a4CuEniKRam53yiHbKx+LESRBm6plYI7KoHMqNqbre328fCAjoYmiUhOO84hKH+gn8yQ0vqE5wm3d0E'
    'EHOM7nIMGjSSfH6H2hKlagUvXTRViO0p+kuKFGVEmWTeMi0WZJM//xr9Fk/SdoBV6Cg+AhGT6Cg7JBBhH7v7HL6h2g//8gCzGl2J'
    'NjwjwL4/3YwcuLsZkv+ctXBzakPtplt/+LTs9Qytivaw/1YEiHOFP74o/P1vfwTZH5V/A/LL8ZAwfUTwgdIew2Q9hrH9XNBSW0eM'
    'rlXREAMhbtYxNHcwo2mhW6Pk01UizU8TAVLR5zyydG/NvaQ1L+eWZTBXfEYlOpjTvCgDC1F7tyRRYpinPO3JF8P7BIXil2ulRQzP'
    '54wZ/DH9T0frzlyQuvCCD2ExN2VDJAuYUTCQRP1uNU/30zovqnhN+F7yxGMqjVBQevfiww5/oJkXvtyH3yDru7PnRo+ITKV0fIS1'
    'pWO23h7Pu1saJpd3ASWF9wDoTWI79hvYDu8Cdni6b8PkXdI/PmK+/GI2nl4ZXvG5sWF2hBt+gK4jeeCYUngkGaBfe7vCXuHw8Zy6'
    'hxd/V+JIWVq0+/T2UyqcY7TJpgrTLYyJXfx3dW3hLfR4QL9nlt8OEFj9jC/bwvJnelUKCMWeeUJHLPFKTv1Wrzvi6OqulyQbEban'
    'EgyoAyo62qhLRYXrYY2cNeQm4kb43DQWbXOifubK8A1pN9FtS/oNMbkSuMJfvuAqXu1aeUqgXOWZUugBP3p8+Gvqhnnb1Mn8d68u'
    'ebnSeCigNKolK10uFMtPOQ/om46Pa/kl/SkicRn+4vKf8E/e7Rl1CADHjiFp29Hn+2bTzR31Kork/DBy3smFa9l87dmWB5aabqQ9'
    'tV7gRnH53FGp7BQnhhNtVFy9gO9T+indlwRmezuZe/Upybfy8bofloPCfNv2nb2aT8iU9/HjvdSLTr7I+LmQc7HOvpi3Yfie8wx/'
    'O1Df70sTua3cDOVGqF2vuAnvXhFff/zLzx++Ia8ILeOzDz8+gAb5o2J7n5Gn21/wmxXhl5/xyzZ9+YBf0FXHnx8K379q355uBuFg'
    'iwwy+JDOzzedCJ2GBLwKjZ4TIT/OrF/IhRBo8W2r7GtS+BmGkX0u4Aeu8GOBYhj0hh++Yb+Y3JHRE6rrGYkHEb4dI7+k0OYEwIJy'
    'QCtq9pblg3WG1J6bjTrlUspX8xu2MqHfjwX0im1N+R2Kv6Fa/vzr5pF4+v6Mfsnsl3r6/vS3jLjUQEZDJ9uRfGQBmt3uN0BqR+oK'
    'gg0RwIy2ZvLSRQSwx7A2yHSITYrIQIGulzOs0nUXNMuopHdBFqKrioGuWMDCKhp85GGPH9RCbscqLXncGYaFLn8pTAbDRvc5NQ3i'
    's+xQB96zQkVSUfNeDsu/19sEwghaU0JYMPiWwMzOjjWunKEydea3Y10/5zdcYR3p2LIHTefnzMKugAnGxqRQ/oIm/QkRO6JEVIgK'
    'AyQHkgskVeKRDvMImYroG8oFyekDUg9KlZzdAKu4V4TMceCvMD9bdJnRtxyqpKYB03nBq60b11RBUwCpiaQoiqxUCQ7QI8AwMDRL'
    '0xT6C0nbDCyyUmF4nuIhSUV6o/2qHookeYKu8Bx1q4flCJbnmQpD3uohiSrNszzDstd6wlf1EBxHE1SFJflbPRRHVklIrrK3eliK'
    '56tclSCYtJ58D5GtCcEDg1yBQUedsHChKk+zZLXKoTI2LAp0p3CFqFJEhUWdB9ZbQ/4BJb5a5XmuwmO4LWTYLVUojuEpikiLosoq'
    'DMHwdJXg+bRoHbdKUAwPddJV8t4qR1WrZJVlqVuzHMGxVaaKByE713KlGsPnvOhUg3qvW4bpVmIdgHz69vmHQt5q+3UICk4D/u+S'
    'aP4BS/BO49chyB4N+L9LXZPVp6sNREeY1EWKaJf8nL69t2Op7/JblvCWE7J3qNBjg0QHBqHngNFdhMoNKpeADJfwp4haQOTnGU/P'
    'kMQiLWp9iMV5IHsNSG/g9AZKb6Tpt9uetgHom+gQ6t0RDe/igOiywzdOpjChGWxc9QME8g51oJ5PRd2C1NyqwtZDPFmAnDRdhX9I'
    'M6yl2EcyHEwoU0WIVMdrkk7RH8p8xDjNMCxJVxgOl8F4xdIcUyGrFJcvE97LEBxf4SBDlcnKgLDNkxWOYSq5Ip9fC1WVElFlqxUS'
    'kOmKm3SJJgC/SIYn6RtyUjQBqwxWK5Ui50eonuUqNAcIz2aYSZVYgoduVQiSvGEmXSFpkodRYLKCeI2QPAsYS2ctAkrDQic5FqhG'
    '1iIJSVX0TqCqwm+pVz4iP8krvgQL8joPyOmTfH6h6SUZgUSXrAFB+iUjjz8V0PFZTBPxM4zNI4lEYND50uEEYpnZO7KFlGrRSKy4'
    'QZGUIje7bwIYdQlU1AU6xv4IC+SBAMmyhK55f3x4eHphzk4ZVsac77c5XAnuG3qbNoWAY5gcjtmnvHKWFUZk1LmlQ+P3dIyTUKgI'
    'OZ5SLUJH5gkbeRrYznUV71Ijbqjg3SodHanQkT5F3nwV1BA7i1hYcX6hser6Ey6PQAONMEB7Wo/b1N23XEBf/xVvEmTft+g72rQK'
    '0s/Y9ASMK0CuD7ekHLMKKSSoAWQ/pfAAWjIZDbDQJ4SEQPBhCXwsWK82wpCM904nqKwXgGMwIOnZ6Z9eZQRN8F+xtkk94QdcIl2w'
    'uLx2VfyunBNwcAv/q5h2fv2qPaO72AjQX77Cr5Y9EvjxlD2iD1kGInvU8OPp27evjyn13FiuGzzu8CgiiwaLn769wdE8AO8umd9e'
    'LIAceDAQqv1nkBsIajv198D3DCP7ceaIiN3QbBcoK96tNbE/z81R8TnzE9ILmcfPbztTlZB4l943gOU03fCwQIUvKciuFtJNFH9E'
    'M65uyIAqaf2fXm5VIyvf1ek4jlIvyDDboc7iHaCWNrdYFK+kTWSoxiVgQHbGrVApjeTxfPNvSS+nwiZPBRc2nSjnIq3YuEPXcblK'
    'lOfriUBbiUA8S13UcbptGFEJb8qP3SMymKO4KUbqz4mUVXxV2fV6QRjIEHpvPD6lrrfXYqnrLWp0YfjpgYDbZjqeHnQA5v/l7l2X'
    '28aydMH/fgrYlSdEWBSTlC/pkmwrbFdmZU45M91t98noUShaIAlJsEiCJkBLLLci+uf8njgR8wYTMf/OM5zzJv0ks79vrX0DQNnO'
    'ruozMRlVFgFs7L2xL2uv67fIwa4XxYd1nmSTVVk5uG6tXUcc3tzwk1/Px4usgNtAWaaBN4dp811suDsL/GUj/0EbJI97PrDQPNCO'
    'H7OycqkGdkt07p7BqHI2WGHPmj9DQa+x/oVqNw9dqDpWfi9gkcQ962wwuYbpaSO/N6nWTuVS0Fqa2g3wzjk5WBcRkTwsiqj6MCww'
    'b8BwIcNhdgeAKYlXq6FXQOMzG+hiPR40BpLf7r0w7xbVj+txL/BaSz/jaOm94C5Mfdap02su7HS5t2J7sEMx0CNMb+AY826cxeLy'
    '10VbyO063lwzhpD/0XPnj55859n7EfimMfQHj2la/8PIcNyjMa25fzjjfzuH6ryuMPpOIluKkWFuNuaklybZNFvWlaNNlgL0BLEv'
    'W+2NZ0DkuLcy1OqefSoof4L2XiyI9p7My2nugj7e/fj9z99bqC6Wg1vF+DzoHyTdJRBkgztmmHC9PzWMyZMdomfy+tHjB/l4R1At'
    'cWM6zr/jC5gywDgORvsSA4enj8eGIxxqLN3kQHQVE6AMIXK3h18QQKgQh0bA3DDigxnZAaWzuu+7BFfsPF/qW+EbLDXkfzupBONh'
    'GPxnjh6OHo2ehJ85OjMy4Hf+M/OH+aP8j/4zH+fZk7M8+MxR/iB7nIef+fCR/8zsSXY2zpqfybXpKQUWx+Rs+iAfYnF8ZhAe4zwf'
    'jOwY6KL6zBjYkcIYKGZotly+wwoLQ0HsDw0GGQCLoTKEu5aC0JVj/BhvKT/MN3LlCBDxK7GNrmgoDNFncXLJyQJ0vWzlXB6vLKir'
    'ueRjRLoSR9bFsAW2xwSsl/m0822G6PMOy0DvPHB9GIFP+y617hsgqDC0k6k8HxRQ1+/vsyJRw/OzfjQ00ByYSQ/AtCmp4LqmhTf4'
    'vmxSQ1usn9kXXQugdNU2TeRaMTT4vBaovbfIz8WT+JkajlM9jqlxhqE7v87gDewOVNMDnmymyF/zVeiWrc3/qUDUFpmzTXiEwdcX'
    'OLbiZGfWzHUY34bTQ0BkEMjq7294f+OsbufdxhPrth2cSKb+b1He2jlMvby2No7QgiVzcYV5uEhjxnTVtEGfm7o+MIpJvI2tVcWQ'
    '6g/o+lT8ka3RfNU8SKV37hz9AOY1DQ7WDxvc8MY307Wo8IdNSuPcHqoWt/v1uJgkL//n//PXwuwAxU/OquSY+GB9qsZX5QzxD/an'
    'WXKGDzyxCz10jbN7uEco4mxwTf0lj/cM3tfc/Bs82ciTDZ9s+ITWRq+Vy//6ou69aajkoEale9SbY/D0b45HJ32KI2P/YMQH+/pg'
    '4h/s88EDPghGlk/5j/2EvtwbU2DAZR0LlDRHvMz/+vftnndTbXQut7d8B+f2FjyeG993fCy9MRWYp3NIOnOWmkh7JydeNV+tx+a7'
    'MJ34NNhUhYq7L44+fZjKB5IDBMmqwaTVwrLZn/CnNO2Ln/QkWyy80KIO0x+t+ACGiD/KqwxZZ2oGZfSVfpxZZk+BVJ5DYd1j/rVV'
    'fmaoxzT0mCahgSxlOnom0A6AdPDiP/LdaIPOcGXNKyOG7D5LHj7RWN1QUeu6uQskKHCl5gIruDCfbd5wxs+zXrCIU/bXW69o/Sph'
    'iDD9ABY3TVEWgMB25lLEhUsMsOnLJfti9RGE6OiZSnbN60J6mu3O6aYuLbMJc0NNzWycl9bopevloggBf3SY6oZBpy6dcQE8Aw6S'
    '1cSp45FcT+RAJAwqrwAMbw4IyljmxDw1t06T//l/CZC6WLF6VXG+AFbdpfoG80AJ6EF5RQR43QfmMnLmBlF1hEYPAkdesJ+dksZS'
    'eBRKNbSrZBC1qhbPFz3Wfr9BRHGk6IMZkg883B+G2iELwN4TsjcGvRMHIp4e6MF9NEQC2BMKOAbpE1rPI8cVEtWw3cBZ35EAs4j3'
    'TcEHAY0Kbo1PolnBkS/o9LPiMg8kcgtLkS2St3uyAym7a+YQomGvVrQF+Z1KTYELFyILUEGOp5BciShsI5fgKwRhS5G1FwkRLJA1'
    'ycYWOeGL3nAFiJhZ9PZu34oSaMZnzhJcaPHuHCQ/IcokK4jcLH7tZjlPRQ4MeiMwBEpSfGpK4fP4dUYopPpBPofYyoBYpH3J8kt+'
    '3CLMJkFWEJeoQfLrmSKMl5ViMqJXb4MMjaFFq09ZB+QQwlAuwSDoWY+WLD9RhtNNdSRXEwQQkP08W69YJVUe+tvwUX0X6n1HUwo4'
    'sKrVeoFkAheFduwsv/K6lEpzWfoJ18fScV0xAhhkfRBouhVu8BRNLk7TIF2Wdt48WuV5dYqTq1rmk4LxAxwj547ok3Gi91B04b3y'
    'aoG3SP4JRwm3gPVsSj9kWdM+j4xd24Pke6bUO9MmCkJuORgM8H0E2c5l8GQ9ohQmAWNFy+ZpVp/i5oXy0DIqGFmIpwfJRTY7M3PJ'
    'tdWYPbOc4QEHkT1BYAxhLsKAuJCOiaqnn1D7ayRxIWqg4vIkIPcgcV0sVVYfhpSCRGh+7fism/jWWG6NT0IH3fmGdbeZsq66SWBN'
    'TXNf9zi6JVTIfS9zcyD7R2/ZT2zkDp1kLkmVJfg0SL8A6xLgX//0/Q8v/un1u7dEqeon4ikYlebCim822TH2b6n9W+rH2/sLvb+Q'
    '+3CgDQWIYJifR7ftCKmHr43bJM0F+TBECZQhc44c1LSSOEkCVrNqYR83S2UbQfJek6YyfKOpqmkydmKReWZDYKzvvrmFM6JkHg7X'
    'dYgce05SoRPc4741TclUru1k4tdGU1UMk5sTz9iw1ueIOwkcdig4HyO0bnQSuM0IkCFkmqPEN4D8azhHSyRQbLT1QOET2p2J3rJl'
    '08j6SkeTyLIquQGqZjTXFjym42Mz3JIptddgOSBpyQqmhwusCggXOHaK0Y7670b1R+O15nybuWWsa/Dgo3uwaGCyXYVT+ZGLc91c'
    'nB+5ONcDi9imny+Tcay0Z91PDM95Zb5hPQC3sZt8xF+IBlGJuyjywDyOi6Utb62MRPh4ODDC4XDwBAvglnZB7kzFD1sVt9vXoo+6'
    '+9AAHBiL57PpBlA29uTPcPCAvx/g5yP+fMRO8ucTBOOMaF4dtXq9dSmADWwshsdW6A7YxNHwxJKIFyELBBQJs/X15FmoNcTSCnfk'
    'LEAVLNdTaFojMFuaTiHJp+eW15JWDM3pDfUOfHbMgR+IW2SylFNSevNGDi84ZYHvGII4GYnPJd3gvvOUqP6ekI70BVMgbepSTDcJ'
    '7Ne4T2hxNElDVseLAkK+9dUg2HtGK5PIpaZPVEGkTXqIJkK57wMKhKolvvkBJOXDgAYG0WVgqPZYI98JdQ99KnHcDYzSUWTIqMV6'
    'vR/p5ka4vyv3I8cWyikfLIaAyikfPLzA9DYpJRcWIaxvgfq6vtC0nruv7CywZwuYVbzZUgsLoKpttfS189gBi1nc+QXMOdr5iEZH'
    'tt4p3KMX6O8UETeLjYRj4qf4BN1YQ/kYy9SmhaomiLh+5nIoNVEv30BfVdUnkmiFmzr0O6UHIgr4Q42LO8WT3WfRDMvaw+wvADMo'
    'DiP73N+PhtaWN5cAcJz9DJl4MPwf/52CnNuethXuhdvbWaqSLmonBsGBLP9AgMUeM9jE1PdURiVSWdiFEi1rKCoe76eRtkEPS44X'
    'GTRfQ4vdKK050DvLuvmUpVXiWHoaaDhH7GRQasNSGyl1EZUKF1oZ7tenYDk+6dBx7BsosvavmRDRRFtqKfEvmZMIRaO0KMelWXVV'
    'rtky+5rihlhIg8AVOOzRMu7RY6zvhvo6et7EsrERIIb57X1gNC9ruJIraJfl+x7bpRUT8Wzh5LFLIBlRYqKfc6UL0MjKf5XYa8U2'
    'VOhLKH3YNJhmNjZ0je2zMfcfjP5KRxuyL44h4vfGvSr5SICQQ6hovypl4mTTVpNDu5vfeHd/pQ544LQYH9bIOKqsMvIMbZPbmPdL'
    '+GeyIhbBZLyeXOaSkohAz+erYpoe8J0Xi01vWVcpPQJE1+HlRIzPKm2Jix/oA1BApEsYTMckp2ea3MinM/DVw+GCgcujx5FFY0Xt'
    'HdC0fs6WyOQG2DtzvhX95D0PtkKCv4dD8F/vG/TtA7+xDsRDaApNFaHjCrbit2ze2gjs/Y29nx4mPXQFqGlI4WNWIi8rXBpu7CTV'
    'J6mwRB80PMPaTGSUGsdwMbQHgbSnNIFOR9qbYtRRZDcq8r5dy6ZRy/tRR5Gwlg6iWQxVt1uMQhxGPH5vHr83j9/j8Xvz+H0DppEr'
    'yw+XGW3OFofNDFVMCGt+9AchhKuI+tX8EiUQK2eB8lj6ekPTGyYuTKT3Q6Ajs7oYq8yxCS6gIxqkjuOUqBHZLepFY6mgU9MpBwp+'
    '8oDCq3KJljmUt62axZoORaC9IxkyEXQACCBqfSX5Zaa+3uUit9gSpForKOeEtFDiVlZTMpoQDEIU/O5DiT9B9pYd7WsCuDzw7EE9'
    'VG85dnrlw27pyeQ0otRyBV5SUFxrSG5WUw1ouBfDZeaKiKiOQwnVPVTCmU9fw5VK3cyp4Egm1Db1smh+cvr1+E8JNdpeungTyRKh'
    'AuN/AcNNFx9pGPEjjmHRNfkm8A5cirJGuEGxgny1hgKKNBTqss2qdTzyG4o1GLHwT52BZJVAb3AKi7Zhj830ne4BV2mgV7hp6AyY'
    'SMuO4pF8KLVXqdVMNDRK9ZgvfE/xQIoj/ZkrHimaVCS05nm3hDR/rXrAZC6Awi0o3b5m9iVvH1YuUgcJdszA8cmLaewKDisfSQ6M'
    'jBAzeOPa3mjCYgXFh83iwxOFyGq34jyzxyJJOf9tXgemEgA2xK/WolKraaupZcbqTFuy6hLV2flqUc1uoq1tDrxrePgEs/Ox+929'
    're/u2XfbCr48uVCgrdNpsTr1wfwWF7lOTutT5+dgyaoXoim0201TM8FtsG2cWXCoNsFeuH2OzOI3O4gQGLvNRxeUtIbDrlNPMYgf'
    'DK1wEFitGhbElpgnB5np5gCiGqyonCzcgMQ2T5lt6EgNimbFi6HRcuXh3oyruig49HF15uXmbszj3YgBxGasrUJ676Purj0ov26I'
    'k2ue5eGe5EvIGG4+aM0S4xgIJhBcc1mAORXduSzNPBNT3YMQMIOapI5lbjXmue1hLnr7j/zsS/Y1F3X7R370pdOka9vrsOTYqvRs'
    'yXwcmOwjVbmkWDYMPugOkYcOEpfpRtMS20xwjN08cFneULG4f/k3XUq5z73qEaKZQ+1ffnjx6t2v/yi9MUf9AYOt+5rmi+mMmVEO'
    'EQGP/bvrBRNiq79S4MvY0CzIc+oVouVFEyrHjBZXZAm9UcBkjIlsX83JhoSlOMAJVSeOBciKMT0IbJAKX25NpNtMocGZvpyZJ15T'
    'KGe5xdn+EvVzYOodQy0VmHrlljf1AmQpVEp+udkidKBtDIxSscWOw4I0A7VoDEpgNobF2PrC0WQce3dgoMSEa8fKCOaX1lbSB7NB'
    'y+TbyDZpZVztTE+FrNMFjYiFzFTVtK2iHZyZ1raqbJ4Cq4lPbmyp0/nl2wehU5wALFfIeZ4zSRDZRfCY5ZkaIs9ziyQkXu+zYj4W'
    'm59jnFfS/Dg/o3JIbb0ArwstyJN1rQpd5qhWUdI08uuZd5DRVuhYZ4Z81Y/xvHX9BgmJ5ACyYvFpZah5vqpOFWDFGnA5NXQQiHzk'
    'XQRAE5VWlpv5AKAfa52MFL8F2LP/lWa4W6wpzxrWlA7/iM9tGk/0v9rY19dhfhZvO9TjQvI4OTYHUkMl6U291EoeH+NNGiVg97gb'
    'XdmLJ+HFflTuSXS1f3IS24qQil7jCDBs/FrDz2fiYG6aMdRGvudgm0U6yPkjG5M60EqElbSp16LcoGtCACH/gQD6hPPlq/8AjjiN'
    'JYlEh+zo6JncCLQL8gSxBuin0ixJ5OWplqDiWucB9G7s8nwZQd2QfrerdVPK5sb+Neu9UM8GacMGhDAWxbpUyNPaBy7Pu/dF1bM6'
    '5jDgL9DwjDdvXI4se7cL6RvVcDQVCxdjbd+lZsblQEyOB4OBe3QePFKdBPM1NxcicVEvK65C+3K8eBRIvQBzLPThmdo5E/NiMxdJ'
    'cDJnFmm3T3cC4u866UKKjH2RsSvStihyJC4DBdcbh2MeUSF2LyXbqmODr3sDnG8CzVJt9SZtqRkVkQBBDCX9T3QZBIfgMtGtUML2'
    'JKsRarejpPdOgoZmCQVqc0aei36QemazzuoL+AMFcTnNbdDl3LwU5+YrisNWcb4/FFgyryTfD/DSloTn+EvIK1nwjs4sJM+S/YcN'
    'EcBbBv4iloH9h+lhl06f+MnPE0ogDUU+Z/l5chHY/akpjLOWHEYhvqbrZl4ksBe//wHesJMr70osqEKxr0tv4r1T9hq+KuaZLbnF'
    'oTN50ZGBxWr+RlT8JS9dkfdNx0+cYy+OC3h/n8jpZa5OxIf35fF7vT+Vq8BdwnyV/6T7ib+ciugEhCJzb0L/3MwWkcsxi7RUhMFC'
    'ViWhLuW8UiXCG4UKc2u5Lh1zl4Lb8szWJonYLVKgo9ATu0X7g9V7PQyjX0VBYDUGZkavR2HQbOvxpv221TfgwN203/aP7Zkre6Dj'
    'xC0tMe3USAVGLJp4eC4uaYuRGCymrjvvTqoQ79HHzS36OKiXkt+VmcVrghGWXKTwibkeyTXEwAvzfDO013sJsGM2o2bb+FIclC9W'
    'q2zDLHW9T+o/e5A8eACeqvcvFvU5svY92E9vUwvs64YQHP/znxYvy2sYL7i8+RfGOfNbey8/duUH+9u3H5J+1VoVFGBVb5kfOeIv'
    'vYQ2AUddhawx0JPNSA4G1yOsnsFgMzLk+NWsWC5zut7R8ZOsOuDxTKMhFXbflkksMMJ9WU+fo93wJ540/Ikd7bErrx6KoqYe2aQU'
    '0THbTz4op7c35YGI6q4Zi4zr65HUjuu96caemBspsOHqZ3OetcP8LIWBs2kXPkT0QQa4BWjkw1E+mMWwPAwq49v1MNxn8PtfWUSy'
    'ehTu0HrERw1f8CEOlnqkE/vrokOgjOgPNedv/+ufNes4RC/P0PWsaNnlDmx9gammF+FAHIcJYHgKofIUD/rW1tBrCq7Qmaq2VZMn'
    'hMSvSgfJ9+KRV1SQ5hcL8W/V7Ap16Swc4iysgcMXxLSOfZojF2RKowwSk9Toqzz2nKZ5w4aaUYvgh4QBVZDp9P0DZVwZjQ2RUJPz'
    'eJBHyw4jP3wWZWMAU/TaarPF4KDJRQXEuA9viYiN/SQDaZMg6vFi/TDEV0DRwtaFL3ZBVc6ORCAyu5t/Vkm+ROTIfMb2AqkM3AhU'
    'sPcjTdIxzRVUOyGS5X+ZH9LXi7KgE28CdNPLlJysjKJpcJt3LCaTQS1qFUIV3JDR2w2G+PgkBFA0q+WFfOwlytrPh43XsZtHrZDE'
    'Pl98Gb2I4bavLba9Jii/fOkoeQCk5qAvQ+YKR4eObnfRWsYOWqZSojKM0hgomGRJOvqZChcdFY76AvI+coCcEq0kqDc+mH1nx6aR'
    'DDZVXa6Bs2DzF5qdjk2lUw0IHAmiCiKoArydnAilj8kSAIbxibOAPRg8cndHand4I1bb0HewVxdLmmfhpPeXNNC1zehwrmcoAWAX'
    'JDJMI4NQDNJjaLJY254wDtIQDcdqyDANQFNbe+2TkZ19mhg1DYsYXiwPxNG5Jt0LQkkmTGhNQ6k0UdWSCcCB3LF/m3KtIagzOuI4'
    'kC/Zg3D0N3T1Mr9Cdki3C9WtGRJLLVFdTU/AYhmKNXXk2GduuBXzFzr4RTLsSsxPBbf4SgxThcqxmALbZmx7hO66x5fE6o/9Yi//'
    'cmyG9n7ygLwv6xLzvy2zicps0ob9w4biPuPke4vRMa/EsKItOdMKlkpgVKH1c3PgWnMPUG7Xv4alqMlft9e7+4X17jXqPemypskR'
    'mAXmsyypzLmLA3uRN2Cr/TbA8qrXZtE2D72kd3VR2DXn4p8kTAcS5kW5XBYSyqEuQbNyCX5xavGhq5kFwfbNiWOF32roOdG172hC'
    '8ZmEAKFFpyjwnfJLlw9/PXMGQHqfdizgVY4yr46hpsaqaDDvwF0R/p2/EKpof8Obqwskkw8DWvlKaWWw8tVPJz/zjp244MrH60F3'
    'D2iFDhzadJFq6OEr2XMcMV7IjhkQ0qT3Ob/c54YEPgoEiTAeUe9p605brN6bAfl9JcA+Mt44BUj0U/+C+jXEr9jy9tTpR6kDzDIX'
    'zuOVxOkWS8tRvGKIrVnv8tx9+EjiBswDW9I9Gtq6JYHQ0q+s92vCelCKIRfpFqKynfQBcKr+ZcngPi8jYTd+blw+uwzkW/1K0GtH'
    'BgV++9GXjuuXtMc3oxblTrvNjrnBsJ/+/M2nV9QxAAWTvzY3ySv8HLmbI97Er313b9/de+DugRSHgOAwhjogVBhILbIEbaRma53i'
    '9DVzsYdbSPu0eXbvm0840R8M9lE7fu4PHt7cO00O2vWUdb29HrAlzRp2QsYUK+RH4S7cKWF1aKdPl9BITp/dM+NDko4vJM2+SV7r'
    'rdtPD/fC7YfH9up2v6y6+My4+d/vEc0J4zi5uafjEl/tUSp4dm/kbmBkEUL47B4FvHvfPg9nkTnDP8iwTIqV2fDJ5BpVmmVoKp1s'
    '5PfG/F7Z+RsN9unO/+Qm6A8kmBtWbgEONRJaxDezQw+Irl55eS+r6ww5+bwL1VXXinIr4UqhugFkrK2Yh5WNfzQsl2WozKEJK78K'
    'dAprtWNalfPPnK+FBeVXTlX0xE44OwpWyTefpu5DYfEPB97Kbq3xx0jtJn+8iaZhki3tLBhBL5sUtRnewQOMmlvA6Ig5tL6s+cmW'
    'tqurrQ2b6sw+utFVoK1ZvxC3b3pC3ywNV6E4lY0KicYMvJZJm133vilRdW8FQsPS/q1VKsG0lYKKrov0a8alNmJgJYaf9tD4HAoP'
    'YVyAl31q6vnmkxHRb8TV49k9w7lX5eqAjp75ym6Zlq1E48rBNylqnB5TmeFNZlOXfditdIflpk+FRxMJoVzUzHtfhNDkmpTUHMGS'
    '5q6dSZSQBvSe/oWpAm0aUe2sIBqgsy/XxUwzjanaSBVOUA1elSvmXS5X02KR1UiNuC6eSV6rAAXZsANmK18vgUasuMlhKC/h3tZF'
    'P1GoIQdPFGpQ3pn7Alp1zGJqhHb5lsNJt0lVcQ/itksHrFYxSAE6RNuNh15OhyOWS+bE4gEmXaelHQXSzlpvyTwsSXwFrCzCiNqe'
    'ktjjq0mIVZiiNyh6pkUBRycepFCAfzIk+0AiqCabAwmdWg0P2mbGlTczrmhRWI0YzKrsNFDlAsUnriPw3oWvxOWAjXKyEGAQoG6y'
    'ZOA2IzBmVDfS19pCIFq0v0PRVWbMEdZXpg/C8z3AZ8n+DiG6w8R4qKNyc0dBIGeelJAVENBDwwbA3a1cWF1dS8TgIfJMi3jQOYX6'
    'UsyvdwP0ioBcpcO/J8iIBRr0OZstng6ShL0bTCxaXRwB15z71gTbSIjTbz7h+uZfv/mkFeEneiFMmXoccEiOzSsnTaGHJMI/RpVo'
    '6JtPisS4u2sr0pgww4NXQTKCThiWZ8ljhWGR4iTQlUBAnJlNBILbIyjiboxaSN+9bxEO9C3XHY+rcrnHL8NbbtiaWH/yWpreWKqM'
    '/zjvbBzLKpv92WNJorICJ4Vdcf+0MAvx2b11la/emjM4/3XxT5U5PITrAeyiY3uAu2j5Hunkc3O04kNvnn4bN2S7Ekllp+vVrPcH'
    'GWEZdaLQB0F88MOsVDHM4Kt47dqkxbGtn54V24idJ0uBu0QX1ZlGIGKDaURmzMJ4Ld7sZ+VkXb3LJDOcS1U0UOizqmefp2GBEBKy'
    'o6jybhdmn3OvS/CDeZddkDExk9lz3ThKdp6eBxzT6Mm955JPD46/TokfuVkt+poBJcJOgBWB2W4XdKKCstoSrX7iAeYeu9yJwPyG'
    'LvIg2e/rYvskir0DNz3qakL/EJx+FwhBOwXs3h4+BssHTyGm3NBTOfqwb8/ttxzGmV4UEOL4JFR/WgiawJyy04BH6TmUEx8eorfU'
    'o4Ohzz4CRSVnVd4Q6SYIZHPxXF6TnucvGs48uPemrlx3Q8sfPVDEvUYHrOFew/e6rbij26y4Q0tLtXVxtTCTC5tNy4VGY7zZnZBV'
    'MpRSvogOM1TpwI9I753LPedAJLWfNOYKvlTvYKB65oLdtE9ilzejLFtXfVFw4zVyWPnjC5pAOQnx0DOHViTpa4CTujXSAAbVOwQp'
    'psmFUs4pRARheLGweXWBS0ycXk121vuNjCR3HYFd7F7M6SuKJvKJhFNKwgiLdcM23YY9D/pZIyDoyrwKrZZZk7bjg9Rj74ICmC9e'
    'F5KMJaAtpnRy14PxmsvXtLP5W7/0zE1kvPU8MW/45LR2CO+9EuxU6TEwKTHU9/qKT1ycneXk13g78BtFumwHl2sZl0Jz/fpM1WJd'
    '4OSJy6DhcuFLJ+oogSm+9wr5wnMj53GHEUkZTPULi+sKaC/Bz7zAzFyZYfY7jLWLTdAuj2AhU7n66/i9Gd3Bx2y2NqQVPCu/Nm16'
    'oyFbOgI4JEN3uO2Er5gN2NjRoC5fl1f56lVWKSutKatMKcwVfxhBwXfNVOcvLE/x5sXr79+9+/5Yu2fuVr3gFZuk57/YgnrjJN5O'
    'XBgFjRqyZIKVccuHz3PJG+oXyGygcVjPbE1mG4ePqWu2D50PzcxuzYiRJLqT2nbH5bVkTZV0pYvQ5SyG54x98gODKJPTESrzQpBK'
    'bw6jDHPInTjLAjDJZTaNE7cP+94VQUIqMnHC6SdjRV0TyE7rcoiXMnXjCAru+YJMdJdy9u9va2jDhi7s+4LcdtHRkPiHBAX3fEFp'
    'qPNk4wYSzQ24f0Yri9OhoInlNtRzZSPF4DIhm7kqak29jWQ+NmibgeHBNnYQXjwb5yQABQIuxFhBk4kGSCKADN0C5fMbVFwAjlsm'
    'HPbhvAR6GGoGdgkjKpBhbIl+ntKqUp2y8/SVMIc0U5yZlnqfbLI2LAqcfCDl62qdzVxKU7N5SHRSAL6p5784+RgJLbbJXAonoChw'
    '8pbSQPanAG4QulldFGf0AJFWNFWmuku7yuCAYlELe+roUdUQz0pnwbxUYLYgpQmtVmZKNXhUm0CW1QP/wBm8BFMethUJWJCZ4naM'
    'b8k48Y5wPbQSMOLADJq0wtgyReVjOD5CfPP8rxLEkJ1D3VIzHncQRHGW9Q+kuz1yeZrZuiLgViMyLYLgwMWrkjdCFI4tYhNCzy7b'
    'uBQKewYe8ZK5HiRR9p7H12VqwEvZQ/cJqfJdaMzVPtcOzcIz+1GBDmwWJpXIuwtG4C4s2IaQlCgxuodJjNggQjuJMFr2ekGZbwVA'
    'krArvhq9b7XJ8WJsQ3UcV4VOFTlNmbQBnJPMDunFkFLHGfzPNuqNNrQJMYhszp97we8h4wke6c8995sISlqYP0/aECEr6wcj8fwL'
    'KPIzKPfZvQGSIGbX7vKKJ4ME7S82jaI8LVy5iwN/X6EI5Vr2ws1hlCJPjMLPxABYMtp06EuEOQqpYYFTDr3heLIStItr33+dO6Ii'
    '4OmlVQ8RUdkeMOUmLmP1RvxzYRGiQ/AUU+vT5AGhTzb4lcoH7O4eetQOllF8lA1/pvJtppSr7qYxHRPZnnKQu5ytE9PHVLQ8u/bQ'
    'Rd6asg/1BPMcMb6UR/6XvPUEbz0a6msy+PeBS7Orw38/eRh8cgCUJRvsETOgoHgF1IsHVJ64Mtl1Gr6SbSRhioPekVQhGqxxduYc'
    '9HgUlGJ4wUBUEWANh+apI2JQNQcEjdBAltyt2gAzEhOjxZn+QpBoQuBcGXRKaCgau4sIyknk5vG+HHeKk7dyvy6hpHAI56Ukpa7D'
    'yD71JotcAxtu7S0GUlzaGoxjAJZEHnLcrWhxPoGGVzT8TJ2v4F39PIHHNTdXxlVsr8aRftC6F3q/uF+YCe2XHtACrHeckzmhMkg7'
    'FR8SYGhuU4dPdcmM0eD23YbMm4USb3B/rPdP0r6Terf7Uj/zMdbsm53/4IBxkrxOXFbnVnKDj9QqdCBh5hJB8PEitdTJ2rQjtMzc'
    'Imclv2Lcrooq99wNM5JU3inMqVZsHo4yzNDWt+3gk69ukTlTZYUI7Yw7rsZBuObWdellMSyHQLLSu7GAph4wFFYImq7mhqMEOlO9'
    'gmwcxw3aWpGd5MisW7Qrr+Anyr8biFemzbRthHwriM4mgaJ5NnF7rec+LuD7fDbLlXO7O4BLG/npqzTiCV7Q4pFp+Iusbeqr6cIc'
    'qajNEYYdii7bJDIvwI9Mxo27L9P076LOpv65pa6WrJkTONKPrY56i4YaNChb/Q4N9fUIJV/QLr/R39BPX+/j90u5r783ka46btJ3'
    'ikvHaqlNF9LTw3DCP4RSLWMAXvKIf+FiAF7yODfdcFJuPBBb8x2pl8sLiWOaEsb3g62MtxT57to+Jh7elE6CI6bGs1xO6NM/LQjh'
    '4PQHCPEkVRXh31yO/SUpWa9LwY21+Hkd97izTHAsmN6kXp3dUGE/uvdcl6IrESiyPY3/Glo+M1zJ/uCRV1QLggFCT9RTPfCojhXV'
    'KEm7iyiqvZ/6gWrrvEYO1AZKVOv7AKIB9d3NLZ8OJfctp8Rje0qYFoSe87NbB8VjeI/JR6EPrkkwC/a9mfvU2eTALec+18ZNaK18'
    '5yMKaH4m/gHN+SUxx+krsh0AgUJjwJi8CTXcljVJ088ci10f7PXb9mOp/LqJA/niL9XvQx8wGJZbV1gDpxypbKI7BZFeUN9MeR+a'
    'YGp+BUbPud9pYBxeYu5yj3vsj6u7PVkkvPH9tKjdMmllKKeBljmk4D42emRpEfOpI2c7SNLj4TD55tNZdbO8Nn9/+PWXd944qXI6'
    'BTwwiKPv4P42GkquQUNghGqJx6vVnwQaD0CU0zEl56mOWGaoDjUrD2a6ITZotL1PE68fzkzxsH1chVZzM4t8gb25PVO8P6ECXBir'
    'AToI5P36Cjw/Um9fiKdcZRWp9zGMu8kTL/LdNER/EERVajQ1GjMxWTW0TnCSkFSUcw3Ooxy34Q2JxguENoYLbJY5POwlI9aO9QfZ'
    'SZU3mfTmqfMK4/k8tc5hNl127bXqMB0Qciyr7ErNBSOYwPcu47waUI5n6tkhsO4Wep36VX6PO+xEqcsz+DzpIHpbnH+++YSddZTs'
    'xNRbbHY3z58iEiCh8ZgHMH7gVPZ+YObiIse6wtUFDMrX3hEJqXtlgMUPyfrTvRuMzyMXv24qTO4NxNesi0mHI9jWt/aZf3afPMod'
    'L4r6pdurrdHt9Cn2vXzifOA/EslR8QpWYa+Q1Hn4BJTeAxkEayTax3uGDzWfmi3qPYQzoRUzzpBMs5n5ZrPr986yeTFjxdzuercq'
    '/sqvN6RA71zpUBoS4UcL3274nbyamM1lGB504fmpzxFqOheeQTdekWCJGFiBW2hY53prnlD4fu7cITeqOtbgtHEnoSxC3F60gAME'
    'v0qs8QjNwWUml6HTtefP7M+q9xl3gO60YdfMhBmk3pJNLq49Lp/apMFXLyzVYk7PgujDXHTQrDhTenXF3HueITgf0JNH4suIwAT5'
    'Qe659w59VYKtdCguoTgsqXFncsfeJLUqCDeNYfVw0emoHSnJxGtHKj0fmD9Hjcxy+2LqT22D7wZIyMeUfQ8fxc26+t8NmHewUe1o'
    '8NhWYm7lE+7UsDIKWxijACC2nRIv+I6dwK9xp2OobGN+JK4Mg0fcQDbEBl0PHqRhw7L0kQ3xXbYCGAj9mLD2/VfiaaibWF23E7qF'
    'z/kpdBRQ5G6mnpJzxnzaKqM4lrZSAVq8QyVLcMXVW+qks6A2deoddRbUmU43jrbqgsb1Rq4v9NpSjLOIuFZd/rs35h/288bTyAO4'
    'GHmCb7vhCOI0Iv2mGxHxN91wXVxd/wd6EznriC/pM3E5nGVmnIhVeVlMX4GtVTPkHb5CJ6PwCBTxU9xTABZZVfCmnebo1Be7/jQO'
    'xyfucAxc09xJFCwt35twTPcoX+uQykU4ouCE9ulFIx9+BD0w0qo1h/q2go0jeHUtuAU9+5rAaW71u+aZ25ql/XsdoQqPk4deD0BX'
    'QemNGQy76u+Gu91jdlOHpfNpHXwYADizmGHk24nLBXo/YUqnIKGRj7YKNiU4WUs6nlniQRIxPk8O9BEIeBVytaDniEKyzJSdOd3j'
    'vRF48GHfHggVK+hHy+KR4ZlwENtXHvWTR7e+YJZRethA0La0erht/JodM316oPljd/oOsc/cPfUtcT6Z99VIvtpkRz3+89wYBRKv'
    'WdHz85bTZXjGFnrIFvaU3cXN+fk/xwz7ZMZozVP8jb0zZVloVuwgATYi4F0CbEitTeiyyjuBiceKYQElddQV3VtiyoCG3xCzh7QB'
    'l4a7CrZo4Uhe0SB3RZPeFZbgPTab4Om3tuqI5zx9WsyRxvtilZ8pMZqbqV2Bn/1d7aGVPYQJPLunui1+Q3oP6fuq3PBqL5B5q/7H'
    'zIgpz+5d/1xM/9n8H6GOk9xv1lCxRGQWO2c1yJJZipEkpklQzd1APrJlDGuGNFy93swy1Z9aw+6Z7EXAZMP4U2i9fyfe2nAMLe6a'
    'd3nmmDGtMzMwJPLynohJctuSeneUGUbD8eIzz4vrkKYhRzi5MIe6jp/TJtNWYw6dJdLWBwrcSbiV8OZvoRga8L54RmRyqd9VnCUr'
    'TUtP2miI5rkgXqgMKtDBdI9A2wzxNGdd7cEAbRIYqxBpmRfBJ6HRAYJfLHd+LHdOmDH8yeMn+R8f71Dz4soix7w9a0Hc5LbXDQSH'
    'tlnKtv5TOcBNMxh2DLc8SrdKsqdtkXXiVppb3Nn5P3OMzY8flWlyO44tNPccCgacV/BeEBwWMTjm473cGkm6nuFhGWHHzcETy6lC'
    'NfyGmeD4lr5py61P+rvtnfozoqmKLKXZC3ZbuCnc+cOO7TiAB/mDEqLbNxBaT/1KwIc+s1+qVmAu4h47Qo+Qh+6Qvmkdnq2E2zxF'
    'QzrWPMHWm5jw8Y/DXjtsUTFqa8RSYTdr7SaFt9feZiGMfFhi35W4LbgR4w6RCiAchiF4Kl7aENy2hr01qDrioTK4B4mjWJPP6t3b'
    'fXTPAskQIdFIS1lSzeGBdu/f/4//8549f13EYLnMFy7n4ksg6dfl+bllv9SfHzRMPhmw7Q+Jzvgs2fih9AxicyJETWEmbhdrplet'
    'x7DKitt5eAaZOiGGjqiaoeHQqQq/a0+XSgHS1UAS6CYgIeUY028w2m9jnIujUUgwxiGx2N8XKjEabYtj7aQF+w0dVbjzx9e+8b/L'
    'Fh/tNzb3dx2bW7Y2R7tj4wbaprYQ1JbU0g7e4GunqS6MZPD8lS5rXZamZ7wdx/mOvRg91miX0TDUQ1K58blo48Hj1iQFlIBr5SGo'
    'uNKAsacBY+wHfbbvnt3W2P72PR6O+i2SJyXafFoQMCsUuaglhaMAgizHZV2X871ZflanB+Crz230hER8hkhZNCsYLnNCl1FltheB'
    't2mXLHZhyYGRUC4sIYAEupc82LpV6WCAENmty4CuchdZ4RfCn9D3Vp9xR+JXL/K5XRzxHEYr5cKvlIsvXCndcnLXallXVgD4Q8Fv'
    'VN7/ItIHXDQUAtidlrpwp36NtD54uDU4e2vofOcCu8iqX8o6DzNUqgCvIjqEtKSYwPSm3KcsrZXABFGFdiD+LTo1sHcsUGfS01ey'
    '5bLvV5iZOh44mLp00Haw9IfMA/Ws/JK1xRa/mLz8ig7wle7F48+KBSbxiWPLeEwMg1l8HMziH+WMePAfJ0HHe8hvOeoDRYgWDWgg'
    'rUkj5FNInRxtWjg9njIpdE4oXDQYHHIfpo5c+eK39+7RLZyJN1QE3Y8MFpFOwj8Jk0/RwwTKUvwwxxH+mNOIV6cuWE4tEawLUexB'
    'Ap7lcrb5r0V+1QujtWmOpeIZnlm9bz59NCUEMYO/NjdImpbN3KNLjXFkRDlcj17U9aoYr83LosA2otp8hy7KyTe9nT+I7+RmJ729'
    'rKlxWVYFegrbTLnqpXFa5Rw+fdp1abtYmG3147ufXzPHGkLT4QjBqoJvxWW1WUzeleVsnK38DW7pN9nCxp/T7Qk9xvz9nC/WpsvC'
    'IaYs/1pvS+l6tYFhtTRD89b01hAAfN9PdT7vvX336z9+30/+t7e//jIwS8KcQcXZBk6MqarkJ4gWUkDLu5V5O/8tMySCAADBJSHf'
    'gGpZl1lV93bMFwDTgoR+XZdV9jF39AaJlQzh//d/+28JKO1bPDPlIPPSOys7y3cIUXyDNfHt/WTP/WfYYDS6CW/d/9aP/KScz4u6'
    'J4aKRVFdvFgUczMI8LIs30I5KQ4O3d/LA9oVVFb1OXI8pkEFjFBAnatcb2kgHRAM/lSs6k2PYxcsBw5U731VLto9gyXjjSS0EsIN'
    'm5C1kUo4GRzn8JspOgwnKN1fZqtKK9W+N+LW7kqUWirsBhM+mNqBvAMghqi3dsVG/cYncyirPDcEAZc72tLd5jDZEPNgVG4baTsk'
    'wbSUy17aHDdtny36epstftHc2haD7rkWG2tMmTEcaqtMQhbj5cbj9N7FenxPQMYrF+aoAXsHGjjEZCTE4gAXdgYfH8uiZYrvrGcs'
    'QAoWPoEJ3tmp0NB4Zvr6LY1nVjnUA1O4oZoJWiPxJMkH5wM6i5puEZJ1WeZzm1zTENSqKs4Xc4QjDzSlS1H9iLzlCePFXID2VrwI'
    'zdaCOFsVTOHRnbE972oZRywm2Rk8aMUnU7RS5m4g2uL3mboyKcx/yWwh8qKRhtdm2ub6IoBvoRJDk0xKEiJr2Zar3GwMczzMNlHW'
    'x+uaCrAeEfbza5qNwrOlKujizajKfEqAfeshfYkBurQ+0fouZSUdp7sRrkZfvvUZqzzGP4FIfBJgt9j4xF6PLxy5OMTCzNo1PLvN'
    'be89i8CbXSh2OwIWiQDzZ8ZKY3RcFLaZlXhGKsav4SP7skYFKVPWicRxy9SoZc0QCq5A1FqFuReQ+E9ItiDe2glHCJcA7/N2sCmC'
    '6dA7PyDA2lT8kyoYvGNa7EFAi5KdGSkfggtcdsObfIqawfyl2+CXJ0G0aLG72x0S2gTxgFMwnLuCjp4zMwKQYwQJRzTLXZ0Lu3Yu'
    'XVNDvnshmRyqu4AWuLH+Q5ftIvJ55MK4Fv4x1wkRQuQm1S0HCR9WnGW7q9pTpEyMnABsdccxIE5olQMNrFBPnUPkFG5MI9NUZjPD'
    'wtidJVQnjYejtp/iDqWQt4J6DD6BzDRlWOjzhSSutYludG85IB4JxV14MwfhKPiWtx4vxLGmmduz21klTJS4iENHXCQMuPiF5Bft'
    'WTPxMLWplB9GKUc3LLvRsjD5PnjiilIVd2OzQv3ArABykDDGUnJ5giZPLooZMQWA2e3yEy535FyySUmUBUPKGXxXpnCyGjO0lHRR'
    'QhPi1FmT/BfDoC47BlwBDSDoceUvB03Sebc53FysKeWgSxdELOkGL23Sir5Z5Ta1hYuF1vSEe3zhzU9iwqyWKwHX07uOP9YzbZm2'
    'XY9+Md2MII3aiQ+X6npkerJU5fE1WLNGa6LmVufpa40pkSSHWqIBz7CMk4qEq2kZuFZVdc4YAcOuBelC0PAjww/CbXf0BLiizLed'
    'SnFp3Zxve9Pm3lsNGU5nRwT5zPYfwB49xD9PzD8PvxvCLCQurNGzk3RrnCl6uNcRYqoe8DkJIvvWVCFP4XGDAvcTP5v4pDsdmcun'
    'GZBHZejbSbt9rJQO/DSLH4FSCuzP0meGeDR0caxowuUKzFIJZn2i5S9sfGtcFAkpbdFHcXPYCktJmuwiZVmx+LQtJROyfSQVxXit'
    'HSQu3fbdBB82K095jCMf5zAYDMx97LKc6AuL8z8VZ2fw8cuR6+nALVCXY1SHGt/knaEpWZjhH0NUH+V7f2RAHl03XBzepwR9JWpA'
    'Qx/F+LpWaN2dOPmkjNY+1psCt+8mD4fAZfIURb/vJjoNEC7/CpRP+Lqs9t5cn27amc+WerJIRKmztOCDprlZ3XkS3D38jOhuzmOx'
    '5U6nCjbeRNpbL3BdiXU2QL5CHBQ40p+mu7t9qBKYDROUwFNa9pMFS7MUjq2bJ74SOv0DwjRh6MrK4t2bXyBWJGvmsrBIiQfC6su2'
    'jzhhLIKlBbMiR3DAAr/ipyaZ4irCkJL5EFGymAZsLC6CKTHDEc2IzMIX8wvBMLUmN+2ExYN+4V2BGJ1PgRxr7/b8RJ0TPTrOBAHR'
    'pJrBw3syKyeXjMMT2cPhtkuUHzrf4+iL3ib+4reG2QCEbiRRcMlN1queHGBuYJQKV5iOCmLFgfnjTqMbL2c5UfDAAn6MN4oibOS/'
    'pWHLsfCuoNzH5+7xdiGI8qUPK5RoQdHvGnLs2f5B9A0/m9Z6v2u2IEWOx+V1z4bKhQs8ABFZSei3c+SCPtQsL1VMSMgEgxQGUvTo'
    'yPwkZ7YrkftfsB882IghKI+FoASaj2CDyBFmhnBqXkaRHbdfHKOuu6K99n/PKuxcRZxsMHR7Z7Myo95BVAIHAdiHYdL8YlD/KVMr'
    'CiPLpyCGSNAIUPuX6zpG7jSz+wMMtF+9GzXjuPNbce4ntWgoD4JwlXy+rDeMw00CqA8FW68mpv1FQ+Qi7e9VH43IM0Mw4G+EFMHx'
    'vJeIahd8sGhyOZFB2R+pow8Lb3xhKyhlDBhvxHqtxIl7BVP9cCg5vuyJmxHjOgOuNUrsArw9lWokg7kc6+yM5BxasQs3QSjXW1EJ'
    'ZRZtmAbioqXccaBO1oOyRDg+TBiirALmcFHrU6coGmw/Sb5wg8gnbvhj227AeuzcDYrDrw4brV1xC5Fc5XMjZbxVD4VIrJSj18uV'
    'Vvt516JXRtCY+tU0PR5r0SBZ2OxogDFMVRF9+g6GLFoWzbq2QdXHx998kvH8JZsjxJEx9OnNyYmdKLF3mcV7r1WSQfjpzT2bZ0jq'
    'ZRqC9WKWVxX3oHwvg9hOnSe6bizLbHR8R0v1201LrOrT4QsAmIjJM+dG9BNey3QoEjwqwZQONcSiIHYbvXI61TsWtpGHQsVgU0um'
    'lRFjlIJPBCBq/xcOzneR50iBVAu8DjWTfvFvOUfOFRLVHH1v89q5lVQ8AxoCTUFhF2+k4XC6xd8F/Dc7CfAaLBxLCNhAhY2pkmDG'
    'Fq8Ljj3+HtZJe/60QdkL9jCPdBjh9IX7whwgwo5NbtG0tHdEuJhaqyhUD/kO2DVzs5VDaVJ+N/1GvgzqvBPEukzaWrcqaj5Q7FRW'
    'jSV5bXLZOFRYHgSAvDmxMvRF29aK+qwV6wB2flM/ZCpU0AOfrwSKraaKs6CEMMmXdaDXjJSafYXcCnSb2pcqVI9pf6Q3nDnBcYyG'
    'qanDjFWD3epjV/Wl+9RgucAImdW9s8UXHeS3TnJyhqk9/PwSXeWynoWyMyQn5HMXFu67TwPtLz0tAl6wkkwT3MYqe3mEaq2L55Zs'
    'qMUAB5ALz/TmEzNKgfWENjMkFSwXbUcSu66WUEITpLki3gqbtiyoF3KkD+irBYB7oStD6yOihluZQJbUNatgGw3TD4ZRNWiycmFN'
    't5CO1nRiU4Dc7XWaWtQPi0vFWrvSaMmJQFfHAl3wKUaksJaDADSQgqYTMVmyAtQsFRaQI0VrqXgKlCdFN9mkvRzXKd2ZzcynA3qC'
    'Tq8P5Yp+AdPNodpvv02wpowsZY7F+iCc1p3Glqcu2qLEOtwgw8zGALNy0J1lRL+Xt+7QWducNta8dpZNqMx0mtCiDhAx6XAhU1ld'
    'AD8eDUbJgaLMgwPErdMYZ3tLhyoe8AVsa4qlJHHBG4RxK5hdaUhKzPhVoOa5jkaY/q/mxgvOANxon5Tyovce8LvXeayDB9avgyRA'
    '4D1NkrjA97Pj2Pk/FGCgX9Wr2e7QVLR3Zg7unFH5q/zD2vCglrDOTT1q4BPRU70faE3igkp6RkRR4zx0ygz9AFUKvlC7vjQn2A+C'
    'T0tNu6UlEeh+M37U6fNvhdDXKHPDeoVQth2xS+AJs4IgtJi1LAFCx8zSl0Nu6tDjVuZaEA1114ua4ApxToM7rfg3b39QTTgtEEFU'
    'XOqxOo8lMfZCseyjRIFrda7wWckVTIC9WuUI7FqcS37VM8yDS5x+qSsNd1+Tv2kJ4mLBcueWDtFRcgxFsDRNnKVCIIetBa4IQ4BL'
    'ZiCXmnw6C0SvYZoQMAxJ/AGNH6Mnw+BNcWJ1L2PWjm0WgR7bCuif02ua2v0zC4BWGcmFvlRQUUq9YmSQFE+mj3LqHrifujR+zGZn'
    'dK6lacqSfF1UU51wn2BvLtsaq+MMLDTfdHCAACq2RTsy4p33k7nHTI10zvNUwnWsbrqtarYlXDyPVi5tb689fPeqVXPYNgxP+w91'
    'XN41ZFV//l0ALJQURdwxPdGWdFgSuES6YA5pQ1tJ21TRZoaLQCWRYamH9G8xGrCzxOOZzGPN5ECX1ZfO+fnSmlmkigCkKmuYkKz6'
    'm8YcW1MlfjJYtqbpEM+OQWtKR5wycb1sGj+E4WvZPaplhg2zH9g97kfdlwb7xMrIEKKIF2jocoajS/89oYnDo90yj9n5kktiV9Oa'
    'nesVbD2ybPTWt0lvPzRGOPsBWu57IwHMIB4lBNY5ZKjoMHQAYAN2PHncMnbMXR3mCFcu19/LGOhoWvbOhqpX+cEzBH23V7vZAa7H'
    'Fgtg8b+EXyMPIKxiAY/FYpX2pSGvCfa+EmZvzwEoOHo4/B//nfZTBS9/qalHeSoo0l9eC7rhqjStSofgG0sGROGC5VZh8WSTCzjB'
    'VUtS8FJzwNdXojKLk5x6yvLDi1/+5c3rFz/9ElkjTQ+F1PaTt+++fxM8c/Y1ByVz6c4WyNtb0azPZlmNw4eA1scdgIQNMMKTNCDz'
    'GIRN0MqxgNKYpsUTVqi/PS3CN80ivZoq5PS5wE6fCzrFp8DSxvopnJ8LTmBwYwwGeZ+B1octG32maNNqpc9IH8/HgytrfN9H2Mp1'
    'ZKvPFDh6Y9+5kHcunMEeZsPrwxA8EgtN0hF4eA37AW+EIS8WkieYz/ua/+s4NPzWTGOeENFy3/wFXBMQ9AMMQyS1xRzvp07YZ3qo'
    'sC8WfbX3gUkpzuMT48Mg8Fvwp9GTaAg+DAKHBT2QUOgwJOzY2cVU86FuIe0k1YHw6Cm2o26UkS6rpsffnQgPyaykH3O6JFxW4u1B'
    'pwIrdpKoyv0C9+UNSVeVxglwzIYytbhtZTYQ90/QxlHyEEGADx5FuJgUHMIz+FYC/PCRniZOaCgkJy/oBsgIpt+mNrABYj8IuH8i'
    '/m4kdmcCMw3SICQQNKbKZx8JRm3k4mIuZ3K5yA/0dLaSihAlafqsUPxVKmUqm2GVwJO5WYA2Rbp6PlAe+5gvZhuznse4evDIkMQM'
    '8jaSBgViW3Em8pBkiDgrFK8rzJJqxsQjqwZKegETp6Jefj5lGlX+DqGq59ZHIojONf38aPWnTXxFj3uWuHWl6GdNwGR/3FbHxUl4'
    '5EozOKALsyLm5jFd+2wa7MgrAV85D7d8dFJL6lYuIKwPs13MApkHG5hWh+h0tWWow48OVvuEZvjDCFK3SG22trnpqu/xU3c4wAoC'
    'etvD6PX9h7OcYPRkdQ/NnhuGcY5TGseLbwaVUiI7tBPA8ocd8Lym6DxyioQ7i9l2EVRvYtdIY7DM8XFZed8hHTvHFgnNIU87Goz2'
    '29Hz64qHXqsP/eQqW/j2zHiaHgVIkXjPiDWXzSB70Ij7HIuYmFg/BP/Cc6L69NjMHvtB5qtRo1tECAEzrIvTfygrDt5FuM8+tjhE'
    'P0geV8h4ArZC3egrsdUwlzEZFDxTbDVnxUOV6eBOB5KdDnHvsokR4IHcdLlx2nf1c+8nWDD8QrKs2xd7MGHzJle5uI2nXHwtR2nt'
    'BaEu8jJ0UuOxcDdMY5g2XpasQKaKAaWb3sjzRPZMwRHf+6VHBZjL+/QLjxiOJPFLj+WEvfSJdC+tvB/h7s2pmjPDl88O2OzctnSs'
    '+jatRPVtWk+fHb2J4Q1EmrNqGnr/XZSzPHAQtgyqy3vgPYR5aNSB3JNRTdJzdp3TKl+e2naY8SA+O9KA626tRCaeCNRuPA5nOGU2'
    '1uEhk0RJkqzBWrvItwt+ArLYWFnsat3Q+FU8AzGmldXaWKOdJItYSq4Ps8WcHsd7+TKuo1dJflDzmR3bwGZeOT4GM7U8OenrUgFW'
    'NRw0w7OtkaAxsOUImjtZueMob5iqujQ3lFkoqN5llvKrLkw1lqYeE91Ku/wIt8cCCJDW9rZf9jZRuBls79ZZkimOozsfKKjmy/iA'
    'RIkGtP+Wo32078/2voiA+5aodkD9fxFVyYDEvIWaWFe8xW2ueLGvgn/XfPHbAQ7CymWd4IvuPjexWTrHgjR2wgHu8SQXkC7T3gTp'
    'lJlSYcGDfGMfmEoVX3gSwGc2GIq3A0MZBNTTtAWui5vzmSNEC5zWhi2CEQbua3wHa8e9E9ZMV2I4C2TiQmf2luEYIahpTIb5xWpO'
    'Qr7CaQAvWTvIlOSQJ+f/XnKkcWXr7ePSrGgZjbvCa5g+vj/pO6afGQvAXiB4Cb0l107KScEFUkvjFUNegw4lksoLnQ7elU7wWvtg'
    'xbAxyruqpfHUAYnb4B4RmhbthjgmtzaURn3XBlo5Ji4bjE+YLYLbTLY8fgYvy5C7rdwcdCEneGfQGLOTsAshQWFhTH7aBnDVs4nd'
    '0QMmwtcTtZbSvOdKHaTzAZM1wC6RZ0Nz4U6oNxmR8VuWlPPyQKSIjJmLiqlNqh14sZ9BSxWIHV7IsBQYtJzccciaDNPPixyS1APf'
    'xsGv4IVsuMIOOeRvwKs6h9sv6vZNdLhj4Mq5+ZQ6GxvBjIqkqY4ipUXEcFMdxc9dLyEgRnKbGIhgUmWa9xBasWSuYw+/5odDeOYA'
    'g9OcAT6hS+gJzvQ2hlXum1b7yf7jfjJ6ApS2E8uEwW29ANXWRHEaAjWVlGiCCAkx4S34bCdM1duGaWqPD42MRJ/rFBXwc+jI/Fhi'
    'G9FjW/zQDT5yjHBPMg51y7SEK0NiEfKljoYsfbc7BUVYzlp3rm7bwJ/UJnOtO0o28EDsq9OUbHBwH5ZWn/rYO/2Jaah3Viyymcbn'
    '+jwJ9Yrug5AuyOwBli35sEaGCklzsdgzqwTZONPmZEoOgi2RPCRooereKW+8sl/1H5+JkYS9sBI9gqps1YyfqCqi186reWvXPtGj'
    '2FzM0Yt+bGEAb2XYsZ8W3c80cYyZ+p/FDSokflRCzMP7IuUGgl+anGcgUJB9kalpHogSzu/V8AiXB8r8HzhZZR7JKtOWsALD1k3q'
    'tbDwwqVhtZ/A/9VZitXtXa2vUKbNsmu6hbogpqqcfcx/lWCg6Fu4hhAEXVMA6NlwNXfjQT95OByGiPa0OSLZZE2LM61GmYQMFjZn'
    'LCiTOtyJTRIzLcqsK0gN82xqGJErzWgXa/zvON83doWF+oSjIPHGaeXaCTzkrDs09VzqHoJuqLUAOUPF7VISjGqGUu2TKufkYeAg'
    'xKVNO4Jq7RkEalZv4H9EUzPSvHkx3bmF3NH8LRiCEpo10ZxpQzBS8HX6KuQSZOnyCcLjcBBkGF/VC03x4zPiLrNi9bsSGP19chGx'
    'O8qgQOVtJWDbeSa/zST1rbsXJwIaUxgKy487yo9d+ewkXJs/lleJLNxpnMPxwFpluHHNwM3WFX1zJdSOi8mNfGYjJ5VeQeplWDLC'
    '6XTh1NlltApF57pjs7VirU4PwkwOBO/xaR4oyXqIHPkVpAiUr4C00Uoiv6hCPwRzwk+ufP7OiQglY03AycwnvYlmyWRCtN7YX/GZ'
    'LRnHwtYXciZiRqkx0hm9xcrhM4qEes7sQNPujA8028gSWXo6UzGPvrslFfPocZr6/KXCl9SeK2GX/alLoWesmpOmNFxDEg3yCrrh'
    'silEMTodsI9zBmKyIaHyBSO3Q1kW2+N4PjCNzwfjEx8bqUu848m4IwQscavxwDOy74WJfQ8G9rH5Cz61I8EQH17Gmu8wXMqMCMWG'
    'D/Y3vuFEdHpzCJPHl+Zq7a/4vCncmFWHsFEj/aywjvzlGvYj8b4391bmhpkEW0QuP7AIDu5aXPGHypS5rz4MJKVmIrhgPkoLQU/u'
    'JEh0plnOtuv+y1jvf+sYi6fu+U+Ll+V1z45eOHJlCHAP8Ci5tRvY2ngrwLy3pSxikpZKOwalmQrvJo5N9jnt1L9DjxszMM6ITiVZ'
    'eGIyc7v4INUldWStE1KSmMAbxgtqizKZXID5tBm+X0TeJF6FrR6VTuVouJ4rjUPu1FIKUPAYCsDFGdMqhRm95QhXRIstVseFjS5X'
    '7ADHpAG40ew8B4ThXNu9HcnmdVrFkcKSpCDQwiGuQgAnw5tIz8Lsulh8cdRzoH3qh1qqgIJlBM5qhaarzeIz6npEuMHpxXsMyDry'
    '1/dJOhu2iEbylqLTO//y8+xpnPzsWux+1SZM/dny7KcaorWHo9Nd3dIQiE5DMV5hm2UgIU7jzLC/mIfez5VXzpzN/LDon9lWUUEI'
    'd9ND9Ng9cS/xSWjculvRZeButUn94XYpwm19IFPhtGgyq0ROatoA/Cs+Xi6av35kqQrvY5X1guVVmfVYMROq6hsaJgLlFxCn9IxM'
    'FFbVSTt7e1bT+UFCVY2MLrncRYC5QpGrwWVMdPB9ZjBQterF3AqVZK60rVo3Zk30p4QKIZMqwt4V/kIlSRfBG96M9rtV5XgvzKaz'
    'pdAKs81P3NrtHffZC+Fd8CvV0xt48vvBXtSgZycLNaVQBpuwKtou0JmmG9hVRiVD5GNpl4DerXLxuGdPDr04T5/Zw1aq5rg3mgxJ'
    '06iKZdF225ZwQRymM2mz1SvCzLKIPhEffd9RWfS2W6EDMhvC0XEGot0PfaOoAsunVlfRGLNrxGsOOWox8GyQ9s+qRvZYmp7qViuy'
    'Z15uTQad1YMYBCd3f9573aGpSE71+qp0Niy6izKNq3gpiaMFJHyeh5mYqSKQosw5p1dXmoDcnCT2gCPoEWMWWvY4akLHQPE9N21R'
    'JBCRgR2yByQCQWkTqzVzmhlAuoSIPcLZxdBQ2NuqbDvTQU/i1YWBEItDncLsGQXUOcxvdEaB0AoQyAr1nWXEcOoZgWU0hL9cXlA5'
    'a2Vu5zUJF/hDazbMJNE6buZ2XMRVPXYqMZOaZ9PAr9xqg8KYlIbss14GAvGi8uTgU2DiiRyuxHIEoLRra6o7TGT9XTsLbzIRKfba'
    'CzJKXyYnTiknDbz+6eef3sWOekPnqPd72ALvIA6pDm2+BoRzSwyMjFfmeT+pQrPVeJN+dsvo+RpbyN3QqQtXGiZxes0YU5fA6TV0'
    'lAvqM1+T4bUmMFrADlkKjzb6CC69NIHpLgxiWMxw3/69gUdZ4+wPuua6Jae+xsD4EjzXTQfGGyUxveAN++h3j9tnqY5y6T8j6MBZ'
    'zalvGEO7asmLoAbCJKhB4TYEKk1OEX956jYOKQsRvkl7lPxIK46CgGLok3lgR/fE4otIk/SkR1S3K9Wf6TeknD5tQvc5j4mWz5ho'
    'BivnDZCJ8Uc91s5LxOT8Y66W/Yscb0tLLvYKhGOKqBTnhrazomvDtDg7y2mBxzRVffaA2Sh9Jm5PyPmB8zyvhcRl9Z1mbNqB0yrz'
    'w0WJzOQ4DkiirEKVDYm8U8Rgnvocl1/p9Sla+uYehvJtvRQdmPi4M8ew3hrLrQKlJpnhZxbTn2A/UXZ8MvZKBBv7oKb8DBaRIfYA'
    'C4nNZZIdF9lJqrltvEz0i31yC1TWa4k2lHJ9TabMS9r/XFblyfi4o0UWicyKmHRHrc4XvSZr+9Juy77mA+bm3Qup6Atf5IUrkiq7'
    'H9q5sphcZJ5cZG7z95PVOOnQCb32OqHXTiekgsu6juXF1yovvg7lxdcqL74O5EVlqahoBg+lqnKzN8KUWwVX018MoYqUbovySvOE'
    'huP1Fz8YfwnHCycxvUZDeA6eWYGYodeoeTeZBto7894ebh/GRmFiPJn+9V70kz1O5X2ud0iaK7iMrMawW0zHWuxlP9lWKvL5zc8I'
    'QYUyLeSiVRbdG/PeWF5HX81y0LPDlD+UWy/drXFkKZE9iTSMaJFWHB73po3nWAdHyQuBb3EVEJ89koA6asHKa/d6t91rU1jBpeyJ'
    '8ArMpscI0SjXSTlfgjefmfODrrqe/VwItY05UGYUBmKI1aYwu3B6R5244PMgjGNZ9n1uLxwzSV3MwcDm5o6l4xPbJ1o3lOjx0OBx'
    'MUh6bwKqD95QrB0LMWqwE/APvshnS+35gXfRYrLVEpFucIGsB8lP+LwzugBQ12SPiDMCWKD37Msd7yxGN2n20hpcrmsXJA7XbDLB'
    'ZJoNNcVJe2Y4RXa+ItmXI83aumz+V6J0BOonNw6xMt67Htfqe0wn/iF/hdpX+hTz1Ir0PN3Oy4uG83KkmKS2WZSTQbn3XU7O2KEL'
    'yOBiyVmI0vI8s/rPTPwUzsf2xjhWiCqJI/fUHUKx1xVxYc7Wjb7SEUGx1xVwETuhmRafi/bYVKS/MPd6qjqSVV6jKbjd78NtWYc3'
    'VLhEuhsWiOMMGgyoTcAcTvGWmdueA9XCKwSYu+6MdQrDrYhvgmUW+PxdD0O35aUwuBjk61FIz4MHm8YbVFjidNs03tAHcQcWEu9g'
    '1paqTsrw4Gnozl0oCvU9C692X/JnQ//9xEzm9dA+CZXlT8xqNt/DJ7E2HO9shvZJqDrHO5vRYeDGxFlG/53eyCPCkmIATACbGJMn'
    'uQ0QjKUUNBoFWLWEdxaz1qLPgUmtD2in5Wr/0S2Wq/2HaZc1SawXqPqL7RRYkRckOBEl6aYl+8QjNWJKrcRE3oxMGYWaMootpown'
    'bVPGk7Yp40nblPGksbHRtt3LC7rM7Q/Vn+HWDXwTHros5s5NS5h7cc56EWYEC4o/n0qkE3c4AVNwF+MRVqCIXZ3BsWIehvWXkNs8'
    'LGw8YtK7RY3SZ8i/98tH7Xc0yjsdBOqnBQJFx8Bx3pH6K4vd2neO1+yAiEBwoWgpUHqCbyJ556l3oqc0aqOHRzELonZ4NC6smkkU'
    'WgTOcwfpRXlFUAGi/dNnbxVhPcc+NzYgtmV7CYmuqkh/t1KkWJyV3ihy2ZSmbgsF6LRfdDg69rYERbSgbBkCa8FsGS4bWUNmpVhD'
    'LopbrSECttHY/GHsXCt0rqmSrq5hcqFq9fgYwHt72MbH7gdu2Tujk5Muo/C0Q54QD+oKypqe39SjYeo/Xfyvq2spcuVAkFM3IAhJ'
    'irxiZ2V4PM1KyDaHMkbubLooeHer+TcMpkAN5u2byHE1srQg2kLinekHmwEJ8cZiL29j4h40mbjbGIEG0cUa7Y4/k8F+wQzjZyUp'
    '70t7oY4EyX8J32+Ggou/pojKLwcI+HoxYORhEHSOKnrhdXhAvhhcwLbzcmDmQT0mt/Eiv+Ggk+IvUPz5M/Oaf9tISBCPgkAgEZp/'
    'GwQbop/g0m2WVDPReTSJYZ8++sPB8HG6dYv8NvCINFNVrzny8BsGgDo7ZyzYDZSgwWO7fNQpSvIm9H5DH2VZuB60zyKPemsZSefW'
    'rYYEpyoS9y9HzinS6THiKLtV2q019txCKTJKXB3NeCpo+YLEnDCMByLRmOcBpr/1kladhPr2ywFB+DroF9TKjyPBe2YSSEQcGENA'
    'l9Bh8isIu9Dfph3Zuot+3pKsnpTarKfxPbuVD76GuDd8JyO8FvjnopxkCIchk5wrfFhjCE9qajnUzMiBqbISeq8L8EiNROLj4MfZ'
    'AUrV9ND084E2TsVF+zQh2sEq0IU6x0Qvii826MPpojpFS1YRoHqBIG3GnPrkC5qO7lip/ExsU1XI+pq20r7XHitbIx4foHuVhUJE'
    'r+nEvzpAF63ywEY592nokiwR9EC2Cxmf7dkbFcmZQoJ+Kl71rFBGAnBkk0sPklMAbeXTU9PqHSv5k11xXJW+aJgXP1POE89qRi5T'
    'CwA3XxOGPdtoiFpdlgMFoZAdxHQYsolEZQDliDBkfXywDb720WoM846Na4peNkj+/OKNWPVWQh+WAbRV1F8HSnValbMCH8wnEk0n'
    'K0o123yNNSkAi6QCQEKnnmR+u7aR4LMZZ/9Mp7kkXfGgVTtuOSuCFOGSAlKge1KGuK89Mme/+b/MSx8faLY9gOXZ7xj+iciLfCn0'
    'x4FYIq+3qUhGTct5gzs815NEOgL241yPGr0D6VeDNfy7cig1S8q7YW3p7+dOTWUTy6RpdSFKJePWs0rjT/jL8BfyyzMH9oAXwQWe'
    'GjJmbV8NI6xk4Kvwg0pWOpdWscha9TysFrBdi7O6ATYVBJnYkM3KGVOoNQR9E5pnFXFyLtYwgDDxD19TynZoSVBjU9p2xHKNaJYL'
    'gbWSIOaC7QYus2nfARpkKFtQwaLhnGwrXt8WesDrcH49ix3FtipXaG/UsaG1ZSHWlmUjuDNwdZXE2UJtED8E9KrA/xVJNxDnLVPi'
    '62zp+5TXrMGE7T9U1A+rZoFbZgT8sf8wjA81jUKM5nmlXTkSNIEPwo9fKAzwB+HgL8yfG9OpD0H4qIKsVOIA6sOYP4gOqeP+ph3L'
    'bEpAQ3UQ5SW4rqidCnyb7M1No+SGNxslzc0GM2/Wzp9wEnJxzfxiNpxkT8IwYboJjjPrs60ojk7LTWb3KPQl0hcMRz2jPmKqDmy0'
    'Cw875MBYKaPqOVGYTGOtCThb6ujc01CBMhqqok7UKNNYl8Kno/BpqFYZRYk0ZgPTylN05F//NTEXQ2jZRnKxwZONPtngyWbUZd/r'
    'FmNmjCr1PoMqy0SusCxDOUZ/qQ7pml+Pb8SXeKNihztc0I+blnL1zxRqtxNDkHuEAuzJryxNm8KWZRzNDniW/LnfdHUUmEye01Wk'
    '9yT98H6Hjk3sLcJ9Z0bWnmKR7M91YZOn6FT7S66LveDxqJ1rZaum4DMagobGGBOxCBV6hgbEqmNM0yLU75kSsQ55M7ReFTZlymFD'
    'mbwZ9V3ydlsipjSI3vJ5tawXDj/g0OKXXLfi59Upx2VQsGvmmt47N2YVAM+rap9riq0MZqTtaSqz3Va61AJr1isH8bDqXmcqBLZH'
    'ul5Tt/+J9C+c6YNoog/ieQ4uw3hrrRYOeobj/BTT1PEAkxhpZZsU1hQZNbS0TXo7HmyGDa1tk/qaIqOGFjcN9OvxhM43r9VcIiyf'
    'Qksy7DGUyUQmjyeWkON2Z4UFFFBD3pSjXJ43UTsoPnR2QCa3Ac3ZWFdsRKp39bqwNtqeRTyBnwx5bCcl0LwaMCvbonjUMdKJAqzP'
    't0RkOJc4gNkUDtSL0rBYhUUixVNhwCCwwJAaHnMRjm0iol7e3ZI4Mhp5RcydMkY7AWCdQtV1NWP5K2cLJUv25Yhnjpn6DPPj2Jsm'
    '5xNGErU5Do3YuW5uieD+Ji6/oTdHc/G7+xHE0nxSXw/OSjrinz4eDpPR/vI6+ebTD7/+8u7mNF6TMprPtsbcyarrQuTISOZaEXga'
    'ghc/AUh935kqZwOZ4CMKLe/y67qnt/rJ6LshWNHjlkm3zs4VT6LyEKyfkisdjUlezHohSyYlCS9BNFeMieKossU6HTD9dCrZXB73'
    'k4uDuPr7yegRrXk3gR94g5kU667pG3At4HplCYR6RRWLcXCTflF+nm6ccocDPBtkPKVng/EWwsGZ4rxEL96dDUzjFE7xaxxMWu8T'
    '9MczapG5B8xIZ302Yd1BG9RxSxvSBHkytBAQoN/otJHppoXDIUBo6yiC/0Nfd7Pnco1cVe5UAvXRwRwry+sM+ot3nH+gVtTbuN4G'
    'bqDlYQmNWIsrgDsZvUtAF5qgZWH11Yv4Veca8KRjL/0g7k/6GfHGaQa6+nmNzRuORabtmUAssAOCT6bN2d/ZjMTWTIgWuTOkjZl3'
    '0i3sGF3xhVJChlCObA993sPYd3LbvmNmud9WM+dKmezRPrlsbhDrBKsTvKWRm67Ram40biyzLxGXs+kYQJ+aRRY95cxsIMnqzTo+'
    'wgAeEJcXiWfIPNgHGz4An/bJ52/qob34rbF9axy+FZmNtvFw3VF/ZNSDaSnJq4HuoUxzUDkUZfqZycI3oXLs2VumTFMJg2ihMb0c'
    '6+Vta+WzXWzM+uenvUPoummRG8dk9FW9E8nVQmuc663lMrwXWsAnUN+MW6qPDLgQHlfOV01raxAmgFVu3e8KykXhxm7kPegdzWKm'
    'PGP38q7epAhjt7MtSalFd7QtqR4vxw0oLJUdPnWvwTHNAMK160GvLuFjITZj8XQZC6EZi3fLWIjMeKPPSGDG22TyYAYtObRj85k9'
    'vkXK8bl4triWqP+ViBGlKiue8luAES8SiL3/nF/F+xspf2HLb4b2/p6//1y+tB3m/DWS7iISdaNEoiLDTvW4EhDfhRxVpT+ioKkO'
    'DymRWqd6Utm3LvSDgrcacxQMfMIlJLxr+bmpmTlCC5/5bk+gxplSfpbQbzsMc6VJs2hNzqI1OYvW5CxYk3/TA4+W0+YyvrVwbByI'
    'iFjIN0vuNqfW37iLDfUDtsSlrg6WuLSTbkp8RmjpwLj7SuGl0eeZ6J/+s0SZ5llwV+VjRmzSt89NZgHxsPQ9vmmgbBKQG16/1rX/'
    'z6bhOcgsLBG4WA2JHVrVvLoN055eIFJbhKBKxwZUx2fiExEV2xMXifAegwvmlHUs9H8QsNh2q+qHMWtRry6KL+/Vbd0IslV35FZu'
    '6VzVU40YWH/kD6BWwfP1yOwpU99jcNAO38lw6kbE2gPO1j5cfPb//d/+78YikwzM2/Iva4pLBoiYidhlSmDu/pK4DYZ2m4fPnyV0'
    '9rAPzcVz8GUdOBXORWrO89bsodXPhUNQ7EhJ0TufCGX2hHlbbgsUvRCFlJMVWlDMk9JDtNHLHm8+1FXQMGyr1/l4pRGVQPbZJA89'
    'CMw0P7dgVA1sxpXKgSugM++yVdBmT3/a0LYWzXUaEqYWxq2gvEYsb5TTEsN56NrEIcX1dMRlNViZJbKiW9ZIM1s+HrrVgs8rziVR'
    't6J9W4eQap7NZhKnVTV4gLtgxoxg2VulgynTZvLXJu0+wHV1s9SWg52NQpkPn8+HQw3sB9IanzyXj8RCc03rM98DfwMdCRq1D6I+'
    'dcMuhj7hksB6G/cROBtxmKfXkYeR3NscOgOiDa8WWUfeEPFGSmJ6Wzm077q3jagfWsLVq+iFxGA3E00xdeiE6cdw7NAoe56LHyiC'
    'KIAVaJHh4abg0BfVvVMRf5m/GnD1DYh666diPVCXLrCPp0eYUTlIG7scJD9IkiQIAlxdadBpeocA7Ws2SwRd3np4UM9h3UI2EoKS'
    'iy+qwuLPNslFfp2dl8C7uzBftJmU83Hor+Th24JY4SZ6W4zd1unBtMqmxbqyyO6hGuwrQNsCLfaW+NW2V2eYwyIMap37oNb5gOEO'
    'kV/DVd+RRvFpRIlHw9CZYnLBtIVcl8SoU0ZJfpMLUkhmw/JQyyXv9EnoOB6CbWcYipMgh4dbA7SLez1wFjvLLgVOiVUyLa0gLcn1'
    'tfsgSdjjdL29Xtb0Y/ysn6OLpRLlG3zYwk1jt0iwL4rKfrrHsrboN9brumoBV680vFZA2+gkBFQ7rOuufeaSw7hMrjlijpYSEYfA'
    'Xca/CnQ2gBSY+CkGf5vG+VOP55rEKMwohre/X0y/TAd93K1wbiubT5pJ24iAFYAcNjxYcFzpmoFldSnJ5DwzHSHO2C47zPUQY8xQ'
    'FNOLTKJV54QJtcla5dE4pRb4KDmWt5jbTJ9sfSnzL40BHndCHXkMfYaF8ywhe0yNs0tMtZ73k2NmEiUllH6au/GuNAXIC5R2A0O6'
    'pCvYNTOWkQUo7ZZ2DzfMb0Vv2EctSzgdD2UBboH82reQX8r8apoRrnNduZLYy2zwO00xKkqatWsqDHnHx/YY1dkUUYf0RHJEmT0O'
    '5oQwYDESN0psukqII5VjeW62elNL178sJK5R9n0wHOajAWZldiuQAQMX25aLkFRCp4YP/hKxcw3QAdGNLz3iv3g4M9hYP1djij/I'
    'VWibnvoYbPD6Gg0rl089J8uY19V4a8CYS0HHDA1aWiJMdykBTF0WMBw7Fy7i+sOq9kaeIXut70uV9+Vvy7DBhKIy6e77U1sa+AlG'
    'JmSKUZl2PzBhme3raY6aYTAK32StOLBwRx+6pgHZYDXM82tfoOvt3e63ozXYkNYM8Z6UTEEU+2e01G3yKXEYoK5HCtvLhkti6VdP'
    '6Tv71K4cSl6Pts575bA/KNX0WhXb89XWbs9fHKKgb0TS2vWHuLmGmS7fexB5UExMjzgABFTWkagmh3aIypilFbHkSJkN2wc0KSNh'
    'CekVAQEBK6VnuvnqvjMiaFcbEefXiTLdjiuiwYq3lJS2YTumIW4HObcO5I5p2uD3G6w+wTuEjGgWUE1MV85m5VVijq5cTO76lbqc'
    'DckZkztYuSXGsyibTqUrAZ/PPLrjdV2XgrhzEMIlV0mPHAudAgDSR0dduFFWjDMrjBQzXRk5wvn4B0nlrE/nHZ9OnpmVpwEOiNPv'
    's+xUtP59kTKyZFyaOnn8QN4QvRzYlnyWVXUxGSQ/Rzw+/aqXa82Tm0W4zzHM7thwUjPxKq0GyYt1Xe4xBy3wjhDZFo4AaIeXEdCO'
    'pJ66ygjtIYDT8NJOsNvka8TTNM7t7YCRAzFhvRDTQxe2tLd7b48zq780zuxv4xr2/wvHMGf3Z3wWpvrAcOOcGmLWG/LRo6HneqQA'
    '7BOzKXq06GzsrdVBSFFN9wU5bDMiXpgWgoJmKBqYYRj4RTLAqRcCvWZChwG6krblQhSkY7HkHpb3HNTs2gb9riPgd+vvJi8fS17j'
    'ogEfNfubM+wcYI995zlq7Qcj/2mX1BuM/Kd9kt91HJY74YiAMYmejf2z1A/nrCuhn8V7+Wtu/bJDCdalfKYo66+8TPt5J5woOm7W'
    'hVYsqPQOqhkoiJWGW0k4eKVeF4Ek53DYhATdic3h21NqFuY8ZtTS8eVAYJMuzcRISkw3Wam4sqYD0NOeiCsc8D6NxSeNx0gbL449'
    'MQYJRhV89K78GosHDjZJb+YSK5saRt8hH1/Tc0d9haz/Ds5iZtRM/S6xkzdf45izCYea9BCn0DPdFBx8tyHkHORLyCbmPGW+MOzS'
    '5W8Er3F2JpWXQeWgE7b2gTP+MaJwRG7CP3VGPnnKviSK+TQjaF1dUHK3ugD5VkIaknoHG14Wl81T3LRTr7PkWbTZ+sl6nMTbranD'
    '/kj+RuTGs7Pj9fjEIlKj27iTUXHzkUyPiJBaTuGqg3KblrDyka+G0EiB5Z1md4gOJcw1JzpCD325H6R1MEOmn4KSdnaot8kjmW6F'
    't6X3rdLS2ah0Kx1NlxAoK+uLZMC4aCcyygu7Vl0ErlxBxuM0vBxM7Dy8l2l4gTsyvoWfBlNu48ttpNzGl/u6aThn2NEL8v8v+e9o'
    'NITpJzbcoNhzwc7+QRd9MM54itl7cChP4+GOnr5vzmjzaTyxwdOmMn3baRhjot/VwzXCYOmIsZeR+kEHWr7CnHSXVMo+B87GEf75'
    '1lwdhKNoJwe91pG5n1weuslw9ze831h4EVtiXgmxmV57vZyD/Bf320JRsxH5Vzle+QL/CLQRUgAYzlSiCElPUMNiPT1nAOnM8OCV'
    'TwRNbXjJTI6G06VQcF58zH0wJJCJ1jNNGwl2N/WZIVFGMVvncHemuGCazQXBiH0PVIpR0oBlV9KA5S1JA5ZR0oDIDMfDID4fqvy8'
    '+2Q+DvzJSLwizuM6cCprP900PMuCEuPw/XHz/XHwfnDkBky6Gy7xjFSDQZz+qEGizCd2B/3ry3G6AVParMTjkVAXvRLNvH+0iR5t'
    '2hSyQfrCLnQSvmOZ7AJef+MTAYIhDTwW4P7C/Ck+2Afvm9kBJedHsSSokV584MU4fKIXH7pshTZvgFt1khRALj9EeQOkS1mcWmCs'
    'eQPcBO3u3gIW46fxPtD0wRbZ2SA3YdURc7oIQtvbUOSq/iRUzCrHYDadCKCQXhPKmxUnRlGGLPVoqZNw8Uo2SijWhbnKmNOJ+X3M'
    'z8oxVs4n4TE8A0aG+DXukzI+BFGURGemnqdaiV43402Vmevk3EJF1l2pDeFOMRGX/TfkPhs2XUYkjrdXmJHbHzz44x/N4Eo9SIr2'
    'Xct+I1AS+48wTX8cgshI6f+SPGzHHl4fBJrmxTlR9dgLr13Wu92Q6MKxWr5WmETInXB0NbPTM88DwMCJom1j4pjW009ioAszh4ZC'
    'S99yJBoR0amyeEgd4s4muLM5DKFJlKOEnM86RX9lZ6GlC1h3YGWsm7br9UDwaMXEbPUuB8n5DJaoAM1Ig8uplVmWVQElyiB5g0Wj'
    'kBWiY5HoXjNd5+c5HNVdNlYqhMxxyCMsq7X4DhFZS3olDO5IDoRi7vxjfJ4z0zUcgj0fSX4XkhYsxDzMbAHqzVdwpva8BfZWdfHC'
    'VNwLzijqu3y8mKh8mhDyxws1utqEirNsU67rsB7iaX5lLU1M9GOcTyeCiQ5xPsoOF6WEU/QSbRpKmGW+MtXNs8UkHyzKKyBhT9fc'
    'P08C4y8GGP0sr5oncpQO20hKPZTZM3VTJ75eMQybtt2RBe1bmmZwYeb2wRZk/GMGfY7km+qyKcUtfMyfoLVtU28fW7j4ZxyZJoy+'
    '4E1TPWS1Ptjq6LBFnKaiqOc0QfowOiKYuzPY5ARvTLkUze4Cs/XMlPpgxPsaqyjDkvwB93sYVn2RMPrR6lXCr/c+MY8Kqzu4rTa8'
    'dONXfrh4/dpHnZFmBdM/a1Tn+/+5RceSmCVU/ktTD969BBuf6kcx6Hxdnp/P8lflDLnmcmrBEBHfS4NPuTRkqhfmEPRfhef5tMAO'
    'T3UgvjeXdvfN5/a3dG6i7aCVu81bVFtN8zPorPFKlc8Yhxr1PaAzCvoCNf9BskPXkR1eVa2chlPmLfToGzYFwI5H+9EXwat3ocoR'
    'MIW+r6aTQSOkvSEKfl6/mM3seE57KCpDCWy53g57u2PWOx981RA2gSxJydJEEkKYreRG0taKJsjf6eCkbdcA8beRVcVpnkfJIufR'
    'jFm/3rhuN4S3VB88oGeZbypo+jJq+nJr052nShrRfb9czmT0uFL+AslLloYC6dHD13pzhDnQvTGjqJl+E+wj9HsWBtBlmRO4cpdV'
    'Au1AiNTY0DifO9PlZhuFHbLYt+JclbsU69KrW81IAheYHmi2dYuuQSBiI072radZADgoGe0QfetAFgrJDDMtVvlEuIW/WNkUnPId'
    'iwTCcan0flW3cY6i8FYjB0x513P0puWJBVskI2ItmXd8vsWzMP+FXVOD5KVOgzdlacwdXAMkld/McC/k7CVxh03aiEKo3yEbA6Lb'
    'ORMwa8bpGLJ9fWqI8xLA+1dmxS7UyOVyWAab2+XZVFTiZ4DSlDqIqTMc3pb94s2LP+GIHloMntGTGM+2iYWyHd+0arm9d0i54vJe'
    'dLu8xzinvx9hxPH4plvLAxe+3f/74o04aY3BSpHiR8Cyo8Dv7rhvI+sobBZMq4XmxOlbPGsshghhh6kDvtS88bXxxTGo8a2RwiMb'
    'KezU4WILEU9QgRM1fEs4O19sjupvjzT+6vjiLw0vPhH7RZcJLNO8gDrBL5h+VtJvIL7feu+pM63G7ut4hBv9yPPY8AL0mjSGdLpJ'
    'EOHZCybttAqfA+TuS1q1DqRtKOWawNyafK0DZFtLR5jcsSnpGl7Y5vUj/HyKD2Hdo8dmVM1tuXPBO4ct5OxLUpoAFKBBbj4XY/Mf'
    'Izb/yQABgWp4KzSRwpP3BfGrgU00bmITkVCAm0+PEmgMkEgpB5pbeea1w2yGVKVYLsWPw/MCOOHKa6/evdBwyhlXZakx3mUT2aiB'
    'azQOcI1EGVzGuEbmwFEvBfc4BDbi481QTVR7aC9ENpLHo/BxCG1kHntx7G+BbNSNif23RTJqtupXhhLfGenLPOnNuxaI6jKPWnp5'
    'BD1gyWGZwm3a/F1uVE1P3bsq6amVVxW9/Y37WuYwzGJQVbldFPPPLoo5V8F8QDkbvZ1z3ucDxtryxkZKUNguN7ghJRhjW25akzmP'
    'ZnMeTec8ms/575jQTy23Vj+rY38VJbN1MaQRTfBdbdMR3/EO2uA+o01P7Ec1NR5diWfxSZ0a/OW1S8or5jvOw3IT3t3oZHwIyvKb'
    'XfkPm+aTTTBfkZ5ec+Tw0/kdfiWq6r6jxAe2EWvz+ZJ91E/sa06933huK1N9f1coe1vfH+9BXcU5GWkuedHxDwTFz6wGTJS/hNZO'
    'VqDcmQ8kS1wUwp5pjUyZotR8kkEU4PaKU4ZU0ZHYdYQj3tid/R5YYxwDazSjloNTPa7gIq4gDGBWqvTbBXtO2cZKpSK3nhp5+dRQ'
    'RFKrK0FrDD0MJ4JOcnZmuM+DUEms+YtOmcjlVJBG/TmEmGaCPvfeKhg3yzVybPwdvOIAG8f2oBNi+IoKEidb1ZLdaOv/H3GcC5Z7'
    'EGpBiV5WiJ6+CmhgDhDTSobOZGgvA+0BA2zBUPZMBWZRZR4KRa4tEIp97mFQVjGzZZ24GRN2EGDnjekB+TYA6mGi2Gyl9uVwiQvT'
    'KgbcrvubuPyFv7/bum+EjbBPjIA/4DoQccEiNZzEmD/SUdn/vqszwq7NiKw2I3gazinfRLFYIJQI7n42EqYBXuZSGes7N8003eJP'
    'bWUM3YaSZKkQrNQxxI2Aafh4EBbdpitx2KzSlIWIFq2SKyUvCV2LixTqu+sxXp3rg4aPJ78iZZ7lSZVDLRML7loJuOuhD6EqFgxy'
    'CjrP1E0kQwogS+DiYpVUGVBIJuUSiX4RMOi/Xxr6iKaQGMs8TAfJ27pcVqBOi1rCXSb03eLOMDWczop5UZ8Oml4Kjhx9clGNftX0'
    'ZXrhIPARAuy8CO21Ddo18Y4BynlMoV4U4PIJ7G2XKUQrVnObC28TYCQEuZHzpKdkasx1CkfyR1AQufNxYlPdULV3ZQRTjGwEMMx0'
    '4QG2Hilj25zT6gAhbCA7o4rBUkLC66qHy7BDo0aH7nQhVHB0b/9gVi7Cy95HMAPm380Xt+JGNQhTc7VKl9Xg8TXd9gvkCyCAZsEg'
    'zb62uXmzOUk9YDgP7f2cVSlLH91D9ftfULvOwRdVbLYBnd6CGdj/XdN8y3fNmm2LkNIx+Z9p+tgpYmjlmimolePjLqtW+jxPFAXm'
    'UXQ6DrlRFb9NRCxRewiDF8oTbz1uHfjJ4CBMGy5xbCdUHOkXPu74ws7UUbdCYNmlV36m3huxYm5f0d1ruKuy2P2meeD5kOHbFPRB'
    'YiWCgM9KpIOgO4Ezm8yzGsekwPkjN4FqZ4NkrNKEjU1uBW/QPBTlpbhsBm7QeJQ2MYeD0ObMBm711U932UpROvZFxq5I6jNbXHp4'
    'cI+zArplUVZCDTYmJNZ4KZOrVA6ZmqMbQ7idnKgTeZRt0pzvxRQe3ZpFCoacvkJCVJpBZJspyMyLpsOFq8cCm0ZtQ7DgWJ0WuR4k'
    'RiGqmEsMLuUj41HLZuSFt1KQ7avmHAqWe+Wx3BtZaCofXVcFsZmN0PTKT457AUHLTOva0kziUH+sOC0P9/EDUBsReavOaUXV3Ett'
    'G+XxcPDkUR9ZqUeDEX4MHrSkkTFzD+yyrvvbUVxMJ1txuIAVuQxjcAmNXakf5NJBj1yGUbhaZtMVixt3/bt+ov23ncc/j8wXxJ3x'
    'o09N1CVRe9QZP4wH1Seu4WikH1hInP2HQx3rB8O0UwH0RPU/cS+m4UAU0TA+lN5Mw2FolnC9si7BpnJGcPioBsMawncjCkLy5yTd'
    'BRFkoARkbe5rjBDdcvZMMedIEigsyO5KIvTKQX+J69gXQJV0hi7aXf8iuVif54rqZzbltMjOV9lcRXt1Ii6Qh6TaCEnITWvIuoN0'
    'NHRERjYISiiZoRHXQEOYg/NGZwy7eSntqF+z81qWuL1iurHGWroy29a1cKejM+n5bXn91GoKPD2xmT53T4PkXWoEs/5aTZh3l66z'
    '7cSlnPIiPfHRImembxcH1hwPq71XBCVns2JpU7+YQ+2tzWFArf5kluFNaldk0MV91HAcYDgKSd/U67Tw6wHXV/2MGKgK2BUlnS6u'
    '8zAXBhvLW0aWgD+LxeI2P75o8v6qJCN6YTeby1B1adjuRXwiFATAWzAVwKKFDh9opj1508nLKofztL1Jv5S5u/P7+aOAiSP+2dbu'
    'l2w529b/qJZGXtImn3frGLVaaHGJMaUmC23rs64uAfzR53PY2va1XYGD1RrjiHbdZE9pL4gglgTNCK/30lbq1QzZylazAvmF6FWh'
    'iCpY9YRbLyqbNfoLQNOUTtIbiP1ustW6n6t0O1xZHMFbfWkEr2thGvhdPxi2Plhpg80DBggu1XtIZu71ssprNS3DxUgyetYX2YKq'
    'n3y2rBodftvKWnGV4RPI5vYCXggpzwhgBN7JjEHzy5dlOWNd0Ms6LUhokP9Y+ZOu62hLCU2enwkaAN2lbTWovN9wCk875ZePmL6P'
    '3WjDqm/RJnYFqetowCTkR0eGtUrd6dnCVOa74fr0WIDI6k2N0ph+yjJCPJtEgz8tYeK3wfwKI8YFv7cXtsMTWo5nNyaHbZhVwcnv'
    'GB6rUoI/w0fLDMjHNj+HlTztGgCQstbU025h1oVDR9P46o996c7Nls8IhOzbIdPuCmZac1dJVYRiYH38xTr112Z7dkf7lmKV8iBw'
    'sAxyaaHVulNC/J5sjb9gWiN4Mwc0QIcvgSqheElVWnZdSGoI5VAUOg+1H4YZ6DSHGhENQtiBqpx9zH+V5qqeRPqNnmz37NqemfTR'
    'fyAz6X80tfzfIrF8iOZhY8gslIeNMIvLbk1Bj2EMEspPb00+3yy8iQ5o08ZTheMxNQj5aC7yrgzVASoOqsDLR4CwpukTGxXROJR1'
    '6Cgxgp/VUCFy/AsIujY96nhpw5ca2C8YaT3islRf1+txqqFBRvYwlG2s/vtVZqvIJF50jthIc1fihp+hQ3I9FjFCno8PxdJin4+3'
    'ba8Yt/DOt/eTPfdfUswzmASCO/e/vUMHiatFNcnEgS7TTKhPhsPlNVncfD6GeAEN0NSI68k//ePrpPfmlz8TH8V6ZLJu6Ppn5t4a'
    '3g21OWYr0sPJxkgPWbVZTJJgJ2bTn/BOzxz2eQQCssKpaBoZTEyhOhc3O3MtJfFt8MGNFEnzcz2UpUobSzA/H1QrWAVMnXIru8oK'
    'lh9MjUQ1dUV168PhAw8XmRnGbPYbvN2wFB8MYSi8iJ/+mFOPYh9XjUAOM4BmxbvjfHGFGmKnzKsoBW8/xBEyXTHznIZQUR2FLqRQ'
    'WCc+d1pO1og81RH8fsY41N6OOV0/ZtWOkZ8m4smHbNO4uJBPeZZcRFXV2E4TSAOvzBaEC+DO/nTHNldfD+A8KUNuxqWPDWX+Zz70'
    'IoZxYzWmuKmIpf9kllEvKDzAuvI8cjZbXmSOiMYE9IGCkV17Aopt8VAOreU1sA2eInYN4ritiITCciEN2BOzQA604JH51rpE57Da'
    'drikv10uzneYSbD96P0yP98RVUwqX6KmRXj6cyN84jpe5R/Ly2Adm9WYStRXY1NUOj48Y/2+6F7uspQb+8g7+myNOgjiDlRBIfWZ'
    'fw99WMaWoAxHb9ybb4mXWpeZ4a522BPopA3B+Pd/+282KA0aS8KOqBAtxWrDg42zlaynG8P6wc3uk63qFdlzI77zE8Xhg8O+0z12'
    'Zvez2l+wq5cYwKz+zxlEhJy/uihmU9/sJ1Z/k24fxq//3iYxX0ieYbMrE3TTbJKYsLuRwVOuqKL6Jb+y++r/5e5NmuNIkjXBe/4K'
    'J5Kvwj0ZCCxkslgBAhAuYJJdIMEBwMqqBpHJWByAF2J74R5YEkBLneY0h5E5dM9h5tIj8g79s/KXjH6qapu7BwBm5Xst0pVSRLi7'
    '7aamprtCs0qT6wxkeXSmSqlCJJwdtxU+0IfWJjQ36kza0X/a2/lABDNiN2dHlzB+VnNMydDBDWtgG3X6SbzGONU6l1nTrsdTkX4Y'
    'AxAu5n0UHtAnrHy3MTpgdPHwzqsQX6sdESLMiaufoMSo2OtNx+DmgQ+UHdKCdPL20oFIvXcBs7E/KsU1zajmpRFGWc9/Wa3ebJrD'
    'EcT6f/h+WcaDc4ub8x3LLMCVo/aIaYx+LuXF4zg9bEIlxtrxSKM0nGXpeevU85UM7pLjFqZ03BqcAHuFXzgc3JNmtPI9++ydyjUU'
    's8O2dRWWojAWe8ohwr2eeqCrxG6GipQMz6lj5JZx1qhohP8MnIlNmBzebFNxCc8uQ28fFe3oy8MrniaoupFEmqCm2GzlZnLxpYlA'
    'pK4UBtS71EInthC3xzciFz2XmnIr8psTeQPvACA8fnfcOoI/+6n79KNWoC/nWhgDxous6AyyHk2+Ib8atACNERxHB42mlY2+dT3y'
    'YtjWJ+J2w18qa6/TwVSiZzqdm6TGjZHxl/gqVlNDz4c9nEr9uOYhCiMOKh9RQ5YHgCsgq4dfh7AZpS3gGVqK4GBNU47fFy99zh89'
    'XGpGDbki2MRDcxZ7iEAs+6nhFqGjoYRoejDC1ZR4tv80AOAvq37udIm0HcPrCGQj/AHbUX86noi2c8SpdlgppvGveUReKKLE41nE'
    'G/Tqbi/QwGnTsvNy5xrvmjVQb+wqDNhALCnGtfQxT2M4a+8Vnd5pazKexJb1vnEesCODYGVp5arhL7IW9ru/YpuyMQSRDb3c7DLr'
    'ugG7aFVgdde4gR0tBqOtcrGEA6/ZgUPOmrZwjfD1qO81NeGwMz19nU0L3JJA8bRsP2an2W56lMfSWlM7SJyLv38VsImOjD4puZMq'
    'jNFJ2sJlsJ3lRTqieo1sNJkVRMjFqt0J8KxdTw9C/WsdB21uy93BbGob9mmI2yqdppdwaaV6qdG20noRGvtI8Nk5Zthyk01bVF6c'
    'NbeIiZsQvUBTSFt65b1OjzqzQSHekrZ/HFFdQIaNckNE7E8bfJCoZ4iU/pxe3qPZW5rc73TnDswKoSyaYXPfsGHPNZqWTOgtdmAn'
    '2ogWo0QdAdmz9BbphOfQRcX4x/GUWgm4T6iv87NjsCovwWPRYF4NMhrvLt1GhtpwoS9oij3+/FeYabZwJUXSuwS1lRtYVK6m6N+4'
    'KBLxaslLV7Lkfd7tji+UPPg9jHPLTsYuNX29E0oNYSFn/newxOV2fh9r3JtvqhZzoXMetELbnFrVTrU6ha5ag8+fgljHdm8xJu6q'
    'Qfj84YvFbHf+8D8adRo7aeUlTfuKulosG1cLFzhvdBp1x+esCZ3Bj7cvYfW9GCGTrEegy5yXt91Blnt251qeu80Ssflp7epI0vun'
    'tesiYaCf1q7Iv/KKPLVr4Z+vC1FeoInzdmQDixKZphEl5MBgdSYpn1ZJVqnUgUf/FEGkWc4hzYerGf2oR15OJ8t8mtHb4KWKehaj'
    'J2z2EXT1oxVYvuVfxvKTOLlBJxNTnEsaH53/4xanRzkWnXnR6SYIRQHOVGTTdNsrVnc9+OSY4ghfztR64qmMltkcxH78ERHHu+I7'
    'uIqYzm/lxYm+UPpByWfMRMjxOIRzIi8dI6FU9Dq3tWrCkTmADgp3JpPB5V/osRSXYkScGoHbhG64i95g1k/59pf90d03IYAh5Qq9'
    'OLVKKxvxX00Jf4tfZ4DNAlOS48CZQyKpjdgbZN1zpXtSKnXJpS61lHGZe7Jmqe7SXaQxltVnFXSlF8y0dDmp3/Pp+zEvihCKDE9X'
    'kYQwRXQdIukkVXvvZDzOS6EICslxQX+9wBUgWuFDHWvYnRzuxmjqWGj5Ei8gpUz2d+PzI4IK4ZPreuRabBzRuDv4hTdLf2ptNyqW'
    'J9DIj3FxEh8IColjdjdQN4NcztL/ppKVRNGlTURl7bJEMRFKbLrO9HrSCIFT3vJi6c1b2o+aUU1TyN9LA3sYN74VxdZlI2mxCe7b'
    '/ffb1AzIbF8cQBQRHRLucuJjKclHbfoX3+7bW/7yfEKAGvXXF94/vOq0Lm6a+HN5E20/vJrIIwHwzQIEY4P1hRFxQAswCRyfpusL'
    'D6/2326939o7oHO7f5IO08MWwcmNKbDIDPL6wmrre/uq30FQqWnncn3hj5F7DV6WaNH1BcZ0C0sbX2q4UZ6viU0UBIUKZuzi68ie'
    'mD1H4CdNY4+ErWOmMyV8k8OYsHf1DhvsgrqpCb/uVP3sqyAIGtYPEp0DTp/sEtHPjo5StreU9OzJmvG4wLken0s/oq80uZMkJl0O'
    'QyKcHM4a4sJVtkrRXzwKGHEERsRyvOtLRD0bV0CjVot4Tg4MTfpGg+lgbVRyq/xkOTCQzw1pSrKCM+DkxHURTpIjTpigl3ojheRU'
    'TtQ2L1or+pSL+wjsxokwHM34KImgF4EVMmQVHJ/mjTpcOBzPqHpJA/VdtNc56kyztgjRcJZzXrYTtuQ6Q8QHAEYuEjqgO/BkMTQ5'
    'x8QnwxouT6eL8t1GMFk8T7unWbEollrfcH5QKIUHavAx6YhoOh0cRTlLBqNYBqKPOeuljwbj87YKN4hiSDklUY6ZdiKWLyIIRZYO'
    'aFdYTY2OTC6wEyvlZu89ahZXABxkBsiolUq0u5bB/DLZ19POsSNhQIRUecTJOAOPpnyiYVyD+qL0OPYEm3GyqZjqxWDAUs6cWbZm'
    'JPzgN3P7mU3m9WKysN7dhpzhe7djdVjVBmWfee18JtnFU0tb9I1m3gKhsX85SRk3rLDASb5A5GQKidxFlWRWhuAGB+yy2eKAFDgH'
    '3xotWlLHzDIz6lHzkj/+wM7G/NDumk5X1x33CeEAtSOyUiNpyi3DUeTTQd0yMJB6C8r37aAl7/fH7FVrn7eJNU2i4PN6+FXME25q'
    '97C2L3n5V3QjP/+WRKZ1Vu+peOReMGy3UQQHmoIDUqTl+8ckwx69J5SkdhvlwIN18rlJR37Ye8VcPpa3CogscdbTeE4dFh6iQimg'
    'n4UtCzUHUHEuEgo36lP/DiTAfFSwEjRPYYKj0VMCu2fDHXm5Cub1wtcFTseho5AGbJ/s6MBHg9x2aMubw8ecD335KDv0qjMB20i7'
    'olv2rp+Y/HB+PMTRbVMnfijNvQGNOH6n3FWPRm72XG7Nu9KEBh4TR/QBn+Icofdrep9knCxsXv8wVHW9o7D0X7wBDkead7yzw4B5'
    'Z10vg9M7Ft5f81Odos7k0eA0WPPgqvYu6mqvKoqt7zXtE5bwKW5vYenCNj2iWHVda3o1EgVOPAlKrq03bxDwrEB2GFhhjR3qPb5t'
    '/TkWoTfOggXDpRCFj4pjtwX8qXY97jxjTXZMcRK+poTejF53Cg3TWSK75p1BV6zfHWgET2LpiCKC1UyLcyV8Lym7zbtMYueJebZn'
    'tumLCm3hC8J8nlzQvueIAk8l5Km8khiWbR6HmBrRWJpMDV60bSN/ZXmJa9IqZamarw9ho3Hl71RBTCttJbcAH/vdyluZa5yYcvSa'
    '08RMEify4DgEAi1pvx0mHapBZuFIsF5pqzMw0mZxlRgUj5jnlQRJHjuntv1MsWuuSGJavnEqFSWG6+Fdyll8iGVUyoM/3I0A75yO'
    'We65g6m4wjlhO9Iigt5vW8to653WF4KJYIEIG1Yi9tOGwAFPpx1NjPoextHsCs9+FBn7DSYAOf57eZjcos5vipld21gLqNglGJAx'
    'Y/UXNdA2lcdKl20DcbQCeM19gEXih7aKpJChoW0kTjd2x6ryAGp2ZNlubMR9tg+Uya2ECeZfJkwcceAz7Q7PhBKJMuGCd63C0KO8'
    'GgZIrBCOy5xB/ubjC36bX6w5+ZuUu/TK/c2WU7tNX/xWS0WUcWTfJBU0DQGerFWoSL68D5fBZFtilhniPOM1ZaSChNSe+KviVXSK'
    '4yBSLmE3xMkFucWFjUZRQBnBcZFgUZytNEAuXgSBmoFC34sVeJbjR/xB9sJ40WosU2OiwNyCZ6+O+l7AWTFS74L7nR6z56WHjQrJ'
    'WW5jfyEYru0f6lEr++QR6LFKZDHGk31hT9a5qrjGGAcfN2ZlWQhJ6Od2XRzgxJN/01vwMrEn4zOgvNkSUC0HpdaBlmDbRGimoRXm'
    'pgsFVLQ39kU/YO5+k2guuP0rZPNd1HLtUdT7XA/RmsFSdwn3AizDx1nOMvZGsDDH5e+3Kra4cvbt5pbuh7ngXgPrPpg7U0YBBxoP'
    'LgHXka6ILvtuutgpCsTi6DtEaS/8+mjutMsfuFkLcg+sVBg3+y/pjro++IUMPYCRTLwkr1A2ov22icPJQS2Jg2LjivIBMNtRMh3o'
    '38d04Jag0reifJZz6Fm563qw8oy7yp+fpFLOafOrYoP7cKe0pDtIKv++02tCh7BIhwHuM8Jzg/Ki4pqTHmoGKoc7YA35IiUFMVFw'
    'I0433yumg0c8sATe37/+H//3IxWB/TIeDzk5jfhvoQ2xA0AVUCbyNEyLjpJpenUtgn7pp4Oi81d7Tbl3f1urvY48JH2H5r0pxv1V'
    'fbsa8Ve06+6kn67C5mjQGSLtG99CasCWXkziRTNAmPm7WW5KajLY7y8vr3wPQ2zRrj0OdWac6Tbmf43W/zt0aBT63o3NWXNj/teo'
    '/euKAp5PV6vqM1iVIoRldpYqUSbCFRjws+GSWPeP+TKycXBpc9PhpLj0cuyJ1MLogqVgomGrW/kkQ7QG2MECD4Pt5ihighSrwA3c'
    'CSmphe9aC49aqo3RgyBUnsltXXAmUit+moehXYu3Njee3HEa79GBl8iCgQ+M4z48Ho7SKfwXU4TzsfTRUfk2OOKrQ+io/MesODE2'
    '5Y2SLUaZRBOKwhARiuHxctNZjwtR0IyOYLce2EVz8P8mGIQjn1jHiJY+t37JJg+XslYBZvqoBdsrGsxsRK/jo6RFF/YozoaT8bT4'
    'S4c9wtmCOU6nU0kSj1tm4ZUJyO2smM9Quh0tgFSdTglz5DmNR8gJ7h5A9oaWLD5SsqWkNOiNJ4R2APxFWvVeeQVU9srEqWKnMOU/'
    '/WS3fpw8E1yL6Bi21WWr0hwiggJ/9GQgGypSAYj2wEV+9XS54DeTlozgLzI+Di3OvjLqZqqmF6UxrUmlPbB7riocajiquUSuzr0w'
    'YHQW4ZdvyUxDOhkvfeLKcpHy5y0N8ZJNJAkax1AnrIqAghGimYyQShHB2WcFxDvseGnHa2YBNCJdERrKOQ0nL5bYRpq6suwahRub'
    'KSkbbSPoBuHTRP/W+kaA+tX2u48/7//t4xZ0ocByWY/vvKWLRcE/ixqSoLEmehG48pu8TXjYF5u8RqMpXe1nQw4xU0pbA8B5ydOq'
    '5L6ocz5mE1UNkFb28Z3ajClO3EknKtcgMZbL9rP/EkM9Y1Dqv0LSZJivIXbBSC7LKTIOjeSSnCLXkKrZR2tBxs87o40HIfQGLD/F'
    'HS3z0Ih6QpiX3yIquAtWXh7tQHPjytpfcbixNosZeOJNHdmNKaR7ooCxc2QWy8QgoiKBEtgvKOkZlwMLkIPG56IBW+C0Q6QtXHRj'
    '5xrg2wh/93lE/ywdN6NG1EiMTSuR4o1f//FvDYnEwx66KVsMupA/bgSnQjmzj58J09P4PGqY5BLv9NRoAIu46HQ58QFfqrmqienZ'
    'qB67CMlTcJHRbNhlz/huivBIdNB4ReFvaw6Fg1f68oa2SqKtw8jVg1UTO6M0/SlPnOad0zEqZNQBTAx0RRIXiuj75WUvVbBnnG9t'
    'PULRp4H0Aw6I4EhuJkn5RZtYF14jCKIODdJj6sFl7fWjXgB3mMAX4Y0n7WhsPNos3DFLP2GHE2TfczMvZMvpfw3DufsiNbXb5VZk'
    'BVzdn+KDxe8e/fqP//7rf/u3X//r//j1H//f4fXn/qODVnKYfM4fLemKmvXiIHHSttjdxDxpIy6gcyXPBKiLKxglogzKPBL9xPba'
    'ocRP7/E8GLu80WAULJRkrOvc+Jsa+6kdBWPYDIewcqhccVOc03FwbQCA3HFT/q4loXCIozmaIfpRWoylOvP+lvMWk4yJF41hxcpw'
    'c1y+nQHbQQwkGOhxR6QldIPqLefCt8glI9c9R6ekQ5Wnv3Ht2nxL1K0fi5xrIpuIuSRNJYkKO1VNVeRZJ9bjwzYfElzk4mZkBiEu'
    'R2aF0TqAuTcejHGzfHyxvbW/v6UkY6kLU7i+q7B5xlavTlI6oopoYCUB+w5GPiJDVxJC79jEEREIboO7nY4tGzUMJMo9mkv7AZ5K'
    'OyNiziZxz/MfeQE7oFaW89+4t8na9zyZg1O6l+/6fDxzTjah1xsGuDXi1CxxzN8Ijx8cCtK+YDH2xSavxMWhn7u9H3hMXMk6tbmT'
    'uKcDscumbzVkzQ2cpVJJz6ZXvtZwMYgejTZbJvZIiBJL17J2FZwXNM437si2IUnXuA9Oea/nSuVpvRY2vrpwJbiQYmWYKA9IZmlA'
    'stdip2304kNnT70c9LWFpI98BhWS5Jiq/USMQbWF0sWyeXoeZiWdtDRDGGqmZsegNTkqMmcbyvp9Yjxb6AcxADmSrRKOeupdoibt'
    '+8QSnNSWB5BcTQCyqSNs2kalT71KWRLgoNduRq9s5vhBlVna32VaWDWoy+4ENEWcQq5MiLCFkguMh+TzieKJbkDLWbaWt32tjIHt'
    '4mx6teegY20DSWSoP8eAeph53kQzt8qdwhPNehO5dzYzvgwCYaeIEuWdlxfOZjir+ab0Bfrn8YlgAzwZ2CjhVky6No6t69P0JsIY'
    'VFynTMEGy8jhd80NOeyoBXKdj4TBHmK0YGTxaDORsLaELyRCmW+5l9zalFPD2s2XBsNIF95lh56OtSdkRx1zpgEOflem2+H8ieGY'
    'a85VVeksAtfI3acKxbEOTC0M0fgaL4rcpXiuc1QYyJwUjZpgTGWGw74Ct1EK/1lj7lhn8FgzyYFOEv24KWq/4Jb9l7AxtVev+NHA'
    'eaYEqOsOUAVfeLkvD/CGjeKfLAs6EZ8Fua+tDCVsKfA0iUseBmo9X/YUUt+JuOJ64BX33IV8NUe5cxesTwP1sdvIsiSCgLwYtvMy'
    'RchjOYoCR01AmhH85rEQcwpfE09nCAq6X3dcPLrJ32YT1F92o+A7sGnOr2O+Ry7+KseAKDxtU+2yRh7mU+X+qHWacVxCwn1lIpWp'
    'dHotJUzeRHFy81CDviWqETdaw0RrsXkYQb768WpG5QYTKmQi3lrHjMUV5kKNmlHR91CyYChK4QVgkkPfSyt0WDWXIqICac8McXZM'
    'XNAflFzn2MuRJTF3d3b2f37zbnt7rTJuninGzcHiIVdB9QYBBY23Oz4HS6r7Y6yDRMfAWNYz7ojg775uPHdowAIsLj3YU+POU/vN'
    'Joj2TQjCQLOFr9gKIEC+rLlVwfxcObMlwDWiszJkggd4mmruNI2MoNeT4/lydY7DWXROU7VTxoXJxRoIgD8Yz+hQUNkBWOWTWZdJ'
    'wNwmKNVlTVp+PK/YbtW6t1kATw6QPPLzZ+IK58J682T521kXrgObPL9X/CmYX4Sos1zFTpW3ijfhQ8pZ3RHCWDaFgVUmdFiT74LN'
    'BDoF2wk48wB6cckvavKAsLiD2/PUmS5Iqh8jlesqbPD1Y4dSdweNJBMpDDIEqlmGS0z35agHc0HOGwi3RavMz6bRwQHfL4eHEavy'
    'Ikvu5EjtALm3l6BW0ZblwZI6M56yB/KcLKZhCBAvagXbNFpTe756fVME4CUmxfv0W8N0045+0XcPr7waN2YuX4zwat9p2jvKVR+P'
    'DU3d9qTTREmrGqhE0WNOI0cmGlm2EeeKCNbobVVF4wzIhPTDFFlJMbDWCo6fnBUqpvUFXjmfeJHZrnkKyWwU53OtNsrU7Qsb3VaC'
    'xnXYbhHBzOC9YJiUtlBUmTgPGJUCtV6knb6h6gEPeavOqAyV97k/T+KceAZlBAsQUSOFraiS9nQJXSjbwvA3syJidRTnHYGbjjoS'
    'WIG+L0Ttz0R4nt66ct6ocoPtPJaJ/mlGNlRnpNQhsTs24aeJGOOVyZ3ZxU0ocdeVQAyUQIA58tgf3bJFROAeSYZvAbUP0HoHTJKN'
    'zh7yxpDvepxKwx2fLw+vsIh0Zl7NCr7KXzEP17iJFh5eobcb/KUCX5iDo9/m0OD1hpy3nGtSHaOD+SLPcqxMYF/dknfshsJGuhKy'
    'lJj6rYEJiQEzfI2agZ8lu9XNVtz4VlVPHIlAmHJa+U5TjxrhZnAGLILOik5X7WhvcZHAPpRt18qjhTEQTPcVmB84Z6oHKOqrLOst'
    'FljlLk0iMhYwHkf2suqdZtmwkNu9tS6THkucpLLhdD2qF7xtwrPif735slszzumfhalVl6BblkGYdd8pBvksDe5xujKLdzhkn94K'
    'nek0gyVejKkzgmSeG8hHrlW5LGgUA7gxR910AH8vzgMB7Jr25698jf0VYgmulxemyfp0kCIxCmyKLl2lgIeCEY44msYtGnSrZZ8X'
    'ccJkWjUac9WLH2kAC5NMyFzvHDuM33ixWGR4x2UYEMyEmmzXYMJ8eXJ10UuE1X0wkBYaTjRlJKk8Aq4O6zsjsLO6t00R07VLoV1q'
    'lEpt1cbNA/RAnObd7nHS9OCRRklDC+SJ9fr70/RSNNFzAnGMOmfWUHTOJVYOQ00MZN8LfnGv4BahvIWp4jp5y9kFR+O5MAkbzkwo'
    'K07O0NSItOso9x1I4UcoQb+QkDGdTvykv1KEDX64yIVnQinNmNABXHND2/4OyRzqByeZyta14COp951JICxOWSjxnNYHwM+rxK/W'
    '7PK5wDkcSJzjCBuHEY0BHPqFhGSqidy7N6SL+IRltiPOyq0ZdDu5IgNjVyAkZA7upzce0jbhBuOQB+oPGTOSMkrDE5DkvZNskhOD'
    'JBhQbOCq+v0w7luJ1JiTSFBE74z1a4xCD3q0471LyHwQq2mzVYxN8jhw4gfssEHAYJSfw6y/CKp+EUkV2lEnGzIcihUE5wQ4IQqS'
    'bgPbw72jTTQjuEJD3tQdFwX7Rb8lSIKDIJYobySt8dERoTAbnAIB2+rCvrEAygZJi3t+pBYJ7sbBPIISj4ISrq1L2xbHduv50Vqk'
    'rcuVcolHQYmaBBuDMQybaMLZCNLYCw3nD3+YMbK1djDiIUJuRzH+PJJCGoCCyjyi0vKsGfDGCC3eNsGgNfNaG80914bwL7ffRk/S'
    'yaZ2RS/akknOY3gltLZJQzxE3BAaVKLcr3yV5MT8VTbN8we4YFETcJwHdHfafOpKXdj90cTissBEKmI/CAscQflFjZWdmzioubgt'
    'lTL3FKV4tbG4NhXLvJAcLyTVqMVcbEIN46EwNpCeFWQuRvi0valn8JiLJT6/rTgkCJ/vjjY8qUB4T9N/nRESKq0J52fxzNxv5Jqy'
    'tW+p5ch1cSh7OR70LZvKy1ZoiBE62F35CAf2eJS0js5pVH9cVrdYv5V3Es9vXjuZ+fzA/iaMY4Nh+u1J3BdQBHUN6TexXo31mZpa'
    'hjyQUOziY44AWG38FiKxJsBYfSQxQKxthxZ4eil865gaacH1v010YXwgbM5hwraLgRNuYObLxyDgjOxRcK4W+M6O+SfEmg1SJzSj'
    'seV2oPM4qEZS0yR/AbDQDXdbq7ezaIYTk2BxNfTscCxOmsaCmNtRM2nBy7zABiGgOIR7fsS1eeQqz2Bnko6UoKNBiS8sjoTzjK1Z'
    'b+ollMaz/+opXWvb43N4RuWpH9Z3oMP5Ze5QAhc1mODzGGCjb6K/efoQ09xlYz4hfmvFHoOgFbdYBcBciYvEsbFialUYX6pEBSas'
    'LFLJSxKV2s4v6jv3hFVr9RXPGtbyReJMgLmSESBtHgHfmmRaySTfW3c6Ps8RqI7lGRo5hF3MR0au7nOBbgs8qfUu0wAiRsrPs0Ls'
    '/ZlNUxbunFgnOIxyzzjpCIYiLJ9J8OFOS8xiQOYxuuOLxPUDoRQzgfCa5vYlb4eYnHBuC23M6G2tmZtK8+cypIElpycx80MOmCCl'
    'cpdaFEfk4JkJc775zwpWkopsbB4LJMEzVq1x2Bwo7s8Ff098N/cM5Pc7i8jW+0IwAn7e0uB4boNjRjFzK6b3G0l6ARvxHTGu5AHJ'
    'm48ffqhpXNtemtt2yUN8/vC6dzSBi/+W6tkd1eXGnz+DdXb/0odHt2A8XOHxytx2Fu+quji/7vLcumKUcpQhNJdEwwsj4fuaZLsl'
    '6uvjPLJvkaWIEb+NiqpNlYVtQlCofl8/HuJtHFyE3kq+WeWn+DTUiAQjsyx+3fhUzmUN8NF3W1ylo/OpYBNOsI3YTlG8B5PeZvRm'
    'lWXDPByW3qpdP37kiW8JiI8cW9JMli77ylhPxUuQ/tuM4uoKtKRzlvuAsDuVO1Ujp9fszW3hVK27vpGdBI5+9yI4qIk9cdaL59R/'
    'zWpWf6Ne0l3A9tC3wK+v+pjXsm64PkXzcQ4Hs75tii4cbui6HUQTc9WONBBIEkQFER2HaqSDgB3zQ2nc1I7nxZTueQTamU/ndc7Y'
    'VGB5zoy4Bb7pb23irhY+TW6tvoycqbfVRzSKu1qoNnDL+Z2LswbGaUO3mwNQqDJKVIpiuEgnZl4kYLoMmV5gBMU+kMbHTaS5mvVe'
    'nOc41U0fZmkVNyNoUY1XSs46q7blIliDJXaOJ8bOkSfOlBLMaLkER5nD5dzXz6hvdZC+IwBhiP2sGKReagAgjQLvrIbTvrHi7kz0'
    'Zy4Wpr7wjOZbscz++u/5eJQ8XMpseHWVnHWGbNdqdKvWHiUeylIDR30acb/90OsA+nF1NbBBftCa2fjn69FjZ9PqfxGVm7yyRvcE'
    'g+qI0YwYKTYYIzcQ559Liqk7hAJ4DG2nv4iiz2tu1W/txij+/FEggj7HBPziRAb5YHZsmfzYbYtb0YOfPp9/XowOHxk/DD96Pb9b'
    'hFOKz2/xGpYcnWjJGMigdJeUrWOoZnonvImayU2zQaNktNKK3u7s7beNtfZZ1mFw2xPgfm1yuk4mksZ00Jkhqfc00TB1muaV1T97'
    'BJPRkvwh+F2KwGsC2gfj49xkhVYuhe11o9VW9OpkOh5mM5wGOO9Fe5dEFQ+jF70eDGJffHwnJR+3oo9Qa0QQOQzGHTjZiGU5SPIo'
    'fpNNiV+4sK4zwVjbdkwSc4FDcaWcilw8xowJApYCyYyYx2ntfXz3emv3Z7w0Uhaq/zFjx5UHXJbwTwNB/NA+ho+PIDxooNKIqTjh'
    'Dwgixx4wV1E/zXvTbILe21FDl9tsYzPq0PwnRZtQWuDZhuPWaEcHDcU+jUPcEoemlzfvtrd+3tvf2WWXuBA22lgu9YTDz48dzuMh'
    'apDzzpR2/7VZ22rkY+cWf6YhNoBu+3gDMeIahzJkrTtjUBcy1r725eoibaNzsCmoB6BssIyiBkZwkXPgc0E4uozPIcCmBtAUnLNG'
    'w1sSVuUcIgWmtcWdpdDTaChOux9knI0RDQAvC7aKYkYPK0dfJbRmERanF401fh1WaPz6j/9uPvCs191EJfJl3pBQTTRFgwCYBiOa'
    'IB4N2Z4qljXfRDDAAu45B+rBECyI60DDZIw1DYLw7WZZIVm3sLAZffk8enhlnm/EUiHR6KGyZKZZOwrMKRIbB/atm7Onm/O+CEZG'
    'kifXSCNEPlaFiROXqBYVJ3ewV4yn8LCGApaQRuzAv6JCv7Iw37R9NxV+b5JQxeqDL5FwcCkecfGJf2REBhg5YZKdrIKGf8pQU168'
    'NdWkvh9wwkqd/BtcTmTcHYy7YuNSjuw7D5w7snWdFl0GR3NS4aFV0Omtvjv5MvYOlEg9jZNbkaLUpSOTjhIWZCx74nJC9hn706hn'
    'p7RQ2p5izMssEaNkfVesaNu2YGvDsOwljT0+CFqPk8OmixJVwZsSlDLM99WZZPGEoQKBM2F1ehNojwuJPbJeBkqm0MzX6YxDurTk'
    'wgOHxxIsOnTsESS0Y8Mkn5k6W4CpzR12lMJBUUZyFQ1TusX6NIePBPKNJmv/OJ/0FayQGJ8s4i5p1E2TaIW/LspoF/dpi3Bh4OgQ'
    '9UAPEDVhqpVoXXjJqajFSlvTilHrezJLFmHQZX3Oq79FFPw01gXwOHUkV+oUs5zp8yfLj5OvacMw2fjI8lbV5VIDhtyA5BNX+CnU'
    'TIzLik7XbtffXS62FtYiNtEFlPK6QuiA8bRtd+7Gc6SatsanQE1/b3GhpDJS/YAyZppqZWMJxr+rsSRnh6eRqcluB+MbpeqxDCBR'
    'aaohUcz0cnbW6RA4nBPYUyXYGlqjvoGxOIThJbqJIaMU+2J0BnNjyBaSVvTuKGhfGxa3UymcmUTzPJ4YTISQLOxkxcJPTuD2jRWA'
    'D4nSoqY03nDKmZgQmpgay0Fr5mNj64iNO+pkHEwGYY7pihNvzDFCYCtVqksi/Aw1xE7+RGcidziGpGLgSyoK1KQClnRw1Iymxu2z'
    'MzIAYhkzG0Gr02357FbE8upJoeEE2C1MaFHkJRnx0rAQ2nXHAmBjsipWBNTTD9gBm/6OXuzKgngh8GHeAYF4TSgBnvOLyUQJIlsO'
    'UMbJ5cazKZH9jSXCTEv8dZPP7Tou63SEbKOfdt+9os2gYRCedydbQJmrtOgbg+p6EGn3QTDYhJGfdCTRSILDcsWoQAVfx8yMUoPs'
    'UteJCFh7s8mmf1X6p9yym2a56MiU+nbyQrekJnKbTFsE8LElbminzoiEhk9BUqKsFuYjZ95S5d7PWSdyPp6ellE1YNNgE8J9U3iO'
    'RqDML2GEX4YgmGW0FsJxvUQKypoEg0r+T8ddNrjh28fsSaAKAQx3YceinBgPbJMdb4HRgBWGY1ztrOyxg1U1SQn6RbQolwz2IfZv'
    'mcZSo8mBswkzcOTHRVqraYr7MSEc6Dxj7lj1xq45w9QzgiT4ziO35LyMoqPBLD/xtI1+ME2LSy1zJgfSfL8JreEC6oSX2XO0vylR'
    'L+H3SvJPyHHT/XEspJlPB5zbi0W+KSX141TUPTI2KXDe4mZiS5mwZNF882Da0JbaopCYPm3p2fI39phLaCjX+0HsOqqZX1llw+MW'
    'ST1e3MPp0mU1NXQ2OFtDvyY2HImjVxzqyCWk0hXTuG2PzIZpYjsqEWhMYJiZT3XS0xbqOiVAZc5S0OoajJTqre6TSfYia6yb6BXw'
    'M6Ui0FBi86V6kYSY73TpUzEtTT7LwgKxxdLLLBIFiJdmyOjN5mwKq9S+eluUBp0dE2dYSLpCw2PQ9ix9ViGAi7ZkmapNV7LN0qeY'
    'GSsjNQg5qiuHLAJfqXm7vdjJecPtwG7Za983adoSkfnAxJaeAwU1269fbhQD3LGVtyilVIATTLoefuSpKtyJvYl/YPmttw5gPYhM'
    '96U9N4kdTjhs3vqpzF7F4t3xtGBas5EENhg3zIMrK+ghlqbrO0Ap4VtZn5KIh1h381tX2cFZ+5ZvgKJoX48BcQ8dthigc8E3pUoZ'
    'kZ2DBXtpNJ7OkScK/FcET0IDVA6R6JQtXVEB3FtAFlUbmvovhEF0qSMiKJQQKRVorNu63wBxVlS4o2HKKqLC+Qfx4OTQzqvaRHxl'
    'wO73EysSD8kMlMoXvZNsL2e3dDIw/XMCQ1cGwkToBUDpSXi72Zv8nzoQoE5Yppk4WUUt3GhQOJYalUd9ZMd45O4YW9svL+BxD0GQ'
    'svl9dkNAmIFpeMWqx4LnA1AYLjKS8oro/0KsEvKtoALiuLN46y9bu3vvdj6s+U0NMxphIb4EdZedr2e2oMu8Gs4C8Wof0vN0imXi'
    'tdadJgyx7wkLmS3kGAes6mIunYZ6JoMExxeecQjs0w4hgtmExuWHgWxoB+1oYR+mShohBrR5J8oDkF0ItNZzL8qAniwFkQBT/FHy'
    '4HklJDsu/PxF8MQrp6pCVVqJo2adn+YtvpkSzvbFYGCkeUEMWbWYqEoVA5KPmIj07XioZKJsmMDFZvRlR7gD9UBr6ur2TUweBSCz'
    'KzErPowgClYHwjCzZybbiCYs5tVWjVaMT5J3vmocpVhe7cJ1+kEs1erRhq90r0xy9kZjzXjW+FEbI+OtpGKLPhxyWCtkGaoQ+fvs'
    'tN5/72CRQP3EZcYXPOa9WN5m9HiZGQThzyTWqRWkqHFdIIVKPfEO7jRRH9W5VdElSvjbLZvYoSK9bMa3K/TZdqzB7Jhw5gGxNR5v'
    'tyfDaOSSiIqZum/CS/EoxDaB6Py4IjpPkjXn9eSJsI9a5mHNF3XL6w8sNDbqoKMW/1or82pq4cqW0crbEfd7YqOzfQtgWI9bj5KH'
    'S5LdrwoHDx4Mre2rQW2EpWg6l0ZlslcAGQpyRtQu2xlO2siYxEclEmERXz1Gpp9WZC3Dg5VDULUSxJTjld6DhGhGQWzTSvBSKBzm'
    'goyw9zOmjkKwkcVWNk2o/jrrhxpbBrGja0cfP/wgFgsi/oB43sTjDO0WNNTWYNzdH78klP70CXx86NHI4j9Ch0ughRxqHjqYqmAL'
    'W7fLImxm9+HsJcSeHDuqRWtH/9KQjSVAs4Hoc1waIWBf5PBv81QWN6LpFr3uSKek0cbaxh+RaVTRP1vFtpO4sqDkPGNFsCGuW3XM'
    '2xY37qlgEBRq1L+FGr2TjZLxhlxU22vbcFRSz195WYA7WCvloLbMqgRMVGBZfxtHtTQbAcHRLUIXGMc4uJZxM72ZGK7TB2h2l0b7'
    'TkAF2JqmfPWXmAC6ltJRR+LPUmFdExh63klY1+nFPGlJMHEl64KsXhU6cTI6ZoXSeFLkFS3QRFT+uBCpHOe0pJuDLzMWgTMiRM2W'
    'PMDQUOqsS2Ra2OuZbJiRsIcegw8N4GzCHnZ06GOVIHNTJelYNevwhM8R3Lt+NI44vTQbaL5efP0uWk3ENcz/euJ9LQcX+/I8PzuO'
    'LoaDUb6+cFIUk/bS0vn5eev8cWs8PV6Cfm+JSixEmsnz4dWPNwvRCfuP4ektPcF75+X4Ao+SEJs6u4nwcOkefsQ/VHoDoSewBjfP'
    '0TDSfNroTsNjRSLiYitCk+FxS4ba4GMiHrtU8xENeo1IE7rmivVZcbT4rDlHbE7VPZkdGhR870vyAswm0Shc/AVQCYm5kjXf46QD'
    'jzob+dkEAWb+9y8/OAGuaHS4Q9+nL6d72UKSPBAkPWIpLJ4czPVu0fuavIK8hi3eIk7K/J20TwehJVvFnoDmrR1Er7jgAAtEGLCk'
    'l5ijxmrfy5EbC6AjSLnJH7Jpj4Z7C9JKIj6KO09xAUKB6I5LnqOmiC0kP2z3eM2W4Dj9SPvXNMNv2iEb5SQV7U87EpE8ps3j0vUV'
    'nIiusp29VjHmQ0+bqV7fE436XsEPnu2583Sax454l4ZAksEuENg4YRw6o54nEgi+0iU0oPfs0F06Crmds+y4QzSR84pXqfQBVuGV'
    'dawH6XflT77txkp3zGGY+wMEgwYyRHIV00oj4DmvvAQtGjoc8tTOWScbMLJnQSokq5AS8QVO7TacRzB0ducn44HT3MU2mJ+G/+Gz'
    'xRlv6Lrj4JFsWNI0brI53zojkVhpFOUmx5JHB3QT9E754mcqemU1Gjf4XQsqOFpKNqbUgE0SbxldaNs2XA3M0dSmYVRNHhqPnKFj'
    'aM5XG2jah9MWkN5mJJlp2D7mgDfokE1kzG+YLBYENkwH7YRhaNhlmHWzsixQH9mVo+Np16kV7UlQ3bYk6/XibXpTNqHrK83ks65d'
    '8fhkNWlFb1y4nxzR4jVWEqgIDSxvFrmLFZeo8ojQmhsVsKms2ZUJ0LKiFS1IhOEFjAtJcwnfwimc22CfcCjxZE8WfUqWrQd/ZN26'
    'a5hVmAO2sQeciOr9vAPPa/ZlovahEmYzfUSnwPRUYe/yFjJBlOPAcbB9BqX4RfTr//5/RS/b3AmNXqK+vFiL8OH/xAd58zJh194T'
    '6c2EzMQbGdJorONwH1jfT7C+UIwXpDfWyS7g54LjB0X95xkBY557HKVvEJgOcfPEibXkF8Hp9rsPWz+/3nrz4tP2/h67Fsg3g/q1'
    'CvvwjPpWIodAWC3JJI0giQTWtPaNw8OaapJsN6iICqb6/IpYgLs6bEbzm/vKitmI692Eqyjy/twGCdBG54fUH3SK9yYuvr8NJnJf'
    'fEDn4pB5IM7MyOkexVg6PiAGRT4dYGSHiah09aO8YpsWi4fiD/FYIxrNrGU1bPIG6heCSEXxwyt9vEnUwC+pi6f/EicrD6w2h55B'
    'dzMaErOW4UVgfo14CA+sRXmTxWE5B5oYuICFWQ4sgWDCs8IPAd+JerMcIQpYAGwQr0Vjjhyf5SBpYnAhErcYeQWJIkk0HL8J3u0X'
    'kAjF+E3r4NZsxK4cEt1bQx9rGX/H8Urj3yFYdqvV4v6CDAsmWP96xJkIBoRXEV+EmLbE+cx70UV6EJl6CQVAJfG4G4MMMXzAG2oj'
    'gvva3BhtKL9leZD2GfdatkvEd9RuVVRuKTfeMsOnSle8sNTbEIK6agzzU3+MQxO6zo0U8pJTDNSMcDkYluRD8Nw4gpCM4QhEXHOl'
    '++R5LtSEVh9yuL7cGSq40QwrozEmB/NmVZrRanlKK/VTWnXMsyehZni3EZL9eZ5U5tjY8VKwQKNaHbY36CO2qULzJUA5soDCYenr'
    'h33Ew17xdsLhLzowarX2wkRBy9V/l66b98SYgduWkH65HB0RFgnqkajxdPV/4qvKEg2SCMdRZHKe0U0+JHRARU3Ttsya4Zg6OnAi'
    'KvSTRokDNrg0OTA4yoLknfCiAGHg+2PTdnxSDHnNZdzWPssOiy6Xb7/9tkGgWeb6Obiz8J6vd95/BFNJbLgIUREJaY9NJ+Mvz2E5'
    'SSxs3hkRef6L+tSj34T4Wf74pSnBUJfwlmg+vHSY4+X2zqs/U09LP8Ufr9+uXr99fP1p+3pn+3r73TV/+98+7exvXX/c3bref/Fy'
    'm/59u/Xi9fX+y53Xf7vef7Ozs3+9v0svr/dfX7/dTR4uuabTvPde8hITCpIlAE1Je+Yo0vjg8+cv3/188Pnw+cb1YcKE6efPD1d8'
    'f57zaQcCipiOV+GhM86Bza0C8ZtoUS54oh9ziC60DmKzEBx2oc4srNg3JnI4oVHkn/cOv9tM+FEFwBZIO4jWgv9nff3VtQY+JuEH'
    'Sy7XTUx9M0aAkVw0jcZaLRIOwmmb0Ld4uW9yrCI2UGt/66/7P3/Yeb1l3fJdBFAibC4jMeS6BGXMVmc7XQLmjEhKsbPM09TLLczK'
    'PhrWIxPN8C+gH6puP5H1jlqKPx98Pjj4if49/Dw6fET/0m4puYCQErwxWfQv0apuMu9+XCTGZ6lhsWFUCgtlnM4rs39gZr+1TQz7'
    'B7MA5dqO7+kh57lY12ejUepMEGV/qO0ePBo+8Jr7MsxC/T/ZbVMf9vZ3d8AbmpUCGMaN775raONxkgSxjL123vntbL2vtHGPJvZK'
    'Q3n35y3/zeut7XKr/+W/3KPZ9y92/1yuuL7uVxToig38IPxTdnwygEBjzXgH2twGY06fhWDByZwOX9GWNZwRF8RcslHOmm/NDMfg'
    'CC7U5j8tZbXzuPGlwRLeL19YsMplwJ5++cKc6Rf/5ZfGmoWp8oBeNNxpszluxUuBBU8vCkIk3VmR0rVJr+G6Y9x+dI08rjk4Smb4'
    'sZTnfOpdjiG7Lj1swqdP6F/QwngnhDA7L9jmoJz+cqAlOQYLHyUudHOoFT3vvTj5nB/ivFZFjQm1Xz5kFWB97wG5mUPjQAWJzPd/'
    'eXCAfsvrk097Db+Hcssvd2sa/iyhyaOIflQqEj7+dL336SX9/+M1YJVwsQj6ES+11JRuB8b3/OFVEToo3tClqAXoIqz5HI5am9Ya'
    'figMn1AJcL6kfYliRyQn5fhUJt+VxJmX6wB8y0rlLhhwfOl0IAhqirhC/pUwyAxmEyf87XeNeXgQwmzGfNSYqcO7sbPdEAjMHj26'
    'aTH/tYhM5rNuZDI98YGyCcukJcNhPWKnGL8nZhs5ziUNzyHWQ8Nq9TiObO115iN0NiekfQfVYbfbYvLE4TKhtpj6xCx4xDcivU+n'
    'kOYrlqdxJZV0WZ9HQluMxKKsm3AU3Ap53pOMXt42GLCcNzx/WAAJxJtE+3VAJEX91GwBRLE5L+9cGZBYTiNrTdsahLGCuUejmDaS'
    'Q76MC5Yuo2AxtbM4tOKAou+a1iCh6UBwG69d0fevyHtJDq0ekM9lYhrEH4/O++maiAeiGT5fcxMPVz5/vm6UDbsOUIlZXEnAZJMP'
    'EG8RP6KxhfiHbh7xmwSSXEkQijlhRn8AckPP3I2f9PsBFrKcRMaQZuaGGuR+3gMaDFfC4vLaTm0Ie6MBs0s+9cbO7Sy60uVxWfLV'
    'jiPshpqOp4Z4iq5pzZMS5PhYxoyicc23Y7UyH+3rRkDXHvCWo1sw4E1T2Y3fDHpxEQ7g1dZ4ujxs8VFf0VyM1GwpBWEA5yw5NYnZ'
    'yqBu5TIWYw7YBtq9U550oJKYxNf6Fw6UuZoFVLmXEiehgT7Ha9kkbqijz/0jMY9Sr6VVmTNhLqqKNq6kd81PAx2xQef2puYpxsmt'
    'dG7hOzbWkbk1J1Wv548eXXahYXnNSl14K3WRzKem3q76VOnbxzXElde0/VLuwlzpFyCGDHfMl5V5IkTvOgEd8a0Jbv7w6oLdhb98'
    '9x1+fvedQ+zzRu0Y24Y3CAFL2gsLuZyI0k9KaTON2hFL8kYMZUPOxcA/pnPpcOKn76CK/avroWRzXKsumJLKRBV/kavNkMCfR/Sq'
    'ccvOfdr2d25n218Jc481bpnB291GzQY2nPEOLwpjjnlNsEDBb0X8WXqlTu1npNEwexRcr8FBqSHY9JVW5uj7hkh5OR4jl1q4586B'
    'WKiMbaXj1A6XsCsfNw5SXQsekHdPOE4EkhAMQsxdFnfHR8MgyYCPAVmuN9T1Gvbt8fLQVJcliqHkPCmZAYlEbT3qMsLalBQjnCaq'
    'JLGSAi0NOXcVORFYl4OVy0AGWcOlWPA/nKzK2WSpVttIt0oYzKQD7oquwqX//PLdttG7tb9jew0p4AU9EbWBj8z87kWe6wFU41u+'
    '0bpqHNeogcVg+EFd9PjtVzawWtPC7U240pEjvWnmEKryPbvoVQ+T/GAZRWGH3cyJObc5BrOpE4WOpzZltmcVkk2NnDMfG8kmR+QW'
    'pWeYuIjJnJoBBlxBeTEGWRC4KvfRBZ8NnZp81JxOkvvGLYpgNe8YxibFeYcTKqOAIscA09X3y89avK47bdtrrqI5+MqTV7d0ymxt'
    'bkbLyb1B2cLPum3Jhj6Wb3qQmtHTZdCmcwEtWPwSXMkw/HNZ3bVI1lXOqTZSPqgolzRKzXq4x2u1sre3oCNP6M9JT6srBvQD1GPH'
    '2vCXoqp98DCzf+NePW7eKMPInzQVgcCbaiz2OCCWGq128ujt/vvtJsOHiRsqVu44d0ymcSqKH8bjY+LyXo97iFL043jqZ6XV1tBS'
    '7Lw5ILjXVPFsyrgeLa54RlMDIWKpbSaENb0zl4TdL84gt/CImni+NMg2ni/NBhsNiZW5uMiW0qXsA7dBNqSDViTo21lo1jDY+hTw'
    'tRgRI5zBv96fMvAVJq0xYtmIHbW0MkezSr656+ZCrFBf4eHDibePzyEbiDfbbNC62FtfiD+fP0oWks0N7G38czPq8UX+hQtGOezD'
    '1hdg4348HRMuXeR0Y+2HV1fRMcL840br/uloufOMtqI7mMGD+dtO2n92dEQvJhyVsfHt0VG33+/RvXfQO2SNOL1Jl58+bdwsbHxJ'
    'vAvsruvw+WTjebbh7sTnS9kGXYtp3ourJw5irsmGfz96KOWBw8chM9E55mR3fHao5skKAn60I1FFnqzi12PMRNo5tBc5exJziD0D'
    'WiyD6xxD7iYDZLwisjd5zSMmOp536ebLWkmAdeMNWi6XDYbQpATTzyN7O/qATSD9nGBbwfrRIxPC0N4HMmZTd618JqSu1DCfvImY'
    'ewo2DQYGvzzvZ2cbZkLPl/DkBS5ia0G7UA7roHWgEFjG81EwNvGdqNUf9y7E/OmXbIJD+Nf32+LY2IpezohkRUwKuOsgfzvy0jTp'
    'zkd0DKTwhUGaXOYw+MVMJGHYCFZO3WkHgQUk+ACbLKHvZnA449mEjeMJlbxGUOWEj+s21U13jo6Iw285i/xXu69+ZgIedHGcVI3Q'
    'oLv8RCjv8aoIFFa/f+pSygKtjSSpJ3aUvtGPR4+YLTaZa9Zc0VMpekpFn9EfFORMxNEfOOze8sXW65fPnj1eXY5+IhQWbWxw6vZ2'
    'pD/XouJgxHlh+Xk58J6GAjqJbcCf3rT3eBXH8bIwDgVmRMsXb/R/az6yvODUgJeFSW9jV+aAhvJTRHzuH2iC3x+6sT1z7uZcxDWc'
    '2AF6fAKBAltFqoMrG8B7i52OerrcsCrZYiXAVOyzp4WIn5uSRqIz0CfOpSDaZYnc7HYukyBS43MI294SToYhzvPn0cpKdG1ev6dT'
    'K7Hb6cP37v2eRI2JMYtoJciTxPGTtNgbojv/lnYgu1+MVv70bJnb+RO1Y0q8J8xwwvftSrkPN2BWrnL6EIaOb2pMFrBgpVSu4jlE'
    'a9YSdUmsvpdN49CI5UXdljyL6Ri07aAtgnriG9nWok2ADmAMAOTcIa2OKRWvE8Q/xsV4nPiSWM3b4zalwzkm8MCn5+UMwWu4suOO'
    'z+AEKEcMElJq08vX57HCZ4pgg1sHUcBoSPFjWC9fLD9Zfvyk+72hRwem5ZWn8RNE1TINB1+ecs1ny/Vfn7Gpijce/+MKPmUswKrW'
    'XFnlzaj5SBNdecILXd8yvj+TnbTUcE0bq6t3lKFBrD4V145SGc35QQdLOQrjlVPZ8J5Z4SeyTqvLK94K9+aucC9c4TlfnlXWvlda'
    '3nDxe6X1DRY/+PiktPg9f3GfVhff/47B1i1sUObJHWWw+M/mL77f1hOaiaCAsIggO5Wtei46kUEYdLk/Xlb/HKfh8oZlL3DxjtAU'
    'Jtou3bszoi9jsKGSKhQy9xbugG0dsMk9c+txXl01mfWCg0wb+3T5ewCLXZw03HqhCEoLmJYAoK5QqTNAgiCkchu62ZXF9fwZJAge'
    'Mu7iOLAuQBeIpm6D4bH4x4jTLoaDrRwHg2/W3FNi/+H5xgIrsXsaLK3xBwSY+0NnOFkDffucnwYFP2zww7E8LPDDv87G9Mg0d1KN'
    'tAeyiocL9/GPotn2r9Aff/6wBw5LHY7y3kk67OQtUJI0ZGHjcnZAOieiaTIdI0AsXQnDATySni5x2mx33+3eu7kxk1Wv1Z1GGpum'
    'A3YZzZFAzGt1OhsZa6ovz8/b0w36h5e0zTHL1xdABCJiEnyaZKVjpsCp2Ab+nfrOTbRpHb6PwPQ0kRJJzErXORCm9jFBH5OPU1iY'
    'sfPMprwWT5rz9llnAC8r/nazsKTUL9H43BZ3LbVp7GYsE38Uw7SfdXw73CtFp9NM/RC9Uwi3G1r0XV6HWO5clolIxrOK+h3FuANP'
    'h80tY5LTd/13w2P20bP5W7+wewOSqbZ4CjdqJCCNqGFvZXyh3NlujY6Wfk7aah/Wz/Jif31heYF/vbS/tu2vXfza+KL39yO0NmnT'
    'SCAv6rFHW+/iZoEmyz8vseYoQfD9cRplfbwd0XeMcX1BAZ2zw2rB3oezH6adyUnW4/RStDfPO+1j7802q+ZG41fsY/8in6S9Yn1h'
    'BdWXauv7Y7VNea0C+UWzaWa9+W45Dbpk5lSpCcrCxnP61Z6gWfwYndHEMHI80IB05stm2iZB7pIrgfKYgV/dHzjed5FkMhsMMHb8'
    'jqZtjqWOBmm3ub1Om0hBxDHDT+Mwhoa9D0tBY+Ve8oms+cXRdIi/hACiCx78Jf7lPiArmrfZS67qZJoXP6TjYYQf6wtTGsoC3nfO'
    'tnMdlCmio5LOl8xq+mNbCjZsw3uWjRcIZjRiAduhFE+5q5tWe0Lpuvw4rUMu9K+HLNw5rznkVRzSffpEmTXxId1gtvMZX7TsVBF3'
    'CkL99K3k4K2XDdSlnekroulfFPFy4jFDR1mxNZxhKufN6ITz+v3I/75NPM7wgl0T8KV3aSwHWHwU4230XYTEgecqcaYiG9rClVT1'
    'yveQfg4fqQJNdU0axAtIM6yRhOR3VJV1aDoNmxxGYk0O1jMSe2ebADpX42mrDyjGYj4wm2gSAXhZsVogaXneBWidHR6xFt0KohVH'
    'WSOioyfP4oKe5lhaeIkqZaHhTdmilcYfWu2VZ6vPmMBdefzHlacuKEYHicqo/mo2It57pfV9NvLHIsL19RqFFYAug89Ve5Aesbcw'
    'FJ3vuIIVDLlrLEDrCtaxAbZY/YCTpvEIDvL4eq7B7GIJsTR+oOG/T1L4XpojgVHhAucgkW12zyWEuwpcYK2cvpRNKECGsNAQWyEL'
    'D8tDlYN+jfOfaPCogpduzpxhrSt+MOr7pwZmgRncO7PmIrejIT1+ukyg7DQU6kzyTFn6Ryhg8o/CElv7UI0Ul2YZ1WhGKBjMd4uu'
    'CtsnW0PD5/xPy6tPzbjPiVqKumlxjjiWL55gnMfZKP8GZ0RCUKgwGV5yLHczISbKklhISNRF48Ns6Az4XKldpiHEbNQLOWEpC8hs'
    'OcB5INJlZZn0YogJJiO4nRsnE5oi8o+32URs78hwKvYu3OMqteyN13AwwTtRtfRdJ7YPqBIh9EvZM1IzDSoASHhcwhFpB1WKnLmF'
    'NVk+TptcdE6p/McPPyz9p49bP0gitfGImiqQcYGD17IA1mET9ECUV67MEazSkrrkx+y25Sc+fjAyuqNQcOxVPGjiCjhE9VBBYKqK'
    '3T9s5paeA2tR6fWF+OCnhcNHycLScRLa95ihIlIMe+3PM7rMhqVAAfRGowTQv6asxMUxXv/O6d9zX64aAeE8iI3P0k8Oq3wGWlFj'
    'RAzMwy9hMUI2m+WCjIA0E6kVe3njlCx1F0XVludevv+e5z/NctQhSOoMOEtw4P/vvkn2X889oBIAIPC4F4d7pJ6TkcOV3kRo8V3p'
    '13TdeGHKJkF2a4m9xcKAXWXE3rb0hMjwlPo4b5cnw4qS8iQsN2A0jchrSPwKsYwTOhOZJPIT2/mp6urlNAlZzFlgs6nkGlSs8pFj'
    'soVOJReeSwnbiLR67Ex4IRoNIszejOEhTBdK3suI+KblzMeDTr5Ar05ejPLSq17uPS9tBC13vWa7pW+Z9y0rfcu9b5CgnqalAsCE'
    'XhlWthmmcvn7p49frZSHgrtHa+DatGpIx4o6TR3/dXq63mVn5JR0gJJR0YHAQFoVTd1lOhiMzxtMA/j9zjhtRHnAM9MtRAGDtDxY'
    'WFZztXw28QYN3PiCRj1yg5aydDLpj4RQZEKB6qVTffaGpAj8QimaKdPMF0wX47cjXgx67xUXbc+pEMSPIZMAi7g4m8aLj9PziG27'
    '3tnOBAgxE96qV/7q0mPRl+YM5qEL3F+HA/V9o66TkiXzv7tj27+ra5snjMlFpdHHmT5qSkCapGxeHXp/3en/dT8PMM9VxDcKvd2T'
    'a82r5YxhDVSykObjND6i5f1tYqV5zl0O5/5WB685pq+nkkvWt3YNLUzv49WFfYzREi6AVqtFG9k1BiZmT12r93b0qmk2u3+zn25t'
    'aHb/hr7Gi6ymp/wrevoULvOnj7e2fFDyxzm8f0+hC1tN20Dn7Yozl5iAiK+AwfP36U4d2OZ3h4v3/qP3faIaRlTYZeEUHhrza75o'
    'BAf2hA7QFBdSNG2L4E8Zk7jejS3hUFc145dkouH4+XTbHvzzXe89VsVIQhEbIgtZh2u9xypYKRvaWXpiICKzmCQDs91iegxjN0ID'
    'kRlAZGD5TbwkBvRP369+r3Oip6ePvydy7vHT7/8IaUJSh6B8ZzBvrY7KG3sTaljV2LikY/3I8RjgUlYWfLHEywjTKxIwK0Xnur7A'
    'q873rJ9OSveOMlGz4bv+XD8wx1OyCGCFVnBwNrCOL7SEz/j2tnae0s3a/a62W9zZvsKh7X+Wo5n16PwYMwxwBIIrOhwqd1j0hB4x'
    'lg3mllW9CAJpEoHTYTkqy9/btCcf+cTzYlv6D083tsS7vvvCjyL4NbW/eOP85zzXdJbG2p93OLDovReUG681BkbQljWweC//tZCl'
    'hmcX1F3ssGa9sVa8M36XQ1iTDnxSsj0ve3etOBemW7znjL6XwKAQ0/8RvAipq7hAJqLlpKYfGxPxaDAeT+PYAQ+v0RKPhUMxTSXs'
    'Nq6Df8lLPAU95r+sLzzhH0KPLTPDBmZpfeHlG/znOA8rsuVGec0bxXgCPSm6xd/uuCjGiMfemHIaXg45BKvwt+7nXxriTcjeWdKW'
    'pSkb/4J4IWmNY79DCjgMRXewIX8E5OnHjzTwc1ZmYHm+4xW4wWwgqV1f6F90WOjJDMqmaeQdS2y5Gj5Uyiu2/GIPxSNT86UsArWo'
    'yyFEq/sgxbY7lxi1afUou0j7chjp4yuiFN53eAI8LB7Js+XyIHCTKyNa/30pbG3JLEzNsH+YZn0aM56O6eer8cBfNmYEjQU4g5CZ'
    'Fdf7UoONCaoJNwDIa1zfU8180JLQiYw1g/uCuSKm7SrngkWGsSpRSpV8hgOAMctZfIlAibQIeXBzhKPlDF5eP3Xkxci/qdxBVKdL'
    '9GUs/JGzdzmJutO0c+oTGzyeRzAzrHJTJ4x4KjMKSvIklBYregwtPQX0XhnORzVAPtKUwWab94DvHN4PtOlsDsxilBN7N/Qgk/Uw'
    'AcLA4xFayfWFN6v4D3hB2mAQ6QXwJjCnV1zg94v4r9ThleOEqBHcf2Y6MNt7CguXRp3uApoL8QCQXn2i9ibc8TXZhue8cfLAtp33'
    'Xtyb2oOmZSfm0SdgPRK6AOHFB0BWt5haTPWWI0ZrfbxumL3gscl6eoxv9aa08yc02OCFZneg+QtWc7VaR9lY4ojByCWtuV4ZM60z'
    'uWYd+bksbdbjp8uGAl6PgjuodGN0cAdJLVmOycu+j/dqbqWVVe9aeuYB44un+E+3g9tpBI5bVlXHOiOL7UvKOcb2oTauZL2iUV42'
    '9McmrbLS25gO+w0lQW2fbm1WPIvn+RabwBPUqRwXrti0q3XlmHs9KcIt1LsYf4WT8e/gZlzir+4kkqktX5JkoiqFzsr3FPeUHJhr'
    '5Ti1IhtPeOAWvRegqLvXfi7PeqvTsgNOCSBU0zXOmeelfMUd3yY2UtYWLdp5lRqxgFvlI1Tk+vDKXniPm8FcNqNVGsFjjreIZvOT'
    '7Ij1v8sJq7NZjXzDrie8mjKQuezvLY7SGLhxwTVb4DMMcx2d5y7vXT7PFf9aWNxKtKk4U0RVlqHYZM6+YPMqENTcS8o5KEk560JZ'
    'ebxigHl+620tOOs+e1PvwO0zdMu3nQFPDuWuJoPyhUeoR/pPPZy/UseKeDi/PJtbPMAxEPX/VjZyrVYqUwK/Cq9awjlzWNeqR7hZ'
    'rptAUZ3vHBkriwdlFzT2MyxZmXwjyYusFqTswGh1MFXDE6uC8dw6vaiazxJfFcORBAmMv5FwUXf2t9z0wjS6ZnAYYClE+KLOkXsl'
    'cgEhPROJYE1KTmu8KIF1Vx3F80ysW/5pEx0nMvvGsVDcpZJyGbNmgWbx+z/hP4VTQ/HVYwLnehcFiGBOZ7+1G4tw6r36XMeeJBCE'
    'jGYNF+rmnt6b7gZmE6K4m1ScBQP/Y4O5uS9zHTf2NXBq6DhcMa62vuovBudI0ozA12CSnXkJPPvoDkH2ZiSq5ajW5xwEiFMDsIHa'
    'EbKXsEkPZxnyEhuoiU+rRF9MRsee/5kYAoaJ4kyc+SvJdNEG+IksxMst0DbxOnkobbpkkaO249nvJxXSpl9x4aGuWl0ubuzXEMle'
    'kqpHJ+NBP1eTqws66bCusS3aJVfTswmc+RsSuN+Jv/tnEIJZk334MflvVsGmff/HxyvfwyXg6ZNl+IzM49xWnyyLLOPvPXtxwU5w'
    '6jEoDtOa8XnmgbANfGSQhDwoFrWAFs11+ywS12QQlIGDaQDslBJaYcirDT0RlFvlcjbhm3wLpLINNnz/Ml8yW8bFwMN1ktqVWhHt'
    'b1khz9xdDW1YnrZJKMJkVqPuWssLEu6Pprm+8Gn/zSKxX0ip1+8MxiPCLpdpvrC58Q3s0E0znFRFWGf4OxDrLG+meLPrvzmf/AZr'
    '7dAz4rV8NC12fkODcKow9ekM/FMG5CBp2J4Af0D7ISGASgmO934RkcLKyp+Wmbo5od9Pnz1+Jhs9OX7fAVovxrQsK0+esHBvKgln'
    'zKMQTO5Zbi/zJKd9feGPy8wkHxG54T0ezworBgAMmaEt6aDZ5lo30bd7PhpLJuw6a58OHH4z39jHvUk7efEizzrBSzYA0keVJqsc'
    'Xow8/jkY1EYqELgh8Kkpw3K9S/Vxwxq3YKa8ab+Y87a6KnuT//IqL78bdBin8bt0tPjDS/8SXir3MCk/zSNYsKsZprX69Il52J0h'
    'YAAT80r3ah9+q0vhHO16WMnVxCqJ6FVfyiltzQXf9dcXPgDKB7xg7Kyi89PXPO9/fcMnQYEIFe/qy7bO93mlcXnLbSOme39nVNft'
    'CFZ2tw5n/rLqhbNkSyih5Db6+5qNlnfejn7dZM0tUpmvyTiy8nvOGckvP8BKKVwAya23vvB4lSErMPumgkq9bbu7qH6hulX6duXN'
    '42cEoUvhOj6uWcfHv8s6rs5dx9X/wHUkfL9Q4i9ql3Hlvsu4+ub7J396Wl7G1ac1eOfp77GMj+cu4+P/wGVceeov49O5y7h632V8'
    'soz/Ksv4pGYZn/xTyxhq28tria9RSRl/y4LeB3eZWfXEUHnWGexJkfAmMLMwP3P/Cud0cayk/fUf/x0M36//7d/4z3/9Hw3P5eBo'
    'KHEcGv20l9EgWZ0L46ntFKSDfdwdDzsjv6KW3xZ/ivXI84mC8xJ49nb0J4gsEQwnsxYqQgODFGbzBLmo2b8lOEdM774Zeua3GOkB'
    'wsA/PlQymdrY98DzX6g5CDRuWvbzf7LMBqimBX/RQ1GAOpVkng8J63/gqsg0yOOny6V7mJovy+2MyuQ/ZknEo6V2KR5e8fZXlut/'
    'ynpYR5t/ktJz7dQSe51uThx2r/gwg3TRe3rHHpwowpliGGJZS2GQ4SVRpv33+MZbp4YC2EQWkXhNBfKZWztc+doOg/N0a78j7m/k'
    '9xN0Xr7WR159328HIu+sb4AwaJWgsH8zv+UVHvFXgPcObfgUopV6MPc+BzepV9MHrRs7K/dO59fQTwIoPrMxlTP52wFw1/edL6UR'
    'vYVvJMR9Cr+Rqv89zd9vM8LCT9/1WUGTL0T7fCMp+7yUm7eccXx9QZ7huoa1qmuHdqzciF0Y107gBcfbKh7pAI6h7GClcSrTYrfl'
    'UvPsIOOa5oaWUNg4Tft7qEG7XGDT2o4GtR1Z81HXmdOstCSbgfn0ftynmlsXdJmN+A4OASnY1YAFzoQ3PWDIEt98pClUfdLPGFF+'
    'iFVrmKzGvx22uLHfCFM9GdAiKBjAlHKDEaY8koEA9hciHbksZWcyGWSSP3zpbNQv9bKoPbQCgH2k0FbTA77M72B+vQlgMahnvazm'
    '1ICHWW0V/kB1LDIhmqz4wG77LEBast5ltw+2ZjUklIatXw7U0bJfIFcyqzR3HN7R/V1HIe3e2X144n/XEdimbxsEB5QYT3IC3Gn6'
    '9WMwkInai873zfS4xEdp4wtdQ+HB/RmHYAkAnf8OB/Y/6jJYKaO+MKqLw39VCJ9zLayaFv+Z0S4N06KDNVwqbYMbUHWbsTsldFvZ'
    'pUqt32GvepM2WvtoB6n0Y2/y1Yswf9rSZN+Jkiez6UAEx72lVBxZ86WV1sqSK0tX0jCvrcBfbMmLPJuTsHxl6a/vt/d48IvZCJPv'
    'QdbW77VZyebUfy7xIC49+x0l2dd2PN0Is9hzIfPpuY5VXqT9iEZkTOP0y4+PX73efwOFowv91yrG7/Z21O0u0UQOCLrwp+TmP6OD'
    'oFGCjspO1UBIBdAthFhtRG0Vh3VtBeNkWFc8wJK2hmNBaisJjvEHF+IbpkG55mFJryqpH0EwJRpcywsJZJoXggqmD0JSmWaHLS9a'
    'kJoflAI7Nn6nG04C2NdnEd/RmPP3SOxtZQ9EYCHHukqBiLk1yeArEerHJmuYDfnhpSM/A5Xwn7NJmIncpRqLuEDSolWBRAN/kiBp'
    'CBIV2a4Q0gsaP1Ho2gBfGCgePmY9Lwu8MZOwUcv80Ps2VFk78kPtw5iB3UuHGo2a7Yr4DYehNoHtvRlijEGWdYABtdnEP/PSrP/u'
    'O+ISsgd7wwvm9PJwTEfqackHGuQuN9lk89n0LDtLbTjrSvxqOhoSwFqa/C35362223PlrdkoiYjt7ZRXHJHAS83IBtVtOCdRqLRj'
    'N9Q05NLP2wT0ryT5PJLHY0HSucthTXn9sPF3rg5nBPbBsty/wglgJhPDCNtCEN7cxpIw4zaloGiOOmedbMAeOyfpNOXZwK17j4DY'
    'mIxI8HsvLTNgVnvfmTBhEORmvg0em3wyK+cWw/VO6u74nCqcZP0+Rzc3X+Dz7b9HcucLU5WRRbkEenkQICJTvPvKHbVyjfVSDW/q'
    'HL/5fTqa6YzLt4FFxlWfpha9nzWShDC/7Q32VnXGOrc0c9CZZp3Fk04+GU9mk0M02EXQCs/tiUsQeqezm/aBOtluRW4BOuYYfo6g'
    '0ccuU7s4q6T945SdLTQdRFGMR2vR+UkqESqK8XgAa0akicyjuEPAy1nRz7MR4cMEbgKdgsBthF44MTbyQSKiGWqzXbc0HuU9BGPg'
    '6DBEYPQ5hz3CrMsZOsvScy8IPlQUO6M9rhJjEWXp8UvYpxYb6eBWtNZPKj7igH9UjIjbl4ioRViLwJ8WFnHaOHM4WwxRsWeehpvN'
    'Zdc5VRf9eG4KbZofi+YTEQctWTm1OOdAIPTd1qh7u2hrtSVMMdAyd5rMm9QXfiAqPP1r/PCKy95MLpBpka6Qfn/rjDMmEBJCusLG'
    'NIXdEG28sVf/WihtE2aIDwRKDxOAWLgHQAh+4ppifExIj49FtxjZlLRskkUvEcAcv5WiVmBjtYkGGAOgeTEgR4ixRi21oMjSgDJ7'
    'WXcg6UuICBK5NC+WjHLNxFaXs7lm4MPhCq1m1lsfMdYcc2rwvJlMQz2OjFQFPAnDg5HdfuKUfDad8Mmzi17dsMk4g1UVExUcJnZD'
    '85U8gO8VWLMWTy4vNlu6RYs4hNgZf9a8K99odCv5n1rYLRHVOT2NhogL5n200dv332693/p5b39nF/HbGzmzFYt9YSvabBTX8Dac'
    'Zr+Pd0j1O6W/ILAVncnhJMqVC+AlltxO3vzQXWUimFprFX5pTN00m2iYpMG41xnsEZhCjkA1mFzwhs3Gh+62uzF4nodBGJ5PIsgG'
    'uInQpI3JMdalIbFWhKIbjseaoi6oz7yXXkYn42Fafl9ubu88w0A4oB52AEvP7bsPdkvsreQ37A+4fiZmqR6g2tZAgR2kNsL7vaWX'
    'cWKjuBETNKKrPidkgFgHgtDRIrMfo77kOb35hgNivQfTEjfiyTQ9It5d8l4sMsOdtnnchBVqALnHUUItDKtdKihiePYgvtSabqd5'
    'F2zrcXVby3vK8+XKiYPCtGWCxm2aHfBMOPn2MwvhzT6/pGEPo9mImK08uhzPGmcc6g4mvnRxfVNzmFANmWkYSbSlFcaeKSd/P+Xk'
    'SnzZodBAFfbFOCwp5n+lc2jPFqqKPMZjAagujI+JmJE0W3/4A46UmAcf6MdDy2RdRad0JfMSjE6RJab793ZNebh4ixFSO9p+92Hr'
    '59dbb1582t7f43J+xDmOpcmpi233HzAmn3nl/GEPsnx3TJdHnrArjg6jIAzaaLJbEzHwOp68xYt0fc1OOvNGgqrsycPAYwNHs63/'
    'vsTzGrEi4td//D8PryTvHJPOI4nsMRvxAUXMMCvKeLyc3Pz6j//3y1pI0mJjPdLOWUb7O2JOqnsHHOBcVnDVwH2tgdYanNz+lP3a'
    'xKadtkNdAr7wfpr4hA+v7IziD3HRohViJV2S3DALVve9GCeSAO0LgyRBmV+qYMv/REIWmxErfRyOtzBm+g2hBKKOgVDwFHyia2E6'
    'Kxjciesgwq0zupQC9AbTbJWN0EEo3k568AixARHh92PcbWWymNqoqSfkQ8OatHdb/SwHS9PnzVDTW7pBO3kOVNUSciVujHHbPqDt'
    'IsCVNT1AD+ZKgqTwEFm56JZS6Kx+T3hnu/blmTXaNWv+kki33onPY9AtzjDBnAmfDX+PdtOcgaoyCVPgNU0+ZHOCBhnI/PLbyBt+'
    'V/Gb4HIHQMWYXzNitu2uE8FYuTD4R/DGcJh5XyvHwI/kyH3wN2+pdXn7PNtItoffrQkf7b2hEVlpR8BlBwlxOcCNHAtGPc1Iarel'
    'snEFuueA0IKOx1bb6f6dwLJ1ml7mkvTW5kzzutXl01nY6dnvazYnmbuUw8thLCAV32dXqrA2b5e8w5axy30+66KCYhKQxCZ9nzfa'
    'hC4C+tKas8a0qME8XeG1+ZOEI4yA4L8L3HkTPcU8DxrMcIFRZn4WP9hjEz+Y8mmU4fDUhKfXNGXEGbeFgWW8mEcDPnP5N9FtuxxM'
    '/p/ClGiMMFMNQQbk7HgKg0vXozJj4dCoxEnoJhYPlHFeM0R3dUwHzawz5GviBFHumYuYR+9w2VQ1GPeXevIKO+EQ2mhw9JSLW2KS'
    'ZqPJrBDingrKlSAhHaKGjKOxxl8UAUROBSPv2R0VXjoSoYXrFifE3+okG6ZpwxY0tsDZASyk/WaEhBe4WKH2GbSi7RSitqyI0uGk'
    'uMQXtlPMfAYZGmo6lGlH0j/w1EtCJH3JdWIagI73iBYij68iIuQBGMTLEv1rnV6ljNClLodSf8xHmclm37QCu0DvwRW7kAPYKVTw'
    'z2BkmjDiLT+fkV3d2qCE6l/uaLXV5WXrPHNBVYbjM96M0hrYwcqIeIx0q58x3oMiTTdEgmC7T56KjY+HIg+5BJLIVaQbJsRk9tOa'
    'O8d+gjl/GA/ODMHONcKu7m4PkdsBabGL+o3FqJ52ungCGYKMppUX4wnUc51jViXFnotfistKwxUCUBvmuMVe+hw7H7903utMUldc'
    'mSyML5k/wO5gNrVyKb+jxCTA85ktFTeGeAMQypLs/WyYTgMhFMTbw/y4fGkAQ/BH4LaiRPzyXY1K+ORIRBp63MC6q8oJ7trocDwj'
    'ytr2jkr2gVmkwhSSKfpNKuxqqwzZy14qnPwcLOwrXDdswbS7s7P/85t329vs3PfxxfbW/v4W0RqYjZRN85KUwG+CTbQkEg9vmG3u'
    'G2Y+ngu2j3h46wtSMxIPK5Mc8+FV72ahmgSzLe8ZVtcX9tntUtFTI9cLsa3R25mLkDj4jMgQuW1Kpbvj84WN9/Tj+ZIMhG0d23PG'
    '9ZVD4ocN17Jv3lpavXtemD3/wjRXX08TOPBFyYuOSBihYBRs5b6AcUDLlPnpTWWnbRBu3k7mS47T8fAgJ+qLIxIP6Q6A72eeOAmV'
    '5Qc8jsHIC9Ydwx4/yNFCnOVYeHDo9BJbl8eGTmVIWfGa5ii70JvW807iqThJR7FXh5Zi0JnkpQFJ5w9OEb+KeHKZka3D8fFL5esa'
    'DM9uvtnq6TcO2bPFAljmZG0d28qnUX9c6oIgZ7xXEBR5Ob647G5aKTtNq2W/QmvTEqATbc1cTpR33BFXcnLzFtOgPulz6u3wrRIh'
    'MyNu4fUYbKUoF9zZYUDbFAHw3oGR2x62erHpGBnrTzflob7k4NQVbfgqNnr3nrVeJVDAnTg4tQXZerZakL99zHp1TdRyLAeNb49e'
    'EnHGedaP3hUdOszyew9pT8Qzgopkx8fm994JrjH+ifw88ktYcPzMXvT7oP4fMt9SC5/SYzJ/V7cx3e3W0Xm0sR79UekZrqkjvLtu'
    'xgVdRRl1YslUOgk5Xgl9Y4vxjIJSiC8SFuIZ1ojHJXI+h02Jc07igiMW7QrR9us//o3PWaT+/Xi2w8v2oH6qbGW2yzdgeSdtghi/'
    'qjdk+oqXPOr3dtj51nBy4iw6hFSHXgA8Q94iYvqkk2d2k/I3nX46v/gRfbVFcXJYZpLPr8Dk5yu+61wfL2bFeH4VeIXuZxKS3PTD'
    'yNXjNbwO8NEW/ZGVPfUloQhyZMSYc6Ehi0h61oyORkyGCPRWLjst4d1Xo/T8KxgxDq0igdiR5cFRtERrfkxZ22q/0pBB/A86o1M8'
    '5sy7LXvsxXQ8hMYCIBGoMwJGGbEfpHpBsJ3GwHxI3YxolWNDILNQwLSXGLOHD+m55URh5fCqmA4e/WfwW5qxPKJjzApr4EZRluMY'
    '0CWYskjAUAZujaiMlMAV6BfhNNXmI0wp/I9QXgQfX+Tlzy9yW+AV4kz534WwpL3kL3FvhrATtjiudr80lcMr890wyl6JgP227bwR'
    'iX21V3yIXX+wolABZ6U0jJn2efF7thR07sIquCZmhV+3NyukqC3wEdY11ebZ6AbGLDHsXprybIRDlV64kT9n/fyrGzL8ibTzeiYm'
    'ecGA+ual21fRVpe2Qt+6xoRyC3YDKHJPNUW2IPCGX6ygZ7dXWVGdlFFr04FpuHNzYysxOeTVAi1kPzL9E4zK+yi2bXwne0WYXvbs'
    'ANIWQSaipshCYgHrrusujrFpi9om3OKe6GZyD45G4EdHW/CjoRLwAPSBExm8eD+eprjIaQ5Ajl8zboRoocIQZ+XUkuQwYsuZDljz'
    'qVosxJhKM6JB014rH4RfJrhNh1GsKuxz1p4MstOUNSdETBHvhGby1m2GAiXuRHjysiCP7QNaHBJ8Q20rmpHleiIlRelVxmM19zL9'
    'UsKnzqpA9t6oyCo7f3XbGq6V1GulFk+r0MssIz45VOOpUrzivjzcL2kpOAfCKs70S1XPn82m5c8/PJTh+BVx/obj4J+moCq/+fjh'
    'hwDJBiiSnv3vW74lb7Up/RA0V1PYsz01RT37PRQ0yv2q/R9VqDMKdD0qN1ZZaVki8z24WOTVC6HJb90f2OIMBqZGP250GR5STj51'
    'U2kSF2L+9Y0yqxy2KAznbxmisUlwbe2KWORuYJRyIRSKacjcS0Dsd2QYYjHh7HMCoxUxmQBhz6+CPkQWUOnDkwFQCzxUJfqoGRBC'
    '+mTasQyavcsYBPDWFnGcW1jonWGDpJjH1IVjEgO4eHHF69XyfLVFvZKWIwyNWcToPh7Juo6U3/LkQkKcE5eC5JpEKqdIqOeaNdzl'
    '7a0yf3b/RitoTiWrQatVfVdXtyCz66wGg43cTB4D8dReI1Z5uZ6Za6z0yxzc8BjuC8zU0je38eZDZQ2MlO3Inzi7QBwsQ9kbrgVb'
    'eIolO3hjT4rGgjgJqpUjMteRD77CWN65/obZLG9BMHflY+9YdrNyzN4GT3ucM1FTGBacWE/+YnLvIEf1uxO2srpqNcpORwuonwOR'
    'KWn6C5CoyvNFa8l6iWLc71wS1YEAdtQuKI41NpAXsS2bbI4iiE6RYZXtN0d9MeWrMrWBRlE6Dxk3U5C1nXZqzMTXAoTlJeu4+rre'
    '6vtyACASgPv3BZHAHf24tj2Rwf178GUI9+6JJQH37wPCgRpgvmutRDTxFVNB+Vv7uRFC+s+AvNP0UhwQmHomhi9H8EkmsEXnOcuN'
    '7lh1QB5RXJWtauxEQ+nqo2g17aNqflt0Rrc6xIciXCnUVFUiuxvG+X/5aX9/5wPfjsPxLE9nE74f7cIowVrW/HRb0HWBNaeJ41Tt'
    '8kWz0+UYn1MtNREpCXFw1D7zaNQ2vL4uOVZkkrTGUiHOz46ranZNztoZERJ0r6GzwxyN/qXXGXFgyWgK/x6pYxKgNiPI/JJWxLc0'
    '4QLiRyQ2J3HBEKsXJ9Px7PiklD5V/GKo3Q6sKZnVYNv/adqdZSaEpfq4C6uU96bgOmh2xICI0yJQvH4ktgqSF1Y00nAbRZQPZ7jx'
    '0Q0hIEl6mEOohRZp7fsDpDOhmw3EeeE6i89PMtZkIRAOVeimvQ4cWtiArTMDWTiNXnx8B5v0aUqrBEEkelFXiCznqKK0IirZlEXh'
    'zO99Wo9OLmlGP+1u5+y/ICEHiGG5BMgdLWIgHVzULWddzUv9kbdJRKEj0auoBmUreP1yTLw+7TUUnfzizXiqxrNa3qgbvVev+FwW'
    'LHXUKKX8fpet99T01h8NKDYb0f6BG6CVuklZJFf7+dXO9s6n3T2OOGSyaEKVy+gUCTQbxhzGJeDsKV7rpojOSosKw8wolkRrSfQc'
    'TnQb2smHnf2tn/df/LDHBkRir9w5jhY3xE6B1egJWGm1GGAnAirB5ofLUTwbAc219VpzkJdzSmIYx3zkjFYvd+UP/yuJ//jnO/53'
    '6z3/+SRfTZl3f97in6+3tuXVJ63+SdrEAvEP5IXjHx93+S/1+nalzXFI6ZCt8qe3j+XPE7x/jPff219Pza9P0tGO/NmWwbnA6/z4'
    'Qsb9Xsb/dlc75PDZ/IqTtMgvpK+UX0hhKb92tZD8kYKv3/2FhoDLZe/jiw8cGPrNzod9/PjmxsDD692dj2arln6K5Vxes07pOjsi'
    'Rji9ln/HbAp3zefmuqCLG84r16OxqXF2fE1n9OQa6PmaFbfX8NO+hv7qGpG4rkFNXTPavhbUfi0o/RqUEp3JzvUZQdb4ujPrZ+Nr'
    'yTacPFzKfPVrNVmor4TlfMx3Zx6FmxnHlUUDGyYRKR5Ek3JX/lEVzHOWiXmGSf3szHduPe+wji8GUgLz4+X48NNiw5uDCHqUqk0X'
    'ITmrOf73belDqYMWXTp0F4lMuTRImBOjjmuqnFR0trq83GUTngbuu5qs1dWRzM1cYUFMkleMvAREc/NtA12sR37RVjH+RFPSdJLN'
    'aDpjIx6Lag6o3GGQ4BolsBhYe82vQgsfTEZw02x0OoIhA22EYJ4J7snOsSIg2DkADLy2eXgmZ2Ml4xJnjdflqcvUqEZLahoV5sd4'
    'QIcQQQbyzTadp2xQjNvJUiYrxyF17phRKYRzMFikcmRNbZhBHHGnrxG35fo4O7o+T7uTZA0H9umT5kFn8ZflxT89Wlr/nB8+emgG'
    'UjMzTvaoE5u3qXxbzjkwOI8wCOddxWBzPq0g0/hdGxsSphQNQpOHO4LMhHl15cVjoXZPTB6UtWrVacp8/mgM4Qfd06MxO9FMYVy1'
    'Nn+lk2pLWKTaMYSpMoOmOBsqds2/uVvZqDeY9ZH3vtqYSYSa1IxAv9UOwtarHce+pAhzz29Dy9uOSCJMhj5knxuf88/D6hGB3SDj'
    '5XejOmhCUvaV5dLJOON8Wmzo95y+Lldn12lGZ5Ug5iVUqC4u+J93iuzbG2OPxx85bTzhed8rhh59hy2jpiU2VihudV958EAJcrbU'
    'WXoeZ8Pja05/cX0yTT537VGSUnx09LfDw88Pfto4/G7j+g+jbj5ZU3yskCoG4Lhj3PXopHOIKBexKrEZsclo4Mx3qxK4Qjr61pii'
    '5s1YFsBWjErPQh8dWkBrcALum5ZA6eJWlqu5DzrEchjgMAXuMHD1M3RXsQlTxyxUVSNYXEjaIc4Kd8GfjZ2RZ+cYQXEsjCgbVaqB'
    'H7Gk3CxrvUsliNeULqfqJVL2LDeS06uydn3OQhsD2xKfUDYuN4w3JxZgNmQ8qnVJi/POmWG9wZBlRSOHyw9eggIf9eV6Y5NY1Wi0'
    'QnO3D3aYngnBA99SzLMUFrLAjF0tmWAn9sG+ZlCPS85n8rhu502NBuBlXNNcckDbS+DCZusbSwvlrzjXRcnaDO7cVf+yT+pfpivY'
    'SOb4UeVpyksnnJ9/HiA7ImALXSDKh2U+RMiuZ/1wYqiyibdtCxC3rMWmvxReFXsKPeMgLENIV1ucZIy/TLVeeHS1cgNAyzIUCUtg'
    'a1R4WA/qOb0xcqbJMGesUfXebFMJjlmhRiVgL3/MTjNZ3HBtpTOW3yDZ8VVo3es47GQtZLc9GY/biWb0BBZdER8yGMMKFjesaDZl'
    'm1do14k5zovx9JIuSdjG4rojkiCPhlkOfbAIlGDrT0R999Kx0uz0/l5jzqAXJzXDeeSlzeVsssT2GKFawG3AhacgzrmF2GEcryVX'
    't1vixLvEnMPbskMIAfIRKtyhGdKW9bkPsdntMHuEVlqRhEDmwC/al+qvITPiMhHkKS2RPfGz+v3LkqDSOQcZoXfog/BHjsDQHcSS'
    'yFlnPhvxsBEHt9MTAU5OtEvqhw/gNod0ws+oUdju6P3XT1pOZmIhplmBmGYdxDg0TNMpXiEOb8VgN0Tm1tKILmDsHJu1Mu7ywZ/N'
    'aznfOSP+F0W8DBNMWtxXKieaWoRYOqnz76smBPIwDA2aZaR/1z1GMLw16sedojQINCmvdo6O8rRI/IQPiGmMcBjF2IYFc0awOvYD'
    'LtbU0o/QXKX4YdnN8JVb7J53WfRChy5miKuLsT9N0x+J7KJLTmfYZIbyDScBb+293fnxZ3C5YP7mX/3q8zKSVLQ0JoNBmFZlZwPk'
    'RuJIFMwEw+ZfriCEBlldq3wPMysN5J722Ga3dMa1W0IHLKPV3sHyITLUIp/0gFPdyqbtYVkRbYELLEYjUeZS0ytrXsoc09aKtLVS'
    '2xYAgFtaCVtaNS2NOGmcmN7dfFMapWnmq8gl45UZjDHxC1p3k7nnLcrrKKw8JKoYDfOx9hAPY4xLRlTEuOO5oyiZsRSYSQLTNksL'
    'MUSmerpwy+4gHxVcGCwSGhDaSHySh/rii2CPmtKWzP3lIxB0vM4h9ggUzj3/RKnBJO95tFjCTcy58JKXcRaVXjOnhDepXEAb3uR2'
    '276pJUuu1quXe0CQAYG2OgV06JstrgF6S0RoroDGu8PrpqDOdohBb5Jqq+prsMG+XV5jHNbGp2y8W75yf8N+LYZdWt1isyx/nc3W'
    'TPI9bazt+oMwpFSIb422X6EpILIuMrbJeOIjflyuHqYi1tFbj3Z1gW9bojpSi+9dtCWslI8u+RM342qXaaCQzlmr0ESOXIeLSm5Z'
    'hR8RfszxCuzUI0QwR2dynj0tJniOsqlkLhhJ8CgQAdFZlmcF7n9wEfaoeefGp2Vl5+5HhN2Dmq1S9sKCVG8VPQklcra8E1DTiHLe'
    'cO2xnse2tHADWpt/tT07De3XkMeBEYdEDRix6j/khh6EpHDoKlghk8X1U5Er9vd1Ni0uHYyO1LhgZGQN9By6Meq3IOS6ZDlct/Dh'
    'OJQqx26KJ6GG31DDxuI6A0IFPjLEGrQ2/bGYSrNNddLGlQt6bjYSKlUxGEKkIic3gRYC4/ErDxRBoBKQeaBVNT+/P40vIWrK7HQE'
    '38SlaNdEOrJkrEfDsjLQuCxiCCDXheplRScHlpnmmE46xfi9uGu8JLcafubmIizpne9DoQYEqidbmUufAuDGoxd05YFh8QnVq1Cr'
    'WKmIGL5WqFJBLxB4+N4GU25fjp3W4gnRUu/gKraB53SV6fhBZzugTxx+zV3xcccuvToQUnG2yqXXp1yQBUUJOyZKFybAFEFaPhnD'
    'oRzhLqPhmNWL3fQEcQMEBnlvZbQKfsOsv6jwGXcsRwbLhiQ6H88Gfenj77PhxJ8BhwjoREcEswNO1cK5Ku/aQAcX9OHMyMAFhaj+'
    'GATp77fNDiXdX8xm73gBjroBuM+3gthvpwBdBxqyUmJN2fVLL9Ie0CcdyrihcT1sEqC9FImEaDQmZBSU240g/pTof8Sjf9g5BW0Z'
    'PZ8g9h8ME6gv5epDWuXVsB/3hn0NpRIZY7VQNlYv63QbUXNWTLBZR34mQai1YLasov0xK05e7e25CTppZm0tHrUWlTgwdXRFHRlh'
    'knoD1+GbUjRy4W7YZWlICXxl15eKulasht5as4JAaMkmczBPM2E44obYF0CdUG+okEiELtq7QMCCThCnEhlheXdaEdaKxmmaPqaD'
    'RxdVVqgpKt39XEG5BUJKrkGYiQwIUfUvqTca8fQ8A+/DwhsxT+AmwUog2Gq/JegumNsEbLTKhCClcZYV09mI4x/CTcWrA2jLcpbd'
    'IEO6XEe4YVLYfabpRDywpW+RlGAAECzB7FAXzsPOICdkJ6TO7wSxerpZMTBPopIOSjIVvEFnxtm3XsxChb4OwxnfMJXXwgxJgKoY'
    'ewvOBK6vnRdhYKkzjiV6yqmwC9+qdcjsv2QQNkEPravGUK2sdTjDWrQ5BHk5NGJZ0TcpecWDhWghNwSFBYamwIGCwWUDRkwXdIHU'
    'AZp3C52zROVWact03rreZmYAxezcerI6qMAhVecUmyPecfuC1ciVXywLcHjooRRnrf5LInRti0NyIvdqzu8L9pf3BTmqApZuhfXz'
    '5Wa8sNh8/oxwDIWz4sC4lEuVi3xaEsjxenkCuYgNcphjNRWgpAyK0wtb+DaJE7XyvKYAolQxzEj8uLFquRQ2ebQb0XK0GRTjIHXo'
    'T0J/wG4bEWgKiX5hu3CHW+DN9OjQRc1NxuEVBFdixh73ZN4q9PLlG8v5w2FhNrBt8VvYVuLjPXlVciZnGTS3nHjbhb2SLuLCi6Ay'
    'tOFu5bzhcHnIml3s2awQcMBYeSzIni0NHZIPTB8k/eJtAmC2k71Nqvn/8/Z2221c2XrovZ+iRCsBIIEgJbs7HVIiI9tyW2lb8pDk'
    'dnpTsFkkiiRMAAWjQFFsiT36ao8zxslFkpMxdi7Oud03eYDcZ7+Jn+TM75tz/VUVQLp3jyS7ZaJq1fpfc83fbxIyh9UE/eG0n8FW'
    'ER4/nY0+4w8MSUfRRTwaAgSyYnk80NvNUqzTsmCjLEuXSJtd8W08IQARavPPoW+UlmMXJbf+rqPR5B+Q8vdVJhrSS+BAO4y7nH90'
    'hv3sgNUDsgv/7QxbvAaOxlRbk9+UuYdFwSsr6240UjY29zVdUnyGxnIOZ/epyjqkDE7HiVfmPNCV+qBxOdBRMAC24WoQb8lom7ur'
    'GETf8btNr4sMGSRWOGtYpa49VQ44NwHwNd3BYJB4jCUA9XG/3JxO1/iu2SXWGJW6HNhoerfu7jLpKbCmp25Wl7Hbhd2CCD64mNuB'
    '4OZcUpkLEdwiMqgzoMR4qUydhnACtGaphjNGOcwKObJH0hW89Ee40nYccDn8wm14AbCc+odkF8PEfuKv8qbPOuasnyE5xHJRQsAc'
    '97NCDslFH/iox/QyqS7w/oIozwoGPUlM0nDNKmqVA7ZBajtadNSdxwNmtWDVH8guWN/DTm+YWjNMDzbldWnRzIEU4uE+aX5wn/f+'
    'SHi5woOIJaer3IugdMC3InpyEzT2rj8mDjHr2t/BilW20u0jCoZxa0uOyjFHUg/eBgLKS+Fge6h01L0DgdM38eWWbWYPhv1sxYvm'
    '7Wv+Mq0iLpDdnJBLb+gWOSxxJoFm+LNJifirG3VEajQdqUIn4rv3s/WGy8hRwLl3Kv96k8OpNcaCgfWLjImhqoYGYVTwgldW0WEC'
    'Nx1QTBSt52i4EaaHLW5Cl1RlB7oFp6NhwJbFXJXBxcnArPkkrdZEaNk2spkjSJ/pqI5ovRabtpx5PFmX9oZsS7S++0GcOHvYz84+'
    '6SM3zvE5oYD70NgEZJYZv4mQRFDdPv6N/GYjn8mMHuEtiWqCZM+Au0pTFsV7TehQjRd3UX7wWNbSdPkawJdTt1ZFkq/IM1t69HWC'
    'UZly2Jo1BcK1Rvqd9OL5DLlZLiaa3wQlM6bdYfYlFnY2TdbqONFUV6HvmGxV01wC/6ZaEIJsPJA/rjdiYDEmMZ3vPTpCVt35Xic9'
    'jXJ0NZb9V0rQxnGom9XqVc878mul4zC9g3e2tjruqF8sIHrPhW+fy8fEkJIOirReEX2DjQV2HaVhucBHoOe+urijWiVSoQUf5Zu8'
    'k6W0LLB+iR/BR7XzHxSh8U76FE0iCEvroQNR1Jn7qGqN2gHdqXnjRQqFxvIfPsrpmI31Lqpj9vYaidL8j0db+Z46Wh6yAbJOXq+l'
    'F42BG6C8s4nQWweshyquEfembjTmcsd3URKhHQuDmxMW1hxqXCZ4edRHleBhaPiGBfU+HpyWKrABDlUYFPyny4IqoFBZKZcpVh5K'
    'zAXTtzi3HrBT8icMGBkRcSvUp/YWNIPa8qPyLcG+jwrg6ZfOPm6Kblr+4ABXvhP5QU2Epam8ECw4MA0hQU8/Lxj0TF/hFHRvlfd3'
    'DrzG43VBC547JSvkNSzH1J8A0eNimfTXOrujLCLUebA3neUq/kDv5zUmcFbCXI5KoWHUJ8qsQremvi/yWzoV2aPAImKI3eMC8Vpq'
    'PJKjlAOcK6KY6xx+JurPhBoG+JtjXunxg2J+16N4nSv77CXObyoB0rPBCYEe7/1I+nGuwX2IIaTrhCLVYhcQ6Mja0XGR59eRRd4d'
    'NmZ11JdJ6vwdXD0ynY2KpohnMscMmXyvl58Qh1mRgxZoWjZvkLT1hk8r1ffqmai634rnDHu6XC7L6Y4y97YJoMctdLVpc+TsjE+C'
    'NFFFS87qeda7bKDPw9QLGTHGR9zw8kqV74Bq4DMeun38iHlsIXZ4AuvLuLyoHOctd5n6p3TxMWxA+GyNEg5U1ZVJlFhB9zo+crxO'
    'i0Ym871sP2y0l6CB259MwwvmqDkhhmHMjuzYI5X7+Ww3uH9HvG/kqGTDC5udUXEhA6E/jtFUg8YJWz/AjsIf0jCkI/dqaJ4w/n3f'
    '9di2My4jGW9dSbxaOxP3dCWfHHl+SVnf5rbthlYJwkvwcvV+9fLDs29+37u7pTduPDO9nqstNPJZmGSqYVOVjpt7Rddvpzsso/uI'
    'tduO9ATrNmQo+SB1JuMZMtz4v7vnWHbjgtheSVT5uhS9GhXaH6ylQ9/X3Qf0tgyJ0WBTFvJKakNd5li1D2ZedCHS+VXsiUbukHnN'
    'FsmtAg023TdlVkLysyp24ThuaGT1M+BvJL42i4bbKO04s5ZpS8L6RGKLRPaDRLM91FiWVa8pLTfc2BXmvZjs39yyGmra0r9Ftdqo'
    'US0gWMt3g7OCCtx9Pgui5mrWAVyAcEXyUv6U7VAh0c2M14ryP7wxusyx15GLRrZ+ubBkAfJW6CFvnU6vhXUQ8VuZB9kTqMAW+Pb3'
    'Xzpv/HBlTrx8MllLu3K0uobpCMYYqSZf3VIoS/gQzAupgs0DzS1Q/PiV4C99K7vi38uqEGlf7uz72YN/J6IuxvZNvjwbTEUs0z/y'
    'd913zAqgGfvuZ59qkgDLwLcpv51gRKfqWKMRpgBH69uyGmNREBv8LRK29Vawqq2Fu3PpxlXPY0azsYPjQclN/pwKP/drqDTOk/K0'
    'aq7ErTqRllzVg/qJPk4O566/WHNqHLl1vD4mXwqJkLukJll52sz38C0/eDCMrqeUIQ4rj1PReqny3D2Bew30GQSmIJ9eP4bKzWF5'
    's5c80RXYbbBu4OARaTAq8onpgUGFo7PGb/9QXHWxEsUkCRV38Ss6eid48ylcCtqs2f3snIAo0ueQqYTVtBqvTfjHu9T87SlyLR/D'
    'wvlgNQ3R4LxUpOqa9SOyFN5kpG1+kFpnG+97cW7C5QhZQDv+bjk3Fiw/6qSaZHJS2IDIF0Mer6mNc5UNnVVR8ewbC6CJejiBu15L'
    'Z6pq5dj472A8GxXvXpwopQKucaE+x7LoMvLNBzK8B70onc8d1kE1uy/orX2QAM3mTvpN4VFFA7mlzZbRykKHDCYao+JnIGY1+5T3'
    'V3Pay0UntZ5hzGO6/sp/HrFyZVed+Tcb37/f0zQxcYCrE8Ax3VEwr27IgRDu0Viu5ORXrMfWIF+8ND8BwJcAuCZuBOoFV7GtC/rh'
    'uGn/qsHUZ1Fsg/qyetrBn4mF2gVDOoLlNt8TqDC+YMJu6Wz88Lu5aZqijaDRhalyKN64ZGwfZ426+86eH/Fh6ommcpPUOZXZO7nq'
    'dgw9zIkQsnyXSNoMegebEn/0ma6IoH3cbsHl1DGBdDPMTsvYPMMt00IR6DcQOjajuser4S9rd0AcNVstFZHuRhwJ08qn1IL6+jb6'
    'wAqw/lEcDFtiogLOJEih9BvRn048LHnZ76kzvt77DyEj6vNH4flm9rAXefnQS5rTmM/okGWp6iKbnhzfOFYYOq/G0XRnktIi/kko'
    'SjRyEhfrNKjKpicrWv07CygA6BO6bMmE17Fljn35XZgwnKqYQwxHyvNAel8V4A+lo/1w6qIjjOzn78Ju5B2847mwOAXMCq3G2kNo'
    '5+Qz2dfVPD8u4jPoEldEqYTurDh79tbdbFKHv+RsI9XuSTs1YyhnFNUb9DmNvMSI1Q1+Bbm2PUNmHhXAFU+VX6YU8jpBeIDmANWF'
    '4tRbFPlJ08XhmDvvhksv9mdQfBLevDWvpOPealeFucbtrXcRyVislZ+v+UgcR1Nt35hyQntW5yOjp1FMYb0+W8ZQJYypTSajHxiP'
    'RmX8UtdxpX/HccNyfrzGcH78a/VXwakD+9ezv792YtouwMbJcm2BI460+bHyWaN5qfvHtdGpvJayPPF5eJCAmJOG1LDQJ8ypaZhl'
    'XalEqJBrBI+5wwFDZLtab/FRWS4G8V0xHhU3bDgUWSs8ZlmTYuy7z6LNcfOkUjUzKv7WbRr7ELEeOvzUN5itzR2WCAGv3GHwKWrb'
    'Y2cL4FYr59EooxlNZWc5Cv3osSeiRi/tUtnuhUyRsYBwXRNpnqhAkjuvUIU3fc9bbCf7hP43+ANhTO/bHfHWuvIeq6ixwjjpyFk/'
    'kaH2Gzy8Exi0mzpetckl94PDALklpkfik6YCQlN1+K/D8XCoUDA2OwHU/OXsZ8pXBEPX4aPlYu/u+8NHd9/Lk2uzHtuPQ3hByXi6'
    'WC/0uILJUT44lA2Ujwy47FWx7K524bGpdc6KdQsnX+89WsKaKP2QvgEpusN27BkbJzMEMB3kDVsa/JmWRuaYuJ8sCp4CdSgoGlEh'
    '8FNbC0byw+SgTRVudb1Pkg0I8iC8wQicI5MxOMtFgO7FTpk5mDAvK+BnQ8ffD7aozAKC8hETMBLsbRyr7hx3GEzePhd5wnuY+0Gb'
    'hlB3RsOXfLlwaoXAPvJIem1Dwr21c6VjY0o9P7pc9BT5lDGCUdUptilRAjuxdpBIvgbNngiA26skPQbvvYz39ZrDmYqvrYKrdLdN'
    'bF0htMISHKy7i904abk8JCxcl2ZylGzgYR87PzjPGA8DcZndZICeOb9EqeA4dUk7TpwYZ+p24hSNp6UPLFSwS7tUoy0jtVaww48R'
    'c3IS4fFQiSUbCrFwp8hS3ySbC7pbcvX3uaRANTTnOV0rk/UhOi3M3Ja8SAxJtaqfHDGHU0ST0ZK66jg7na/szNne81PZk8BHhDqv'
    '3qklyCgnxS3+gRyAoSetLsxztRcEJd9uNH/AY63cGaYpRXFhxw7TxMBEekG6aem+m4vrVfMh3aRAU3v2tchqforizL6WxLxKtbZh'
    'O990VCmgnVE+Q+eQ1uKEZpl41vBsv6Wf+3hjy31ME5/8tCEf99TmF5+y48idsnX0wj7qXmtxEVUZeQzNPCmH+w2dkdJpme/YOzXs'
    'JectSqQJbp0ZXee5nXa9ZuorFK3TJDysa59UU5Rupnd6F8sJOyqOy2nR2FEK8FVazPR+Q7AuJxoV3iJO794wZ1iM9ZsjXs/92iyl'
    '5yTtUI12pt2JmqJkuE4GxURIdUeEIu6FwA3eON5UqE+i3rUMVq9sVeY0W0vE3Rb9gjFodtslTr5+dk/L6KY/LfuRJb7pIfuRYy6a'
    'IdaKEB6h6zelMRohHBRTiPr1ziR/LhblJlOHZxRdPDPBQ7frvaQokiGS2UIYoUqAv/q8GPXN3Ry+7GCsFQx+URmAmBC2C80yjv16'
    'WS5G1DioQZi+jv45xLiqgLhyXPTWhRn3s2Xd9ZfhxOt8fz18SQiKWuNz0ow1cuCM8Zvg6qeAsp0alE4b6FEsuPVD2ExcrU8lnS97'
    'GrgUGogOihGl8GGtmna0211Nz2niBIGZNq0biVcKRifby8+RyTYIoaKhs6CHcI8BRthcr2xvde1FO6YZoOVX7meGbDMbnEsGswJl'
    'LVtfj44mPR31MSXuu4ZzxgiEgQWMf6HB1t2eoU+kQuba2YGub0VLI1Mg9m4cQ5x3+n0tcWEDF2V9XS1Jtk2EKUe0+B0vFxNYEthx'
    'gFrLj8gamHpYh9QdzdTa71vnL+2866dmG6iRxkZ27xZjRxIqUP99J4UY2PrhTXWvu7m5+eHNPfz/Dz/++GNPHjkPo/jbJJyq53OR'
    'N8dDerchlW4ofh17ClPaaPyWeQKgq1cysKJ6zQnj/cLiwPJyMf4zaNbk5YXTMiQzhDXj8WukQW+f/Bilc7e1KtPVVLdcv8QEqbkf'
    '6ZiCP29o4nxlE97hvP172QH5xK2/Uy79OdbMX+mF3FZ3QF/yZXWnewvp7oopjnedfXu2cggh+tzqk00SIRAibTsBvUYQi9Q1ExoY'
    'xQUpY0X/jsZ1268qs2wQUzJEAaKR+lEL9uqK4PDlWNhjCA5MFPoZXV0hSpTn6JoCu/DVdwaVdCpUrbxY2GW7ds5rR/Cgc8RsTPjn'
    'ojMMF+H52lXAPn+fHdFWw3xO450opdOF/EDE7IJmxOz64Hz4a1bmXeempgm5fV681gQhnTW0B9b/OmmJNIDQhd7UWHJMOuXFciTl'
    'KAdB5TFbNpq/0zbvN+goyZDEXiAxvWmUbr/ebriU06SJ4erQaORu++XRc7FQYD2F7QnR1PjudnTGIQzIBxAsQWyK5ZdgEV6LgOUe'
    'g/KclAjYxIWojy/lL5tdB90dJyuKolC8CEC6smIsq7p7KQtZXg5wzLr5ALEXchp+ZMLgGE69X4dTXz/fc8sd6+e7bck8bBxTuaiC'
    'Dd2fjOfMU/SFcGD7mpEMYzkYBo+UE+b9WhPC5JGt8XXdyXJFFFUDoKzWF7DA+G83TjfhGlKIvpqylw+bUSoRm9W/oRECH3M86yd8'
    'tMhPRUpbuDnHtJTzb0W4yU9zlTdu+L6cN89HbWXAEr8WcaWSjfCvXZg7bSuz275T2kYTAT6U1c1+gPu2s6TEf7I5lz//dCNIKboq'
    'DdQAQeVJ4kEYfrub2kF1LX6VT2Hy6VqnwtbBsMOr9rZlAnud4HVV2fSiWtKreUm5OKjyLDGTQX0NXCAH9QTE+IIdHkYtRVgD53i6'
    '0ATD1c8X8IHdlXmRvkI4A7dwwhgO1cczsGWqkAfvIMOrrd+FPw0+alNRf/o700qHDXpkGZyWRxPkCu70bmdB5thlM6oRDjje2b/J'
    'fgelmdf2d6Ez4+NetqXvdpm4LI2mzxfjfJMZ5eT0HN59j/qugSNNU438yfEexo7yZ1Tal5auEEcrHQEV2otiNvRJ0+BK+xNlqHct'
    'IauUNUt6/f/EYTzSUeEy+EkG8VMYxCNVdMkmtSaZnbHO1JdwSPFj+Zd/qo0Ft/8zRdOz5eyY/r8lq5smbyvI3PukbTIDXZfee81X'
    '1O+kX/ns4u2fNdKwhm9203SusYnWGTz7Zp21XXFtIun1R3+fSOabO+wuiDRu2WUHtCDiluyA/mJR3AVXDhbONDPgNax/HFRbUvAZ'
    '+JzPlkTv+njGg45ff1v2bu2yr6QlR65XC0MjTG1aObmYwnRQTDWFGMHeoEwT4rna77iJSnorKLwaGrjDom17aXEIwunrgKSdO3e6'
    's/2b/PJqTnmB96277P6KDaZ7igO3XTUaV/gFJcgd66BS+19dK/jOW27VICeGzarcNCSPWTmjv4QBAqVFen9L1+IB39S3+GyHptUP'
    'QS/BzyeWWD7Kdcm4UtyERKmLdpph+vurUNMPBpn4tCwq8xO9Ki8A+KUIlYO/mW74+2k1bYxVYU2OyZ+/epp301D49+QR2hMKs0PP'
    'pqfNjML+zeqUwo5pTPMKr8wq3OBZqjgtqupPcXKSvOleJaRr+oVwwAl6MnUSDHJYlpZvWmjLrmrqaSxgLkqHRjqIsiK++vF7dE0T'
    'Zm4amO6OLhE/7ewaxmWAyb8vVDefvJIFlSGAi38mdKxrtVn4x2UvTidDbMiBduWx1HE/68zfdRKYCr8Qmsa002uTtUo6J9aVo+sk'
    'Lhh0IN+8jRTUbX2imYtYWl3hO6bzLsGZv+fbTfk8MKEPf7cN8ujf3su2B/+u1wtjCo1fzL2vw3vz7kB/2kdlPtv4D6Xp1SUvIL9c'
    'zHvOyonVSZakSpekH6e2ahs/k1vVUUM4jpVrkPZ2ZbHQVezxvzNYqobsEPvYbFtyuV4pfRJSRg8pUjdmbmSoIyERhFe6mIxAAKeO'
    'ADqX91n+dixyV5Hllzk9dcbLwUc3y6DOXJGKjRANq/3I6vQlSMMqqwUm6AZp9e/UigI5mGnxTNYJUKMitgg7Pld5pXgnpGVUKQU5'
    'PivHx0U7Cfnq2fPXr1oICGuNsT5lS341ZgTvGZzK3xtcjJbrtfD6zuYFteMdfrQbffOapeTDBM0e8sZ+Nj4GLX2nmCnZV9gFPqEN'
    'FHr63qWItmKvfAkC7a8+Uxxx37XVeUAV4XZtY14rOY96Wmcp34cZaZ8Hz8hFM8FsgCkDGswy/nz5ilvJNPuv0RHS+QTaxn/oc2rU'
    '00GfldMCeugdQyP24OszMAQwpBwt8sUV4tXyhWY+rqWNfh1nSYaTXZVka67qVUFZOIJSfT65qLRV9TMGAwJ8EOjsRrRmA9LdskaP'
    'wEpL1cwUAA7NMor11RzedQno72eWWAqf5JDvkZJhEzntFYfPNPjyv4vp0SwfT6Kcy5gMn1gZP1xOZdd1lz+ZH1fmUPlNHvz+fa3Z'
    'qz/+PpvLHMzlGro/XY6nhTWyFAkZF9gcm8Yq3h+gNXD981jzZG/5kkA2fwEq0dzM0/Fbr4vayebRGRWaBhDSFM0rJBQRuRq5QuQ6'
    'XApNn40VCfXgt9vwc2ReJ8Im8vd0PLtYKoziw0/lt1DcBX/9O/kxyq/496eDT34jPy+L4py/HzzEl7Lvz/jz2QyZAJeymzpXsp06'
    'w6Fzb0O2xqomTRyAa+hngGAipiM7GDuRIUsjyqTudz6GF5mW8ffJpCwX3beRz9/Mu0jZKDG3P11oNBSO/+Hd97PrTP6RgtfyH3Nl'
    '7ZDadDrXmNhDl/rmbbb1mP1w+fmUobv0gUPuTHkxcAYGfGJ5EeBQTiPmnB6gmv+iQ2QYubUQ3BUHnLr9RdVYvLK0nKDjeDHArrv+'
    'YD+4+/Arn8/ltMrfh94XgxuZzrDnVLQ7p1R9LiSGz3fr6Hi88/vZaYFcw+fjEV1A+pkmGYSr+uz884vFWwgc+PtrKJmq4M1YvT19'
    'rT5fnUCdDdXj2AKdcOl1p2OZuWXR/Y+vXjzXNMv6p6ZuRWScDhcgJ8Vlj5mE04NYYeuQ4hg5ggXwYi7VIjW7yCwuZuHLBbH8ogQU'
    'XC8aAkX0O4VbJYjKDCQr+3NZkkhCnMoXeseKTD+eBRIqzU0sq73cSoPEcXlxTk6yOhZaZ8S5T4Xg0VH5Du41l/FOPhqAwcYx/O2n'
    'CM07S1+e2UtmlauFjB0N3slbVLCVPZSDzv/2GT1/NLjiqzN7xf9ayIVfn8NH8neGyf2sfAdkq3c4F1f45xL/nF1vMLy6WMAMPReh'
    '8CWU3I833n0zHv1J/pdNi2K5kVHXqNvj8Qb0ZwDG0nm4frQlbexxT0ZXV7xF1BltPGMeh/dZ92/cfojBJBIi67M9Xuke77sW40ys'
    '9qgFzA7cwleyNbq3SHdaz8EYK/Pkp946LZlQHew5Lt7oUnrFBx0Df8TfN6VacMU0iCbCWvvqxavXHqYwueN0H/gmhRZdVJ1VHhSu'
    '2O8X41GNgzt8NBq/zcgEPd5AmU16rm7s/SlmCaBf0FNTyfkqRnpsXikX8YWdJ6FeWffR0V7KmG7KAl+8e7R1tAeWofl6mh8THFyO'
    'Lgr1BogleDZTSuuEBGE9IFNY5Co4EGTcgBiifsFUF+Out1oHj7ZkWLpl6x7+N8yZG7LcJrxMvhwzblNZJDcJv/z1nzsei0s/6Nl1'
    'oZsuYmn9sinMYT4fdztb8u+WvXFmbj1Y3WLhIXpv6OmWS1ou7VL4M48dqWEwLaoqP1WmhNoNw6tWXDnpKuewtoCW0jRmBjEFUX1t'
    '85kOO4pUkgNTuCPYOEQav+tG+KWynBSTZZy1Ui71xKJ4Wh07LP5l8N47GNy7v//D3ffX3d6HgzfDN2+G9OR78+buv+3EuWk8/m9X'
    'cbshVFcBwMsZZqtjvu+1IYjbJ1YU//HdwPZ7WZw+fTfvsqNdVgQ7UOd0DL/uqQYIgaiCtgpZ5Z+HMUHTzGAmZ1OGEsnwuFjMZeM4'
    '3HGXnssID7ok/cQ7wy6wXdpRfPI4sd1sLDJ7y/ANvAAubIZu3/Ro83Aqm8K4aQrE7TVT5Fg+2NhYcQhkMYXVONuzDInAIXkkf374'
    'QFtcTucybWy869MtuuCR6xi+5BGyF9rkdTrNDJf+Gt42R87fGJpGDCvDAWv1LMXcigjM3o7Xpqt1yonC8SejCUmWHyvHb/kypfZe'
    '5Fta3ed2zDqKTyFNP8qiFtMKkxMUH62AMxoRnBRV9OeWS0h1oQYJly6q7QD56GfzoWVfPd7/Z2U5KfKZX3xnsHdyjRrZgad6EvRt'
    'LhW6Y3YHlAKv38zwN9l1/RMTcH3Y3GUOVQU9sxwAPO5SY1C4LHvNBKt+md5nJ8IrHJcLkZm1mjh/gXUobTip2S3LdZr9IJ4NU7tf'
    'vSq5x/ycl4g8c9pn2ipkwB12DsEbwkFSM5kPXC+oLyg+L6cw5ginaM/7IS9Cn1qCGTwO3opkRjiJCr5fGuWyE1WLzylKyC7P3d88'
    'oVyoSnrXjUtzjlhW/5LTp0PSQrVk2+mqh/QTN1xSugJa3CbCZCD39BpEg/Kc0S3Ic5rw1N3BlUh0U16Pv/z1/737fu0ev/7lr//f'
    'oc3N4Y3VHkYxryIEYHuHbS0M2wkiaGubG1S0NjK4Xhlt1a3tqeuOZ8JMtCiWuTsaU2ibXBSmf4ChIshpVORV9r//V2bRlnjPZMrX'
    'lqnRP2iOimeNilepGHX4B9ceLr+ooorBhCeF+eCazHl435w9k7b5EXQZtul61wnnlTKZmGfUCRGYVWLCv82VEDqwYpPjNzJhlIvH'
    'G2q02gD/wlvk8cb2RkbbHWpxgL5aZ0++4ilyj6nQcS+B+Gsx+HGnKGtA5IkEeAS8gou04iv7/KiaC2tqFR3lo1ORnV6AvRLmTEQn'
    'eblnw3ENWz47+wQyQT6x8eiPlSN6BSWo7A7V0aHDqlvV35vg6hjsqy20jRTxP34KapOANlBnYJQ8QdLtnM5I+jV2tkNTxt+3LuzW'
    'R8fQa3x39z1P3H66jey8pd3Fw1pfD9Op57NIOgiJ7u7EB7qn5GBwMdMMtoe1NcNbCBwbck5VbnpeXH4uD8OSQH0qa/E8SCV+WQ5X'
    'eappo5p2qIVwrpLVnhsSBGmknHpSSUztWkpJUukkJUcxVzcRJEBlNq+K5cCJDhUlNOiDIQVKY3TfZvpQ6dP4GHqBPgQ7KopLmsNh'
    'OYI8aMpoSogU6Vbpo7sQTkxS6CtYdc91vxdfRS1irk6sg3YPSU+tum4b3+XfxSzymPheXa8Xdp1TV8XADR0mVKH9uMruyJIjgL1v'
    '+8yIAax9m1ra04SYHCB8VuUA9TgYVw3S8C4mCEaPIpj7eOJqYliqJzja+zpdkB0u2d33nBPA0idDxhWzkdHkKeOfFO82hXEZVzvY'
    'Ext7cOJwtFHPphu4O09PRqMvayOxE5XJK+uD8M0prWt2YU/3fjGioJJYPmBUBt+HqasujmxYtU1NQdmMHcHYSZ9LaCoxeNVTDtzc'
    'hlyJ5fnr8qXKAd4sfWeEdL6YLykjgty026GqxaUEcNpJBIO7rLmWTmqQ8VpxOmj2Jr/afzPr/sn0I0i1O15qFhte9AjqGPQSKRgD'
    'el3ChBVEiqij3SRX6KTMRzYdUMKp6WwpX8ONOGX2IOjWFArFu3w6FzZXJ133msEpPJm5t27EOyazsd+eBYLXJLXvRNVXEfgYPmjI'
    'v6jiUk3zh/HBl5ViE69PP87m9Y1oAi6IlyeC1mL3xtmJ3TQWLRoedIUcCt3/2Dq0ffGkLoxdXFA4wn/Z5RaVkM1crN3RhKi18es2'
    'NhclVNZ3GBDvDQ0maPPbuh4+iQWyxUD2FwKRNX910GotdlMNkIaX37LrNYp969gK5ZJaYxYOIjZq2IkAkfFAAxWa/t7RmmlBv2A7'
    '1pZ39bKmRTDkEDEodVisj9Cbs3ajiNF6bz+OWIdOJNQWl26D9FIJZc2Y0d1oxCjdS08D7RxuILrP6CVy4zKsjI/89V2yOJJ6ECPj'
    'SfzDbHX00E0DsvCRFVfa7XfYdO3uiu7leJNNe+nxSxS9W8ln8Q6bRrsLRbTTEW+6YuP4OxLTtaZhGbVr1VZcnSUCZ4hQNYsGDqc5'
    'KVfSiTn45LUXk60cO16EfRwXwi0Wl2LGieg9bqf4Pe+F1xfI1J1PXEGEwH1tvvEN99/EHZtAlMWEWXHuuEzNMAbxc/cqdgqkslpv'
    'p3o/X2taOxY7+qqYzG/sKEcEq26zo7LifNN1hl+DWECaNkiWFGooO/JRL67SNnbb6G/Sqt9ZW2C3wRqHiTnCejccJcMSb21lvy+Z'
    'ag9WWd2ssUpa2Hb6m4D1V9u7jHxHHtJhVtXaCo2zUPaqzgFFrhOV3MpfFwyp9c5NijYB3rihiDp8BQbO6oGpg0LSqDxWCRcECFwB'
    '0Fn2I+XtoKvMy4efqnLWu7s1JkQASsunbElVTvuHu3EfvpicxjPuTYa+AHojJW7OwR5uhEzurOmYORNmRV0ppTZNXOSzilp8txHa'
    'uhOML9HbcsZFNX1m8sLIv0c4Qge62lDP3C+z1dVFfY1Da5o0zbkmx2knj5y5tns0GI/0fIQJpM8H/4AjePL+i3F1TAReKTJyf8tJ'
    'Ujamk2bSjGks60gH4/sQvlafBA4RzlCR76PDFVs1LWEyExfD20IFtLIvze5dO/11C4ccH9q/xT7OWDNlmhMsD9t5jpeMDmhgJF0h'
    'IhhZbyOOulmIy0tzEGt1MfRRHzyXFeU5orQGWC3PtUKGO8nH4F/NcGnbJGKzgtNALS0Epqa07KBCOny+JE/WTKuqCgx6oZhKRkpf'
    'QAar5RFqzj5VsrgZIWIkkARIJiTL/W1BQ7SP/q15KahjDmNrLb2kBre5m8+dXfTm1TLnyTwgslTymz4LS/r28KJ0t4HuMo2G/siM'
    'ub+CT1zpJNFfC7GxFkljFfpEQJ9WrwrqvHq0o4Tf5reSii639NZQCactKn7LgF+MkgBqQ+tcdZr/Rv+QW0CCJOQsdEKRiFSNILSq'
    'oLeTyDHJVbKoYrMWpIKswc+7EGgpW5My+KwuZqyasQjIfXWn22Zude/2b7WArXAhtUyZ7GHZWSeKdL3EAXrxAn4p3+THYI8ZuBn8'
    'oEkV6HScdX/5z/+D2ihgTQAQS07fPB9lwpjAGbaKs8UIfzS5khrVRSrRRWqW+2aE8etFUXzPdyFIFeJ8n1FkX9KcOXj11Yvvf0RA'
    'Wd8OUn58XMwZTraTMXw0jjALd3R1vBjPl/3s48tyMRnJf0m3PiOomFy1UQtfPvv69dOXP758+h+ffv5abt7mqyeff/7029d9r4X3'
    'cblCzLu4IHWETJpGZGxhgHuWmMjDOZUyOX+AZmpWy0zfyNy8Lg6MPCBcYMn3nTnBLvZmRaZmlGIOZuUZ4+b96934i6g6fhf9rn8d'
    'F23Bdzu/YQjq0J6dH40cutt5ygEb2rAs03ndTeyX//w/OxFupXTKYKThtZp2o5rfrh9QhaIj1TwNGIh+ei67o/mOcFfSbfN//68M'
    '4R68bk/N66VE6BUkj/l4BqeXUNQ+li6OXJRW80MFiktd65f5aVXzlf+Yz7yWV9NA0dqqeNsiOXSZ2fPFkfB743y2A8+IJQ0SswsE'
    'asgfP/ZhVJe2txS/htGmo/EpvKMH5pF/peEMwqDM6YVKVBftu2tO9YKal1zR6Bf5eHaExJwLFGbKXVBqtbiAz9lVhjRTDFGM3ZvG'
    'LHxAa3eezsgcKlPW1a/As53mcKOVuWRKnkwuWyaaAMvZixzxXz/5PRzQuj98OHhTdff6w97H3YM38/dfX8s/z69/HMY/3mxtDu/1'
    'tk4vdp2HfX76eX58ViT++fTjPzHwEu/kGMFen1YvTrqzON/u/sBiCUxGOvDu6ktFrmUrdJKeWdFg7Et5V8tsZcWC/Pfo4Ie94b09'
    '58ATXmia2Jbn+dQe/1t3T7qEMA7cmVi/8P/hxYtDI9PZG9J2RB+x6cHDYXoT9QIIxjsaEbZ+OHgzknm972C63sVQyX7ojEvcyx5u'
    'b2/3woQcCwu6cIxSKBumSda8DkS+NI4YmAHcNDKraoXQHar7i8dmJ+Bx1jdtPxNJf44AVqoA7NOu5UyzomhmhvxgR/Ky6jnfbdu6'
    'Isgtrnx4rXQknyjI81iDZ3OeKPMCnxaTZaUpPwkayyqS/FCnn0sfakY+BOVCWw7kA33Nn5E/TKVZ0Lq9uldNDiF0k7Jo/RKa4cTO'
    'ql7TYc5t7Z7MhDV4sBxm+/sBELxH1WX32ydfP339+ql3pZsBqLBc9ELOd93H239D2+Gmk/FL+/UkFKbwneRUMzCFNnZy1OPhoKJS'
    'lhmdvHNfmrwtP6qkwGY2Fs7fjcYDNtZK9ACU/yDK/zRXhcKmATt6fuFcRZ3z7FG9TkTs4KNHfA98DwX4xii6RJHN7mfnvezf1D6U'
    'tq2xNYX+tb2Ipo4RHn+f/tDQZa35r/hRe3ldbSljLw/wieH52nZiJQZSEtEE+TIxm8foU0ZfI4JOWFH/G6IR8/8lCRtN0nT4Sla4'
    'Z9aVQ3i/4Oh/fPe9e3e9A9cjHkUjkDMN07d9HVz7fG0973hmQWkD3HPumjtsZRXodIve7WRbKPnTxXSumgB/p6acxDfmigGrnkOc'
    'NwdSF+9Pex9tm/55TphXe+rYkF6wgI4q8/H9yGUWGWQbYFo2aIiuIg6iSi/5gWIwaq5jve+JLaCq1u7FDPYB5jw+oYd/MYrvex27'
    'yYT6A6K7/vUMhoPkHZ+EAl+Pq/Q9HrjQPX3ylcW2DUOlQuGUkqWW3bHukVtorViyRQcb9THWBdibz3T24jq06E2q2uggUFoKPW10'
    'RfWvceUB6jPYcePORLfTz/RRrA1hhYPvsbu9oosuArcC/heIA06Mu/vpyRFzNLdlgRquvCYwwLd05JVL9UuJR7eGNs7oP9vG0Mfj'
    'GKeCORKIzQbjKTDvOhZDSu3uxYxC2KgT3Rrq3RquDdLen3v++XaUDgvvfk7AxT5WU6S7M+ksTWfvB6aFDKSGtx/5s3eavrAXGvlk'
    'NzTQ+kXcKP2b3ZcPXRyj/x4TFBf/OSr96W5bWfXuFl79zeaPW90hnLzZ9CWavqzVFXe6pTJPUH9OOpmW5NZKyG9cOloIfQRewV6P'
    '1P3tgD9EgBp6TtRe1/2YkcZC5C3LZhHtmhwJSgNzEb05it5E59yIkGvHYUw/eKh+XbpOLutpg0xlEbVLZN5QuXoVI/1Dw6lYBc7H'
    'XuuiML2AuNmHaTZDYHE3GsLzrivZ43GIdj4C7qsvFwXODXMRIrbaxEqcEe9bkzgmU/J9HF2cfvyf6PCXTbe25an38Aoi9w7BvZSt'
    'ud7ln/JoPDt/QUR7fQE33I/N9w3uaW1eae3uwycjqcw7IQuHDi9hqv/G8JAbS8VJH0flsr2Tr796+s3TVwfO9DocHHers3xUKDuM'
    'arRXqUvZ1HmtJuQpJUjfRgTpO78sfpjMBlRdJ/Vy+V3Veuu74omzajRBtauiWPy+7I7ji2KW7L2D8dDHNrqryUvDs8TnS2im2klH'
    'ybXp+Nx5tE135Zfbqbt887w777mdycr54DhK/mcsuLYAKQPg5bj8TOeUfrAb9cWFg2Vm3pAZHzUsHDEjac47VB7OnExGTxTXOtwR'
    'X4+RuoQzGt2rq7MJRDczHOvWftNiEVkLOOlQY5t5bVSJGdEYh+VHxWITzqNEo/eL4Lk0Ntc3T7d6u23VHUQlhvu3y0WuxsZfZ8hM'
    'd+INFo2VgLhu56fDWlVZsDasr9CRdS+7RjQ8pBdIedX7EFW5ft2besActbdvX6PX4jebtbaub9yHCVo+/E7G00Lkt67baOaMTj7V'
    'A6F4NS8SgLx1GJdqDm9haK/lrvzNds/3hdvqdphSkSfiKqerMQxP6mZ14264vwi7Xo3hNNAkMt3BAaNahkOIVMr6piLc16mi93JB'
    'QUO+A9HXzxraYQ2UGQe8cqe0ogmaqX+6QlAJaqAVfYAieEYFpNQJtbE+/7jSXB5D4VSy12cI4dXKzcG+TGI94YDc54YoaHsuVDDx'
    '4CwKAB1w5nYcscUTPyKUBA+EhigeDjImUIBm/XJWb5IabOazorLZVe0x0vRTyKVUzBVjOvwA5YlXMHxM5RxRmJBRnQqXEkmc3z/7'
    'wzOomN8cvDnoHvzwBnG9sw8fD+/3uvs7Bx9/GLpnw3u9ffnvcOvUqZfDzRxkm31qXBuyzZvq3puZ/BOEGIpRu21SGLnfJqIHeeI2'
    '6Sty3rlRVajJ79jXdWIPKAjgPjAOveucpzkAvZ9T1fDYgpP3vM75ixfffAtkjkW3pxAdsNRaVsvDR5b7jx9xehAswCx/yM4UsKhp'
    'QowNR0F9jbVK9dcPhi7GhD5h3zjQrxCZrHuZOMAzi+3TrRgdSmzFABD8knNJNET1HJtdWS3HWGq5KC/Rq0gddTU7hreE5gCZpaZT'
    'Gr6cdtXPnrcTaCCHX/teEkNqCXJk+cj6cAE9h4znceykZRB/cfSTnGcV1klYNabOV8wVmwy0tKv1Jm7MYlLIF8iHym9NOAR6tmOY'
    '1CxOZCNRjLVT79s/mEg7w3YeK9YVl2gD1ZnqkimuKUJax5GNHCJviYZr1dfke7hpsQi0i89G9+/vOmQZ+0g+IYQNYGHR0A5nA4ao'
    'fkTbnINVreupitJemvHiZSGnlcYHR5gv5nJPyKk5OHgxGSmU0VBlMZgPmMQJdH8J1BKhYbrfNLXu0aLIY+ifBSovgLH/sjipuuVk'
    '9JoWPNlkrzXzWX1PgNe3YjeSJJfwHd9YjTd/E6LM0uTrfpch/W89inzh7HIGZtB5I4QW/1fdgxDKlb8d9AJg3vBZd/+xfD4U6t3r'
    'GBrCGlUQFQ2mi5K9tCjUwOVOpmaQGwi7uwzCtzPctZjwoEToHByg6zLaXQcAxUDKQG1w86nx1zAUSg3gpMV3NK6krisacmncugIQ'
    'qzqmwoJLNRohI2Kczx+/efLyD69+1R324VcbVIE3SyNapflPPIRVyIjOi8/bgWX3u7yJluKMdjRNWSaSFGC8luUFA6a6l4ucxrqP'
    '1DGAgEqWZLHS7K5M4UhEWjUSXGiS9AoUeVKW57Eri8t2kaozNZhQVb+38Ggx1OV2X5bUi2SJvIKrvEiizTelRj5KC+YvtrCMiX0M'
    '91tPO67KKqCcwm9maS7gO9lUTXTEgvC/ZAtOka3WIU3g2tmJb0vzg4lTnjQMvdODT4a927XO9h6G9tb1RfY+uvJJzfBsPYozUqPh'
    'RPtQy7UVDPSW/uPzV6/2B34DUsEMBE2Z9K+8dwJlIw960GlSpcuJUSX/DfTb03FVYe+1vDJ9Vu15je6c0C4a9mWvERe1LvF5lLTh'
    'hNtHrivVpbpU1chtHl4BF0S/RFw1E7awlzsxl3miyVnk3SXgrW2Eav4NjkEyp9GU0nbfwTg2LxEPcQm/zZVFrMqOn751haWDHZ1M'
    '5xP72rNpQjdlKkE2I/8VIkgzwa0waC2nn7luPOaOTo2mt/CuxeuzbQRt/Pzm1BwrclmwXRg296NUG7vWj/j5r8qw0Z4k+dYJNlyn'
    'Fvv1xIyhY+7di6h3LkIAX+/Hu1mlCsuaopUz99uI3KHVuffYbdro4aPHtl29dfZa+XhLk5lrbCyOMRDcEjl54+Nsw2Vd7Wcbm9mG'
    'yYAbDwbyt7pJye1iD/fk2c8X4Fhz+lqjncgeijCf3ezePaTDunevn93TZFjy1+GxDESElL/8RZNW/eUvvMUfP/b7WAZ7CcOp66pi'
    '/U3KSmPlZY4GKRVLsjQenyXAnFQ4pkk2PXslL+NMm2C08GhcfR7Ung02C5YGKZSkvuz7PbAiNydeh8wAd5qZAdB2S2aCUZEErqoK'
    '1MXaMRjZfr252N7Ot2v5f6nyy3TrmG7XdEFBSTPvI7lfPzt7KP/7BLuir99xcYWERCkJ6iBNWn9bTgW+Ya4sLRMnL9y3ZzvuSVz1'
    'fFHcQL2lRKDfhty0LafQnoN0K3VaxEcu6T9JBRjU0sTpWLXAiXQcOULNzQx+5866aUTiNHPF9NntNN2spZ/NLSJhRt4zl7HPNimK'
    'YFOXLquibrEL+qhu/fDx+wf9h9eZYyGWuF0Oagk9OmcPO0OZS5T+pP/bG0t/wtJ2c+9lnbZCYf07Qwu3QQMHm/fuD+P6Iava/KAW'
    'hez/bkaXsWJEbwHt2oODQe/mL1/UvgsQURrKfAEn3nrMSbLKQOiqp48K/rFUs4l0yIwOIrWozAC4wrEhoL1b7ih7zWj8ogYtWqxh'
    'LLQVDQPNCHkbWuwTHdP5voVcJdxxbEPLhW3dsoEBJuxNn9EH6/e7lVP1gSmAqgSxy1Mm9cCOaQVJlC7NZ5qafGXyJLqVaFUyia/G'
    'RxPyJwp6CjOHy8urXXV4qpDtL2Y6X8zLrOsBxILlopTrCWgK6iACucafrMtS01PxuplpnA/m1wApkTwCYV0GFKzeu23a81aAfewz'
    'YbE9mD5/P4BfX2ahNbVs1J79TwEWUw/VZJqDkba5aC4tOG3a77POvc6O8G1byPEqwug9kTrv9/Dj7hZOqhxXdPWAPr3y9s2wZ+Wq'
    'IaRVfnBPf/f2e/YZ0ls+GA6R1U9r//FH+eZH1v3jj1HNQ2qis86hFjuUUocsdchCuMqtHEC0WeYvf5FCf2Ghv/yFpSpf5LEWefxY'
    'ijxmkcePWQT7VEtl1wfHZ0PFZakDV0MnIFxrH8Sb0NWYpfTKmzocRAqD3UXs139nWveNTFMfJ3fEopFxrUWQ0LxA609tJK7BFwAX'
    '3L4Kj/ZwJ2NKCV/Z+hOtxdoPtDc4NrrtTirySjpRtRZNMD3Qrj2UDj0Yxo25VCwigxeTpCk9s02534nsnV/++n/7exFqR3WXWJaK'
    'd60aiH4ShhmS6LhuspEu/22jKHzR9/6mnquuJ4w3BdLvy5qNJw9SEZ3+YI7hpSxXQJdXdeSIgcgr7aliufRC2LNeK/IsYk6j/J3B'
    'ClEPy3SO73WTxSqfd/M4ea46lS/lfAhlOoYfml8bs8zfTnmLvZYqb/UiVEfHdztskHDXD4GGfWUPAHL94OE2U6bI0rt0WDJ1ox11'
    'XumYI9tO9vLFi9c/fvns66+RDiKfFztqoug4XfDtVIot6v7YG6ppc1EbT+qQ3zAvBGf/592xE/TNcfUb6MoUodjWf8PA6zcOg38T'
    'D9zy1/g0LNVK4OXyVQY4lz2Chj1lVbQbuBe7ZmrJYZqWz0bjhUo4AEqFu3+lbrdoRDWHsOHJroaFsK8GQ8a64TyAVaW/fRexB4y/'
    'ORkv1YXVnxRlahQAoIAlEHftv/wTzTwbQHei3Hf+y1//ecMVPiqXy3JqCvh4BHTC1aqOrnSlRCaCGvvoYjyBYxVCcpPkWWpbii1F'
    'MsBoKfvYR8eJre+ofGcerJxiFuxE+nWUp5RSvruF+TwVxOB9855fxl5jiE7FM2fHxtZ2MasBVcbuGE0rudrGNMmXiLJRW408ezWG'
    'S97EW5+6ByL5DsnMMDQ9MWt1D4SyQrpbaImDSfjtSkzSIjGZ0bXBqShlG3CTAU50oH/B5MiMbtBGAdagbgTzDN6rQkR5Sxzql38H'
    'sdhaE90KaNyJt5ftEqxwBYHpl3/8b2Z4lk1sT/47WE7gaQE577/HiQCqK/AB1mcIOviSkALyFfy7olcuL53cVXwlRf5b4mGHwDiO'
    'j/a5/azLAdNBTwalJorI+qssJ2woag2Vn5bnV7NctH/1XP2cou+8FbUTo5G2udbNJnXfufEiwtJsmwa6s1RhQlfNyfPSyAu6QCVY'
    '5a7PeJ061/CBk1n3LoEmNt6XntL9ynVtcuQQM0l70D/YGq83Mm5/B5Y3GShpUsM/ciGEKEv9xhajg6MptEDnVpOu1oFEuYCo6Xs6'
    '1WMXkqBOi3wGYLqNpLspYORpad09LVEdB83+7h0cNBwKbelTt87r4TAASK5sRxg6a2iUzIoN5Avn9WF939j7l3+KwAFrsJhN+uNO'
    'ZJ1a1fbRpkGJkk5qtZrn1fsvXusQ7te/RGIz2YW61sACnE3kQlAVIn7w3q4tY7gxdpyuJLjlhCgLepJJ3RgRMQu1eq0Rg7fn8TzE'
    'qUzBUGDcLQkWZTcqSohhCo3dpYwcuOgbNyEuEYtE06RIFvcWBwVTYUlwidh0FirGvOjFND1evpNVUXCb325vZw8+mb/L7r7/8sXz'
    '15ZAhr5gLVn3jovxpMvvZetWFwsy2lq3RUQAiZ0/46hkq0TYtd/55HuxIQgrQCU3+I/upBfnYeVByZUl2eTs45pclDIrxaScnVa0'
    '7gfzpV3uLuUicqE5NiRC+p7sxL4GIhlq/OH9+kWd7OLr3Y+i5IeuxK2RwU7LNU5qp+UQGoxRsQ6cTt5GoGGnJUNEYmbeWMH7p6Xv'
    '+GnZhPJoZQkriFY1q0UxCcYJmTQmWkkX6/4ochQdsQr6kihshmt24nhTf027tIl6HFSLYZ1ftwZx31Pm6zkH0Kcvh3rueTi3G5bL'
    'eecmqDp+AZpJ3upn1hU2PcwtWmRE0Djx7U1adXhEJGFy+7JKpTc1dFV1EAMrFW6BBvK8OpAlzvjlnAcvufKWvIgST/HbDef2rsq/'
    'ykXXT0eIcVrh6bveXziZWreXSFh7zcyvgSq0fzLcjxkDi81pzR/b0v1fsz3KaE9+FNsNXL19J4evPzAuH1h95EZi3RUDyCNcgaOI'
    '75wk81GfiD5zu7kwsrasFc67MQqI2Y60YRPIPW9pmamxW0p0nHc/M8L1MlfkcfbWpt180uxFTBpqQDv1E6VueAmkdZgPyNoYcd+J'
    'hVlXH8ZaGAQ7lrEszHBJak2aAWmNOYL3zsEHOO7c5VxF/qMu9ow+W20Kmbp2RRU0Za8GlDZVDY2Fga5QvtxS/TJNlS/Tv6/qJdOx'
    'RrqP22s/Motw4yKXzrGSgw55ZBpjX+sxiI/hMiccISu8dlF0YXfFoR9OA9PuF984mTeL+PVbbe3pju47I9c1X3VnXRdKL9Sw2kG6'
    'WOQeoY1iyj9T3/WnfK9JZinhzL2MNcie1L3Wj4rj0nLr4YEHHyFmApBFEMmcZxuf2d8bHzEfWUVrl3ei63vfcRbmOJVxz7obPNs7'
    '0Nq/gHAzHG7UHAc6cL2DtV+OSzEZVT1qhdCQxXdW4Lzgc79c5sdn9EHbGigeBUcIt3qqg9m6ojYi910pQ19eZd25+YY4TJW+Oqgp'
    'aATa4dyqW5smNJ4Xs0ox3y7mLOxMbxW1TM+mOsdwRNZvgVENaHrDYtVg68Gfx3Mz9aAVsLglYeXyZeidrUBEm6Qe3ODFKLijwvMw'
    'KJnluGmyVYqSwXP+6LefHl2pL6T8iV38ncitvxNJPb8iz9bNl+VRV94hQJhYDYPjs3zxudAPOiH0nCP9VT6dvFpC7GMu78PO3fdm'
    '534bGbo7oH0bnc5G77pzGHnOc0r+YTzvtmurnfefQSFV+YnKvgFWUwVggxR3nuN9Quy9ODGADmSrjxy5e32fpQj+hHj7ZBl7eq92'
    'PF3nnl/zhpBjG/c48di/VShguB9crHMOA+F5CKRVrWUXA6ADd6sG2j4+vPse3yOXwPn9+y71Cj+F01jLp7s2iQcQ54cWxJCaG/WU'
    'IRKtWhz32cGGZg+6MXlrJrKtH0DRdsbT/LR4s9Wdz04//DQvTj+cjk8+XBZH894uKvntp/3uQb755+3Nf39/6/GbangfoKo141oj'
    'tZMZpN6pfenBsA2nDY1potj5Kea7Wa4x7W7mBsI5Ix3VqiWQPeRXYeW8u0rC9OMztwLWuKb7cG6b8pxJivQUXG/FpM1uSOkTp9Uf'
    '6y5dOiM+zViPXs16nB221bbr0swzwRyFcsrcXv/vtKdqEx9XwZ03V7ifoLLzkTxBbE+qkIt2EAGFz8rZOh311OunB5ECkd3Aqr7P'
    'BoPBxN3uiDfQ213FUNMryyErkC34WpZ/0vt1cAPxiei7NE3gKFz0gXBQVJ5wyHLC3/XIRiXPrnqeXzJonhbLFJHcDjrgsuAkQy8X'
    '/EG2Cn8gMS3dZ2RbEJmbLm8sMv4zSwh1eWV/4sokIrPPWT40g9fB+TDgXWNAeCC/Dxy6i5rFqIqC75X+dcfsXfrJwANjLZlnNaKC'
    'mlPgIKlL+hU4Nubv002orwYkJXoaLH8fSrMd0EuU3mXFekIO70A3mi+vh8ND7nGX+y+LLXqBZXYgPA8c/xmqYsnXpXNgDIY/f5Du'
    '0BW/242JGAjV8L6jW4FswXOit3U67iOYTzaljKsXgxxnLTPAsR/aOXSk2nPKIVQMjkzxwCOdPdSyOg8Rz2x7aszcZeYxFWKddabw'
    '1rszhUnpfPxx5lg62UJywFgQJ5F8wSGCJDVZm5yMY5wM9CjuQwyYxSO+Lp6J3lqqcY86Jx+v6JtyyuwYCnkKIf2CXlvlyH0nOIal'
    '3NkhTdzRCJQdwAQwB1Q0GBCQFYMBo1fdZjgRzeq+N2IEsiTdBcLaTLpfdKHLkgfdiZGDfR4PUgj3CNTq/bUvZwaJ90mokxaR9e/Z'
    'Tkg6ZkSVCVomHvJiz/syUEzHsPxE88xZVjcdceo8Wc7JQ3VEnNAF6LYBUxwcqnQgBG0n24im1xXGFG8cwgfvYCgDPFSuHJBNxlvW'
    's4UzcVgPt5413ekMb3Nz2rkaTEf+wuQgTAv2Zsa9wO0VnkS36Oz9J/1rDV2a8ZUFZCCCadZpRkEIT//ZRLhoyyPUAUzr+Jgqsi15'
    'V8Nn8KziUqOXNJ1oMxz14M2brZ17+xuP9j58/IOQIw2m2uz0bqeXQbrS7PojjXTLRyZ7AHaKEDxAyCxgCpa/ZW0WY9BO2uoPNBMF'
    'HXaPsuvhoI4YfjGTihop7Y8uToy1DhJGV2G6mfU9x4PPLk5OIG/3VNHEgFRZH4IJSAWDI77v9Y2IBAxHzdGKIj7i/iFZM2PM8N5h'
    'zL2FGzU68cnDLh0KKE5zq26/2/7t9m8+PfrNdg9Vbm56BSYTsQIX8QzsBjr2VJiIRXfjNUQz8+7ESnM0G97HBmEHtQahR/mtE+Lj'
    'GCRkv90GT8A8jeGzB791n2172R+pb1lQ/gRG3Ps0beQZcbLjGubx93ILwdaUdg0lHoYSOCNfM2C/Xs3D30W9j/jtRd5S+JNQI5RY'
    'RWNoLPTQF2KW05aeffqwpVHN0cTlgFXqiwK+gQhdHvEv7pnq4oh7S2uRidf/yj82wl6rm7n2A/2Xf+L+uhcP3Rquev87P6ZFfmm7'
    '03fGfMi1tftcjliuwcAQU2G4UlsBXdiiymyJHxMLCReeEbtwNHc4LSQ8B9KBYeD5YzzrUM/vVtajp1SjPKu5zJLmr46qBlEugFA/'
    'mI/nxWs5IxenZyyEJZkSH1ZIwyst1THKsinfysB6AzQTBbQpryLL9DhZJ/lLN9l9t5PaIQYtH/YUztY+CAWwn0jlJmfNMA0s6qTq'
    'KxpeXwNLAGeaq0blWN0hL/gD7PWW8tZbGkLSRzumwJLT6RRPgyhQVFb3CqKQGnCpkTHdjX6XYiT0WgJMXpdfLaeT7nQUk1JTfVlu'
    '8/jko8tVxGgT2jbcB/SkhR8tboWuCELKiR4i/GB7G1BMI3dtypvN7MG1vjmM/NXUauQYi4QjZtzq8IOGrL75gB8BcEEbPGGDyJRi'
    'Iv9+JPOLbK+++ic9JrAEm08baDE9KkYwWZ24vL0bTNV5SC6CnFlbh7QDZNQPfuhRfSD/lSc9150LHX9LSxe0izVq7e4/unOnZyMF'
    'Z4/Kz5bLeQW3Z7bxYZoLt1W6nz1trfMoz84WxYnU/XBj7+6DR1v5XqdZv3O4NnfrD+oiTQdp12evdEKWRWH8CWQGHIbW/qqD9qV3'
    '0FZH7u7+nTf3eoggfvN9L/LCxvNLPzvzB2xt/tC3ePf9/AEcP+cPrx+N2bj8QOPjtsbVKZsu2ToFFQde7cU8irpl0ylbC2nK+weW'
    '8L6G7rVMY2a2t7tvRjIg/um6PbbZwW42kKxjNXcMgZPFx+ZIuRvl6pzx5ExHUQuLN7N94/OkywqMx7+bDMjY4boZw4H7mXV6Ljo+'
    'p3Z+WcCwtny+9llsnxrDdOHdxyN5duuHw8NDC23BN726MehYY8OQtWMcbD8rekdhq14lJ6zHipQm2MP794ch6w7656+Nw0dC6aMp'
    'j9hnzDxeHvZ2a+7w117RNg3zAGwQ9tDrC7uIS/rttZyp+93BPaEVPU6Qbzt2bn/0OHtICnL2EPlASS6pCkMv5Blpx6OzT1pefsIe'
    'rpn27pvq3sHmvR+HPUgB8uNubRVClzqPzhZ7nfXV7a1bw58jUr527dJ6bOF+rq9aZIzce1Ptb/VTgeKHNwdy+u+/GR7c3xzuAyFC'
    'dYWu/WiZQ6yWTGHtrvq5tupR2VWLr1MBYIoPA/lffVJ1hHyNbu3sb1IASwYM7nYYTMnpUSiAmv84c+gjKglF4/7w4c0Hb5U1/EtQ'
    '+jdvem8+bPWCksN2y7E7oX5unJN8Drab7WnXwajf91rimgvuLZd21bzYMtNTTu9s366d0ralI3ez92iJvsp/FoDzkT8jRY68k4fH'
    'snTyR+QbggeLPTzVTw0MiO3j64V9jSoXSX0jV9+oWV/tASuV/7KXh/H8rt41XcYIfpCbABF/oBDrDtV4WUxvPfu3aIDLQEMOyr5/'
    'KEThVeO1VMV2PUJ3r6H/m06jGyGQPWm+12zfSGDQCJKZB6gPWzEmflTMkTKSWueTSSni6pRkMtxwS9UPINrKq4K2soe44FQ7uCPM'
    '2sihSZBKOleBKQEgYupxkL37T8LrKeWYPiS608MA6trJhkz70vnlf/wX1bL98j/+q7QbySVOMsEgDuIJAzM6VP3yfQ1Dvh/mKvaj'
    'cJeS04GmmeQuxhMc0K6aATg9rbrYJUHItRsoOxzYdKD75UTRgyed0CSuL4XSkv1OzM5rYGL9BFsBPN98QdtrP8leS8bnNsjBT8MB'
    '+wV1hXUw9E7XuV7Ql7PeH4iU2Scc+5Bipwy6+1O/Vr+QJusw/hMhOL/ZmghrJysotUCl9Qi/cYv9ZNDwzatM/x+ru48JQAXuZvWt'
    'EvPmmrUdSmVhjbKoFpecQ+uSqraiyfQH1nuRYNp/CqjMK6c3mhvUfJvJ8SQTHySjv15Dk5xagqoQR2HW0JfaHjY+zHidN9UH4cg+'
    '7H1oJUEfknuh17wY0IsVjJvpGOR9mJ/24jaumMWTtWVZUHhdZEfCHx2B3wGnt3fYawrnCR4tpOcvFzKFCLyDmtfHL1djZvreOC+u'
    'dtRbccPYc3qiA3A+xmI4CZV0lzXsrFpg5tYPm5ubb2ZdYFu/Gt7b772Z8cH+VojOCRblA/gMEGoxipA1Zbcm+MD2g/LgDwruZxbo'
    'GG0NfH55oublSH6oYZzJ3quzu7Kmm3U6786+bhw2y4VDnw7swVCXCcUCVFBEpQ82OsMP+MfxO73mcW4OyVuO3jbY8oM3l9mmiG87'
    '2KT13t45f1uPfrXHzFrjxZzQorwJ3U4N8rWBmnDT6LysyVut6GF6NSi/0Bnc6zgu6q00/pa6RkNp72ebD2JvFXNX2agjLW39sDG4'
    'txFXo9ndURmNFIROlBe7Prv5+5aWXJ91YKuHPqQDZHqeDviRblCrNAr67Q15xmqaefX++iOdZL1Sn667+gPqHf3LWYwKTSAERcFW'
    'r/tmUJoD1oc30tG8Ouu92bJJKDR5X+Su40DW2qrcejOYjry+J/7W8AGWkeTsZH86CCI6yKDWpAq19BjClcbERpF25fnr8qUtZiOS'
    'Lm5D7tBPt2kcuCN9Pxkvpt3D1yA26qoFZ8+77+MPrjPLfVSVCczpNIeKL6sm5eUg+xzZh7Jytn+YNG6Oji9V/9he8S9//efDaCqX'
    'JXG08QZrTO1w4Ku2yFalb43YyCtg3TuzsNbGQTnIU7bNgE9dmcK+jxIMlNCYqw4aTrTyc5//Sq2pr2HUxtGVa8CSdrldgFuDDR0U'
    '9Z4O5uW8mZaiGMab6ujq26DzX1vv2mrgZYu8pWAGF8VJ3yAxPSsoz+BBSivCdy+ffV7KyZkhll1euB5/zLlNjAej8cI4vnhY3uYG'
    '4qJ34FZNr6XDYvaxLlLVygzjX047Vw9WBmm7NjuUO5Jvw+rc8lssE7+NRrZiLeo6M1N5w22BdIZrcWW+sEoQnaMCLQjQwT+Ds4QW'
    'pNo/oZCxK5dLStwmtMVA5w6UrQbJ4MgjUMeHuiaeS9DeFGyfbKkPYqcWSr15wtWnI7HHaihW07RMdETs4zceCisMLtxO5gyDniWG'
    'J42jDtyFt/TkIRfrxYIxt4V57M5hWgf9OUUUAY21vhr6ogrXFbm3gOGFVTuwAx9/nHWdV8cHulAIT9Tt7u9sZsJZzvZ7gI6cql71'
    'TC0ltr6unYOzIXkCgMmbiTnwOfWoFBePzGCJ6yR3t3Ps6bX2NIYY/eGOgoxCBnRf/SqQ0SH/r7rXWeUgY4JRTbGlmMYBLNWXdm6p'
    'q4BqRuO3rhUtm4TzoLGG2xcMErKxrXgziFDeHwSDxbCp81IChplxruMsKYSOIE/0erCbG6QhU5gZQxdkRmeSRbuZ+zjrOEW4APT4'
    '2OHvniSrKE+ptlb/Lc0Ghr92M10khH89WcokHl0sC5kZPwT111IGy5fstqyNeeCtujyCakMZjIbHjjqh0CfYgCWV++p475TO0LkT'
    'wtEE/oTNEuviOhIQKWAtALbxXMRKBxdrbvPmzz0OPvUeVNZFfcbh5XMDqVTf7HGlHhRKdQi56Do6MJzIeHj6rG1YfJMM50MUouKS'
    'AfVhytrq0Tenlgjma7VlsHsxsnVD9PjY9MmNUDX/kVypQN51l2TWSdNUsiXwaPa3W33orpSDYS12aGL0cc8rMVmSP4RAmHky+km6'
    'N1viNHY7R4ScKuhsqaIu7Z3aXizZZqmmTeNmQI36fof1PY3sO5tzlc/Gy/GfLVt7nRggaGcKZFWpZp9OjkiC586jI3X+UEaORrLL'
    'PqNuK+JFd2q3RWXwN2eFMBZLxA7QbG2BDtWuOeomQR5xiMEgYuzVygz52LmF4e/x6MVJmqY15Jl8NnK+lg7ajNnE1Gd22+kUPWdK'
    'D1oNPVoVcYQaWiKOYq6B8BS2UARtGXODjJdMGR/JCZczxSAD/0zCP47AF6WFKgmG5l/Vz4tlN9Xp1pGjzqFWImSUljNWtdsGcZ4G'
    'aWEmiasqXW265GOmE5o25Sg5KDB1WItZLbBr6nMaWJWc4fvTwTuqrs+zf8Nx9rJ72ScPt7NNHfW97IEFgEnJK5aMlMnn2ZZ9hHQm'
    'Uvjhw22/IFNzWJRvamuT+jeL1P9/xMN5enAOpYH3cZ7pb4QI4I9IOeG2h/OUzKtqfDoD0sv7WrRbLbYtUdMEBCGRHvW8v3dkwL+9'
    '7vUiNHL3OKkm8ZLWWzi9gK3Mbrh/Z+YgLT+chsE7ZLpw8NngRxwGadOSd0YBgTUwufHoS8I5kKXY070JgcHCe/C47pvYEuzobpIP'
    'Hw+3IDe1KjoiCU0WmzRDeeG6a34aGcDOe+gmGdj+wGjoKCw4Kzzg64HSUh2sgVTcroVUbcfPf3RTaJunTeElTXq+A5p+zGj8sOe6'
    'ufKteRHD0zcsZbOkz4s1G2CrNrIBOiqBW1SL9KwoIphJUhtH1Ckx5Vt3oQ0ULYp4eY0o1IYuczMTgaI7uLff24GWsLfvfYXUg0Y2'
    'hCUsmE7DBKi1KWYumTZCpwmw4GVwrq5NeXCziEmrxvBB4nc7YBKNQvGPaSLWnUKv7yhPhXNGVwrrLRCKJhFiSnfQajMVBbyiaXyj'
    't7YGOGbTBM498uyOXMI17JDe3vJni2N4eOodvwPXfH3rne33je3nOOJ4JIzit8IUyXGPgvJE3KECaTEVevznAuSNMw2+h1h6QukY'
    'iTPSuPwKN5eLo93h5Xyt+J2V8RF9RZ6J+AAjqjdDtbVArCn3nSSJCXmH1vjheXS1KaN2SazaYdbogPuH8ajq1niJSX6FuGDz1VUg'
    'wvlC3aw1A4QqFqVQn0I8FIHoiyVkAsDJKTPXJGBuJxocj9TJ4AgNGPRsPCq+AnfTi7SLL+YFwkHvvo9ZFFMuKjDWxt33fpo1tvr6'
    'o1K47o/PpC7qiHmPGq6JhjgjLpkffTFeILIZL13eHkDK4dN5fopc6+dFxX0zL0xJi6xTOzJ+HTmczfsa82rTPvgIXz+dtIAjjBb5'
    'qYiDizpgB8TH10L6qpNisT+AvFPtR3pRTFIF0bgNIQIba02D5byJxHBCuTNtlEPbH8geCfhusbK3pWkrJxKqzEHweRxYwKC5z8vN'
    'eFbMupHKXuabBLVY0NNCF3rj8/JiMoL3ObcXA4U5wzvZBhxmFwshdVUla6KXK28CzY08UeHdAVRE69oCb0NQy+aUBMMBEkh5+AvO'
    'iiZ5OrGQF4gsO9nJ4LI4Oh8vXxaTHDHwVOYiyYzxpOpwfALGSGevCbLhPfJV7+uMBG22jX/9hLWE1zMOkgQ8zgGHkGr1OwYkvAFs'
    'lDODmsq6Gwj3xlEoFxv9bEM1RKMNOIejGwZVV1jy7wBXSIOo0CqER0r9X5QX8mJTc3Lnhlkhp6iicggsCYQ69So3/EIAR9EBWzGt'
    '9KpFnqJCcUPtqkSHP/PAhfyJ9NjlohNnOAPmsYFLjQBTLrJjPoktril+CNJFuWMxqRtgVibj9o2TxYkJb0AUaksDH4QhtM5uKkuL'
    'GxviTvd5V8OyegS3eK6prgbvevB5oZgTlbiKSlyxhF6sqVTg5k2RsyAiTIqTJcON3o6LS7YDIetexp/n1/N3h1iBeShyxSJXSRG7'
    '93ztbv/bjMPt1se07dup8IWbWcz9q5vykkdFqyh9gQIQp73x2WBaHzdyzsoK68aBFiLkfYnW2jHq9eQH6ZbyHxgYTa31X4VJE280'
    't6Gas+gyhTE4EioUmN//3jg218levv7Id+P/GPRSvEYOYORvA1+Ka+IW9EBIa0aV5Bxt9EW+rd6ett3UR5MV0GuT8zWoaoTFCJbi'
    'yflKQCpP8O5PzgMaknzuB1W7H4RPqYgcIszjMlfWDkTZZY9r3Bn0QRrMr0C2p/PKsDsZa0fMjoVsFWl1V++C8gLoscclygOUtDMq'
    '3nbYwIy4HxqRCobZGnQU/sm33/74x6cvXz178RwX6cPth78dPHgweCD//m77NzJ/KPDdt188ef30x+9eElWWgQ07W1uL/HJwOl6e'
    'XRxdVMXi2JSqssu3vv/msxzqyy21e20aL7cF1nlrJKu0JaQJOsD8SHjdJ/M5pSSbop24T33X3x0HgX+cz57pFPpHNqVwS+QTUGQd'
    '3bPnr14/+frrH1+9fvHyKfqedmhnVm7ax5slYgilWzXniEmZj56gl1FWqq9evHrtfDuiEagCJp+Pu50t+XeLrzq9mrWPJ8d9NXDL'
    'j5wetZkWUhIvDogKVzWQQPmFZl1dNn96GF1J8nDFgpsVNC/BWUcFck98IVtkUs4ZhYctRPvwWyjd63VHNX4plPFXVfhH615bvQiW'
    '07++kOno1l8Lwe6b2t9a//yskNPdC+T4Tn1KDaHiP8J/TB+NdgwXkmCnsuqzUcWIDQCkTpjihyn7YGaRrl+QhdJ3BKaQRYYoq3wU'
    'Fd/kYGTMthliexItBi5g8JUwTMI6Qj/2TASvrqzpj6+ePn3upMCujbNy3zFhh3RBpCAypQzoHi93FIWUOSWZNg/A1VeA1JBBATMI'
    'bOLmcjwVhs5rmazKfVc3NlJj/neyO/z45cWs5+b4s+WM0pzDPQQOSWdcbUrLHn8mHl1VG12/0YxaJuLTAIwr2xh6OeGBne8XGvXr'
    'qHF9gZ2GqYG4dYy98R0L2UXTzx7+ZnvbI/Yvn+HKE85gzQefbBefuOUpT1zyTkUgM9JriNAXc4KXMJXzdDy7WDKRLPMzX/vkum5O'
    'WmiQzc1mVRRQs0l7f3S7Ibet8N3rzxGIprYZLK/iOF0CYgpgUzuZo9vbDwcPPv3NJ8CozjYeZs/Lt3y1EXlGxgftbT/s1E6n7iMJ'
    'P/PR+0+ve28G8sebkf/vFpOUwJEteJ5Nww6770K0iy7+GUj3u/eh1OozmaDmPb+vWQip6ZVNVKCk6Y59Ej8wzqP8CpniL2RPU70/'
    'FWIjImOHEpX8viryRVIA8/MPciYAl/T6cyjgzdHp+qOQCHdSnprfiJLx+GnkvYGT4F+l1C6l66bpwJndyS5FeiQWmV1LfZ9wWF3R'
    'EBpqNEm2NcBvGC0uBL0sDLRMH/Gid0fU8tAOOAr9+tnspDQm1V2Ur5aoVXEnuXmjx5gGKG+w3TV7n6Fry37tnORjAEuliPb+aMYh'
    '+8uZiYOORiBgOTxCUxeGbC9lIwKyLE9PJ0W3c5ZXm9ot6cKdO2EsvRtvrGjccs/omaWszDtm9VX46685dJ16x3qrh+4iu/s+PHdf'
    'XgPviP0hTLPuAASWbfzRXWXuynerrLR8g8TPBzJ+fibcn3D+gfxFs5TeNJTO1zqZyCFfU+QIBeZrCgBFHWWIWryyFt6q7l5gDgOs'
    'u7n7dWR63JJbidrC3nJWDRprvnJbDKqL6TRf0CrZeUJC5DZDeZIZEtwXplu0vpyWaWfnIhhKFXKC5E3aEFi/aOfNDI7+C5G8wCni'
    'avZ1roaDdsiQFD++EZrhQIy12s9yRWS+mNmlFOV1wswKJyIyYfdIlg2r4u61pX9RvrOblswmTl4yiLXHZENYgJkmsGJymZyOrsxW'
    'jewJ84ujCVNg8T4kAADkC7epNQHwgOiOYCoajK40QBdaiiqgd6jZaGHt44SgoYeecGEFPrcfsVDzy1//ubPqY6Nv6IDX9bHCRCrK'
    'niwK5QQZwrC/si8uLcHGnzQtCLIWl7ykBxvesVZmPjCoQI7GqX7OcHrVh0TqDF49jvbhsqHaoTxtUAQYgtyVFPxbY5KgUBWrTqq8'
    'HR9PCpzoszXFzj69iS7MCVN+Ow+3UZMcAKa+496mGzRmUQrPPOJIFzGJ5odGohPxolZK9RTxZm8wpt6WrjFeq0ZUTCHPSZlahzvP'
    '3F0vRGPkziEzXJmt9az2ReEIVTtBK8z8r9jSLCLr5iqWw3fWi8dmxq6oyDz1JJY3mpPBbysoNcblRWVjszx50X4Nm8ztVbI5z4vL'
    'Aj4Hjg4EzQZANGCFZRoqzUkFuh1OBpXOjgWalZjxmaUJasAFCeEuFin7EUTvOEtuXerWk7p1rAKidy1dDPK3QgEQQCqndhE8cZNs'
    'qlqZAyAqYCaoSeX3uXnRq8FPVTnbXz7GhiObK5cBbJnSOWHbwGzNyk3iJoEH7bF4N+aYF35L7iWSftQ9nXJP6sxWCR/eU4VN7GpS'
    'prN8cuLFjx5m/eeLcQHfqFLInX2OXEjKXOZG+UjdQRgrNAMokuz78eaX42CioyluWhKR2JBxHbN6TjBmcvyD7MVscpXxekM/tcmY'
    'sG6oWqoqGwsdC1/TfHbhDAee56ExILUR+HJ1ptffELs1yZLrXBfSw4qnu83gN2MWW43rXkO1CJoJO8Z4FrMeiiAZPD7TjqK6DjkH'
    '3iNRClGGF+v4UE/YIxDbtZIvxhWybhcjw4iOmYZYvg7O4qumy+7E3YYR7BYXo8NWbwrx15GE4vuaiimacF0NESqmbHydI7VK1j0h'
    'jYD5zUhzTWszFgrDvdSQpfrUgpgxf3xMAFLkZwLIqKpxcl1o5rhN5JxoCjlvuIe1UgBINaSQWzKrO+n7eHvkN3GmirMa+vH7stGL'
    'W/KitTpG4wpEcBQbgmpFmpaiUEDmqKXEdf1UR7xrJDq+TVl1f4YoWaSduNEcWAeDpi7OXQ8+Z4y6VdCnnhznca42XrJUxnAiAYxN'
    'GTePLAxRaksg8FKGk8UMMR9p7DjQ7m55b6R6n83js4XQ1bIawNV//y3vkberrw9Fw0o9mfJ1bF7HF84HZ+r4Lx2xYmqulN8RZhda'
    'GKIDcJkw/8UtdI4d2JVq/Dw9Xj+aDgqbG4jrxA1Hym/bYiS3CdSwbi3WNaQW8iu4NLvvK73iRi5LVQHHLdq0fWC+yGapGa+FWL11'
    'qlkL5aPmV8mik1rmKbXBraxa1xC6VKeryUbTRldS1noOX2TyCWc36rcSU2ePvGmev7NPICvtuktxFRcFTMqrjnVIBwW/iZ4fWuwY'
    'sXtj26/9qKnYftNRvPuBStoNytRyV8SJC2V1/oSVd1GW4zSewjI0A2kNs3tamsQqV4beIkTod6meVb+P6Cun3L9pMC+1bDSVUkN4'
    'GC1JCuWoKI2/204gGgOY3reyo8dVobgpkW570UcwqosxMq1ljY1RytPZ6qwiI7uWp7w8J59hAXgu2i04SQGn/+11BxGqTAxfs2Fd'
    'f6Sqf5B6kU+xo7vBU8wT8chRzN8HUiwqxEu/6VD2fvWFs+q8hmtl37NMliVblSdsVfYDjEdQ/jUadWezK4XG6rsIzebk4lRBXC2I'
    'j9BHrMzUn1FF5oamek7qdYrB8cUCfrmvXWKoFcYVC20K9pXQaW/uanQ55p2dQdw00Y5fgjHLHQjmP91cjE/PoABdzICvUDJncHY5'
    'nsn4ncujc9ijTGcl3Cnr8hChGWWv4JTqC0XJY3sGcGEXeGSA4N3bplnGRjbnO1vvfU6XNHRayGzJBH4GqUeq+3wylkl9KXdYF+r9'
    '9xlHtZMxauZ75Jjr23jt2VcFh30daZi/X+RzuKAzuZ3OisVzTPN33QcP+1Ft2aYcEy2DfDchd117bZZqtq066wjqs1JphdcfGaSm'
    'bMAXR7phu/GU9RBuj8fdaG5k4Rlgc7HkobzhQ51kEIncRd1V6u7TD0++ZDzWTnbQ0cXoDLklm1rNRWERF0ljauA3DTjPeZ3jR4pd'
    'YVo3doREn2f5KTg1XrPOwkWSrAQ5ZddTAyF3ECOKytCEEkg+uXOn1Qib+AbUrfQWfHvGRLNeWxR8D+j67Z97S4960KtjeDJ0xqdd'
    'LN1+wQJYTYkRGw06ZhZ/9+qlW68i34/qqiJoCBSU3/NEV6oP3fcaqpqgsZ890yTMIBLko5g/3uzfLqJZPXVpHLdUD8pkQQtAnYAy'
    '0rES1Olhb92urHX1d2g28Ve2tmtU2sLSfVx/4OrrXNDYLZFp4Jrr7S6kdrO187teu0DR4hSjO9lzdwL6OvJ03oJLaFinTjTNt60h'
    'nfJOojhIObzAvI6d203dI9a5PNXnfeXtXqMKK6cwa6v1edlWpZ73Vn+E5KDLpw9Sn5yVDdc8uOT4lmAMWt17l8V88+hqE/8VUlRV'
    'EOrhEDBfIKvXsb8+LdsUywnVU9YUm7e0zChytyHsQa4I1ZyeFS7LKXV0ZBILJ+RIzef+FJQnJ5r6dQzUgIJVd95Ky9TDLhHfogxD'
    'Fd/nWtGExFwdxHK0cyKXSW6QAUsFbkalM3CJsvVw+BAHD0h45o+UaRHiSJCT8zFVhy5J1UlRWBzDeYH2c+UGmNnuIrhYKsF9/d3r'
    'lb5abv47keMxuwT/m/eobH+A3/RTKQiyY7V+8fTrH//w9E9wlK2+yY8JNvef/6cqSygmdlz7F2OHn3z46MhlFL4YI6P0UsF0XUk4'
    'plOphcKa2iRG63J6C/xwHJBlHrTEGnHcOR3AdCcjfUY3CTHxkdFsUjk8XYGTiwW9CqguB8hDCeBuZhgrKVhxEcjzC48mHBM1X5X6'
    'jdg6MdvVhEnRDBy7eJcDaSti2GRqXxVIzFrzDwndFGZrG+AMNho+243CAbh/NCnMqDvlFE1DrpjON7j6ZbFz5mMMtXgcHiC3AmPA'
    'smwhTRYhiMbVy7JcdmeskVM3a85YXEvQK7FPt3Y+j+OeqFK1rDa13n/4kN2Zxpuh58Yp5b49K5el3D3w5BxXkR8fuqm5Mr433TrP'
    'OMicezBF5Iw+wOKNYZSFoafS3BaGJdecuUfZJ73seRef04AoHUcyMp+TBy0fND5TyNRnGFKEsYMF3iY8TLzMigiIzn8NqsU+Orr/'
    'eb44kv0zGpfvZH6SrnKxjlYv1iNZq6TjR0nHpc2DG6qoDcKCtyyu00KxeruNOCofLNV5IlwZbCWghXYoXNQ7DpiSdsTNzBS7LiZh'
    'T799hTmRyt676LXO98VEcySWtSu501degSHZXcOpnu/RTu5vnct84q4Lo8c0/dh5N2YZNHhU9nmX6GlekreGqtA4gtZbCQgGphyT'
    'hsMVlV5EKlNqJ0hwWu+gcnZc1O6eARQ17NxpST2ZRqcIBYL/og4BleYTdZ05F7Eg7ZOjxcvxfGPv2dIiychXZQ+2zfBVhXZEKJXm'
    'Me7ZlcoTPsHY3fcXwt/9yz91etd6+ZnSB4dqQo7E81hadF9KOnna8pItyzn7d5hd95M1poGbzNXUUwXkDoDwL68/FqqMcPXW9X5K'
    'U16VJCs08Ue7lGePjvZ8vbiOnGg/FQkCaTmfQbvlZrGyhNpq2DtCqMgop8lWZk0BGtN1p6+sNBEHCrEV2bGRytwye1b5lZuL8TEX'
    'fAFXrLfjijwMPVU1wujR+dFoj2EGj7bwJ+pTArtmkT+3YKYQ9OSjmQZa46uz8cnyflyvTZbP3Evt/ZiZY7Wa3QyJ4jXzwqUI7BUy'
    '+5rbCddTV2ZE90HvpdNy4Xm78s1XGjGr0l0ilAVdIhlNtscRad2K/fG928F+C/gl7scz/To/svmAvV338DOimmAjwzNU1ljhnbC6'
    'PboRRz3CZYcTicMsk53ukddXc90ERNwhVkjrGq+aztbL/UHbBE3hSnoUcotFs2TOCuvmyQ+mdYriTbNmkqyddJZmpTFdZhSAn199'
    'lv6AgKDTErPoncsjkkDoQKlfKHkRxohm1hyI5zC3O3ZR6Kg6ABwDR/1yjDAIeou6cGaaK5ik1unmFtL6kdHV2y7MJ/WF+b2IKjI2'
    'Xu+33LYOSIx0+Qxk2Y9CezYmHo2IFXq+S8UV4IyFzMHpRgtb3K+KTixchxfN9cB+wnxflizGqbayPjmltrVmAT5zd7/6xK0aCL22'
    'R4tc/joilI+Hg/QgbG54EZGfkSrfYnHI/R55UeHoBn63voDflLgXde+gUXC8wCwpGB5BDeDtbqvvKtXRcT1++cf/8ss//tdf/vH/'
    'kYNjC6MZOJFPDmsE5bbNgQUP6pUWqLtllm5QG1IiSifuOrNv7EaqAixW9rrEKqvjkl5cuJ9wFMyK28f7URQt60tppTu6LscXi0qo'
    'woQRIiEVKdbNPHbdHUsnhDr7hNDBZBfbxlnP1Shhqo5t/uS0HCOYONfw2nhn8JrbsTw/mXp3ViExKib2qYEKqcQEL0EKTAcKPaHy'
    'KqAvdXu4zcYa60IW0y6CrFg7APvUPy33b5r4s/mONyTSGte2osrexinIfixX7sMjV/Tjo+9YrnVHGv3wLEONZtx9b3qA64jwc+ll'
    'cMre9cBBVQmVNcVjbYmfl6DFdMlaKqQiy7Gdz5eLyf1/qLWB4emRkDaeBsYdXK+8Md0JSs0K5UpDXcrnuBoXxYhq0xZaYRBrVIIg'
    '13BHjeAdBWiNnnOyG+sBs5hOmog/xerFQDkl6liQb1HY/wHYi1suj3MtXknkOfjPddg7WvxYeE0OXuc7koAc4TdQtST5VmZ2zVGd'
    'umDjGVfprvX2vROtwx/DxXM6fktRnDe53SIimDoyD9pCQSdUEX3MSVbb21k5cXfJigusSShY3RdW3ehCU0di3G4EgTcBd2t+f3JL'
    'Sv0zUFGo/HQ+R066cK4k2jeq5rE8BvQGsyJCF6F+UCaDhI5hasuyvMV21H3VpAOL/FQ1n5XdTH/ThcRqksMPWr8o5xnJMWPl4jUO'
    'ks2mZSofL5Wew0QQGEje7blDX1AKgWveb1sK9TkFi1Zq0eDi7NqXW2usV8hUlugtsKufiLS/iac9Czez0YBMEAmf9+jpZAyoPdId'
    'BgTzIpQFgkDiq1D+PWIHKdGPeSd1ROrNORdwYnH3U/EuP15OrqBFNpeUyxypJEmgg8ilm+4+4FfYH8wVZD6vHvG633FETNfMSQJf'
    'UUznS0jBEDbrgomtDgYWeAnPEay7IhUc61dekpaA9tdek64t3otRxlv/Ru/GxjkAAFJ2MV9NeFEAlNbURnAwWHEWkl1GVlXOgt8Z'
    '3PlwY2UUIfb/YgGWKd6KsyLHVlD3YipQqKAZjfq6B5kJli5WXusctC+VbAA9T7CDLOKdqJKWU3yJqAX6UaPL3+spwmf96CMMP1LF'
    'yEhwFyD8UvYno1DYxeo8ciBrbc70D+qFpX0lndYNmDS2ZtfCy8LZ1FhrPpEjq8ynTLpwCJdQPbjDdVosLeRLQwE1dwWoqXCbbzW3'
    'brUUIe307DZX+5L9I+JZ9JTxh6Noe7Rc8pAJq5WbrLqEWay4+RI3BqB0M23CJmeiGx7IwEal98mSe2JylC967nqGgkfL8XpJr0I3'
    'lTcT1d/jIo4YC7fuUMJg0a1vajuuUW9Vdllgr4rIiNccY//i7MzkUMIsBof7OXe5TWF2ko+URMkROLFLcyIPLvPFqHIyA4U9Suba'
    'olBTZi3AjXLjscCpfal9sjFUsdaPDAcnXKh4ZWfVJs8uBzckTdx0i31FzLjmtvkSeG6Eb1u5c04+E2lXyNPJMyJx4q9XUEFDAJaX'
    '49NT/esV4DHxx5eK4ClFyktW8FL4i+WKjfc1zIc5rFpgzMpj2FgX/XhTYZWkj1Xb1bAT752LyR5yEUE4z7qBmfpM77WebROMIX79'
    'zF4zVZGriimNsHJPfvm//huWzX7dx9/YNZXOAA73EWeAA2uv4xVch9yHFK2P9oglyjXvzsdwnz8q3/WzYjIZzyt1z9IEOcxwkxtJ'
    'k+9g1MNnbOnRlgw5YnuZfoIkfHlZDrJa66b74mLYnC6dIpj7zB807rFlaWB/q3QXzYuSM38nYDbKdajTzb+Zg1r/wuD1T4ynsSm/'
    'Nf6+tiWdRbq5RcdPRqN4x42BDytbcfyS3nerFFhGwam/QtdzJ1nEOquIFLoMCIEWuifjY8Sa5dTbgfrJPNsgfvnrPwd54WiPxETX'
    'vSE99KwMGDAWAVuPBAr+/lB2t6m7TWgGTYpJf22Hhm3L3qhnYnUDW1v6WqRlUM19hd6gkceFg91+ixDftm5bgWC3mjuy161LCKha'
    'b2kSeqFmAI1u0s3cr4GlxbyA1ixHI1qLSIPca5nmyBHSbFWNxNJHJJdnsl5qZQtol8w0XUsf/T2h2TyvZVoTBhDrGqKpWkeeQW3G'
    '2vp1tSldr5aRazvCyIlFICwejjiUd0HzZaAENDMGvd5pCe6L3va4Uu3Sv5jO1jH7Pvc2HBQq552NkAOZ3qO9j7mjbbKortvkE0wa'
    'f967h4m7d49KeTcv8vzgALa34dCJdQTYawh9fScYElTflV2qAMo9upMRFJ+uf+YOm3yK6duyWQQTWdHE6CjildpFQFrz01XbXRMZ'
    'gUdVb5Hm9vco0fZnlIjv4Ie94b09h5/svAwa17WQqaBXucyv1qlzFBP7X6W2iY+LrzA9MVvutMD170Q6WKnwWhMe+8rvSXv56FQx'
    'VnBosRxTzDT194qMcnEMBySMrrbx1XZoVyHrcSt9MUPLPOTwN41XaK6YdwFJtLksHj4cqb0GqClyAbxu4ausCJ1F19RWXz7exew/'
    'pYTVawcw4DViYH3tkN0K8ZzODtUzMlKm4hJqjWWlKukObOsjczICJBG4lJLoxs66vADLL8yXXmiqGT3aI+EwpZgSk/Gsb7wDD4zw'
    '3OdrCIexVohIoX9TJCqgs1DGOR7YTL+mt/G6A738CI1864toYtklTG0AutfVpz0PMlpbPaJS0u/g0pk11i/h+UqeFzDEyHpRr66P'
    'gdLFcDSGyyJUDO48EsmT5Av/0+Nikda1Y1LbHrYZRqqOcw4ksnIkpbjTTWlWKkaWxRMA2dLCCdrUbCKMp5I1BwzfC7vB3FFNPlqj'
    'ynG5JeIV8UCQblHajuPaD7I9X3XrYVRU1ZtPonCTNRHa+u+8CRT22ZwkeabySnVz+2TJHDZs6mEU4Z2vHUbs0BalvUL+kWHioNfX'
    'BBOoIE0yEfm6pZCtPnWEgpjnBmK+E9khD7aHRNff38/wO7veTZBYM7co9Y2u9Drg4qbOHlTTX1TFGgrlNPFKYxyAtDsZBsIKxNtY'
    '5UD+r8Ek66GjFiu/0mB3c8I1rIJszCNW7rTaEh2ybwN9l3Ja7FnTSzpu2MD0kn003gu4wI+2xuu8ArS7IimNClXjKxocDlGncgM1'
    'Ro8nrFPRTirb2GDOvWOUUkd2YzxjPfp5X1UWGu6s9zsq1a+F45koUtP1TbqMViOcKhGr2L6LilcR6BSlPtr+pNmWyl3vK5EbJwPl'
    'VvnnJeN4+KfPQWJAqy1WciKv5ToN7a5cR9QutW/oF7OC0QtBZqxwM8lF5+uSTYT95xwLTdFKXyo6417MsPepyKx5p/Sz47MSfL/s'
    'v29ib7C+stH5rXxz1mjSxsvI+kElgZkNuD0HWTgivJuchlNNV+HYhaGuI+f0qQq+VWvotyvR7uzgq6qzwlGyonT9vmS6ltb1e0Id'
    'SviSR/tkUkK9ZLefiDD9SD044Yoo3w6ywmsXlhbAFQD7G/YQuhfevKhf1hrGSjpCUdGDFN4OqxfRX7g1W4oRJFzPQYSMKZi5M2Rf'
    'wGqWx3me2m52SlfOcnZbjmpcYXTmsb3SNYDyS7Duput2s/njBvV/on9hU2Gr0glLgzSCu5ZKKyrklhGF9VLxlcjf1IVpegY9wWdS'
    '8Eou06M2s7Nv/+m7OcVu1dc1VbtoEMOJbN3Uu13M15mIbVyxa5nFTIWE2s4byUSsSOt9WpYO++XnC17N0jhhyG9WIGOudngSm34H'
    'fMcAvaaG+R9K2KDpfTCrndPxKqXw3fc+oIOaNPNoxJz9Warzwn5FQHPlXReBwQ04OowFgcNfKGh1cCnVOasfjMqNCvBJ59p7OqkZ'
    'e/W6677EwFIZedtp+OAQtXCe3SrqOGexYPb1K9K+CQynfRZZxf1dH2lxdHLoVOFrrRv060SbZR5rHhf+fd0u/0ZLj7HqfsAMjVbI'
    '3IyXzY+qroLeZ1vWmPy5iWxie9n2YPs3uLpZ8uxqXi67Bqm/6cq+62cGoe8fXfWYzLnnmg9Se6sHdxQglexFYThAszrr2Fiq1HgB'
    'e19xov8zAIvINbKFvptVObphjej9AgAtxHw6vpAqKY9uYIYr9nOte/WaLfG9GeZzV00eoydoTJMiIqA5cDBkm4mI3HqbJ2qtO+DH'
    'FJCtLkPlb5WMr9bNH0mZIlbO88GTauXR1xOU2CzwRV1p/sodKSV/id8l3TzkOws41VXgoJUUXpk9mwRYA5Q1QgCEgKD/LrYrmvK7'
    '7w2Y59B0wdpVRDC2BhLo5lAk+jTSPq/OTc+CzaLozmo9UORhiOfxeKp6v6siX8AWeOWW27FqBIanYjGDNQgMn8fBcBEnO3SzQvCn'
    'VzOPq/bQEQCcHta2GqE5GIQ2rtQ0HsA5xtUKdI5cmxpBa+1xVtg4PLsA71RxJxHrekJ4uSo/cYbN6/ZN/yf62KEmekK46WwdDnvh'
    'p8/ZLm5x7aHK5qX2lDk2GxyMPr49A6PlE5VcUahs6vpK1YHz47KIyRajJ7f7t89/7ywLpo5bWgz1p//yT1lFmxi2upqSZHvli/Nw'
    'dOEgpBraJfIdmYNLfBWmxk3pnLRpISfKz+LYfQ9Lrvc46+KI0ePs92UJZfAX5TFzQ/X6mbcYQIAnnpMGoLAX3P/B5U+FUufv12L9'
    'TGNM4PGotvOxd+o3pb9c1POjMl+M+gHPl1a5W2wGumEUYZGbLm8yJOEURsV6kijUY+Vl4ylLPp+znKG4Ss0MKa8uZuRqpmU5i+iO'
    'ursw1dnyEoCuuso04rhOOaKgDI858yjboWKg3Dsnt/ImWHIA9eE7zFTQr6pYbqwaID2tA997J3vCWDxzFaTr3hRpohdtO71m8DKz'
    'lnNbaUSB2PtKIz505N7rjmI1nYY0sTq4wvo2D6f1FZDJj2VXNcm9IX6Q4tMMaHK/MGLca5onSr5dXXt7NJoLfVomMYO8stpcAJyj'
    'luX+bSeEkWOM2rcXdhHOvNaCCna9jCblkr4uJ0WuTrdOGIq3CXSdLq/Q/1/btfW0cQXhd/+KNWpkb2tcIkVVhQNWRS8PQSQCV30g'
    'SJhgwwrjJV5bKY34753vmzm33TUKD3myd/fcLzPnzDnzfYPORezJjdwmVvAI8LNb3k3KUzv9yr/ZXzdBh1OlEp6CffMZBsOrxXR5'
    'p7x6C4VtajL9Bd/R7eR7wa0U7SQ1hO92fy9lQoo/FbGbNe9sHgSn0vPCU2fR4V25HhSExyFFyQd7T2dWOtnL6nrAxGjAXu6zV89m'
    'axiCde4alwojKnClguU8A6zgvfUHmSH3F3kdSIVIJpIvhMJ1HlzJFR4Z79Hx4yFKHdF1ze9R6lu1GOgWb13K7ztYvW8B+XPrsFTW'
    'IFnZglko347AxtiATGHWtLyLqHTDDiPjgTfmsZ5BZ4ApEfg8TxjZP3z13eCsTrInebqUAFpFD4UgaUKj6VNOMRzYS6RMimmlUEFq'
    'ljzI+q/39rIfs0K2PP22fHJCBL3qRclMIE7bq0ZJGwdV3BhPKo6Gul9rsQ39Kwr9O0BJ8ybXlS9+yr1SUPXsRSH++FfWBrX84ia/'
    'fGsSjLRLMosOdkyk7Ojax55kucBwh83wwMyP77n6oJceftu869Vj3Ep2woYwcpjT2edNgSuKFfEUFBwyYFjsK5RKCWzbzRKOdpV6'
    'N9N8wtvUFWcPTHrW9QRYUHcOgMgtCQWwfei98wKYeOL7WWMgnUlZ8MEaGZDjxzMoxpuSQOOs0MhlFWHodbtMiy7YOIBOUvYRHH52'
    'GhtsCWWo5vSq1IXzp+mKl8d6vo0Zr0nx4CD0B1koRZ2zFVSI84Bf+XkjmlBtFuXqt8Wi3xtKf+3eyHaQbJ2LFrS0EGAUyxpdQqHW'
    '8SP9cs2FIH9JQaJEPNlzUhwy46RlsRBGLzZUlJ3xFtTt8TNpGZap3nWgXRFaaxcL4n1bvG0e9DyW49/g+SSFYxmwLHuqayg4gMwZ'
    'dCx0BG4Si+LgcAGMBR5C10V613+A8SYS3C6lEIuf6lGZQRApxmQVJqjKHurhtCccEUVtOp33TmTZ0gXcBKLyz1+4cbzm3w+z1Vyi'
    'd3sX58i9yF5lby409a0q46QV79FPtDRUE7WylooDqG+JW+t1N2m++0QxpnJ0A9rEdQ11PyRUnVHpa1hwqBgq8nTJAh1JL4ns9S97'
    'uraJaZZsyJGGSQFs/iEKyNRLUW+DdudgeqXXoI8cNw65Iipu+29Ws0dFMlBzvhPdtK8qO0XHMID9ctgH+jLFus3uDnHXPMz6f9NF'
    'j3gQ+LP4AlMd4UnzCNrj6P3J5PT98RmJ8GRfyNMQzLtBZo96yuIfi+UDTMfOdBjfDxglkzJM12j9R2by80gA6SpuSCvZAHtEFBtO'
    'IadS6t6FOxzTnRjtrancG+LIru/p1F4wyuLa1zjvaZU4aJN4Jr6mCjNWOTwGvfvn/TaC9GI3D/xNfXvpAwaEI0tIRgJ8lGbXUWnU'
    'lMDiQDttF7UYXTxT7GlhCdbUFqkmiMo7E/GGwoy+oAAIqh1UFaE1JALe9NlOAIrAgfg2VXCvowORGIvVGTWVjlO1mNrlfA5VayVR'
    'NLdY5suKqWVv9aIdhNvzRMKhDpw2yH41lrUXCy9U4DnZxe9bVvwJzO53kpgtuyANmG6E0t2PIRE6ed8Eiq2hww7Bdur4Yb0mxXhy'
    'SjTtyFEihFW9mSB2uHlutf7teTeT3G0keYRx3YLCF8bVMJkK0inzYnXfl5Xr1HAAnFAef1x+XBK2Bm952gh6EchlXOKVQbl06EaR'
    'f5nD61GbvMf48cA94xa8nh30dNJ8nbhOumVptFMCf7WNN1aSjWhju1cJ1XuapXEyes5YwArQcGc7HpFCmPCTUnuDBE6y1bEj7H47'
    '+bi2RwOX8E+yhq82mCR26J/psVPdCv8Ig6NdToo1psEmYDLB6sPrBM7wTwg/RxoZVlE6U6L37eirdXQ/sh8qdl5reDe9Wg0RrYk1'
    'kR47aHqaE/KMyObyT/nA0a4xpHaV0gA+UyKbrbysXQ2X4HbKzYKkV1uBI12lxcDn8TiYmFgunJ1JfWDOqoZT6QB4IOa8g/HfDDLL'
    'OJOxsKK91xt+B5mjU1ZTE6cwjjH7BsK7mlUiByeRGNe6xu9bq7hFrqG4voPZY9MNrhlc43gRZrC8bs4bdTxhdMjUeQC1pYCXwej1'
    'k490kS48wwe30nA71MiJmdZWUSChDDyg25Zt97pYrR9zcrbLZAkzjzk7q96TZnc1u+FduRps9mYJEFBPUbKx014eh0XbaB5hdCKK'
    '4VHn7c/Vp1XxsD6Uf1fl9SN+wXRw2PkfVn3VEA=='
)
EMBEDDED_ICON = (
    'eNqNU02PmzAQve+vmHoPDVIx32RZQQ5VpZ5yqtQ7AQPuGhsZZ0n+fccmVN10Vyqy8MybN7w3Bsr5tYfLKORckcGY6TkIlmWhS0KV'
    '7oM4DMMAGQReOVu+qktFQgghT3GRwwNA+cn34cfEW6bhG697XY9QTxPwRslnMAMDLn0LCNUr2DnAd/F8HU9KYBlXyy50MKPwbLoM'
    '3DBQ0nVj6+cZddx1Emf2BeahbrnsodNqdJy21i/+qFpkNw2TBnaPafPUdp0HRjmG4P1g7ihxlifs5FHwfTdIy7r54JRKwSWr9XeN'
    'OpbL24oYLhiBS4TzE7iu2yVeM9wicriZLGejJlBdNzPjyjb3GyWUrsjNFwneZ0d37NXixi6Dt76c62CzXWrWGMD3E6Mjd194a4aK'
    '5OhhYPYA1lgjJ0oJdFyIipy12D3a4bxVpuzB6FrOndIjTm1DURu2i2KIYpp5MDe1wJTmeb73tqdIJZn1rtULQ98djnjL/JuLmEZ/'
    'IDtGU08V0eos2zfwL8Xlht+mbrhuBIPG2sapmuu64/kkaPm9ckIzV0eTd4w4XBnFX/V/Vfa23+kUHz4p/w9O+pHYVJsB8KM64qkW'
    'PzMaHaOUPkEU0kIkdO9HNDlGiUVSmooYA0yOWI5XxN+gwiLYBRnNoNgUyqA/PJT2tz08/AZluheo'
)
EMBEDDED_ICO = (
    'eNrtnWmUVNW1x6+S92K+EKN8yIeHl7WQsUERUeZu5qkB814n0ZWlGYAGGhxBGbqBAnpg6AbtRuNsgiZxwsREEkTRICgEYxBDHAAp'
    'KiAaoAfornnab//3ufdWVVdVd1V1lQxJrfWjDufss8/et27fuueevU9p2mXaf2mjRmn83k3rPUbTfqhp2oAB6v8v9NC0FVzXrZvx'
    '/ys1redcTfvud9X/135L0/Yv0bQrr1T/n/sN7r9a03qzDlaprdRUvby4YsLtinRfp2Zdq52Z2ePiYMa1WrZeZ2b1ZN97yrtQ3Iv1'
    '97iCx+nCdGW6nWe6GrZcIbaZds5U5UxfjbN7a/WzejA9BdZ1NVN4ZlaPah5rO3OQsTOO84zdsGW72CY29rzatBs0FPdOy/d6Po4W'
    's3p+hylh9rFeD0MXMmynF7YaNl8V7UtKvuNzB3N6o88w5k0mxNBFBmzeIT7M6WP51darYY6SoXn/w++9buW+xy9Cv1tzHL7QT/5b'
    'a2Df4GNC3+f2NfzvA7lb+TjUM3SJUK986qM1so+N7Gti//uAYcxxhi4xjhu+afVz+8T6XtJX+T+3z1XMDoYuUd5kviO+lkTOgTMl'
    'vcR/Pi9K+D3E0CVKyPBRO12i7g3q77xOayzJA1c3lvTdx9ClTd4+5Wsef+59tab5/bTGeXmgkPEydInjMXwV35vmwX95r2bo34T1'
    '8LkR/s/vD67gY7GdoazA51kTX2+aSvqockf0QMfcDuqJZ7vhs9Z0Z3/QhTnIUIfg8+vsgpup5aGfkev5VeR6toyaK/+Xmu66To2b'
    'qh7Ich/0hQ7ogk7oxhgdtlP52kX5fh3oytgZygjDv+ZVheTf/waFvW5SrzCFzp4mz9aHle0ydnv6+oss+qAvdIgmr0t0Ywzz+HTA'
    '3qNMV0Y7q9AZB0OZ0Z/OLRpBgX+8QwlfoRB5frchZX2eVzdIn0QvjIGxMGbm9oqvuvh+9/VAZxwMZcSd/cj1zP1sc8CyM+zjcyDo'
    'jxyCUw5qXjFRjZ9MD85520SRtV6sQ3RZigIyFsbM2F7lqy6+3zMA6IyDoYxgu707non43tJIrifvJe/rT0TOX7+XnJtmsd39k+vh'
    'NshA1vz78b7+uOiCTvOFseQ4Zmqv8hU+a+cUOuNgKCPuhv+/iPX/Kfb/jadi/Hc9XEzn8LeSTA+3QSbGf9YBXbH+/0LGzNhe5asu'
    'vt97A9AZB0MZwba4f7mo1fnv4XM38v/Qv+zUsnKSGj+ZHm6DTOjUsajzP6B0RZ3/GEv8z9Re5asuvt83EOjN9w10MJQJ0NlcWkCB'
    'j3dRslfw2AFqLhvFsgPa0DNAZCCb7IUxMJaMmaG98BU+w/dmRYf8F9geZ+UtFDiwI/Z6FfUd4N32KDUvuDG5Dm6DTKJrP3QGPtoh'
    'YzR3zHcyfNXF9wU3Ap1xiG0d4b4bqGXJcHI9Mps8L1WQ97WHKHz2VMQHdzO5+W+5Wc6BG9R7VBltkLHkua/3tVrRBZ0tS0Yo2Y7a'
    'qXzVxfeFg4DOOFoWDqKOYh4H0y/vljWx34NfHiZXzW3kXFdE7sdKBJRRFzp5OOZ7z/vK2hhd0J0VG9lXw2etRaG3ZMn/WNjeJcPI'
    'v+/V2D+F+i8ofO4M/zH7BJRRF/3y7/u99BUdWbdLfNXF9/tvAjrjYCjrsP3OiqkUdPydUn0F/3mQ+0xTvufCJuWrLr4/cDPQGQdD'
    'OeH+QeTf+WzCa2Kia51/53PSJ2f2KF/hs+ZcJOiMg6Gsw364q39A4YaTUQ56KfDBVvL+qlRAmax7HhJZ9EHfnNikfNWV74MBlwdz'
    '3WDKOuyD77UHYz5z3/bHybl0OLfdqOAy6qLPBd8fHjT8H5wLHIbPmnPxEKAzDoYyw9CL99b1S4ZSYP+2mPtAV8UU9TmYclxGHdqs'
    '+xzug74JdSYcKy0chs+aa4mgMw6G0oJ1uWB72Uhyr5pIrhWjuW5whEU3kYs/2+Cn70WubYf3ibz0jdbDdWiz5LgP+oqOaJ08howF'
    'HRh7cZo2KxyGz+z7UMDloVw3lFKH9SwvIN8LK9nWd/l7/QiF+L7V/+aT5F4znVy2seR5bC75/7yZws31UfPgY+Sumqp8MXVxGXXR'
    '9/3og2smdLhZF3RCN8bAWBgTY8MG5VM6touvuvi+dBjQ3UuHOhhKmWX54lv0vY3l4xefsp0fUtjrjL/mh0Pkf+MJcpeNYL9vFlBG'
    'HdrixFmH+Mw6478o/WIDbEnLdvYVPsN3d6mgMw6GUoKPt2/zA3zN9lBGL+4X5Gu+7/nlQlCu/5nrgi2wKWX7la+68n044PJwrhtO'
    'KVE2nALv/z5ig9dFwYNvUbj+RLx93IZzIfj3Hep+r9W5EPeZswxk0Qd9484HHgNjRbfBFtiUsv3KV118LxsBdO7v8LCOlFhRQMHP'
    '3o2c78f/QZ7VEyjw51/G+rF3C/menC9tHttoCrz1NH+xuZN/lpjjvf0My46RPugLHdHHDWOgDWNGrpXvik2p2g9flc8jNM8yQWcc'
    'DKVK8K9tf/7hM/8k79rp5Fk6JOa4+X61hEKH9sSe71wOHdorbTF+cF/ogK62Pn/Yko7thq+6+L58JNAZB0MpUTaMbV3c5t9scM/L'
    'LJvPY0X1w9jc11MxkUJH/xY5f7jsqZik2iBjyY8UHdDV5t8/2yJ9U7Vf+aor3/NBev4z3pVjKPjOc4mv/+yPd8MPYn2J6TtaPm9L'
    '/vBeqUs4FuuArtDRDxJe/4O7nhNb0rFd+Qqf8zXvCkFnHAylDPxYPY78W8rlfA5/9TmFHB/J36+vpojbRyTv29r/Q8r/5GONYJ3/'
    'J7oxhox16D0K8NiwQWxJx3blqy6+2wqAzjgYSgvDNrFh7TTyVk7iupGKpH1Gkq/2RxT+8lDkb5rLqGuvn4yHMTCW+G0c43TtVr7q'
    'hu+Z+x9DfkrHy//EXPb3cPz32leHpS01f/KpY7ZG/PetHAV0xsFQzuBxfeum8ff6/qSXMrRBRmRzaYvyVRffV40GOuNgKGfwZxb4'
    'NX9nBPxR32XHhciXu19kIJtTW5SvuuG7+O/nOoZyBXwK/vHB2HudzfcJ0fdEkIFsLm3xR/nvXz0G6IyDoZyxku8ZXymP3O+GghQ6'
    'sJ1CH22Xsnk/DBnI5tQW5asuvpePBTrjYChnrOb734dvp3DjyaR//2iDDGRzaovyVTd8B10DFWPtDOWMckVw64bEcwCuQ5spl1Nb'
    'KsYe9VeM7cpogYpxoAtzkKHcwmNXTeBzfDWFHTy/a6kXUEYd2pR9ubZDfO0ivleOB1cw2xnKPcZxqJ5GwZ//REBZ6tD2tdggvsJn'
    'LVg5QQtW8TGoGl/N0NeG2DHW4GscV1EtPrPvcgyqcAwmTGW8QZyflzbwsRA+K9/HasE1E8DVwTUT9zF0aTNhn/KVfV47VmKAQ1XT'
    'tNDaifz/iSX8HmLoEiVk+KiFKgut+O/gmknsv3AVs4OhSxT2beJV8lmvmRiTAxDi/4fWTQLDmBMMXWIcN3yTc731K7R+Avs+WQtX'
    'c/v6ybeG10+uZ+gSoV58gm/sY2jdxIQ5QOL/+sna+7Zifp/C8lOOM3SRcwK+PL9mpvgGH9t6QUaQc2HKMGYHE7oI/Q4Ztg8LG58r'
    'SOXFfSLUFF7FlDD7qKbQy9AFjhe2MvPE9ihf0nkZvluw3quZQqqZWk0bpm5nDjJHmWPnmaOGLdvFtprCqbA12vZwdWHGecCsU6MN'
    't8B/xfopGm2cdgWP14Xpylxznulq2HIF8Wdm2blhqrxn60UPsr6NYJrSfSFTMz11v3bi305Exn+D6r3Aq971s+r92w71/s2d6r2T'
    '+b5SvV9mvmv/eeX01fp4t/48zM/J/NzMz9H8XM3P2fzckQ08gPlp9D4R16a+T4TabwB7DZzH/R5kX4aeae130FDcSzt1u672BxAf'
    'ZA+FfKaYKWVsOabUGCuf7e7SYOxVcPoOvd1c/frZMfsTdGXKWMd+xnke9hzAmPthA3ON2DRbkfC4IwedOTm7G+yfznx4AeXKH4BN'
    'X87pxjb2Ejtj9weQ3HitZWZ37BMwg2m4AHPdYdNMZ/G1ks/fOCeS6910zyAzx30608DtdGEC28RG7dRdA9V+JCV5Ro5632sa5vY5'
    'cBHkmn/ItnaVvHLkV6v8ci73LbuI8qVhK9udZ+ZId2H2sz90UQBblc2S58zkM86McoaNYyL5pyn3y1N9pF9GecrOpvlis5mnXMxQ'
    'WsDeu66nc8vG0znbZDp77yBVl0I/yKIP+kJHSv3iKRbbVZ5taVp5qvP70bmyseR953kK1Z+gUNO/yP/R29S87lYjnzh5P8hAFn3Q'
    'Fzqgq81+iYHNRp7s9TaGUuM6OnvfIPLt/V182I7jIDUvG6dyIVv347rm5eNEJm6JjHVBp8phTdUO2GzludpSzhG9qz+1rCmy8g6D'
    'Jz6lAOKYw2HBtXlJ4hxU5MJuXmrJoQ/6qrzIBtEpubup56rCZjNP05ZyjiMfI+eDd0jetBy797aQ57frrbVmz8tViXMxuc7z8hpr'
    'jRp90NfMwYZO6E4j19IWlWdpSzlHkfvKeWDmRAX8FDbi7cSOTTMT50ByHdpMv6WPEXMRPHlIdLaZgxkPbDbzBG3p5gS6Ny9WuU6t'
    'Ylw9L6wy8rpa9xkgba1jZaEDujLI/bNF5fnZMsmXc/Fn7v3TI+R/9yUKO5vUqdH4JdffTs33XMc2Xa/gsmvj7RRq+FLZzLLog77Q'
    'kWGuHmw289RsGeW7IXcOuYnIr3yt1vobQL6B+6l7yLOlSkDZykFAvibLtpj5fOifWa6ZTeWZSa6ZrWO5ZIPIWZpPgf2vx5xL0fFD'
    'VvHD7SIrNnQsV8wmtj8guWI2fqfMuZmP50ByPz4vNkcWedLB2L0DIANZla/VoTFhs5nnZet47tRg8u/6jWFomIIfv0OeXy4UUJbr'
    'PsJyWUblGnU4V8smti9GrtJgm8r7SYGYsc26m8m1ehKF/nXUilt3lU+x8rBQNuPKIQNZlaeURF9qwGbNhVyjxUNskq/TFpIPNFje'
    '3SvHC1IH29lGd80PrXyawJ4tqt7M6+Ey6sz8GciijykTo88Yo117lM2aaylyZYbaGGoTjFM5lfzvPEehk58JyGf01P2EfC/Y1Dli'
    'nOvBQ3vJtXxUJLeJy0EzLphlIIscH/SFDksf68YYYn979iibNTdyXZYOszGUnKHkto2m4Ievx8dmuc5G4tSirj3+t54hT/X3BZTj'
    'cjy4j/RtfQ/IY2AslY/Tlk1is5mnYmszrwP5Ao/P5Zsdl3UOR+fUqe+kRgp9/oG8mzF3yDOXPHUjNi9OJip3z/zbwRgYC2O2k2sC'
    'mzVPGRhhYygZ0OX7dallR+CNxwVzL4zgX14h76Yfk2flGPI9vyxhvg3q/NwGGciij7kHR4w+HgNjuSU/Y0Rb2MR2lSdiazOvomwY'
    'eR/+qXXckMtv5vOjTmzHeCI7nLwbb6NgVB4R8ji8D96mcj8gg8+T+yTVx2NZORPJsUXledjazQ2wFUicfUxeA5dVXk5BrGzpEDnW'
    'Ko8pTP4XlktdxvoSA5vNPAVb+7H9Rl7CS3yt+dtWAWWJl1/RKk+Aj53/RZs1VxE5fIaZ6kuMLSrPwJZyjDpi+xOVo2LpkTMguURW'
    'HsUeI48gP319ybFFxcnbshYLv6ZQ8l7iYuC5Dm1ZjIG3RcW527IWy464bSNnPXz8oGDltnNbFmPYbVFx2rZsxWIHXlwemQfselYw'
    'v6/QlsUYbJuKsxZsDHUYxFL/nK+z505H5gDG9y7q0KZiqLMwVvlY2KwFJFZ4bGn2YpDHUej1OiJPS+Tk5zLqrFjh7FAqtlci1ndc'
    'sYqxzQKwEfGUzy2gEJ87AGUVw5ylMRTFynaJUy4IVI13ZjUGt/Xxym4srpP15fO7GWPbhdkfXDOBLgpgq7IZsaGaETdYdhHFu5Yh'
    'rjO4VuJ7xX7mGq47cBHEah5Qtk4U2/HyL883YzSnMw2hdZPpAqXBsJGv+flR8YUSW6n51k9DLNpMpuECjJWETTN9NbeIrbA5Nk5U'
    'xdERt4erp0xnDlxAMX+wZTpVfw/xm2JrCvF91zBlVFO4n3Geh3g9jLkfNogtKcbroT1Y9z2JbwtJzJfEgBUwxUwpsyLHlBpjFWDs'
    'kBknWHdLWvF2Kl5tihFnFx3DlWPixipsM15O4od0TZO4om9rmsQZfVPTVBiREZf0n+iv9OK4Lou8m8fRPK7mcTaPOyJRuhm/6WPF'
    'aV2ZPE4rKj5Ia8Tvwszs0ZnRmWs7CHR0bjB0J/ptkZjfEJnVM4+pODOr527mCHOsg0DHLugU3cZvdpi/7dFg/tZHca9OzAzGkcN4'
    'IUf9bB5jdq9O6rc11NiNKsZmBte1MJRT5vAYGEvG7G3GyOQxjq/xdwUcjWpMTeJFSvIqzkO8RwXia5rm9+vM7G5z/3PEMSAmA/tx'
    'm7EZcTL9Wsnktben+i4Z+87+OnMk+d7m/ensohHk+f1D5P/bNtnbHGv6reVQhzbIQBZ9JJ4i+Z7mh5vuvA57Ondn7InX9FVcgnfb'
    'Y+qZKJ5fBPzkfm5Z7Fo+l1En62nyjCMsfay4g8Tr9Biz+7l7BgB70vXwBTdR4LO9FHafI9/uF+V5g2/3C3SOdUT2U75e6lTbiyKL'
    'Pujbxjq7Xca+9wZgb2tNG3tK43mfuZ7u/eMjsWvp2M+Z66z1c2Mf6nbWyTFm9+YFNwJ78j1iB1JL2Wjybt1EgY/fkbW+4IlPyFk+'
    '1doPFuXg8U/Unrcf7xJZ9DH3yE0CxuzesnAQsLe5Jot9VLG2uGgI+d54UsVpfPIu+Xb+Sgh8slvq0AYZkW1/71W7jH3/TcCe8nru'
    'ygkU+uIz69mT+UwKdWhLY/0WY3Z3LhoM7Mn3PryZnA9E7U350B1qveOrz8nzi4UCyqhDm7UH5QNRa3+JwZjdXYuHAHvCtTSswy0r'
    'IPfqSeRaOkzWHH0vV6jllK215Fw4UEBZ6rhN1iWxDoQ+3Nfa8y8eu4y9dCiwJ1qX89T9WPYVDJ12UGDvK+Tf8ZS1515g36vkXl4g'
    'BIz9atEGGciiD/pCR5J1N4zZ3V06nBlmj9tzjfUGD76t1sOi9gINN30lyHrfoT2C7Plt1kftCYq+0CF2xu/pZsfYnmUjgD12XWY4'
    'eVaPl7VdxDOZ63vB/dvIW11E3kdmUOiz96z92FD2/nyGtAWNvSvRB33VXmfjI2s0Eewy9vKRwJ5oLSOw7eHIc8rGL8n32GzylA5V'
    'a0HY54uPN/Cum670c5vvsWKRNZ9zQkeSdRKM2d27Ih/YE65FYB3j10so8Kc68j06K2YvJ9+G71v7saAcvacSZNEHfdW6R8J1DozZ'
    '3bdyFLAnfe6P/Y9WjGDyI3VVkyn00RuRNYCP3pQ6aw0AstJnZFvrAnYZe9VoYE/9WT6f70/Nk33Ewic+FlBGnYyV+nN6jNndv3oM'
    'sKf8fHzVKAo8OoPI2STPruWZNpdRh7Y0nrNjzO6BinE6cyStPSkq+Rr8+iY+z74QUEZdmntR8Jhj9UDl+M7M7rT3hKgaT8G62wT1'
    'bDbtvSAwZuegel5WmdnzzvGKzJ6XViCn2sijz+N3x9eY146xMKY8mwqqZ4QzQusntzCUY1owVnCdypnF8zLJNa2e0omZwThy+LzL'
    'YYzRKRz1rC4mh7emMI+poJrC3cwRxt5BoGM366wU3eLvlLjc2qjna1qoejKes3RmdKZ7B4GOzsHqyUZuZ+yzsp0qJ++y8/A8A7lo'
    'nTAL/66RU2Y9p/hW/HMKY44unJlxbaczs3r0PjOzRyHz/TQplL6sw3rmgbn4XJWrw//Xmbr64p7H6mf1dDGeNHFxX4fS0UtvMHWr'
    'OT7+vzOL8/mdopN1N87L68Tz6bpsz9V5jlwH3Y3z+vVmHAl/I25uH6a3ek+nTeh3jOnF89FCxpVortpS/SPy8PyqpW6W9ZtX5m9j'
    'oU7aWCbJPBc6C3muWcR44n4/adlYNXfCbyqcOU7Nld9TcfaIq+cy6tAGGcgm+D0m6CziuRzwxMZWX08tqwvltxqwBzXie50b71Bz'
    'R8Rdb7xD6mQvbJaBrMxrY+eJ0FnEczngiYtX5vmO5zcrKHjkrxLr43mpkud2qg1l1KENMs0S2xsX7wydRTxvAp6k878lw8n39maJ'
    '+8JvtsjvtnAZdWhrY74HnUU8HwIemRfFcJPQwvMYzxN3yv7VwSPvCyijDm2mXHx/0VnEcxngiZ3jDCaXbZzsLY65GOLtcKxdqyYI'
    'KKNO4jxZRmQltjBmnuQR3UuHAk/0/Mj72BzZX1T2Mf1gq8RQym+wPDFPkDg5rkObKYc+reZD0FnkLhsOPG6137DMURDrJfOaxpMq'
    'TuGtpymE48JzTZmDchl1ch8IGZZFH5nfmHqUziK+1weeyJ68w8n/hxqJNQQoIxbLW8Xn6+d/FVCWmC2Ra4rIYa4RmUdAZ5HXVgA8'
    'MXudYv7w7ELBjH/yrZkqe1UDlK14qRi5mHgk6Czie3XgiZ8j5CuMuUHw7aeJED/JoGzd/0fLxQKdRXwvDDxt33uPptC+V3heVy+g'
    'LPsjtn2fDZ1FfL9byLjavCcuH8P38T+j8N/fFFCWurbvo6GzkO9DezOOdvez4vtka70b5Xb3v4JO6J7Qie9TN2X7XpR11kG3sU6t'
    '8/3hzizea+4UneuM/ZrUfabO1IWrCx18P+RiPGnikr7VUzZBl6z5GvfR5r0VbZzWiWqm9ub7rkKmKE0KpS/rsO4JU9yHpSOv3mp5'
    'SO7ArPuwbyS+D+N7p8v5PqfgzKye5UwdU5sEtJWLLPqoNY/L+b7lbi6fTiNH+TT68H3U5Y0leQWNJX1PWzmnuE+Z3Ysa5/SO5KEi'
    'Jxh1c2NyU0+jb9P8/uWRXMN+dHbBYHI+Op/OrZ5mPZtHGXVoU3VWbmI5f9fXxuSuPb2QQnyd97//Gn9XDxRQRh3aWuW81fJ3bW10'
    '7pKz+jZ5lhr8/ANqWTlRQDnw6bvS1irnqbbl/ptq434vqTSf/Hu2UNC+X0BZ5bLE/R5SrXPx4NpIrsEQ9V24rIACf/kt+f64SUBZ'
    'nh1ym/UbKopa99JhtRJnvmQweZ+cTyGMefgv8gw0sOdlAWWp4zbIQNaITa/1LBtRK8+/+DvK//xy+d7CszJv7e0U5GsekDKen3Eb'
    'ZCBrPDOr5e+CWvO7wVc+nvxPlpBv/S38vcH3cR9uE1BGnbSxTNR3SS1fi2sj1+bRKm4RPMz3YqfsAspW/eqY63ttoHJcecLYtjWT'
    'KPRqlYBykpi2cp73F/C193TC+KOqcYrEsUmn0ZevZZfzNeduviacTiNG5TT68DXwcolF2Tjtcr6OFfC8tJypbYdykUWfLFyH/h+V'
    'j56/'
)    # Windows icon (icon.ico)
VERSION = '2026.11.16.1805'        # build.py stamps each build with its date and time, e.g. 2026.10.19.1534
UPDATE_URL = 'https://raw.githubusercontent.com/WMBanner/spider-diagram/main/dist/'        # build.py: where published builds live (a folder holding version.json); '' = no updates
PORT = int(os.environ.get('SPIDER_DIAGRAM_PORT') or 47615)   # fixed, so the browser's autosave survives restarts
TOKEN = secrets.token_urlsafe(24)  # only pages served by us know it, so other sites can't use the API
IDLE_EXIT = 120
DIAGRAM_SUFFIXES = {'.spider', '.json'}
SYSTEM = platform.system()   # 'Linux', 'Darwin' (macOS) or 'Windows'
DIAGRAM_FILTERS = [('Spider diagrams', ['*.spider', '*.json']), ('All files', ['*'])]
EXPORT_FILTERS = {  # kind -> (file-dialog filters, default extension)
    'png': ([('PNG images', ['*.png'])], '.png'),
    'md': ([('Markdown', ['*.md'])], '.md'),
    'txt': ([('Text files', ['*.txt'])], '.txt'),
    'docx': ([('Word documents', ['*.docx'])], '.docx'),
    'zip': ([('Zip archives', ['*.zip'])], '.zip'),
}

def config_dir():
    if SYSTEM == 'Windows':
        return Path(os.environ.get('APPDATA') or Path.home() / 'AppData' / 'Roaming') / 'Spider Diagram'
    return Path(os.environ.get('XDG_CONFIG_HOME') or Path.home() / '.config') / 'spider-diagram'


def documents_dir():
    """The user's Documents folder. On Windows, ask the system: it's often redirected into OneDrive."""
    if SYSTEM == 'Windows':
        try:
            import ctypes
            from ctypes import wintypes

            class GUID(ctypes.Structure):
                _fields_ = [('a', wintypes.DWORD), ('b', wintypes.WORD), ('c', wintypes.WORD), ('d', ctypes.c_ubyte * 8)]
            documents = GUID(0xFDD39AD0, 0x238F, 0x46AF, (ctypes.c_ubyte * 8)(0xAD, 0xB4, 0x6C, 0x85, 0x48, 0x03, 0x69, 0xC7))
            found = ctypes.c_wchar_p()
            if ctypes.windll.shell32.SHGetKnownFolderPath(ctypes.byref(documents), 0, None, ctypes.byref(found)) == 0:
                path = Path(found.value)
                ctypes.windll.ole32.CoTaskMemFree(found)
                if path.is_dir():
                    return path
        except Exception:
            pass
    docs = Path.home() / 'Documents'
    return docs if docs.is_dir() else Path.home()


CONFIG = config_dir() / 'library.json'
SKIP_DIRS = {'node_modules', '__pycache__', 'venv', 'site-packages', 'Trash'}
MAX_DEPTH, MAX_FILES = 6, 3000

last_seen = time.time()
live, closed_at = 0, None   # tabs connected right now, and when the last one went
lock = threading.Lock()
summaries = {}   # path -> ((mtime, size), summary): files are only re-read when they change
last_dir = documents_dir()


def applescript(text):
    return '"' + str(text).replace('\\', '\\\\').replace('"', '\\"') + '"'


def pick(mode, title, start_dir, suggested='', filters=None):
    """A native file chooser. mode: 'open', 'save' or 'folder'. Returns a path string, or None if cancelled."""
    start_dir, filters = str(start_dir), filters or []
    if SYSTEM == 'Darwin':
        where = f'default location (POSIX file {applescript(start_dir)})'
        ask = {'open': f'choose file with prompt {applescript(title)} {where}',
               'save': f'choose file name with prompt {applescript(title)} default name {applescript(suggested)} {where}',
               'folder': f'choose folder with prompt {applescript(title)} {where}'}[mode]
        # 'activate' brings the dialog in front of the browser; cancelling exits non-zero.
        r = subprocess.run(['osascript', '-e', 'activate', '-e', f'POSIX path of ({ask})'], capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else None
    if SYSTEM != 'Windows' and shutil.which('zenity'):
        args = ['zenity', '--file-selection', f'--title={title}']
        if mode == 'folder':
            args += ['--directory', f'--filename={start_dir}/']
        elif mode == 'save':
            args += ['--save', f'--filename={Path(start_dir) / suggested}']
        else:
            args.append(f'--filename={start_dir}/')
        args += [f'--file-filter={label} | {" ".join(pats)}' for label, pats in filters if mode != 'folder']
        r = subprocess.run(args, capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else None
    if SYSTEM != 'Windows' and shutil.which('kdialog'):
        spec = ' '.join(f'{" ".join(pats)}|{label}' for label, pats in filters)
        args = {'open': ['kdialog', '--title', title, '--getopenfilename', start_dir, spec],
                'save': ['kdialog', '--title', title, '--getsavefilename', str(Path(start_dir) / suggested), spec],
                'folder': ['kdialog', '--title', title, '--getexistingdirectory', start_dir]}[mode]
        r = subprocess.run(args, capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else None
    try:   # Windows, or anything else: Tk's dialogs (bundled with most Python installs)
        import tkinter
        from tkinter import filedialog
    except ImportError:
        raise RuntimeError('No file dialog available here; on Linux, install zenity')
    root = tkinter.Tk()
    root.withdraw()
    root.attributes('-topmost', True)
    root.lift()
    root.focus_force()
    try:
        types = [(label, ' '.join(pats)) for label, pats in filters]
        if mode == 'open':
            chosen = filedialog.askopenfilename(parent=root, title=title, initialdir=start_dir, filetypes=types)
        elif mode == 'save':
            chosen = filedialog.asksaveasfilename(parent=root, title=title, initialdir=start_dir, initialfile=suggested, filetypes=types)
        else:
            chosen = filedialog.askdirectory(parent=root, title=title, initialdir=start_dir)
    finally:
        root.destroy()
    return chosen or None


def dialog(title, save=False, suggested=None, kind=None):
    """Choose a diagram (kind=None) or export file; returns a Path or None if cancelled."""
    global last_dir
    filters, ext = EXPORT_FILTERS[kind] if kind else (DIAGRAM_FILTERS, '.spider')
    chosen = pick('save' if save else 'open', title, last_dir, suggested or '', filters)
    if not chosen:
        return None
    p = Path(chosen)
    if save and not p.suffix:
        p = p.with_suffix(ext)
    last_dir = p.parent
    return p


def reveal(p: Path):
    """Show a file in the system file manager."""
    if SYSTEM == 'Darwin':
        args = ['open', '-R', str(p)]
    elif SYSTEM == 'Windows':
        args = ['explorer', '/select,', str(p)]
    else:
        args = ['xdg-open', str(p.parent)]
    subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)


def write_atomic(path: Path, data: bytes):
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix='.' + path.name, suffix='.tmp')
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(data)
        os.replace(tmp, path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise


def diagram_path(raw) -> Path:
    p = Path(raw or '').expanduser()
    if not p.is_absolute() or p.suffix.lower() not in DIAGRAM_SUFFIXES:
        raise ValueError('Only .spider files can be saved or opened this way')
    return p


def info(p: Path, **extra):
    return {'path': str(p), 'name': p.name, **extra}


# ---------- library ----------

def tiny_png():
    """A 1x1 grey PNG: stands in for bubble pictures in homepage thumbnails (keeps the list light)."""
    def chunk(kind, data):
        return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind + data) & 0xffffffff)
    png = (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', 1, 1, 8, 2, 0, 0, 0))
           + chunk(b'IDAT', zlib.compress(b'\x00\xc4\xc4\xc4')) + chunk(b'IEND', b''))
    return 'data:image/png;base64,' + base64.b64encode(png).decode()


PLACEHOLDER_IMG = tiny_png()
PREVIEW_KEYS = ('text', 'x', 'y', 'parent', 'kind', 'color', 'order', 'collapsed', 'bold', 'italic', 'size', 'shape', 'fill', 'imgSize', 'line')


def load_config():
    try:
        cfg = json.loads(CONFIG.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        cfg = {}
    if not isinstance(cfg.get('folders'), list):
        docs = documents_dir()
        cfg['folders'] = [str(docs)] if docs != Path.home() else []
    if not isinstance(cfg.get('recent'), list):
        cfg['recent'] = []
    return cfg


def save_config(cfg):
    CONFIG.parent.mkdir(parents=True, exist_ok=True)
    write_atomic(CONFIG, json.dumps(cfg, indent=1).encode())


def remember(p: Path):
    """Note a diagram you've opened or saved, so the homepage lists it wherever it lives."""
    with lock:
        cfg = load_config()
        cfg['recent'] = [str(p)] + [r for r in cfg['recent'] if r != str(p)][:199]
        save_config(cfg)


def scan(folder: Path):
    """.spider files under a folder, skipping hidden and bulky directories."""
    base = len(folder.parts)
    for root, dirs, files in os.walk(folder):
        depth = len(Path(root).parts) - base
        dirs[:] = [] if depth >= MAX_DEPTH else [d for d in dirs if not d.startswith('.') and d not in SKIP_DIRS]
        for f in files:
            if f.endswith('.spider'):
                yield Path(root) / f


def strip_html(text):
    """Notes as plain text: block tags become spaces, inline ones (bold, links…) just disappear."""
    text = re.sub(r'</?(p|div|li|h\d|br|tr|td|th|blockquote|pre|hr|ul|ol|table)\b[^>]*>', ' ', text or '', flags=re.I)
    return re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', '', text))).strip()


def summarize(p: Path):
    """Title, counts, searchable text and a lightweight copy for the thumbnail (no pictures, no notes)."""
    st = p.stat()
    key = (st.st_mtime_ns, st.st_size)
    cached = summaries.get(str(p))
    if cached and cached[0] == key:
        return cached[1]
    data = json.loads(p.read_text(encoding='utf-8'))
    if not isinstance(data, dict):
        return None
    # Version 3+ keeps bubbles under "bubbles" (several main ideas possible); older files under "nodes"
    # with bubble 0 as the one centre. The app itself upgrades files; here we only need to read them.
    key_name = 'bubbles' if isinstance(data.get('bubbles'), dict) else 'nodes'
    nodes = data.get(key_name)
    if not isinstance(nodes, dict) or not nodes or (key_name == 'nodes' and not isinstance(nodes.get('0'), dict)):
        return None
    texts, preview, with_notes = [], {}, 0
    for k, n in nodes.items():
        if not isinstance(n, dict):
            continue
        if isinstance(n.get('text'), str):
            texts.append(n['text'])
        notes = n.get('notes') if isinstance(n.get('notes'), str) else ''
        note_text = strip_html(notes)
        if note_text:
            texts.append(note_text)
        pn = {key: n[key] for key in PREVIEW_KEYS if key in n}
        if isinstance(n.get('img'), dict):
            pn['img'] = {'src': PLACEHOLDER_IMG, 'w': n['img'].get('w', 4), 'h': n['img'].get('h', 3)}
        if note_text or '<img' in notes or '<table' in notes:
            pn['notes'] = '<p>notes</p>'
            with_notes += 1
        preview[k] = pn
    if key_name == 'nodes':
        mains = [nodes['0']]
    else:
        def sort_key(item):
            k, n = item
            order = n.get('order')
            return (order if isinstance(order, (int, float)) else int(k) if str(k).isdigit() else 0, str(k))
        mains = [n for k, n in sorted(nodes.items(), key=sort_key)
                 if isinstance(n, dict) and n.get('parent') is None and n.get('kind') != 'free']
    names = [' '.join(m['text'].split()) if isinstance(m.get('text'), str) and m['text'].strip() else 'Untitled' for m in mains]
    if isinstance(data.get('title'), str) and data['title'].strip():   # the diagram's own name, if it has one
        title = ' '.join(data['title'].split())[:200]
    elif not names:
        title = p.stem
    elif len(names) <= 3:   # matches docTitle() in the app
        title = ', '.join(names[:-1]) + ' and ' + names[-1] if len(names) > 1 else names[0]
    else:
        title = f"{', '.join(names[:2])} and {len(names) - 2} more"
    links = data.get('links') if isinstance(data.get('links'), dict) else {}
    preview = {key_name: preview, 'links': links, 'settings': data.get('settings', {}), 'nextId': data.get('nextId', 1)}
    for k in ('format', 'version'):   # so the app knows which version to upgrade the thumbnail from
        if k in data:
            preview[k] = data[k]
    summary = {
        'path': str(p), 'name': p.name, 'folder': str(p.parent), 'mtime': st.st_mtime, 'bytes': st.st_size,
        'title': title, 'count': len(preview[key_name]), 'notes': with_notes, 'mains': max(1, len(mains)),
        'links': len(links), 'text': '\n'.join(texts)[:50000], 'preview': preview,
    }
    summaries[str(p)] = (key, summary)
    return summary


def library():
    with lock:
        cfg = load_config()
        paths = {}
        for folder in cfg['folders']:
            f = Path(folder)
            if f.is_dir():
                for p in scan(f):
                    paths[str(p)] = p
                    if len(paths) >= MAX_FILES:
                        break
        alive = [r for r in cfg['recent'] if Path(r).is_file()]
        if alive != cfg['recent']:   # forget recent files that have since been deleted or moved
            cfg['recent'] = alive
            save_config(cfg)
        for r in alive:
            paths.setdefault(r, Path(r))
    files = []
    for p in paths.values():
        try:
            s = summarize(p)
        except (OSError, ValueError):
            continue
        if s:
            files.append(s)
    files.sort(key=lambda s: s['mtime'], reverse=True)
    return {'folders': cfg['folders'], 'home': str(Path.home()), 'files': files}


def route(path, req):
    if path == '/api/ping':
        return {'ok': True}
    if path == '/api/open':
        p = dialog('Open spider diagram')
        if not p:
            return {'cancelled': True}
        text = p.read_text(encoding='utf-8')
        remember(p)
        return info(p, text=text)
    if path == '/api/open-path':
        p = diagram_path(req.get('path'))
        text = p.read_text(encoding='utf-8')
        remember(p)
        return info(p, text=text)
    if path == '/api/save':
        p = diagram_path(req.get('path'))
        write_atomic(p, req['data'].encode('utf-8'))
        remember(p)
        return info(p)
    if path == '/api/save-as':
        p = dialog('Save spider diagram as', save=True, suggested=req.get('suggested'))
        if not p:
            return {'cancelled': True}
        write_atomic(p, req['data'].encode('utf-8'))
        remember(p)
        return info(p)
    if path == '/api/library':
        return library()
    if path == '/api/library/add-folder':
        folder = pick('folder', 'Add a folder to your library', Path.home())
        if not folder:
            return {'cancelled': True}
        folder = str(Path(folder))   # drops the trailing slash macOS adds
        with lock:
            cfg = load_config()
            if folder not in cfg['folders']:
                cfg['folders'].append(folder)
                save_config(cfg)
        return library()
    if path == '/api/library/remove-folder':
        with lock:
            cfg = load_config()
            cfg['folders'] = [f for f in cfg['folders'] if f != req.get('path')]
            save_config(cfg)
        return library()
    if path == '/api/reveal':
        p = diagram_path(req.get('path'))
        if not p.is_file():
            raise ValueError('That file no longer exists')
        reveal(p)
        return {'ok': True}
    if path in ('/api/export', '/api/export-png'):
        kind = req.get('kind', 'png')
        if kind not in EXPORT_FILTERS:
            raise ValueError('Unknown export type')
        p = dialog('Export ' + ('PNG' if kind == 'png' else 'outline'), save=True, suggested=req.get('suggested'), kind=kind)
        if not p:
            return {'cancelled': True}
        write_atomic(p, base64.b64decode(req['data']))
        return info(p)
    if path == '/api/about':
        return about()
    if path == '/api/install':
        return {'message': install()}
    if path == '/api/update/check':
        return check_update()
    if path == '/api/update/apply':
        return apply_update()
    raise LookupError('unknown endpoint')


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def host_ok(self):
        # Blocks DNS-rebinding: the page must be addressed as localhost.
        return self.headers.get('Host') in (f'127.0.0.1:{PORT}', f'localhost:{PORT}')

    def send(self, code, body, ctype='application/json'):
        data = body if isinstance(body, bytes) else json.dumps(body).encode()
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        global last_seen
        if not self.host_ok():
            return self.send(403, {'error': 'forbidden'})
        if self.path.startswith('/api/alive?'):
            return self.alive()
        if self.path.split('?')[0] not in ('/', '/index.html'):
            return self.send(404, {'error': 'not found'})
        last_seen = time.time()
        html = app_html()
        html = html.replace('<!--spider-host-->', f'<script>window.SPIDER_HOST = {json.dumps({"token": TOKEN})};</script>', 1)
        self.send(200, html.encode(), 'text/html; charset=utf-8')

    def alive(self):
        """Each open tab keeps this connection open. Closing the tab (or the browser) drops it, which is
        how the launcher knows when nothing is using it any more, whatever the browser."""
        global live, closed_at
        if parse_qs(urlsplit(self.path).query).get('token') != [TOKEN]:
            return self.send(403, {'error': 'forbidden'})
        self.send_response(200)
        self.send_header('Content-Type', 'text/event-stream')
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        with lock:
            live += 1
        try:
            while True:
                self.wfile.write(b': still here\n\n')
                self.wfile.flush()
                time.sleep(1)
        except OSError:
            pass
        finally:
            with lock:
                live -= 1
                if not live:
                    closed_at = time.time()

    def do_POST(self):
        global last_seen
        if not self.host_ok():
            return self.send(403, {'error': 'forbidden'})
        if self.headers.get('X-Spider-Token') != TOKEN:
            return self.send(403, {'error': 'forbidden'})
        last_seen = time.time()
        try:
            req = json.loads(self.rfile.read(int(self.headers.get('Content-Length') or 0)) or b'{}')
            self.send(200, route(self.path, req))
        except LookupError as e:
            self.send(404, {'error': str(e)})
        except Exception as e:
            self.send(500, {'error': str(e)})


def unpack(blob, text=True):
    data = zlib.decompress(base64.b64decode(''.join(blob)))
    return data.decode('utf-8') if text else data


def app_html():
    return unpack(EMBEDDED_HTML) if EMBEDDED_HTML else (HERE / 'index.html').read_text(encoding='utf-8')


# ---------- Linux desktop integration ----------

DATA = Path(os.environ.get('XDG_DATA_HOME') or Path.home() / '.local' / 'share')
INSTALLED = {
    'program': Path.home() / '.local' / 'bin' / 'spider-diagram',
    'desktop': DATA / 'applications' / 'spider-diagram.desktop',
    'mime': DATA / 'mime' / 'packages' / 'spider-diagram.xml',
    'icon': DATA / 'icons' / 'hicolor' / 'scalable' / 'apps' / 'spider-diagram.svg',
    'mime-icon': DATA / 'icons' / 'hicolor' / 'scalable' / 'mimetypes' / 'application-x-spider-diagram.svg',
}
MIME_XML = """<?xml version="1.0" encoding="UTF-8"?>
<mime-info xmlns="http://www.freedesktop.org/standards/shared-mime-info">
  <mime-type type="application/x-spider-diagram">
    <comment>Spider diagram</comment>
    <sub-class-of type="application/json"/>
    <icon name="application-x-spider-diagram"/>
    <glob pattern="*.spider" weight="80"/>
  </mime-type>
</mime-info>
"""


def refresh_desktop_caches():
    for cmd in (['update-mime-database', str(DATA / 'mime')], ['update-desktop-database', str(DATA / 'applications')],
                ['kbuildsycoca6'], ['kbuildsycoca5']):
        if shutil.which(cmd[0]):
            subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def install():
    if SYSTEM == 'Windows':
        return windows_install()
    if SYSTEM != 'Linux':
        raise RuntimeError('Installing is for Linux and Windows. On a Mac, just double-click spider-diagram-mac.command.')
    me, prog = Path(__file__).resolve(), INSTALLED['program']
    for p in INSTALLED.values():
        p.parent.mkdir(parents=True, exist_ok=True)
    if me != prog:
        shutil.copyfile(me, prog)
    prog.chmod(0o755)
    icon = unpack(EMBEDDED_ICON) if EMBEDDED_ICON else (HERE / 'icon.svg').read_text(encoding='utf-8')
    INSTALLED['icon'].write_text(icon, encoding='utf-8')
    INSTALLED['mime-icon'].write_text(icon, encoding='utf-8')
    # Some launchers skip an icon folder that has no index.theme; borrow the system one.
    theme = DATA / 'icons' / 'hicolor' / 'index.theme'
    if not theme.exists() and Path('/usr/share/icons/hicolor/index.theme').exists():
        theme.symlink_to('/usr/share/icons/hicolor/index.theme')
    INSTALLED['mime'].write_text(MIME_XML, encoding='utf-8')
    INSTALLED['desktop'].write_text(f"""[Desktop Entry]
Type=Application
Name=Spider Diagram
GenericName=Mind map editor
Comment=Create spider diagrams and export them as pictures or documents
Exec="{prog}" %f
Icon=spider-diagram
Terminal=false
Categories=Office;
MimeType=application/x-spider-diagram;
Keywords=mind map;mindmap;spider;diagram;brainstorm;notes;
StartupNotify=false
""", encoding='utf-8')
    refresh_desktop_caches()
    if shutil.which('xdg-mime'):
        subprocess.run(['xdg-mime', 'default', 'spider-diagram.desktop', 'application/x-spider-diagram'])
    return (f'Installed. Spider Diagram is in your app menu, .spider files open with it, and the program\n'
            f'itself is at {prog}. Remove it again with:  spider-diagram --uninstall')


# ---------- Windows: Start menu shortcut and .spider file type (current user only, no admin needed) ----------

WIN_APP_DIR = Path(os.environ.get('LOCALAPPDATA') or Path.home() / 'AppData' / 'Local') / 'Programs' / 'Spider Diagram'
WIN_SHORTCUT = Path(os.environ.get('APPDATA') or Path.home() / 'AppData' / 'Roaming') / 'Microsoft' / 'Windows' / 'Start Menu' / 'Programs' / 'Spider Diagram.lnk'
WIN_CLASSES = r'Software\Classes'
WIN_KEYS = [r'.spider', r'SpiderDiagram.File\shell\open\command', r'SpiderDiagram.File\shell\open',
            r'SpiderDiagram.File\shell', r'SpiderDiagram.File\DefaultIcon', r'SpiderDiagram.File']   # deepest first


def windows_refresh_icons():
    try:
        import ctypes
        ctypes.windll.shell32.SHChangeNotify(0x08000000, 0, None, None)   # SHCNE_ASSOCCHANGED
    except Exception:
        pass


def windows_install():
    import winreg
    WIN_APP_DIR.mkdir(parents=True, exist_ok=True)
    prog, ico, me = WIN_APP_DIR / 'Spider Diagram.cmd', WIN_APP_DIR / 'spider-diagram.ico', Path(__file__).resolve()
    if me != prog:
        shutil.copyfile(me, prog)
    ico.write_bytes(unpack(EMBEDDED_ICO, text=False) if EMBEDDED_ICO else (HERE / 'icon.ico').read_bytes())
    # Start menu shortcut, starting minimised: the app itself lives in your browser.
    script = ('$s = (New-Object -ComObject WScript.Shell).CreateShortcut($env:SD_LINK); $s.TargetPath = $env:SD_PROG; '
              '$s.IconLocation = $env:SD_ICON; $s.WindowStyle = 7; $s.Description = "Spider Diagram"; $s.Save()')
    WIN_SHORTCUT.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(['powershell', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script], check=True,
                   env={**os.environ, 'SD_LINK': str(WIN_SHORTCUT), 'SD_PROG': str(prog), 'SD_ICON': str(ico)})
    # .spider files: their own icon, and double-click opens them in Spider Diagram.
    values = {r'.spider': 'SpiderDiagram.File', r'SpiderDiagram.File': 'Spider diagram',
              r'SpiderDiagram.File\DefaultIcon': f'"{ico}"', r'SpiderDiagram.File\shell\open\command': f'"{prog}" "%1"'}
    for key, value in values.items():
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, WIN_CLASSES + '\\' + key) as k:
            winreg.SetValueEx(k, '', 0, winreg.REG_SZ, value)
    windows_refresh_icons()
    return ('Installed. Spider Diagram is in your Start menu and .spider files open with it.\n'
            f'The program itself is in {WIN_APP_DIR}. Remove it again with:  "{prog}" --uninstall')


def windows_uninstall():
    import winreg
    for key in WIN_KEYS:
        try:
            winreg.DeleteKey(winreg.HKEY_CURRENT_USER, WIN_CLASSES + '\\' + key)
        except OSError:
            pass
    WIN_SHORTCUT.unlink(missing_ok=True)
    (WIN_APP_DIR / 'spider-diagram.ico').unlink(missing_ok=True)
    windows_refresh_icons()
    # The program file may be the one running right now, so it's left for Windows to tidy away.
    print(f'Removed Spider Diagram from your Start menu and file types. You can delete {WIN_APP_DIR} too.\n'
          'Your diagrams and library settings are untouched.')


def uninstall():
    if SYSTEM == 'Windows':
        return windows_uninstall()
    for p in INSTALLED.values():
        p.unlink(missing_ok=True)
    refresh_desktop_caches()
    print('Removed Spider Diagram from your app menu. Your diagrams and library settings are untouched.')


# ---------- installing from the app, and updates ----------

def installed_program():
    return WIN_APP_DIR / 'Spider Diagram.cmd' if SYSTEM == 'Windows' else INSTALLED['program']


def shown_version():
    """The version to show. The source folder counts as a release when it's exactly the last published
    version (checked out at the release commit, with nothing changed since); otherwise it's 'dev'."""
    if EMBEDDED_HTML is not None or VERSION != 'dev':
        return VERSION
    try:
        git = lambda *a: subprocess.run(['git', '-C', str(HERE), *a], capture_output=True, text=True, timeout=5).stdout.strip()
        released = json.loads((HERE / 'dist' / 'version.json').read_text())['version']
        if git('rev-parse', 'HEAD') == git('log', '-1', '--format=%H', '--', 'dist/version.json') and not git('status', '--porcelain'):
            return released
    except Exception:
        pass
    return 'dev'


def about():
    packed = EMBEDDED_HTML is not None   # a built single-file copy (not the source folder)
    return {'version': shown_version(), 'system': SYSTEM, 'updates': bool(UPDATE_URL) and packed,
            'canInstall': packed and SYSTEM in ('Linux', 'Windows'),
            'installed': Path(__file__).resolve() == installed_program()}


def fetch(url, limit=20_000_000):
    with urlopen(Request(url, headers={'User-Agent': 'Spider Diagram/' + VERSION, 'Cache-Control': 'no-cache'}), timeout=20) as r:
        return r.read(limit)


def latest():
    return json.loads(fetch(UPDATE_URL + 'version.json?t=' + str(int(time.time())), 100_000))


def check_update():
    if not about()['updates']:
        return {'available': False}
    info = latest()
    return {'available': str(info.get('version', '')) > VERSION, 'version': info.get('version'), 'current': VERSION,
            'summary': str(info.get('summary', ''))}


RESTART = False


def apply_update():
    """Download the newest build for this computer, check it, and put it in place of this program."""
    global RESTART
    if not about()['updates']:
        raise RuntimeError('Updates are not set up for this copy')
    info = latest()
    name = 'spider-diagram-windows.cmd' if SYSTEM == 'Windows' else 'spider-diagram-linux'   # Mac uses the Linux file
    data = fetch(UPDATE_URL + name + '?v=' + str(info['version']))
    if hashlib.sha256(data).hexdigest() != info['sha256'][name]:
        raise RuntimeError('The download was damaged; nothing was changed. Try again later')
    if b'Spider Diagram launcher.' not in data[:4000]:
        raise RuntimeError("That download doesn't look like Spider Diagram; nothing was changed")
    me = Path(__file__).resolve()
    mode = me.stat().st_mode
    write_atomic(me, data)
    if SYSTEM != 'Windows':
        me.chmod(mode | 0o755)
    RESTART = True
    threading.Thread(target=lambda: (time.sleep(0.5), SERVER.shutdown()), daemon=True).start()
    return {'version': info['version']}


def restart():
    """Start the freshly updated program in place of this one (no new browser tab: the page reloads itself)."""
    me = str(Path(__file__).resolve())
    if SYSTEM == 'Windows':
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = 7   # minimised, like the Start menu shortcut
        subprocess.Popen([sys.executable, '-x', me, '--no-browser'], creationflags=subprocess.CREATE_NEW_CONSOLE, startupinfo=si)
    else:
        os.execv(sys.executable, [sys.executable, me, '--no-browser'])


SERVER = None


def main():
    global SERVER
    args = sys.argv[1:]
    browser = '--no-browser' not in args
    args = [a for a in args if a != '--no-browser']
    if args and args[0] in ('-h', '--help'):
        return print(__doc__)
    if args and args[0] == '--install':
        try:
            return print(install())
        except RuntimeError as e:
            sys.exit(str(e))
    if args and args[0] == '--uninstall':
        return uninstall()
    url = f'http://127.0.0.1:{PORT}/'
    if args:
        url += '#open=' + quote(str(Path(args[0]).expanduser().resolve()))
    for attempt in range(1 if browser else 40):   # after an update, the old copy may still be letting go of the port
        try:
            server = SERVER = ThreadingHTTPServer(('127.0.0.1', PORT), Handler)
            break
        except OSError:
            time.sleep(0.25)
    else:
        # Already running (e.g. another window): just open another tab on it.
        if browser:
            webbrowser.open(url)
        return

    def watchdog():
        # Stops a few seconds after the last tab closes (a reload is back well within that). A tab from
        # an older version, without the connection, just checks in now and then: then it's IDLE_EXIT.
        global last_seen
        before = time.time()
        while True:
            time.sleep(1)
            now = time.time()
            if now - before > 20:   # the computer was asleep: give the tabs a chance to reconnect
                last_seen = now
            before = now
            if live:
                continue
            if (closed_at is not None and now - closed_at > 3 and last_seen < closed_at) or now - last_seen > IDLE_EXIT:
                server.shutdown()
                return

    threading.Thread(target=watchdog, daemon=True).start()
    print(f'Spider Diagram is running at {url}\nYou can minimise this window. It stops by itself a few seconds '
          'after you close the browser tab.')
    if browser:
        def open_tab():
            # A tab left open from last time reconnects by itself within a second or two: then use that
            # one rather than opening another. (Opening a file always gets a tab to open it in.)
            if not args:
                for _ in range(30):
                    time.sleep(0.1)
                    if live:
                        return
            webbrowser.open(url)
        threading.Thread(target=open_tab, daemon=True).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    server.server_close()
    if RESTART:
        restart()


if __name__ == '__main__':
    main()
